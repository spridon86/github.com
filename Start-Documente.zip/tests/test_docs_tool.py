"""Documente client: firmele din NWCE (una pe firma), clientul pentru evaluare, generarea (raport nou / scorecard
inlocuit) si fereastra. Fara retea / Excel / SAP."""
import datetime as dt
import os

import pytest

from creditapp import docs_tool, limits_book as lb, pipeline
from creditapp.portfolio import Counterparty


def _snap():
    def row(sr, comp, code, name, vat, tbd='TBD by IS', status='UNDER REVIEW'):
        return lb.NwceRow(sr, {'status': status, 'company_code': comp, 'customer_code': float(code) if code else 0.0, 'name': name,
                               'vat': vat, 'tbd_by': tbd, 'grading': 8.0, 'open_kloc': 100.0,
                               'valid_till': lb.to_serial(dt.date.today() + dt.timedelta(days=20))})
    rows = [row(10, '7425 - Spain', 74012187, 'CASA OLEARIA ITALIANA S.P.A', 'IT01458780747'),
            row(11, '6675 - Italy', 74012187, 'CASA OLEARIA ITALIANA S.P.A', 'IT01458780747'),
            row(12, '6675 - Italy', 76019551, 'M.B. MANGIMI S.P.A.', 'IT00139950406', tbd='TBD by AR'),
            row(13, '6675 - Italy', 76000009, 'FIRMA INACTIVA SRL', 'IT00000000099', status='INACTIVE')]
    return lb.Snapshot(rows, {}, dt.datetime.now(), 'test').index('IT')


def test_one_firm_per_client_with_all_companies(cfg):
    firms = {f.name: f for f in docs_tool.firms_from_nwce(_snap(), cfg)}
    casa = firms['CASA OLEARIA ITALIANA S.P.A']
    assert casa.companies == ['6675', '7425'] and casa.rep.company_code == '6675 - Italy'     # randul companiei din Setari
    assert casa.owners == {'IS'} and casa.customer_code == '74012187' and not casa.inactive
    assert firms['FIRMA INACTIVA SRL'].inactive and len(firms) == 3


def test_counterparty_from_open_contracts_or_nwce(cfg):
    firms = {f.name: f for f in docs_tool.firms_from_nwce(_snap(), cfg)}

    class Pf:
        counterparties = {'74012187': Counterparty(partner='74012187', name='CASA OLEARIA ITALIANA S.P.A')}
    assert docs_tool.counterparty_for(firms['CASA OLEARIA ITALIANA S.P.A'], Pf(), cfg) is Pf.counterparties['74012187']
    cp = docs_tool.counterparty_for(firms['M.B. MANGIMI S.P.A.'], Pf(), cfg)       # nu e in Open Contracts -> din NWCE
    assert cp.source == 'nwce' and cp.customer_code == '76019551' and cp.partner.startswith('76019551@6675')


def test_generate_always_scorecard_replaces_old_and_new_report_on_request(monkeypatch):
    seen = {}
    monkeypatch.setattr(pipeline, 'evaluate_all', lambda ctx, preps, cps, overrides, on_done=None: seen.update(overrides) or [])
    cps = {'A': Counterparty(partner='A', name='X')}
    docs_tool.generate(None, [], cps, force_refresh=True)
    assert seen['A'] == {'force_refresh': True, 'replace_scorecard': True}         # fara "skip_scorecard": scorecard mereu
    docs_tool.generate(None, [], cps, force_refresh=False)
    assert seen['A']['force_refresh'] is False


def test_confirmation_and_result_texts():
    ok = pipeline.Evaluation(partner='A', name='X')
    ok.state = 'prepared'
    amb = pipeline.Evaluation(partner='B', name='Y')
    amb.state, amb.warnings = 'prepared', ['Creditsafe a gasit 4 firme pentru IT1, niciuna inregistrata (Registered) - s-a ales Z.']
    assert not docs_tool.needs_confirmation([ok]) and docs_tool.needs_confirmation([ok, amb])
    done = pipeline.Evaluation(partner='A', name='X')
    done.state, done.files, done.scorecard = 'evaluated', {'scorecard': 'S.xlsx', 'pdf': 'R.pdf'}, {'grade': 8}
    assert docs_tool.result_chip(done) == ('Gata · PDF + scorecard (grade 8)', 'ok')
    done.state = 'evaluated_manual'
    assert docs_tool.result_chip(done)[1] == 'warn'
    done.state, done.error = 'error', {'title': 'Firma nu a fost gasita in Creditsafe'}
    assert docs_tool.result_chip(done) == ('Eroare: Firma nu a fost gasita in Creditsafe', 'bad')


def test_window_lists_my_clients_and_one_button(cfg, monkeypatch, tmp_path):
    os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
    QtWidgets = pytest.importorskip('PyQt5.QtWidgets')
    app = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    assert app is not None
    from creditapp import audit, creditsafe_web

    class NoCs:
        def close(self):
            pass
    real_db = audit.AuditDB
    monkeypatch.setattr(audit, 'AuditDB', lambda path=None: real_db(tmp_path / 'd.db'))     # nu data\documente.db
    monkeypatch.setattr(creditsafe_web, 'make_client', lambda c: NoCs())
    win = docs_tool._ui()(cfg, autoload=False)
    win.snap = _snap()
    win.model.load(docs_tool.firms_from_nwce(win.snap, cfg))
    win._fill_lists()
    assert win.f_list.currentText() == 'Lista mea (IS)' and win.proxy.rowCount() == 1        # doar CASA OLEARIA (lista mea)
    assert win.act.text() == 'Bifează clienții' and not win.act.isEnabled()
    win.f_list.setCurrentIndex(win.f_list.findData(None))                                    # toti clientii din NWCE
    assert win.proxy.rowCount() == 2                                                         # fara cel inactiv
    win.chk_inactive.setChecked(True)
    assert win.proxy.rowCount() == 3
    win.model.firms[0].checked = True
    win._update_count()
    assert win.act.text() == 'Generează PDF + scorecard (1)' and win.act.isEnabled()
    assert not win.chk_ar.isChecked()                                                         # Annual Review doar la cerere
    win.chk_ar.setChecked(True)
    assert win.act.text() == 'Generează PDF + scorecard + Annual Review (1)'
    win.db.close()


def test_annual_review_option_per_client_and_errors_do_not_stop_the_rest(cfg, monkeypatch):
    from creditapp import annual_review
    firms = {f.name: f for f in docs_tool.firms_from_nwce(_snap(), cfg)}
    casa, mb = firms['CASA OLEARIA ITALIANA S.P.A'], firms['M.B. MANGIMI S.P.A.']
    assert [r.company_code for r in docs_tool.active_rows(casa)] == ['6675 - Italy', '7425 - Spain']    # ambele companii

    def ev(partner, state='evaluated'):
        e = pipeline.Evaluation(partner=partner, name=partner)
        e.state, e.files, e.scorecard = state, {'scorecard': 'S.xlsx', 'pdf': 'R.pdf'}, {'grade': 8}
        return e
    seen = []

    def fake_renewal(cfg_, rows, cp, e, title, inv=None, replace=True):
        if title.startswith('M.B.'):
            raise RuntimeError('Word blocat')
        seen.append((title, len(rows), replace))
        return f'Annual Review {title} 2026.docx'
    monkeypatch.setattr(annual_review, 'renewal', fake_renewal)
    results = [ev('A'), ev('B'), ev('C', 'error')]
    cps = {'A': Counterparty(partner='A', name='CASA'), 'B': Counterparty(partner='B', name='MB'), 'C': Counterparty(partner='C', name='X')}
    docs_tool.annual_reviews(cfg, results, {'A': casa, 'B': mb, 'C': casa}, cps)
    assert seen == [('CASA OLEARIA ITALIANA S.P.A', 2, True)]                   # clientul cu eroare la Creditsafe e sarit
    assert docs_tool.result_chip(results[0]) == ('Gata · PDF + scorecard + Annual Review (grade 8)', 'ok')
    assert docs_tool.result_chip(results[1])[1] == 'warn' and 'Annual Review' in docs_tool.result_chip(results[1])[0]


def _done_ev(partner='A', scorecard='S.xlsx'):
    e = pipeline.Evaluation(partner=partner, name=partner)
    e.state, e.files, e.scorecard = 'evaluated', {'scorecard': scorecard, 'pdf': 'R.pdf'}, {'grade': '6', 'points': '250'}
    e.inputs = {'experience': {'grade': 'E', 'proposed': 'E', 'why': 'Nicio urma a relatiei.'},
                'payment': {'grade': 'C', 'proposed': 'C', 'why': 'Plati: Fara istoric.'}, 'financial_reporting': 'Average'}
    return e


def test_subjective_change_writes_scorecard_and_only_then_updates(monkeypatch):
    from creditapp import scorecard_live
    calls = []

    class FakeLive:
        fail = False

        def __init__(self, path, excel=None):
            calls.append(('open', path))

        def set(self, **v):
            if FakeLive.fail:
                raise RuntimeError('Excel busy')
            calls.append(('set', v))
            return {'grade': '5', 'scale': 'Middle Market', 'points': '265', 'criteria': {}, 'equity_usd': 1234567.0}

        def save(self):
            calls.append(('save',))

        def close(self):
            calls.append(('close',))
    monkeypatch.setattr(scorecard_live, 'LiveScorecard', FakeLive)
    ev = _done_ev()
    ev.files['annual_review'] = 'AR.docx'
    assert docs_tool.can_edit(ev) and docs_tool.criterion(ev, 'experience') == 'E'
    old, res = docs_tool.set_criterion(ev, 'experience', 'A')
    assert old == '6' and ev.grade == 5 and calls == [('open', 'S.xlsx'), ('set', {'experience': 'A'}), ('save',), ('close',)]
    assert ev.inputs['experience'] == {'grade': 'A', 'proposed': 'E', 'why': 'Nicio urma a relatiei.', 'manual': True}
    assert docs_tool.choices(ev) == {'experience': 'A'} and ev.scorecard['equity_usd'] == '1,234,567'
    assert docs_tool.result_chip(ev) == ('Grade 5 · Annual Review de refăcut (click-dreapta)', 'warn')   # Word-ul are grade-ul vechi
    FakeLive.fail = True
    with pytest.raises(RuntimeError):
        docs_tool.set_criterion(ev, 'payment', 'A')
    assert ev.inputs['payment']['grade'] == 'C' and ev.grade == 5 and docs_tool.choices(ev) == {'experience': 'A'}   # neschimbat
    assert calls[-1] == ('close',)                                                         # Excel inchis si la eroare
    ev.state = 'evaluated_manual'
    assert not docs_tool.can_edit(ev) and not docs_tool.can_edit(None)


def test_regenerate_keeps_my_subjective_choices(monkeypatch):
    seen = {}
    monkeypatch.setattr(pipeline, 'evaluate_all', lambda ctx, preps, cps, overrides, on_done=None: seen.update(overrides) or [])
    cps = {'A': Counterparty(partner='A', name='X'), 'B': Counterparty(partner='B', name='Y')}
    docs_tool.generate(None, [], cps, force_refresh=False, chosen={'A': {'payment': 'B', 'financial_reporting': 'Best'}})
    assert seen['A'] == {'payment': 'B', 'financial_reporting': 'Best', 'force_refresh': False, 'replace_scorecard': True}
    assert seen['B'] == {'force_refresh': False, 'replace_scorecard': True}


def test_previous_documents_are_shown_after_restart(cfg, tmp_path):
    firms = docs_tool.firms_from_nwce(_snap(), cfg)
    by_name = {f.name: f for f in firms}
    sc = tmp_path / 'Scorecard CASA.xlsx'
    sc.write_bytes(b'x')
    old = _done_ev('74012187@6675#99', str(sc))           # randul NWCE s-a mutat intre timp: se gaseste dupa Customer Code
    old.created = '2026-01-15T10:00:00'
    gone = _done_ev('76019551@6675#12', str(tmp_path / 'sters.xlsx'))
    err = pipeline.Evaluation(partner='76000009@6675#13', name='X')
    err.state = 'error'
    latest = {old.partner: (5, old.created, old.state, old.to_dict()), gone.partner: (6, '', gone.state, gone.to_dict()),
              err.partner: (7, '', 'error', err.to_dict())}
    docs_tool.attach_previous(firms, latest, None, cfg)
    casa, mb = by_name['CASA OLEARIA ITALIANA S.P.A'], by_name['M.B. MANGIMI S.P.A.']
    assert casa.ev.partner == old.partner and docs_tool.can_edit(casa.ev)
    assert docs_tool.result_chip(casa.ev) == ('Gata · PDF + scorecard (grade 6) · 15.01.2026', 'ok')
    assert mb.ev is not None and not docs_tool.can_edit(mb.ev)                      # scorecardul sters: fara editare
    assert by_name['FIRMA INACTIVA SRL'].ev is None                                  # erorile vechi nu se arata


def test_window_subjective_columns_editable_only_with_scorecard(cfg, monkeypatch, tmp_path):
    os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
    QtWidgets = pytest.importorskip('PyQt5.QtWidgets')
    from PyQt5.QtCore import Qt
    app = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    assert app is not None
    from creditapp import audit, creditsafe_web

    class NoCs:
        def close(self):
            pass
    real_db = audit.AuditDB
    monkeypatch.setattr(audit, 'AuditDB', lambda path=None: real_db(tmp_path / 'd.db'))
    monkeypatch.setattr(creditsafe_web, 'make_client', lambda c: NoCs())
    win = docs_tool._ui()(cfg, autoload=False)
    firms = docs_tool.firms_from_nwce(_snap(), cfg)
    firms[0].ev = _done_ev()
    win.model.load(firms)
    m = win.model
    cols = [m.headerData(i, Qt.Horizontal) for i in range(m.columnCount())]
    fin, exp, pay, new = (cols.index(c) for c in ('Subiective|9. Fin. reporting', 'Subiective|10. Experience',
                                                  'Subiective|11. Payments', 'Grade|Nou'))
    assert m.data(m.index(0, exp)) == 'E ?' and m.data(m.index(0, pay)) == 'C ?' and m.data(m.index(0, fin)) == 'Average'
    assert m.data(m.index(0, exp), Qt.EditRole) == 'E' and m.data(m.index(0, new)) == 6
    assert m.flags(m.index(0, exp)) & Qt.ItemIsEditable and not m.flags(m.index(1, exp)) & Qt.ItemIsEditable
    got = []
    monkeypatch.setattr(docs_tool, 'set_criterion', lambda ev, crit, value, excel=None: got.append((crit, value)) or ('6', {'grade': '4'}))
    monkeypatch.setattr(win, '_shared_excel', lambda: None)
    assert m.setData(m.index(0, pay), 'A', Qt.EditRole) and got == [('payment', 'A')]
    m.locked = True                                                                    # in timpul generarii
    assert not m.flags(m.index(0, pay)) & Qt.ItemIsEditable and not m.setData(m.index(0, pay), 'B', Qt.EditRole)
    win.db.close()
