"""Revizuirea lunara: expirare, expunerea din luna urmatoare, activitate (facturi), limita noua vs autoritate."""
import datetime as dt

from creditapp import invoices, limits_book as lb, review
from creditapp.pipeline import Evaluation
from creditapp.portfolio import Counterparty, PaymentBehaviour

TODAY = dt.date(2026, 10, 17)


def test_month_labels():
    assert review.next_month(TODAY) == dt.date(2026, 11, 1)
    assert review.month_label(review.next_month(TODAY)) == 'NOV 26'
    assert review.next_month(dt.date(2026, 12, 5)) == dt.date(2027, 1, 1)


def test_expiring():
    row = lambda st, vt: lb.NwceRow(1, {'status': st, 'valid_till': lb.to_serial(vt) if vt else None})
    assert review.expiring(row('UNDER REVIEW', dt.date(2026, 10, 31)), TODAY)
    assert review.expiring(row('APPROVED', dt.date(2026, 9, 30)), TODAY)            # expirat deja
    assert not review.expiring(row('APPROVED', dt.date(2026, 11, 30)), TODAY)       # luna viitoare
    assert not review.expiring(row('INACTIVE', None), TODAY)
    assert not review.expiring(row('CBT', dt.date(2026, 10, 31)), TODAY)
    assert not review.expiring(None, TODAY)


def test_exposure_is_peak_from_next_week_to_the_end():
    # TODAY = 17.10.2026 = saptamana ISO 42: W42 (curenta) si trecutul nu conteaza
    cp = Counterparty(partner='1', name='X', monthly={'OCT 26': 900, 'NOV 26': 500_000},
                      weekly={'W37 SEP26': 2_000_000, 'W42 OCT26': 1_500_000, 'W43 OCT26': 300_000,
                              'W45 NOV26': 610_000, 'W49 DEC26': 999_999, 'W02 JAN27': 50_000})
    assert review.next_month_exposure(cp, TODAY) == (999_999, 'W49 DEC26')
    assert review.next_month_exposure(Counterparty(partner='2', name='Y'), TODAY) == (0.0, '')
    # fara expunere saptamanala: lunile de dupa luna curenta
    cpm = Counterparty(partner='3', name='Z', monthly={'OCT 26': 9_000_000, 'NOV 26': 500_000, 'JAN 27': 700_000})
    assert review.next_month_exposure(cpm, TODAY) == (700_000, 'JAN 27')


def test_week_key_year_boundaries():
    from creditapp.portfolio import week_key
    assert week_key('W45 NOV26') == (2026, 45)
    assert week_key('W01 DEC26') == (2027, 1)
    assert week_key('W53 JAN27') == (2026, 53)
    assert week_key('OCT 26') is None


FRESH = dt.date.today().isoformat()      # fisierul de facturi actualizat (are facturi recente)


def test_activity_by_invoices():
    data = {'by_account': {'76021671': [12, '2025-11-03', '2019-01-01'], '76000001': [3, '2022-01-10', '2021-01-01']},
            'by_vat': {'IT09999999999': [1, '2026-02-01', '2026-02-01']}, 'latest': FRESH}
    cp = Counterparty(partner='76021671', name='A', vat='IT01491571210')
    assert review.activity(cp, 0, data)[0] is True
    assert review.activity(Counterparty(partner='76000001', name='B'), 0, data)[0] is False      # ultima factura > 2 ani
    assert review.activity(Counterparty(partner='7', name='C', vat='09999999999'), 0, data)[0] is True   # dupa VAT
    assert review.activity(Counterparty(partner='8', name='D'), 5, data) == (True, 'expunere in saptamanile viitoare')
    has, why = invoices.recent_activity(data, '76000001', '', 24, TODAY)
    assert not has and '10.01.2022' in why


def test_no_auto_inactivation_when_invoices_missing_empty_or_stale():
    coded = Counterparty(partner='76000009', name='FIRMA INACTIVA SRL')
    # fisier necitit / gol: lipsa facturilor nu dovedeste inactivitatea
    assert review.activity(coded, 0, None)[0] is None
    assert review.activity(coded, 0, {'by_account': {}, 'by_vat': {}})[0] is None
    # fisier neactualizat (cea mai noua factura de acum un an): nu se decide pe el
    old = {'by_account': {'76000001': [3, '2025-10-01', '2021-01-01']}, 'by_vat': {}}
    act, why = review.activity(coded, 0, old)
    assert act is None and 'neactualizat' in why
    # fisier actualizat, clientul fara facturi -> inactiv
    fresh = {'by_account': {'76000001': [3, FRESH, '2021-01-01']}, 'by_vat': {}}
    assert review.activity(coded, 0, fresh)[0] is False


def test_never_inactivate_without_customer_code_or_when_in_open_contracts():
    data = {'by_account': {'1': [1, FRESH, FRESH]}, 'by_vat': {}}
    nwce_cp = Counterparty(partner='NWCE@6675#93', name='AGRINORD S.A.S. DI COMMERCIALE VENETA S.R.L.', vat='IT01229150931',
                           source='nwce')
    act, why = review.activity(nwce_cp, 0, data)
    assert act is None and 'Customer Code' in why                       # fara cod: nu se inactiveaza automat

    class P:
        counterparties = {'76020872': Counterparty(partner='76020872', name='AGRINORD SAS DI COMMERCIALE', limit=100_000)}
    act, why = review.activity(nwce_cp, 0, data, portfolio=P())
    assert act is True and '76020872' in why                            # gasit in Open Contracts dupa nume
    coded = Counterparty(partner='76000009', name='FIRMA INACTIVA SRL')
    assert review.activity(coded, 0, data, portfolio=P())[0] is False   # cu cod, fara expunere / facturi / Open Contracts


def test_restore_plan_and_parse():
    from creditapp import pipeline
    ev = Evaluation(partner='X', name='AGRINORD')
    ev.nwce = {'status': 'ok', 'sheet_row': 6514,
               'before': {'payment_term': 'Max. 30 Days', 'mtm_kusd': '100', 'open_kusd': '0', 'approved_on': '04.09.2025',
                          'valid_till': '30.09.2026', 'comments': 'Viterra'},
               'after': {'payment_term': '0', 'mtm_kusd': '0', 'open_kusd': '0', 'approved_on': '', 'valid_till': '',
                         'comments': 'Fara expunere', 'status': 'INACTIVE'}}
    plan = pipeline.restore_plan(ev)
    assert set(plan) == {'payment_term', 'mtm_kusd', 'approved_on', 'valid_till', 'comments'}     # open_kusd neschimbat
    assert pipeline._parse_display('mtm_kusd', '1.250') == 1250.0 and pipeline._parse_display('mtm_kusd', '12,5') == 12.5
    assert pipeline._parse_display('valid_till', '30.09.2026') == dt.date(2026, 9, 30)
    assert pipeline._parse_display('payment_term', 'Max. 30 Days') == 'Max. 30 Days'
    assert pipeline._parse_display('comments', '') is None


def _ev(grade=5, open_kloc=800.0, open_kusd=900.0, mtm=200.0, total=1100.0, equity_usd='13,611,765'):
    ev = Evaluation(partner='76021671', name='MIRA SUD')
    ev.scorecard = {'grade': str(grade), 'equity_usd': equity_usd}
    ev.nwce_row = {'sheet_row': 10, 'values': {'open_kloc': open_kloc, 'open_kusd': open_kusd, 'mtm_kusd': mtm, 'total_kusd': total,
                                                'payment_term': 'Max. 30 Days'}}
    ev.cs = {'currency': 'EUR', 'equity': 11_570_000}
    return ev


def test_plan_renewal_within_authority(cfg):
    ev = _ev()
    cp = Counterparty(partner='76021671', name='MIRA SUD', limit=800_000)
    rv = review.plan(ev, cp, [], cfg, 1.12, exposure=500_000)
    assert rv['new_open_local'] == 800_000 and 'reinnoieste' in rv['limit_why']
    assert rv['total_usd'] == (900 + 200) * 1000
    assert rv['route'] == 'auto' and rv['authority'] == 'Ionut Spridon'
    assert rv['equity_scenario'] is False
    d = review.auto_decision(ev, rv, cfg, TODAY)
    assert d['valid_till'] == '2027-10-31' and d['grading'] == 5 and d['approval_level'] == 'LOCAL'


def test_plan_exposure_above_limit_escalates(cfg):
    ev = _ev(grade=8)
    cp = Counterparty(partner='76021671', name='MIRA SUD', limit=800_000)
    rv = review.plan(ev, cp, [], cfg, 1.12, exposure=3_100_000)     # grade 8: analistul doar pana la 2.5M USD
    assert rv['new_open_local'] == 3_100_000                   # deja multiplu de 50.000
    assert rv['route'] == 'escalate' and rv['authority'] == 'Valentina / Bea'


def test_no_financials_uses_nwce_grade(cfg):
    ev = _ev()
    ev.scorecard = None                                        # Creditsafe fara bilant -> fara scorecard
    ev.nwce_row['values']['grading'] = 6.0
    rv = review.plan(ev, Counterparty(partner='76021671', name='MIRA SUD', limit=800_000), [], cfg, 1.12, exposure=0)
    assert rv['grade_used'] == 6 and rv['grade_source'] == 'nwce'
    assert rv['route'] == 'auto'                               # 1.1M USD la grade 6 -> in autoritatea analistului
    assert review.auto_decision(ev, rv, cfg, TODAY)['grading'] == 6
    ev.nwce_row['values']['grading'] = None
    assert review.plan(ev, Counterparty(partner='1', name='X'), [], cfg, 1.12, exposure=0)['route'] == 'manual'


def test_scorecard_only_from_350k_usd(cfg):
    vals = {'open_kloc': 200.0, 'open_kusd': 230.0, 'mtm_kusd': 100.0}
    need, total = review.needs_scorecard(vals, 0, cfg, 1.12)        # 200k EUR -> 220 KUSD + 100 KUSD MTM = 320k USD
    assert not need and total == 320_000
    need, total = review.needs_scorecard(vals, 260_000, cfg, 1.12)  # expunerea creste Open la 260k EUR -> 290 KUSD + 100
    assert need and total == 390_000
    assert review.needs_scorecard({'open_kloc': 250.0, 'mtm_kusd': 100.0}, 0, cfg, 1.12)[0]   # 280 + 100 = 380k


def test_intuitive_grade_kept_in_nwce_without_scorecard(cfg):
    ev = _ev()
    ev.scorecard = None
    ev.nwce_row['values']['grading'] = 'Intuitive 9'
    ev.review = {'new_open_local': 800_000, 'mtm_kusd': 200.0}
    dec, auth, rv = review.finalize(ev, cfg, 1.12, 0, TODAY)
    assert dec['grading'] == 'Intuitive 9' and rv['grade_used'] == 9          # NWCE: textul ramane; calculul: 9
    ev.review['edit'] = {'grade': 8}
    assert review.finalize(ev, cfg, 1.12, 0, TODAY)[0]['grading'] == 8         # schimbat manual -> numarul nou
    ev.review['edit'] = {}
    ev.scorecard = {'grade': '7'}
    assert review.finalize(ev, cfg, 1.12, 0, TODAY)[0]['grading'] == 7         # scorecard nou -> numarul


def test_mtm_40pct_of_open_when_current_mtm_is_zero(cfg):
    ev = _ev(open_kloc=100.0, open_kusd=110.0, mtm=0.0, total=110.0)
    cp = Counterparty(partner='76020872', name='AGRINORD', limit=100_000)
    rv = review.plan(ev, cp, [], cfg, 1.12, exposure=182_971)      # Open nou 190.000 EUR -> 210 KUSD (rotunjit la 10)
    assert rv['new_open_local'] == 190_000 and rv['new_open_kusd'] == 210
    assert rv['mtm_kusd'] == 80                                     # 40% din 210 = 84 -> 80 KUSD
    assert rv['total_usd'] == (210 + 80) * 1000 and '40%' in rv['limit_why']
    ev2 = _ev(mtm=150.0)
    assert review.plan(ev2, cp, [], cfg, 1.12, exposure=0)['mtm_kusd'] == 150     # MTM existent: ramane


def test_equity_scenario_flag(cfg):
    ev = _ev(equity_usd='500,000')
    rv = review.plan(ev, Counterparty(partner='1', name='X'), [], cfg, 1.12, exposure=0)
    assert rv['equity_scenario'] is True                       # 1.1M USD > equity 0.5M USD


def test_manual_needed():
    ev = Evaluation(partner='1', name='X')
    ev.inputs = {'payment': {'grade': 'C', 'why': 'Fara istoric in "Payment behaviour report" -> C'},
                 'experience': {'grade': 'E', 'why': 'Nicio urma a relatiei -> E (Nou).'}}
    assert review.manual_needed(ev) == ['payment', 'experience']
    ev.inputs['payment']['manual'] = True
    assert review.manual_needed(ev) == ['experience']
    ev.review = {'manual': {'experience': 'B'}}
    assert review.manual_needed(ev) == []
    assert PaymentBehaviour  # importul folosit de fixture-uri
