"""Client Creditsafe Connect API (acelasi continut ca portalul app.creditsafe.com: raport JSON + PDF).

- Parola: Windows Credential Manager (keyring).
- Rapoartele descarcate se pastreaza in cache (%LOCALAPPDATA%\\CreditLimitsApp\\reports) si se
  refolosesc N zile - un raport consuma credite, cautarea nu.
"""
import datetime as dt
import json
import re
import threading
import time
from pathlib import Path

from . import log, paths
from .errors import AppError
from .http import default as default_http

_log = log.get('creditsafe')
KEYRING_SERVICE = 'CreditLimitsApp/creditsafe-{env}'


# ---------------------------------------------------------------- credentiale
def get_credentials(cfg):
    import keyring
    env = cfg['environment']
    user = (cfg['username'] or '').strip()
    service = KEYRING_SERVICE.format(env=env)
    if user:
        pwd = keyring.get_password(service, user)
        if pwd:
            return user, pwd
    if cfg['password'] and user:
        return user, cfg['password']
    raise AppError('AUTH_MISSING', f'No Creditsafe password saved for {user or "(no user)"} ({env}).')


def save_credentials(cfg, user, password):
    import keyring
    keyring.set_password(KEYRING_SERVICE.format(env=cfg['environment']), user.strip(), password)
    cfg.set(user.strip(), 'username')


def vat_without_prefix(vat, country):
    """Creditsafe pastreaza VAT-ul fara prefixul de tara (IT02555800420 -> 02555800420)."""
    v = re.sub(r'[\s.\-/]', '', str(vat or '')).upper()
    prefixes = [country.upper()]
    if country.upper() == 'GR':
        prefixes.append('EL')
    if country.upper() == 'GB':
        prefixes.append('XI')
    for p in prefixes:
        if v.startswith(p) and len(v) > len(p):
            return v[len(p):]
    return v


def country_of_vat(vat, default=''):
    v = re.sub(r'[^A-Za-z0-9]', '', str(vat or '')).upper()
    if re.match(r'^[A-Z]{2}\d', v):
        p = v[:2]
        return {'EL': 'GR', 'XI': 'GB', 'UK': 'GB'}.get(p, p)
    return default


# ---------------------------------------------------------------- client
class CreditsafeClient:
    def __init__(self, cfg, http=None):
        self.cfg = cfg
        self.http = http or default_http()
        self._token = None
        self._token_expires = 0.0
        self._lock = threading.Lock()

    @property
    def base(self):
        return self.cfg.cs_base_url

    # --- autentificare
    def token(self, force=False):
        with self._lock:
            if self._token and not force and time.time() < self._token_expires:
                return self._token
            user, pwd = get_credentials(self.cfg)
            r = self.http.request('POST', f'{self.base}/authenticate', json_body={'username': user, 'password': pwd}, timeout=40)
            if r.status in (400, 401, 403):
                raise AppError('AUTH', f'Creditsafe rejected user {user} (HTTP {r.status}).', r.text[:300])
            if r.status >= 500:
                raise AppError('CS_SERVER', f'Creditsafe sign-in: HTTP {r.status}', r.text[:300])
            if not r.ok:
                raise AppError('UNKNOWN', f'Creditsafe sign-in: HTTP {r.status}', r.text[:300])
            self._token = r.json()['token']
            self._token_expires = time.time() + 55 * 60   # token valabil 60 min
            return self._token

    def test_login(self):
        self.token(force=True)
        return True

    # --- cerere cu reincercari (429 / 5xx / retea) si reautentificare la 401
    def _call(self, path, params=None, accept='application/json', attempts=4):
        url = f'{self.base}{path}'
        reauth = False
        for attempt in range(1, attempts + 1):
            try:
                r = self.http.request('GET', url, params=params, headers={'Authorization': f'Bearer {self.token()}', 'Accept': accept})
            except OSError as e:   # include erorile requests (RequestException) si WinHTTP
                if attempt < attempts:
                    time.sleep(2 * attempt)
                    continue
                raise AppError('NETWORK', f'Creditsafe could not be reached: {e}')
            if r.ok:
                return r
            if r.status == 401 and not reauth:
                reauth = True
                self.token(force=True)
                continue
            if r.status in (429,) or r.status >= 500:
                if attempt < attempts:
                    time.sleep(3 * attempt)
                    continue
            raise self._http_error(r, path)
        raise AppError('UNKNOWN', f'Creditsafe {path}: no response')

    @staticmethod
    def _http_error(r, path):
        body = r.text[:500]
        if re.search(r'CreditsExceeded', body, re.I):
            return AppError('CREDITS', f'Creditsafe credits used up ({path}).', body)
        if re.search(r'ReportUnavailable|Report unavailable', body, re.I):
            return AppError('REPORT_UNAVAILABLE', f'Creditsafe: report unavailable ({path}).', body)
        code = {401: 'AUTH', 403: 'FORBIDDEN', 404: 'NOT_FOUND', 429: 'RATE_LIMIT'}.get(r.status, 'CS_SERVER' if r.status >= 500 else 'UNKNOWN')
        return AppError(code, f'Creditsafe HTTP {r.status} on {path}.', body)

    # --- cautare (nu consuma credite)
    def search(self, country, vat=None, reg_no=None, name=None, page_size=10):
        params = {'countries': country, 'pageSize': page_size}
        if vat:
            params['vatNo'] = vat_without_prefix(vat, country)
        if reg_no:
            params['regNo'] = reg_no
        if name:
            params['name'] = name
        try:
            r = self._call('/companies', params)
        except AppError as e:
            if e.code in ('NOT_FOUND',) or (e.code == 'UNKNOWN' and 'HTTP 400' in e.message):
                return []
            raise
        return [c for c in (r.json().get('companies') or []) if c]

    def find_by_vat(self, vat, country):
        """Cauta dupa VAT, apoi dupa nr. de inregistrare (in Italia VAT == codice fiscale de cele mai multe ori)."""
        res = self.search(country, vat=vat)
        if not res:
            res = self.search(country, reg_no=vat_without_prefix(vat, country))
        return res

    # --- credite
    def access(self):
        return self._call('/access').json()

    def credits(self, country):
        """(ramase, platite, folosite, expira) pentru rapoartele online ale tarii, sau None."""
        acc = self.access()
        rows = (acc.get('countryAccess') or {}).get('creditsafeConnectOnlineReports') or []
        now = dt.datetime.now()
        paid = used = 0
        expire = None
        found = False
        for r in rows:
            if (r.get('countryIso2') or '').upper() != country.upper():
                continue
            try:
                exp = dt.datetime.fromisoformat(str(r.get('expireDate'))[:19])
            except ValueError:
                exp = None
            if exp and exp < now:
                continue
            found = True
            paid += int(r.get('paid') or 0)
            used += int(r.get('used') or 0)
            expire = exp if expire is None or (exp and exp < expire) else expire
        if not found:
            return None
        return {'left': paid - used, 'paid': paid, 'used': used, 'expires': expire}

    # --- raport (consuma credite) + cache
    @staticmethod
    def cache_dir(connect_id):
        return paths.REPORT_CACHE_DIR / re.sub(r'[^\w\-]', '_', connect_id)

    def cached(self, connect_id, max_days=None):
        """Cel mai recent raport din cache: dict(json_path, pdf_path, fetched) sau None."""
        max_days = self.cfg.get('creditsafe', 'cacheDays', default=30) if max_days is None else max_days
        d = self.cache_dir(connect_id)
        if not d.exists():
            return None
        jsons = sorted(d.glob('*.json'), reverse=True)
        for j in jsons:
            try:
                fetched = dt.datetime.strptime(j.stem, '%Y%m%d_%H%M%S')
            except ValueError:
                continue
            if (dt.datetime.now() - fetched).days > max_days:
                return None
            pdf = j.with_suffix('.pdf')
            return {'json_path': j, 'pdf_path': pdf if pdf.exists() and pdf.stat().st_size > 0 else None, 'fetched': fetched}
        return None

    def fetch_report(self, connect_id, with_pdf=True, use_cache=True):
        """Intoarce dict(report, json_path, pdf_path, fetched, from_cache)."""
        c = self.cached(connect_id) if use_cache else None
        if c and (c['pdf_path'] or not with_pdf):
            return self._load(c, True)
        d = self.cache_dir(connect_id)
        d.mkdir(parents=True, exist_ok=True)
        if c:   # JSON in cache, lipseste doar PDF-ul
            stamp = c['fetched']
            json_path = c['json_path']
        else:
            stamp = dt.datetime.now().replace(microsecond=0)
            json_path = d / f'{stamp:%Y%m%d_%H%M%S}.json'
            lang = self.cfg['reportLanguage']
            r = self._call(f'/companies/{connect_id}', {'language': lang})
            data = r.json()
            if 'report' not in data:
                raise AppError('REPORT_UNAVAILABLE', f'Creditsafe returned no report for {connect_id}.', r.text[:300])
            tmp = json_path.with_suffix('.tmp')
            tmp.write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
            tmp.replace(json_path)
            _log.info('Report %s downloaded', connect_id)
        pdf_path = None
        if with_pdf:
            pdf_path = json_path.with_suffix('.pdf')
            r = self._call(f'/companies/{connect_id}', {'language': self.cfg['reportLanguage']}, accept='application/pdf')
            if not r.content.startswith(b'%PDF'):
                raise AppError('REPORT_UNAVAILABLE', f'Creditsafe PDF for {connect_id} is not a PDF.', r.text[:200])
            tmp = pdf_path.with_suffix('.pdftmp')
            tmp.write_bytes(r.content)
            tmp.replace(pdf_path)
        return self._load({'json_path': json_path, 'pdf_path': pdf_path, 'fetched': stamp}, bool(c))

    @staticmethod
    def _load(c, from_cache):
        data = json.loads(Path(c['json_path']).read_text(encoding='utf-8'))
        return {'report': data['report'], 'json_path': Path(c['json_path']), 'pdf_path': c['pdf_path'],
                'fetched': c['fetched'], 'from_cache': from_cache}
