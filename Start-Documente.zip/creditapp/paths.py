"""Caile folosite de aplicatie. Totul ramane pe calculatorul utilizatorului."""
import os
import tempfile
from pathlib import Path

APP_ROOT = Path(__file__).resolve().parent.parent
CONFIG_FILE = APP_ROOT / 'config.json'
DATA_DIR = APP_ROOT / 'data'                     # baza de date de audit + loguri (se pot salva/arhiva)
LOG_DIR = DATA_DIR / 'logs'
DB_FILE = DATA_DIR / 'creditlimits.db'
OUTPUT_DIR = APP_ROOT / 'output'                 # rezumatele sesiunilor
SAP_TEMPLATE_DIR = APP_ROOT / 'sap_templates'

LOCAL_DIR = Path(os.environ.get('LOCALAPPDATA', tempfile.gettempdir())) / 'CreditLimitsApp'
REPORT_CACHE_DIR = LOCAL_DIR / 'reports'         # rapoartele Creditsafe deja platite (JSON + PDF)
WORK_DIR = Path(tempfile.gettempdir()) / 'CreditLimitsApp' / 'work'


def ensure_dirs():
    for d in (DATA_DIR, LOG_DIR, OUTPUT_DIR, SAP_TEMPLATE_DIR, LOCAL_DIR, REPORT_CACHE_DIR, WORK_DIR):
        d.mkdir(parents=True, exist_ok=True)


def expand(path: str) -> str:
    """Expandeaza %VAR% si ~ (calea functioneaza pentru orice utilizator)."""
    if not path:
        return ''
    return os.path.expanduser(os.path.expandvars(str(path)))
