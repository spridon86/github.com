"""Clientul Creditsafe cu un server HTTP simulat - fara retea, fara credite."""
import json

import pytest

import make_report
from creditapp import creditsafe, paths
from creditapp.errors import AppError
from creditapp.http import Response


class FakeHttp:
    def __init__(self, routes):
        self.routes = routes
        self.calls = []

    def request(self, method, url, params=None, headers=None, json_body=None, timeout=None):
        path = url.split('/v1', 1)[1]
        self.calls.append((method, path, dict(params or {}), (headers or {}).get('Accept')))
        h = self.routes.get((method, path, (headers or {}).get('Accept')))
        if h is None:
            h = self.routes.get((method, path))
        if h is None:
            return Response(404, b'{"message":"Not Found"}')
        return h(params or {}) if callable(h) else h


@pytest.fixture
def client(cfg, tmp_path, monkeypatch):
    monkeypatch.setattr(paths, 'REPORT_CACHE_DIR', tmp_path / 'reports')
    monkeypatch.setattr(creditsafe, 'get_credentials', lambda c: ('user', 'pwd'))
    rep = make_report.report()
    routes = {
        ('POST', '/authenticate'): Response(200, b'{"token":"T"}'),
        ('GET', '/companies'): lambda p: Response(200, json.dumps({'companies': [{'id': 'IT-0-NA470398', 'name': 'MIRA SUD', 'status': 'Active'}] if p.get('vatNo') == '01491571210' else []}).encode()),
        ('GET', '/companies/IT-0-NA470398', 'application/json'): Response(200, json.dumps({'report': rep, 'companyId': 'IT-0-NA470398'}).encode()),
        ('GET', '/companies/IT-0-NA470398', 'application/pdf'): Response(200, b'%PDF-1.4 test'),
        ('GET', '/companies/IT-1-EMPTY', 'application/json'): Response(403, b'{"details":"ServiceCreditsExceeded"}'),
        ('GET', '/access'): Response(200, json.dumps({'countryAccess': {'creditsafeConnectOnlineReports': [
            {'countryIso2': 'IT', 'paid': 200, 'used': 198, 'expireDate': '2099-10-31T23:59:59'},
            {'countryIso2': 'IT', 'paid': 50, 'used': 50, 'expireDate': '2020-01-01T00:00:00'}]}}).encode()),
    }
    http = FakeHttp(routes)
    return creditsafe.CreditsafeClient(cfg, http), http


def test_search_strips_prefix(client):
    c, http = client
    res = c.find_by_vat('IT01491571210', 'IT')
    assert res[0]['id'] == 'IT-0-NA470398'
    assert http.calls[1][2]['vatNo'] == '01491571210'


def test_search_fallback_to_regno(client):
    c, http = client
    assert c.find_by_vat('IT99999999999', 'IT') == []
    assert any(call[2].get('regNo') == '99999999999' for call in http.calls)


def test_report_cache_avoids_second_download(client):
    c, http = client
    r1 = c.fetch_report('IT-0-NA470398')
    assert not r1['from_cache'] and r1['pdf_path'].read_bytes().startswith(b'%PDF')
    n = len([x for x in http.calls if x[1].startswith('/companies/')])
    r2 = c.fetch_report('IT-0-NA470398')
    assert r2['from_cache'] and r2['report']['companyId'] == 'IT-0-NA470398'
    assert len([x for x in http.calls if x[1].startswith('/companies/')]) == n      # nicio cerere noua = niciun credit


def test_credits_error_mapped(client):
    c, _ = client
    with pytest.raises(AppError) as e:
        c.fetch_report('IT-1-EMPTY', use_cache=False)
    assert e.value.code == 'CREDITS'


def test_credits_ignores_expired(client):
    c, _ = client
    cr = c.credits('IT')
    assert cr['left'] == 2 and cr['paid'] == 200
