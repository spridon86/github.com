"""Pornire: python -m creditapp   (sau dublu-click pe Start-CreditTool.cmd)."""
import sys
import traceback


def main():
    from PyQt5.QtCore import QLocale, QLockFile, Qt
    from PyQt5.QtGui import QIcon
    from PyQt5.QtWidgets import QApplication, QMessageBox

    from . import errors, log, paths
    from .config import Config

    try:   # bara de activitati: iconita aplicatiei, nu cea a lui python.exe
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('Bunge.CreditLimitsTool')
    except Exception:
        pass
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)
    app = QApplication(sys.argv)
    app.setApplicationName('Credit Limits Tool')
    icon = paths.APP_ROOT / 'assets' / 'bunge.ico'
    if icon.exists():
        app.setWindowIcon(QIcon(str(icon)))
    app.setStyle('Fusion')
    QLocale.setDefault(QLocale(QLocale.Romanian, QLocale.Romania))   # 1.250.000 / 1,1208 in campurile numerice
    font = app.font()
    font.setFamily('Segoe UI')
    font.setPointSizeF(9)            # varianta A: textul ca in macheta (tabelul are si zoom: Ctrl + rotita)
    app.setFont(font)
    logger = log.setup()
    paths.ensure_dirs()
    # crash-uri native (Qt / COM): stiva Python ajunge in data/logs/crash.log; mesajele Qt (inclusiv qFatal) in app.log
    import faulthandler
    from PyQt5.QtCore import qInstallMessageHandler
    try:
        crash_file = open(paths.LOG_DIR / 'crash.log', 'a', encoding='utf-8')
        faulthandler.enable(crash_file, all_threads=True)
    except OSError:
        pass

    def qt_messages(mode, context, message):
        logger.warning('Qt: %s', message)
    qInstallMessageHandler(qt_messages)

    # o singura instanta: doua ferestre ar putea scrie simultan in NWCE / SAP
    lock = QLockFile(str(paths.LOCAL_DIR / 'app.lock'))
    lock.setStaleLockTime(0)
    if not lock.tryLock(200):
        QMessageBox.information(None, 'Credit Limits Tool', 'Aplicatia este deja deschisa.')
        return 0

    def excepthook(etype, value, tb):
        logger.error('Unhandled exception:\n%s', ''.join(traceback.format_exception(etype, value, tb)))
        try:
            f = errors.friendly(value)
            QMessageBox.warning(None, f['title'], f'{f["title"]}\n\nCe ai de facut:\n{f["action"]}\n\nDetalii:\n{f["details"]}')
        except Exception:
            pass
    sys.excepthook = excepthook

    try:
        cfg = Config.load()
    except Exception as e:
        QMessageBox.critical(None, 'Credit Limits Tool', f'config.json nu poate fi citit:\n{e}')
        return 1
    from .ui.main_window import MainWindow
    w = MainWindow(cfg)
    w.show()
    logger.info('Application started')
    rc = app.exec_()
    lock.unlock()
    return rc


if __name__ == '__main__':
    sys.exit(main())
