"""Inactivarea in NWCE: 0 in Payment Term si limite, date goale (STATUS INACTIVE); randurile INACTIVE recunoscute."""
import datetime as dt

from creditapp import limits_book as lb, pipeline
from creditapp.portfolio import Portfolio


class _Ctx:
    def __init__(self, cfg):
        self.cfg = cfg


def test_inactivation_changes_dates_empty_not_zero():
    ch = lb.inactivation_changes()
    assert ch['valid_till'] is None and ch['approved_on'] is None        # cu 0 formula STATUS ar da "UNDER REVIEW"
    assert all(ch[k] == 0 for k in lb.INACTIVATE_ZERO)
    assert 'total_kusd' not in ch                                        # formula - nu se suprascrie
    assert set(lb.INACTIVATE_ZERO) <= set(lb.WRITABLE)


def test_inactivation_decision_and_changes(cfg):
    ev = pipeline.Evaluation(partner='76033479', name='MONDELEZ')
    ev.nwce_row = {'sheet_row': 5810, 'values': {'open_kusd': 900.0, 'valid_till': 46387.0}}
    ev.decision = pipeline.inactivation_decision(_Ctx(cfg), ev, 'inactiv')
    ev.decision['fields'].append('comments')
    ch = pipeline.decision_changes(_Ctx(cfg), ev)
    assert ch['open_kusd'] == 0 and ch['valid_till'] is None and ch['comments'] == 'inactiv'
    assert ev.decision['sheet_row'] == 5810 and ev.decision['previous']['open_kusd'] == 900.0
    ev.state = 'approved'
    assert 'Inactivare aprobata' in ev.display_state
    ev.nwce = {'status': 'ok'}
    pipeline._maybe_done(ev)
    assert ev.state == 'done' and ev.display_state == 'Inactivat in NWCE'      # fara SAP


def test_inactive_rows_marked_and_hidden(cfg):
    from creditapp.ui.models import COL, ClientsFilter, ClientsModel
    rows = [lb.NwceRow(1, {'company_code': '6675 - Italy', 'customer_code': 76019577.0, 'name': 'MOLINO BOSCHI SRL', 'vat': 'IT1',
                           'status': 'INACTIVE', 'tbd_by': 'TBD by IS'}),
            lb.NwceRow(2, {'company_code': '6675 - Italy', 'customer_code': 76000002.0, 'name': 'ACTIV SRL', 'vat': 'IT2',
                           'status': 'APPROVED', 'tbd_by': 'TBD by IS', 'total_kusd': 100.0})]
    snap = lb.Snapshot(rows, {}, dt.datetime.now(), 't').index('IT')
    m = ClientsModel()
    m.load(Portfolio('x', dt.datetime.now(), {}, [], [], [], []), {}, snap, '6675 - Italy', 'IT', cfg)
    inact = [r for r in m.rows if r.cp.name == 'MOLINO BOSCHI SRL'][0]
    assert inact.cp.inactive and m.data(m.index(inact.idx, COL['state'])) == 'Inactiv (NWCE)'
    assert m.tbd_count('IS') == 1
    p = ClientsFilter()
    p.setSourceModel(m)
    p.tbd = 'IS'
    p.refresh()
    assert [m.rows[p.mapToSource(p.index(i, 0)).row()].cp.name for i in range(p.rowCount())] == ['ACTIV SRL']
    p.hide_blocked = False
    p.refresh()
    assert p.rowCount() == 2
