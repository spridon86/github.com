"""Varianta A: panoul din dreapta cu clientul selectat (cifrele cheie in propozitii, modificarile din "In lucru",
folderul) si fereastra "Toate detaliile" (detaliile complete, graficul de expunere, istoricul)."""
import datetime as dt

from PyQt5.QtCore import QDate, QLocale, Qt, pyqtSignal
from PyQt5.QtWidgets import (QComboBox, QDateEdit, QDialog, QDialogButtonBox, QDoubleSpinBox, QFormLayout, QFrame, QGridLayout,
                             QHBoxLayout, QLabel, QPushButton, QScrollArea, QSpinBox, QTabWidget, QTextBrowser, QVBoxLayout,
                             QWidget)

from .. import limits_book, mapping, review as review_mod, rules
from .models import MANUAL_COLS, fmt_date, fmt_money, money_ccy, step_chip
from .widgets import Chip

INV_MANUAL = {v: k for k, v in MANUAL_COLS.items()}         # experience -> m_exp ...


def _usd(v):
    return f'{fmt_money(v)} $' if isinstance(v, (int, float)) else ''


def _payments(pb):
    """Comportamentul de plata intr-un cuvant (detaliile in tooltip)."""
    if pb is None or pb.risk_score is None:
        return 'fără date'
    if pb.risk_score < 40:
        return 'la timp'
    return 'întârzieri' if pb.risk_score < 70 else 'risc mare'


def explanation(r, model):
    """Fraza de sub cifre: ce se intampla cu limita si cine aproba, pe intelesul tuturor."""
    ev, n = r.ev, r.nwce
    if ev is None or ev.state == 'cancelled':
        vt = limits_book.from_serial(n.get('valid_till')) if n is not None else None
        if vt and vt < dt.date.today() + dt.timedelta(days=45):
            return f'Limita expiră pe {vt:%d.%m.%Y}. Bifează clientul și apasă „Revizuiește bifații”.'
        return 'Bifează clientul și apasă „Revizuiește bifații” ca să-l evaluezi.'
    if ev.state == 'error' and ev.error:
        return f'{ev.error.get("title", "")}. {ev.error.get("action", "")}'
    rv, d = ev.review or {}, ev.decision or {}
    if d.get('inactivate'):
        return 'Fără expunere și fără facturi în ultimii 2 ani: clientul se inactivează în NWCE.'
    if ev.state == 'done':
        if d.get('sap_skip'):
            return 'Scris în NWCE. Aprobat pe alt canal, deci nu s-a transcris în SAP.'
        return 'Scris în NWCE și în SAP.'
    parts = []
    cur = float(n.get('open_kloc') or 0) * 1000 if n is not None else 0.0
    new = model.new_values(r).get('open')
    exp = rv.get('exposure')
    if new is not None and exp is not None:
        if new > cur:
            parts.append(f'Expunerea de săptămâna viitoare ({money_ccy(exp, r.cp.currency)}) trece de limita actuală, '
                         f'deci limita crește la {money_ccy(new, r.cp.currency)}.')
        else:
            parts.append('Limita actuală acoperă expunerea de săptămâna viitoare, deci se reînnoiește.')
    if rv.get('note'):
        parts.append(rv['note'])
    missing = review_mod.manual_needed(ev) if ev.inputs else []
    if missing:
        parts.append('Alege în dreapta criteriile marcate, apoi scorecardul se recalculează.')
    if rv.get('route') == 'escalate' or rv.get('would_escalate'):
        parts.append(f'Trebuie aprobat de {rv.get("authority") or "nivelul superior"}.')
    elif rv.get('authority'):
        parts.append('Ești în autoritatea ta.')
    return ' '.join(parts)


class SidePanel(QFrame):
    """Clientul selectat, ca in macheta: nume, eticheta, cifre, o fraza, modificari ("In lucru"), folderul."""
    edited = pyqtSignal(str, object)        # cheia coloanei (n_open, n_mtm, n_valid, n_grade, m_fin, m_exp, m_pay), valoarea
    folder = pyqtSignal()
    details = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName('side')
        self.setMinimumWidth(340)
        self.setMaximumWidth(440)
        self._loading = False
        self._initial = {}
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setStyleSheet('QScrollArea, QScrollArea > QWidget > QWidget { background: transparent; }')
        outer.addWidget(scroll)
        body = QWidget()
        scroll.setWidget(body)
        lay = QVBoxLayout(body)
        self._scroll, self._body, self._lay = scroll, body, lay
        lay.setContentsMargins(14, 14, 14, 14)
        lay.setSpacing(10)
        self.title = QLabel('Selectează un client')
        self.title.setObjectName('sideTitle')
        self.title.setWordWrap(True)
        lay.addWidget(self.title)
        self.sub = QLabel('')
        self.sub.setObjectName('muted')
        self.sub.setWordWrap(True)
        lay.addWidget(self.sub)
        self.chip = Chip()
        self.chip.setVisible(False)
        row = QHBoxLayout()
        row.addWidget(self.chip)
        row.addStretch(1)
        lay.addLayout(row)
        self.facts_box = QVBoxLayout()               # cifrele: un widget nou la fiecare client (fara resturi de la cel dinainte)
        self.facts_box.setContentsMargins(0, 0, 0, 0)
        self.facts_w = None
        lay.addLayout(self.facts_box)
        self.text = QLabel('')
        self.text.setWordWrap(True)
        self.text.setTextInteractionFlags(Qt.TextSelectableByMouse)
        lay.addWidget(self.text)

        # --- modificari ("In lucru"): aceleasi reguli ca in tabel (scorecard recalculat, autoritate, 30% equity)
        self.edit_box = QFrame()
        self.edit_box.setObjectName('card')
        ef = QFormLayout(self.edit_box)
        ef.setContentsMargins(10, 8, 10, 8)
        ef.setVerticalSpacing(6)
        ef.setLabelAlignment(Qt.AlignLeft)
        head = QLabel('<b>Modifică</b>')
        ef.addRow(head)
        de = QLocale(QLocale.German)                  # 1.300.000, ca restul tabelului
        self.w_open = QDoubleSpinBox()
        self.w_mtm = QDoubleSpinBox()
        for w in (self.w_open, self.w_mtm):
            w.setLocale(de)
            w.setDecimals(0)
            w.setRange(0, 10_000_000_000)
            w.setSingleStep(10_000)
            w.setGroupSeparatorShown(True)
            w.setButtonSymbols(QDoubleSpinBox.NoButtons)
        self.w_valid = QDateEdit()
        self.w_valid.setCalendarPopup(True)
        self.w_valid.setDisplayFormat('dd.MM.yyyy')
        self.w_valid.setDateRange(QDate.currentDate().addDays(1), QDate.currentDate().addMonths(36))
        self.w_grade = QSpinBox()
        self.w_grade.setRange(0, 11)
        self.w_grade.setSpecialValueText('—')
        self.w_fin = QComboBox()
        for x in mapping.FINANCIAL_REPORTING_OPTIONS:
            self.w_fin.addItem(x, x)
        self.w_exp = QComboBox()
        for k, label in mapping.EXPERIENCE_OPTIONS.items():
            self.w_exp.addItem(label, k)
        self.w_pay = QComboBox()
        for k, label in mapping.PAYMENT_OPTIONS.items():
            self.w_pay.addItem(label, k)
        # campurile nu largesc panoul (listele au texte lungi, ex. "C - Prepaid / New no data (0)")
        for w in (self.w_fin, self.w_exp, self.w_pay):
            w.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)
            w.setMinimumContentsLength(10)
        for w in (self.w_open, self.w_mtm, self.w_valid, self.w_grade, self.w_fin, self.w_exp, self.w_pay):
            w.setMinimumWidth(110)
            w.setMaximumWidth(190)
            w.setMinimumHeight(max(26, w.fontMetrics().height() + 14))   # dupa font (monitoare 120 DPI: text mai mare)
        self.lbl_open = QLabel('Open nou:')
        ef.addRow(self.lbl_open, self.w_open)
        ef.addRow('MTM nou ($):', self.w_mtm)
        ef.addRow('Valabil până:', self.w_valid)
        ef.addRow('Grade:', self.w_grade)
        ef.addRow('9. Fin. reporting:', self.w_fin)
        ef.addRow('10. Experiență:', self.w_exp)
        ef.addRow('11. Plăți:', self.w_pay)
        self.w_open.editingFinished.connect(lambda: self._emit('n_open', self.w_open.value()))
        self.w_mtm.editingFinished.connect(lambda: self._emit('n_mtm', self.w_mtm.value()))
        self.w_valid.editingFinished.connect(lambda: self._emit('n_valid', self.w_valid.date()))
        self.w_valid.calendarWidget().clicked.connect(lambda q: self._emit('n_valid', q))
        self.w_grade.editingFinished.connect(lambda: self._emit('n_grade', self.w_grade.value()))
        self.w_fin.activated.connect(lambda _i: self._emit('m_fin', self.w_fin.currentData()))
        self.w_exp.activated.connect(lambda _i: self._emit('m_exp', self.w_exp.currentData()))
        self.w_pay.activated.connect(lambda _i: self._emit('m_pay', self.w_pay.currentData()))
        lay.addWidget(self.edit_box)

        btns = QHBoxLayout()
        self.b_folder = QPushButton('Deschide folderul')
        self.b_folder.clicked.connect(self.folder.emit)
        self.b_details = QPushButton('Toate detaliile…')
        self.b_details.clicked.connect(self.details.emit)
        btns.addWidget(self.b_folder)
        btns.addWidget(self.b_details)
        btns.addStretch(1)
        lay.addLayout(btns)
        lay.addStretch(1)
        self.show_row(None, None)

    # --- afisare
    def _clear_facts(self):
        if self.facts_w is not None:
            self.facts_box.removeWidget(self.facts_w)
            self.facts_w.setParent(None)
            self.facts_w.deleteLater()
        self.facts_w = QWidget()
        self.facts = QGridLayout(self.facts_w)
        self.facts.setContentsMargins(0, 0, 0, 0)
        self.facts.setHorizontalSpacing(8)
        self.facts.setVerticalSpacing(6)
        self.facts.setColumnStretch(0, 1)
        self._rows = 0
        self.facts_box.addWidget(self.facts_w)

    def _fact(self, label, value, tip=''):
        if value in (None, ''):
            return
        i = self._rows
        self._rows += 1
        a = QLabel(label)
        a.setObjectName('muted')
        b = QLabel(f'<b>{value}</b>')
        b.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        if tip:
            a.setToolTip(tip)
            b.setToolTip(tip)
        self.facts.addWidget(a, i, 0)
        self.facts.addWidget(b, i, 1)

    def show_row(self, r, model):
        self._loading = True
        try:
            self._show(r, model)
        finally:
            self._loading = False
        self._fit()

    def _fit(self):
        """Inaltimea continutului pentru latimea reala a panoului: textele rupte pe mai multe randuri (numele, fraza)
        sunt subestimate de Qt, iar caseta "Modifica" ar fi strivita in loc sa apara bara de derulare."""
        w = self._scroll.viewport().width()
        if w > 50 and self._lay.hasHeightForWidth():
            self._body.setMinimumHeight(self._lay.totalHeightForWidth(w))

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._fit()

    def _show(self, r, model):
        self._clear_facts()
        if r is None:
            self.title.setText('Selectează un client')
            self.sub.setText('Click pe un rând din tabel ca să vezi detaliile aici.')
            self.chip.setVisible(False)
            self.text.setText('')
            self.edit_box.setVisible(False)
            self.b_folder.setEnabled(False)
            self.b_details.setEnabled(False)
            return
        cp, n, ev = r.cp, r.nwce, r.ev
        self.b_folder.setEnabled(True)
        self.b_details.setEnabled(True)
        self.title.setText(cp.name)
        comp = n.company_code if n is not None else (cp.company_code or '')
        bits = [comp, f'Customer {cp.customer_code}' if cp.customer_code else '', r.group_name if len(r.group_rows) > 1 else '']
        self.sub.setText(' · '.join(b for b in bits if b))
        text, level = step_chip(r, model.sap_company)
        self.chip.set(level, text)
        self.chip.setVisible(bool(text))
        nv = model.new_values(r)
        rv = (ev.review or {}) if ev else {}
        cur = n.get('open_kloc') if n is not None else None
        cur = float(cur) * 1000 if isinstance(cur, (int, float)) else None
        self._fact('Limită acum', money_ccy(cur, cp.currency))
        mtm = n.get('mtm_kusd') if n is not None else None
        if isinstance(mtm, (int, float)) and mtm:
            self._fact('MTM acum', _usd(float(mtm) * 1000))
        exp = rv.get('exposure')
        if exp is None and cp.source == 'portfolio':
            exp = review_mod.next_month_exposure(cp)[0]
        self._fact('Vârf expunere', money_ccy(exp, cp.currency) if exp else '')
        if nv.get('open') is not None:
            self._fact('Propunere', money_ccy(nv.get('open'), cp.currency))
        if nv.get('equity30_usd') is not None:
            self._fact('30% din equity', _usd(nv['equity30_usd']))
        from .models import payment_summary
        self._fact('Plăți', _payments(cp.payment), payment_summary(cp.payment))
        vt = limits_book.from_serial(n.get('valid_till')) if n is not None else None
        self._fact('Valabil până', fmt_date(vt))
        old_g = rules.grade_number(n.get('grading')) if n is not None else None
        new_g = rules.grade_number(nv.get('grade')) if nv else None
        if old_g or new_g:
            self._fact('Grade', f'{old_g or "—"} → {new_g}' if new_g and new_g != old_g else str(new_g or old_g))
        if rv.get('authority'):
            self._fact('Cine aprobă', 'tu' if rv.get('route') == 'auto' and not rv.get('would_escalate') else rv['authority'])
        self.text.setText(explanation(r, model))

        editable = model.editable_row(r)
        self.edit_box.setVisible(editable)
        if editable:
            self.lbl_open.setText(f'Open nou ({cp.currency or "EUR"}):')
            self.w_open.setValue(float(nv.get('open') or 0))
            self.w_mtm.setValue(float(nv.get('mtm_usd') or 0))
            v = nv.get('valid')
            self.w_valid.setDate(QDate.fromString(v, 'yyyy-MM-dd') if v else QDate.currentDate().addMonths(12))
            has_sc = bool((ev.files or {}).get('scorecard')) and ev.grade is not None
            self.w_grade.setValue(int(new_g or 0))
            self.w_grade.setEnabled(not has_sc)
            self.w_grade.setToolTip('Grade-ul vine din scorecard (se schimbă prin criteriile de mai jos).' if has_sc else '')
            inp = ev.inputs or {}
            for w, crit in ((self.w_fin, 'financial_reporting'), (self.w_exp, 'experience'), (self.w_pay, 'payment')):
                val = inp.get(crit)
                val = val if isinstance(val, str) else (val or {}).get('grade')
                w.setCurrentIndex(w.findData(val) if val is not None else -1)
                need = crit in (review_mod.manual_needed(ev) if inp else [])
                w.setStyleSheet('QComboBox{background:#FBF0DC;border-color:#A35F00}' if need else '')
            self._initial = {'n_open': self.w_open.value(), 'n_mtm': self.w_mtm.value(), 'n_valid': self.w_valid.date(),
                             'n_grade': self.w_grade.value(), 'm_fin': self.w_fin.currentData(), 'm_exp': self.w_exp.currentData(),
                             'm_pay': self.w_pay.currentData()}

    def _emit(self, key, value):
        """Se trimite doar o valoare schimbata de analist (iesirea din camp fara schimbare nu scrie nimic)."""
        if self._loading or value is None or value == self._initial.get(key):
            return
        if key == 'n_grade' and not value:
            return
        self._initial[key] = value
        self.edited.emit(key, value)


class DetailsDialog(QDialog):
    """"Toate detaliile": pagina completa a clientului, graficul de expunere si istoricul (fostul panou de jos)."""

    def __init__(self, parent, chart):
        super().__init__(parent)
        self.setWindowTitle('Toate detaliile')
        self.resize(1000, 720)
        lay = QVBoxLayout(self)
        self.tabs = QTabWidget()
        self.details = QTextBrowser()
        self.details.setOpenLinks(False)
        self.tabs.addTab(self.details, 'Detalii client')
        self.chart = chart
        self.tabs.addTab(self.chart, 'Expunere')
        self.journal = QTextBrowser()
        self.tabs.addTab(self.journal, 'Istoric')
        lay.addWidget(self.tabs)
        bb = QDialogButtonBox(QDialogButtonBox.Close)
        bb.rejected.connect(self.hide)
        bb.button(QDialogButtonBox.Close).setText('Închide')
        lay.addWidget(bb)
