"""Clientul website Creditsafe, cu raspunsurile reale inregistrate (format) si fara browser / retea."""
import json

import pytest

from creditapp import creditsafe_web as cw
from creditapp.http import Response


class FakeHttp:
    def __init__(self, routes):
        self.routes, self.calls = routes, []

    def request(self, method, url, params=None, headers=None, json_body=None, timeout=None):
        path = url.split('.com', 1)[1]
        self.calls.append((path, dict(params or {}), (headers or {}).get('Authorization')))
        h = self.routes.get(path)
        return (h(params or {}) if callable(h) else h) if h else Response(404, b'{}')


SEARCH = {'totalSize': 1, 'content': [{'id': 'IT-0-NA470398', 'country': 'IT', 'regNumber': 'NA470398', 'safeNumber': 'IT03036139',
                                       'name': 'MIRA SUD S.R.L.', 'address': {'city': 'NAPOLI'}, 'status': 'active',
                                       'dateOfLatestAccounts': '2025-12-31T00:00:00Z', 'vatNos': ['06050500633', '01491571210']}]}
SERVICES = [
    {'serviceId': 1001, 'country': 'IT', 'paid': 48999, 'used': 1620, 'isUnlimited': False, 'expireDate': '2099-10-31T23:59:59'},
    {'serviceId': 1001, 'country': 'IT', 'paid': 2000, 'used': 994, 'isUnlimited': False, 'expireDate': '2099-10-31T23:59:59'},
    {'serviceId': 1001, 'country': 'IT', 'paid': 500, 'used': 1, 'isUnlimited': False, 'expireDate': '2020-01-01T00:00:00'},
    {'serviceId': 1002, 'country': 'IT', 'paid': 5, 'used': 0, 'isUnlimited': False, 'expireDate': '2099-10-31T23:59:59'},
    {'serviceId': 1001, 'country': 'DE', 'paid': 10, 'used': 0, 'isUnlimited': False, 'expireDate': '2099-10-31T23:59:59'},
]


@pytest.fixture
def client(cfg, monkeypatch):
    charged = {'IT-0-NA470398': 'ServiceValidNoCharge', 'IT-1-NEW': 'ServiceValidAndRequireCharge'}
    routes = {
        '/v1/search/companies': lambda p: Response(200, json.dumps(SEARCH if p.get('vatNo') == '01491571210' else {'content': []}).encode()),
        '/v1/UserServices': Response(200, json.dumps(SERVICES).encode()),
        '/ubo/users/101714942/services/1002/check': lambda p: Response(200, json.dumps({'serviceState': charged[p['suppliedRef']]}).encode()),
    }
    http = FakeHttp(routes)
    c = cw.CreditsafeWebClient(cfg, http)
    monkeypatch.setattr(c, 'token', lambda force=False: 'TOKEN')
    c.browser.user_id = '101714942'
    return c, http


def test_search_maps_portal_format(client):
    c, http = client
    res = c.find_by_vat('IT01491571210', 'IT')
    assert res[0]['id'] == 'IT-0-NA470398' and res[0]['regNo'] == 'NA470398' and '01491571210' in res[0]['vatNo']
    assert http.calls[0][1]['vatNo'] == '01491571210' and http.calls[0][2] == 'Bearer TOKEN'


def test_credits_sum_active_lines(client):
    c, _ = client
    cr = c.credits('IT')
    assert cr['paid'] == 50999 and cr['used'] == 2614 and cr['left'] == 48385


def test_will_charge(client):
    c, _ = client
    assert c.will_charge('IT-0-NA470398') is False
    assert c.will_charge('IT-1-NEW') is None        # RequireCharge nu e concludent


def test_make_client_modes(cfg):
    assert isinstance(cw.make_client(cfg), cw.CreditsafeWebClient)
    cfg.set('api', 'creditsafe', 'mode')
    assert not isinstance(cw.make_client(cfg), cw.CreditsafeWebClient)


def test_jwt_claims():
    import base64
    payload = base64.urlsafe_b64encode(json.dumps({'exp': 123, 'sub': '5'}).encode()).decode().rstrip('=')
    assert cw._jwt_claims(f'h.{payload}.s') == {'exp': 123, 'sub': '5'}
    assert cw._jwt_claims('garbage') == {}


def test_parallel_report_requests_share_one_browser_thread(cfg):
    """Rapoartele cerute in paralel (cs_1, cs_2...) ruleaza toate in ACELASI fir "edge" - Playwright nu suporta alt fir
    (altfel: "greenlet.error: Cannot switch to a different thread" -> "Eroare neasteptata" la unii clienti)."""
    import threading
    from creditapp import creditsafe_web
    b = creditsafe_web._Browser(cfg)
    gate = threading.Barrier(8)
    seen = []

    def ask():
        gate.wait()
        seen.append(b.call(lambda: (threading.current_thread().name, threading.get_ident()), timeout=10))
    workers = [threading.Thread(target=ask) for _ in range(8)]
    for w in workers:
        w.start()
    for w in workers:
        w.join(15)
    b.stop()
    assert len(seen) == 8 and len(set(seen)) == 1 and seen[0][0] == 'edge'
