"""ZBEU_UKM_BP_CREDIT_L pe inregistrarea reala (Script1.vbs, 16.10.2026: furnizor 88138951, Open 0, MTM 70.000 USD,
31.10.2027, scor 9, fara Equity, fara comentariu) si o sesiune SAP simulata cu aceleasi ecrane."""
import datetime as dt

import pytest

from creditapp import sap_gui
from creditapp.errors import AppError

GRID = 'wnd[0]/usr/cntlC_CONTAINER/shellcont/shell'
SEARCH = 'wnd[0]/usr/subA01P01:SAPLBUD0_SEARCH:0100/txtBUSSEARCH-PARTNER'
VBS = r'''If Not IsObject(application) Then
   Set SapGuiAuto  = GetObject("SAPGUI")
   Set application = SapGuiAuto.GetScriptingEngine
End If
If Not IsObject(connection) Then
   Set connection = application.Children(0)
End If
If Not IsObject(session) Then
   Set session    = connection.Children(0)
End If
If IsObject(WScript) Then
   WScript.ConnectObject session,     "on"
   WScript.ConnectObject application, "on"
End If
session.findById("wnd[0]").maximize
session.findById("wnd[0]/usr/cntlIMAGE_CONTAINER/shellcont/shell/shellcont[0]/shell").doubleClickNode "F00037"
session.findById("wnd[0]").sendVKey 4
session.findById("wnd[0]/usr/subA01P01:SAPLBUD0_SEARCH:0100/txtBUSSEARCH-PARTNER").text = "88138951"
session.findById("wnd[0]/usr/subA01P01:SAPLBUD0_SEARCH:0100/txtBUSSEARCH-PARTNER").caretPosition = 8
session.findById("wnd[0]").sendVKey 0
session.findById("wnd[0]/usr/cntlGRID1/shellcont/shell").selectedRows = "0"
session.findById("wnd[0]/usr/cntlGRID1/shellcont/shell").doubleClickCurrentCell
session.findById("wnd[0]/tbar[1]/btn[8]").press
session.findById("wnd[0]/usr/txtGV_SCORE").text = "9"
session.findById("wnd[0]/usr/ctxtGV_VAL_SCORE").text = "31.10.2027"
session.findById("wnd[0]/usr/ctxtGV_VAL_SCORE").setFocus
session.findById("wnd[0]/usr/ctxtGV_VAL_SCORE").caretPosition = 2
session.findById("wnd[0]/usr/cntlC_CONTAINER/shellcont/shell").pressToolbarButton "NEW_SEGMENTS"
session.findById("wnd[1]/usr/ctxtGS_NEW_SEG-SEGMENT").text = "ZIT1_LIMIT"
session.findById("wnd[1]/usr/ctxtGS_NEW_SEG-SEGMENT").setFocus
session.findById("wnd[1]/usr/ctxtGS_NEW_SEG-SEGMENT").caretPosition = 10
session.findById("wnd[1]/tbar[0]/btn[0]").press
session.findById("wnd[0]/usr/cntlC_CONTAINER/shellcont/shell").modifyCell 3,"CRED_LIM_REQ","70000"
session.findById("wnd[0]/usr/cntlC_CONTAINER/shellcont/shell").setCurrentCell 3,"N_CURRENCY"
session.findById("wnd[0]/usr/cntlC_CONTAINER/shellcont/shell").triggerModified
session.findById("wnd[0]/usr/cntlC_CONTAINER/shellcont/shell").modifyCell 3,"N_CURRENCY","usd"
session.findById("wnd[0]/usr/cntlC_CONTAINER/shellcont/shell").currentCellColumn = "N_VALID_DATE"
session.findById("wnd[0]/usr/cntlC_CONTAINER/shellcont/shell").triggerModified
session.findById("wnd[0]/usr/cntlC_CONTAINER/shellcont/shell").pressToolbarButton "UPD_VAL_DATE"
session.findById("wnd[1]/usr/sub:SAPLSPO4:0300/ctxtSVALD-VALUE[0,21]").text = "31.10.2027"
session.findById("wnd[1]/usr/sub:SAPLSPO4:0300/ctxtSVALD-VALUE[0,21]").caretPosition = 2
session.findById("wnd[1]/tbar[0]/btn[0]").press
session.findById("wnd[0]/tbar[1]/btn[36]").press
session.findById("wnd[1]/usr/btnBUTTON_1").press
session.findById("wnd[1]/tbar[0]/btn[0]").press
session.findById("wnd[1]/tbar[0]/btn[0]").press
session.findById("wnd[1]/tbar[0]/btn[0]").press
session.findById("wnd[0]/tbar[0]/btn[3]").press
'''

SAMPLES = {'bp': None, 'customer_code': '0088138951', 'limit': None, 'mtm': 70000,
           'valid_to': dt.date(2027, 10, 31), 'grade': '9', 'segment': 'ZIT1_LIMIT'}


def _tpl():
    return sap_gui.build_template(VBS, SAMPLES, 'Script1.vbs')


def by_line(tpl, n):
    return [s for s in tpl['steps'] if s.get('line') == n]


def test_import_real_recording():
    tpl, rep = _tpl()
    st = tpl['steps']
    assert st[1]['value'] == '/nSESSION_MANAGER' and st[2]['name'] == 'sendVKey'   # meniul cu Favorite
    assert by_line(tpl, 16)[0]['check_tcode']
    assert by_line(tpl, 18)[0]['value'] == '{bp}'                             # cautare dupa BP, nu Customer Code
    assert by_line(tpl, 21)[0]['expect_one']
    assert by_line(tpl, 24)[0]['value'] == '{grade}' and by_line(tpl, 25)[0]['value'] == '{valid_to}'
    assert by_line(tpl, 29)[0]['value'] == '{segment}' and by_line(tpl, 28)[0]['if_segment_missing']
    assert all(s.get('if_segment_missing') for s in by_line(tpl, 29) + by_line(tpl, 32))
    assert by_line(tpl, 33)[0]['args'] == [3, 'CRED_LIM_REQ', '{mtm}'] and by_line(tpl, 33)[0]['grid_role'] == 'mtm'
    assert by_line(tpl, 36)[0]['grid_role'] == 'mtm' and by_line(tpl, 34)[0]['grid_role'] == 'mtm'
    synth = [s for s in st if s.get('grid_role') == 'open']
    assert [s['args'][1:] for s in synth[:2]] == [['CRED_LIM_REQ', '{limit}'], ['N_CURRENCY', '{currency}']]
    assert st.index(synth[0]) < st.index(by_line(tpl, 33)[0])
    assert by_line(tpl, 40)[0]['value'] == '{valid_to}'
    assert st[tpl['save_step']]['id'] == 'wnd[0]/tbar[1]/btn[36]'            # rotita, nu F8 (btn[8])
    assert 'Open Limit' in rep and 'ATENTIE' not in rep


# ---------------------------------------------------------------- SAP simulat
class Ole:
    def __init__(self, o):
        self.o = o

    def GetIDsOfNames(self, name):
        return name

    def Invoke(self, name, lcid, flags, want, *args):
        import pythoncom
        if flags == pythoncom.DISPATCH_PROPERTYPUT:
            self.o.props[name] = args[0]
            self.o.s.trace.append(('put', self.o.id, name, args[0]))
            return None
        if flags == pythoncom.DISPATCH_PROPERTYGET:
            return self.o.props.get(name)
        return self.o.call(name, *args)


class Coll:
    def __init__(self, s, items):
        self.s, self.id, self.items = s, 'coll', items
        self.props = {'Count': len(items)}
        self._oleobj_ = Ole(self)

    def call(self, name, i):
        return self.items[i]


class Elem:
    def __init__(self, s, sid, props=None):
        self.s, self.id = s, sid
        self.props = {'Text': '', 'text': ''}
        self.props.update(props or {})
        self._oleobj_ = Ole(self)

    def call(self, name, *args):
        s = self.s
        s.trace.append(('call', self.id, name, args))
        if name == 'doubleClickNode':
            s.info.props['Transaction'] = s.favourite
        elif self.id == 'wnd[0]/tbar[1]/btn[8]':
            s.screen = 'main'
        elif self.id == 'wnd[0]/tbar[1]/btn[36]':
            s.executed = True
            s.popups = ['CASE', 'ATTACH', 'COMMENT', 'APPROVE']
        elif self.id == GRID and name == 'pressToolbarButton':
            s.popups.append(args[0])
        elif self.id.startswith('wnd[1]') and name == 'press':
            p = s.popups.pop()
            if p == 'NEW_SEGMENTS':
                seg = s.elems['wnd[1]/usr/ctxtGS_NEW_SEG-SEGMENT'].props['text']
                s.grid += [{'SGM': seg, 'INFO': t, 'CRED_LIM_REQ': '', 'N_CURRENCY': ''}
                           for t in ('Open Limit', 'MTM & PFE limit', 'Temporary limit')]
        if self.id == GRID:
            if name == 'GetDisplayedColumnTitle':
                return {'SGM': 'Segment', 'INFO': 'Info Type Text'}.get(args[0], args[0])
            if name == 'GetCellValue':
                return s.grid[args[0]][args[1]]
            if name == 'modifyCell':
                s.grid[args[0]][args[1]] = args[2]
        return None


class ZbeuSession:
    def __init__(self, grid=None, bp_hits=('76014759',), favourite='ZBEU_UKM_BP_CREDIT_L'):
        self.s, self.id = self, 'session'
        self.trace, self.popups, self.executed, self.screen = [], [], False, 'sel'
        self.favourite, self.bp_hits = favourite, list(bp_hits)
        self.grid = grid if grid is not None else [{'SGM': 'ZRO1_OPEN', 'INFO': 'Open Limit', 'CRED_LIM_REQ': '1', 'N_CURRENCY': 'RON'}]
        self.info = Elem(self, 'info', {'Transaction': 'SESSION_MANAGER'})
        self.props = {'Busy': False, 'Info': self.info}
        self._oleobj_ = Ole(self)
        self.elems = {}
        self.equity = Elem(self, 'chkEQ', {'Type': 'GuiCheckBox', 'Text': 'Equity Scenario', 'Selected': False})

    def call(self, name, sid, *_):
        if sid.startswith('wnd[1]') and not self.popups:
            return None
        if sid == 'wnd[1]':
            return Elem(self, sid, {'Text': {'CASE': 'SCase Created'}.get(self.popups[-1], self.popups[-1])})
        if sid == 'wnd[1]/usr':
            kids = [Elem(self, 'lbl', {'Text': 'Case Number 0000012345'})] if self.popups[-1] == 'CASE' else []
            return Elem(self, sid, {'Children': Coll(self, kids)})
        if sid == 'wnd[0]/sbar':
            return Elem(self, sid, {'MessageType': '', 'Text': ''})
        if sid == 'wnd[0]/usr':
            kids = [Elem(self, 'txtGV_SCORE', {'Type': 'GuiTextField'}), self.equity] if self.screen == 'main' else []
            return Elem(self, sid, {'Children': Coll(self, kids)})
        e = self.elems.setdefault(sid, Elem(self, sid))
        if sid == GRID:
            e.props.update({'RowCount': len(self.grid), 'ColumnOrder': Coll(self, ['SGM', 'INFO', 'CRED_LIM_REQ', 'N_CURRENCY'])})
        if sid == 'wnd[0]/usr/cntlGRID1/shellcont/shell':
            e.props['RowCount'] = len(self.bp_hits)
            e.props['ColumnOrder'] = Coll(self, ['MC_NAME1', 'MC_CITY1', 'PARTNER'])
            e.call = lambda name, *a: self.bp_hits[a[0]] if name == 'GetCellValue' and a[1] == 'PARTNER' else 'X'
        return e


VALUES = {'bp': '76014759', 'customer_code': '76021671', 'limit': 850_000, 'mtm': 200_000, 'currency': 'EUR',
          'valid_to': dt.date(2027, 11, 30), 'grade': 5, 'equity': False}


@pytest.fixture
def zbeu(monkeypatch, cfg):
    holder = {}

    def connect(c):
        return holder['s'], sap_gui.SapSessionInfo('P01', '100', 'UISPRID', '')
    monkeypatch.setattr(sap_gui, 'connect', connect)

    def go(session, values=VALUES, dry=True):
        holder['s'] = session
        return sap_gui.run(_tpl()[0], values, cfg, dry_run=dry)
    return go


def puts(s):
    return {(t[1], t[2]): t[3] for t in s.trace if t[0] == 'put'}


def test_dry_run_new_segment(zbeu):
    s = ZbeuSession()
    res = zbeu(s)
    assert res.ok and not s.executed
    p = puts(s)
    assert p[(SEARCH, 'text')] == '76014759' and p[('wnd[0]/usr/txtGV_SCORE', 'text')] == '5'
    assert p[('wnd[0]/usr/ctxtGV_VAL_SCORE', 'text')] == '30.11.2027'
    assert p[('wnd[1]/usr/ctxtGS_NEW_SEG-SEGMENT', 'text')] == 'ZIT1_LIMIT'
    open_row, mtm_row = s.grid[1], s.grid[2]
    assert open_row['CRED_LIM_REQ'] == '850000' and open_row['N_CURRENCY'] == 'EUR'
    assert mtm_row['CRED_LIM_REQ'] == '200000' and mtm_row['N_CURRENCY'] == 'usd'
    assert s.grid[0]['CRED_LIM_REQ'] == '1' and s.grid[3]['CRED_LIM_REQ'] == ''      # alt segment / alt rand neatinse
    assert p[('wnd[1]/usr/sub:SAPLSPO4:0300/ctxtSVALD-VALUE[0,21]', 'text')] == '30.11.2027'
    assert ('wnd[0]/tbar[0]/okcd', 'Text') in p                                      # iesire cu /n


def test_existing_segment_is_not_added_again(zbeu):
    grid = [{'SGM': 'ZIT1_LIMIT', 'INFO': 'MTM & PFE limit', 'CRED_LIM_REQ': '150000', 'N_CURRENCY': 'USD'},
            {'SGM': 'ZIT1_LIMIT', 'INFO': 'Open Limit', 'CRED_LIM_REQ': '700000', 'N_CURRENCY': 'EUR'}]
    s = ZbeuSession(grid=grid)
    res = zbeu(s)
    assert res.ok and len(s.grid) == 2
    assert not any(t[2] == 'pressToolbarButton' and t[3] == ('NEW_SEGMENTS',) for t in s.trace if t[0] == 'call')
    assert s.grid[1]['CRED_LIM_REQ'] == '850000' and s.grid[0]['CRED_LIM_REQ'] == '200000'
    assert res.before['limit@open'] == '700000' and res.before['mtm@mtm'] == '150000'


def test_supplier_only_mtm_leaves_open_row(zbeu):
    s = ZbeuSession()
    res = zbeu(s, dict(VALUES, limit=0, mtm=70_000))
    assert res.ok and s.grid[1]['CRED_LIM_REQ'] == '' and s.grid[2]['CRED_LIM_REQ'] == '70000'


def test_real_run_gear_popups_case_number_equity(zbeu):
    s = ZbeuSession()
    res = zbeu(s, dict(VALUES, equity=True), dry=False)
    assert res.ok and res.saved and s.executed and not s.popups
    assert res.case_number == '12345' and 'caz 12345' in res.message
    assert s.equity.props['Selected'] is True


def test_same_bp_on_two_addresses_is_accepted(zbeu):
    s = ZbeuSession(bp_hits=('76014759', '0076014759'))          # VBGRAINS: Ancona + Roma, acelasi BP
    assert zbeu(s).ok


@pytest.mark.parametrize('kw,needle', [({'bp_hits': ()}, 'no results'), ({'bp_hits': ('76014759', '76099999')}, 'other partners'),
                                       ({'favourite': 'VA03'}, 'expected ZBEU_UKM_BP_CREDIT_L')])
def test_safety_stops_before_gear(zbeu, kw, needle):
    s = ZbeuSession(**kw)
    with pytest.raises(AppError) as e:
        zbeu(s, dry=False)
    assert needle in e.value.message and not s.executed


def test_missing_bp_stops(zbeu):
    s = ZbeuSession()
    with pytest.raises(AppError) as e:
        zbeu(s, dict(VALUES, bp=None), dry=False)
    assert e.value.code == 'SAP_TEMPLATE' and not s.executed


def test_find_bp_fallbacks(cfg):
    from creditapp import limits_book as lb, pipeline

    class Snap:
        def __init__(self, rows):
            self.rows = rows

        def row_by_sheet(self, n):
            return next((r for r in self.rows if r.sheet_row == n), None)

    class Ctx:
        pass
    ev = pipeline.Evaluation(partner='76020872', name='AGRINORD')
    ev.customer_code, ev.vat = '76020872', 'IT01229150931'
    ev.nwce_row = {'sheet_row': 6514, 'values': {'bp_code': 0.0, 'customer_code': 76020872.0}}
    ctx = Ctx()
    ctx.cfg = cfg
    ctx.nwce = Snap([lb.NwceRow(6514, {'bp_code': 0.0, 'customer_code': 76020872.0})])
    assert pipeline.find_bp(ctx, ev) == ''                                   # nicaieri -> SAP nu porneste
    ctx.nwce = Snap([lb.NwceRow(6514, {'bp_code': 76014444.0, 'customer_code': 76020872.0})])
    assert pipeline.find_bp(ctx, ev) == '76014444'                           # completat in NWCE intre timp
    ctx.nwce = Snap([lb.NwceRow(6514, {'bp_code': 0.0}), lb.NwceRow(7000, {'bp_code': 76015555.0, 'vat': 'IT01229150931'})])
    assert pipeline.find_bp(ctx, ev) == '76015555'                           # alt rand NWCE, acelasi VAT


def test_sap_values_from_evaluation(cfg):
    from creditapp import pipeline
    ev = pipeline.Evaluation(partner='76021671', name='X')
    ev.customer_code, ev.currency = '76021671', 'EUR'
    ev.decision = {'limit_eur': 850000, 'valid_till': '2027-10-31', 'grading': 6, 'mtm_kusd': 200.0}
    ev.review = {'equity_scenario': True}

    class Ctx:
        pass
    ctx = Ctx()
    ctx.cfg, ctx.nwce = cfg, None
    v = pipeline.sap_values(ctx, ev)
    assert v['mtm'] == 200_000 and v['equity'] is True and v['grade'] == 6 and v['currency'] == 'EUR'
    ev.decision['grading'] = 'Intuitive 9'          # textul din NWCE -> in SAP doar cifra
    assert pipeline.sap_values(ctx, ev)['grade'] == 9
