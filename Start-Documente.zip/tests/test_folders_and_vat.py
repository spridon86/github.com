import datetime as dt
import os

from creditapp import client_folders as cf
from creditapp.creditsafe import country_of_vat, vat_without_prefix
from creditapp.fsutil import safe_name, unique_path
from creditapp.limits_book import vat_key


def test_name_key_variants():
    k = cf.name_key
    assert k('MIRA SUD S.R.L.') == k('MIRA SUD S.R.L - BRC') == k('Mira Sud SRL') == 'MIRA SUD'
    assert k('CEREAL DE CARIA SRL') == k('Cereal de Caria - BRC') == 'CEREAL DE CARIA'
    assert k('A.L.S.O. SRL') == 'ALSO'
    assert k('SOCIETÀ AGRICOLA FRANCHINA S.S.') == k('SOCIETA AGRICOLA FRANCHINA - BRC')
    assert k('2T SOCIETA\' A RESPONSABILITA\' LIMITATA') == '2T'
    assert k('X SPA (ex Y SRL)') == 'X'
    assert k('') == ''


def test_find_and_resolve_folders(tmp_path):
    root = tmp_path
    (root / 'MIRA SUD S.R.L - BRC' / '2021').mkdir(parents=True)
    (root / 'Mira Sud SRL' / '2025').mkdir(parents=True)
    newer = root / 'Mira Sud SRL' / '2025' / 'x.pdf'
    newer.write_text('x')
    older = root / 'MIRA SUD S.R.L - BRC' / '2021' / 'y.pdf'
    older.write_text('y')
    os.utime(older, (dt.datetime(2021, 5, 1).timestamp(),) * 2)
    (root / 'CEREAL DOCKS Group' / 'CEREAL DOCKS SPA - BRC').mkdir(parents=True)
    (root / 'MIRANDA SRL').mkdir()
    cf.forget_listing()
    res = cf.resolve_client_folder(root, ['MIRA SUD S.R.L.'], 'MIRA SUD S.R.L.')
    assert res.exists and res.path.name == 'Mira Sud SRL'        # cel folosit cel mai recent
    assert [p.name for p in res.alternatives] == ['MIRA SUD S.R.L - BRC']
    res = cf.resolve_client_folder(root, ['Cereal Docks S.p.A.'], 'Cereal Docks S.p.A.')
    assert res.exists and res.path.parent.name == 'CEREAL DOCKS Group'
    res = cf.resolve_client_folder(root, ['NEW CLIENT: X/Y SRL.'], 'NEW CLIENT: X/Y SRL.')
    assert not res.exists and res.path.name == 'NEW CLIENT X Y SRL'
    d, why = cf.earliest_trace(root / 'MIRA SUD S.R.L - BRC')
    assert d == dt.date(2021, 1, 1) and '2021' in why


def test_vat_helpers():
    assert vat_without_prefix('IT02555800420', 'IT') == '02555800420'
    assert vat_without_prefix('02555800420', 'IT') == '02555800420'
    assert vat_without_prefix('EL 123.456.789', 'GR') == '123456789'
    assert country_of_vat('IT01491571210') == 'IT'
    assert country_of_vat('EL123456789') == 'GR'
    assert country_of_vat('01491571210', 'IT') == 'IT'
    assert vat_key('01491571210', 'IT') == 'IT01491571210'
    assert vat_key('IT 0149-1571210') == 'IT01491571210'
    assert vat_key('n/a') == ''


def test_file_names(tmp_path):
    assert safe_name('A/B: C*?.') == 'A B C'
    p = tmp_path / 'Scorecard X 2025.xlsx'
    assert unique_path(p) == p
    p.write_text('1')
    assert unique_path(p).name == 'Scorecard X 2025 (2).xlsx'
