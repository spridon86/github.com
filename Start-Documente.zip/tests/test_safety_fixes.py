"""Corecturile de siguranta din 19.10.2026: SAP fara retrimitere dupa rotita, NWCE tot-sau-nimic,
reguli (plati, rotunjire KUSD, grupuri cu diacritice)."""
import datetime as dt

import pytest

from creditapp import groups, limits_book as lb, pipeline, rules, sap_gui
from creditapp.errors import AppError
from creditapp.portfolio import PaymentBehaviour

from test_sap_zbeu import VALUES, Elem, ZbeuSession


# ---------------------------------------------------------------- SAP
@pytest.fixture
def zbeu(monkeypatch, cfg):
    from test_sap_zbeu import _tpl
    holder = {}
    monkeypatch.setattr(sap_gui, 'connect', lambda c: (holder['s'], sap_gui.SapSessionInfo('P01', '100', 'UISPRID', '')))
    monkeypatch.setattr(sap_gui, 'POPUP_WAIT', 0)

    def go(session, values=VALUES, dry=False):
        holder['s'] = session
        return sap_gui.run(_tpl()[0], values, cfg, dry_run=dry)
    return go


class FewerPopups(ZbeuSession):
    """Dupa rotita SAP arata doar Approve + SCase (fara comentariu / atasamente)."""

    def call(self, name, sid, *a):
        e = super().call(name, sid, *a)
        if sid == 'wnd[0]/tbar[1]/btn[36]' and not hasattr(e, '_patched'):
            orig = e.call

            def press(n, *args):
                r = orig(n, *args)
                self.popups = ['CASE', 'APPROVE']
                return r
            e.call, e._patched = press, True
        return e


class Boom(Elem):
    def call(self, name, *args):
        raise RuntimeError('RPC server unavailable')


def test_missing_confirmations_after_gear_are_not_an_error(zbeu):
    s = FewerPopups()
    res = zbeu(s)
    assert res.ok and res.saved and s.executed and res.case_number == '12345'
    assert any('nu a mai aparut' in line for line in res.log)


def test_error_after_gear_is_marked_submitted(zbeu):
    s = ZbeuSession()
    s.elems['wnd[1]/usr/btnBUTTON_1'] = Boom(s, 'wnd[1]/usr/btnBUTTON_1')
    with pytest.raises(AppError) as e:
        zbeu(s)
    assert e.value.code == 'SAP_SUBMITTED' and 'DUPA SAVE' in e.value.message
    assert e.value.sap_result.saved and s.executed


def test_com_error_on_gear_press_is_marked_submitted(zbeu):
    s = ZbeuSession()
    s.elems['wnd[0]/tbar[1]/btn[36]'] = Boom(s, 'wnd[0]/tbar[1]/btn[36]')
    with pytest.raises(AppError) as e:
        zbeu(s)
    # apelul COM a esuat, dar cererea poate fi plecata: nu se spune "nimic salvat"
    assert e.value.code == 'SAP_SUBMITTED' and e.value.sap_result.submit_attempted


def test_error_before_gear_is_not_submitted(zbeu):
    s = ZbeuSession(bp_hits=())
    with pytest.raises(AppError) as e:
        zbeu(s)
    assert e.value.code != 'SAP_SUBMITTED' and not e.value.sap_result.submit_attempted


class _DB:
    def __init__(self):
        self.changes, self.events, self.saved = [], [], 0

    def change(self, *a):
        self.changes.append(a)

    def event(self, *a):
        self.events.append(a)

    def save_evaluation(self, ev):
        self.saved += 1


def _ev():
    ev = pipeline.Evaluation(partner='99000001', name='CLIENT TEST')
    ev.customer_code, ev.currency, ev.company_code = '99000001', 'EUR', '6675 - Italy'
    ev.decision = {'limit_eur': 180000, 'valid_till': '2027-10-31', 'grading': 9, 'mtm_kusd': 50.0}
    ev.nwce = {'status': 'ok'}
    ev.nwce_row = {'values': {'bp_code': 76014000.0}}
    ev.state = 'approved'
    return ev


def test_run_sap_keeps_submitted_flag_and_blocks_resend(monkeypatch, cfg):
    def fail_after_gear(tpl, values, c, **kw):
        res = sap_gui.SapRunResult(dry_run=False, saved=True, submit_attempted=True)
        e = AppError('SAP_SUBMITTED', 'DUPA SAVE / ROTITA ...: Step 36: field not on screen')
        e.sap_result = res
        raise e
    monkeypatch.setattr(sap_gui, 'run', fail_after_gear)
    ctx = pipeline.Context(cfg, _DB(), None)
    ev = _ev()
    pipeline.run_sap(ctx, ev, {}, dry_run=False)
    assert ev.sap['status'] == 'error' and ev.sap['submitted'] is True
    assert pipeline.sap_sent(ev) and ev.state == 'approved'
    # analistul confirma in SAP -> gata; sau confirma ca nu exista -> se poate retrimite
    pipeline.sap_confirm_manual(ctx, ev, True)
    assert ev.sap['status'] == 'ok' and ev.state == 'done'
    ev2 = _ev()
    ev2.sap = {'status': 'error', 'submitted': True, 'message': 'x'}
    pipeline.sap_confirm_manual(ctx, ev2, False)
    assert not pipeline.sap_sent(ev2) and ev2.state == 'approved'


def test_sap_sent_recognises_old_records():
    ev = _ev()
    ev.sap = {'status': 'error', 'message': 'Ecranul SAP difera: DUPA SAVE / ROTITA (cererea poate fi deja trimisa ...)'}
    assert pipeline.sap_sent(ev)                       # inregistrare dinainte de flag (eroare dupa rotita)
    ev.sap = {'status': 'error', 'message': 'SAP nu este deschis'}
    assert not pipeline.sap_sent(ev)
    ev.sap = {'status': 'ok'}
    assert pipeline.sap_sent(ev)


# ---------------------------------------------------------------- NWCE (Excel simulat)
HEADER = ['STATUS', 'Company code', 'Customer Code', 'Counterparty name', 'VAT code', 'Grading', 'Payment Term',
          'Open limit KUSD', 'Open limit K loc. curr.', 'MTM limit KUSD', 'Approved on mm/dd/yyyy', 'Valid till mm/dd/yyyy']


class Cell:
    def __init__(self, sheet, r, c):
        self.__dict__.update(sheet=sheet, r=r, c=c)

    @property
    def Value2(self):
        return self.sheet.cells.get((self.r, self.c))

    def __setattr__(self, name, value):
        if name != 'Value2':
            return super().__setattr__(name, value)
        if (self.r, self.c) in self.sheet.fail_on and value != self.sheet.cells.get((self.r, self.c)):
            raise RuntimeError('cell locked')
        self.sheet.cells[(self.r, self.c)] = value


class Sheet:
    def __init__(self, header, rows):
        self.cells, self.fail_on = {}, set()
        for c, h in enumerate(header, 1):
            self.cells[(1, c)] = h
        for r, row in enumerate(rows, 2):
            for c, v in enumerate(row, 1):
                self.cells[(r, c)] = v
        self.header = header

    def Cells(self, r, c):
        return Cell(self, r, c)


class _Rng:
    def __init__(self, v, row=1, col=1):
        self.Value2, self.Row, self.Column = v, row, col


class Lo:
    def __init__(self, sheet):
        self.HeaderRowRange = _Rng((tuple(sheet.header),))
        self.Range = _Rng(None)


class Wb:
    ReadOnly = False

    def __init__(self, sheet):
        self.sheet, self.saves = sheet, 0

    def Worksheets(self, name):
        sheet = self.sheet

        class Ws:
            def Cells(self, r, c):
                return sheet.Cells(r, c)

            def ListObjects(self, name):
                return Lo(sheet)
        return Ws()

    def Save(self):
        self.saves += 1

    def Close(self, *_):
        pass


@pytest.fixture
def nwce(monkeypatch):
    sheet = Sheet(HEADER, [['APPROVED', '6675 - Italy', 99000001.0, 'CLIENT TEST', 'IT001', '9', 'Max. 30 Days', 200.0, 180.0, 50.0, 46000.0, 46300.0],
                           ['APPROVED', '6675 - Italy', 99000002.0, 'CLIENT TEST 2', 'IT002', '9', 'Max. 30 Days', 60.0, 50.0, 150.0, 46000.0, 46300.0]])
    wb = Wb(sheet)

    class Xl:
        def open(self, url, read_only=False):
            return wb

        def quit(self, **kw):
            pass
    monkeypatch.setattr(lb, 'ExcelApp', Xl)

    def reload(cfg, url=None, **kw):
        cols = lb._map_columns(HEADER)
        rows = [lb.NwceRow(r, {k: sheet.cells.get((r, c)) for k, c in cols.items()}) for r in (2, 3)]
        return lb.Snapshot(rows, cols, dt.datetime.now(), 'test')
    monkeypatch.setattr(lb, 'load', reload)
    monkeypatch.setattr(lb.time, 'sleep', lambda s: None)
    return sheet, wb


def _upd(row=2, code='99000001', **changes):
    return lb.RowUpdate(partner=code, sheet_row=row, expected={}, changes=changes, customer_code=code, company_code='6675 - Italy')


def test_failed_row_is_rolled_back_and_others_still_saved(nwce, cfg):
    sheet, wb = nwce
    sheet.fail_on.add((2, 12))                      # Valid till de pe primul rand nu se poate scrie
    a = _upd(2, open_kloc=250, open_kusd=290, valid_till=dt.date(2027, 10, 31))
    b = _upd(3, '99000002', open_kloc=60)
    lb.apply([a, b], cfg)
    assert not a.ok and sheet.cells[(2, 9)] == 180.0 and sheet.cells[(2, 8)] == 200.0     # rand refacut, nu jumatate scris
    assert b.ok and sheet.cells[(3, 9)] == 60 and wb.saves == 1


def test_missing_column_fails_the_row(nwce, cfg):
    sheet, wb = nwce
    u = _upd(2, open_kloc=250, approval_level='LOCAL')        # "Approval level" lipseste din foaie
    lb.apply([u], cfg)
    assert not u.ok and 'Approval level' in u.message and wb.saves == 0 and sheet.cells[(2, 9)] == 180.0


def test_inactivation_requires_status_inactive(nwce, cfg):
    sheet, _wb = nwce
    u = _upd(2, **lb.inactivation_changes())
    u.inactivate = True
    lb.apply([u], cfg)                              # foaia simulata nu are formula STATUS -> ramane APPROVED
    assert not u.ok and 'INACTIVE' in u.message
    sheet.cells[(2, 1)] = 'INACTIVE'
    v = _upd(2, **lb.inactivation_changes())
    v.inactivate = True
    lb.apply([v], cfg)
    assert v.ok


# ---------------------------------------------------------------- reguli
def test_k_usd_rounds_half_up_like_excel():
    assert rules.k_usd(845_000, 1.0, 10) == 850       # Python round() ar da 840
    assert rules.k_usd(800_000, 1.12, 10) == 900
    assert rules.k_usd(844_000, 1.0, 10) == 840


def test_overdue_or_returns_floor_to_d_even_with_few_invoices(cfg):
    pb = PaymentBehaviour(recent_invoices=1, baseline_invoices=1, oldest_overdue_days=120)
    g, why = rules.payment_grade(pb, cfg)
    assert g == 'D' and '120' in why
    pb2 = PaymentBehaviour(recent_invoices=1, baseline_invoices=0, payment_returns=2)
    assert rules.payment_grade(pb2, cfg)[0] == 'D'
    assert rules.payment_grade(PaymentBehaviour(recent_invoices=1, baseline_invoices=1), cfg)[0] == 'C'


def test_group_key_ignores_accents():
    assert groups.norm_group('NESTLÉ') == groups.norm_group('Nestle') == 'NESTLE'


# ---------------------------------------------------------------- panoul de detalii: client vs grup
def test_details_table_separates_client_and_group_totals():
    import os
    os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
    pytest.importorskip('PyQt5.QtWidgets')
    from creditapp.portfolio import Counterparty
    from creditapp.ui import dialogs
    from creditapp.ui.models import Row

    def row(sr, name, code, vat, kloc, kusd, mtm, total, grade):
        nr = lb.NwceRow(sr, {'status': 'UNDER REVIEW', 'company_code': '6675 - Italy', 'customer_code': float(code), 'name': name,
                             'vat': vat, 'group': 'Monaldi', 'open_kloc': kloc, 'open_kusd': kusd, 'mtm_kusd': mtm,
                             'total_kusd': total, 'grading': grade, 'valid_till': 46326.0})
        r = Row(Counterparty(partner=str(code), name=name, vat=vat))
        r.nwce, r.client, r.group_name = nr, 'VAT:' + vat, 'Monaldi'
        return r
    antiche = row(6238, 'ANTICHE FATTORIE MARCHIGIANE S.R.L.', 76029287, 'IT02557800394', 1100.0, 1300.0, 350.0, 1650.0, 8.0)
    monaldi = row(6237, 'MONALDI ITALIA SRL', 76021993, 'IT04195860236', 1800.0, 2200.0, 400.0, 2600.0, 7.0)
    html = dialogs._group_html([antiche, monaldi], antiche.cp)
    assert 'grupul Monaldi' in html and 'MONALDI ITALIA SRL' in html and 'ANTICHE FATTORIE' in html
    assert 'Total client' in html and '1.650' in html and 'TOTAL grup' in html and '4.250' in html
    single = dialogs._group_html([antiche], antiche.cp)
    assert 'TOTAL client' in single and 'grupul' not in single


# ---------------------------------------------------------------- folderul clientului in folderele de grup
def test_client_folder_found_inside_italian_and_spanish_group_folders(tmp_path):
    from creditapp import client_folders as cf
    (tmp_path / 'GRUPPO Marseglia - BRC' / 'CASA OLEARIA ITALIANA SPA' / '2025').mkdir(parents=True)
    (tmp_path / 'GRUPPO Marseglia - BRC' / 'ITAL BI-OIL SRL (Gruppo Marseglia)').mkdir(parents=True)
    (tmp_path / 'GRUPO AVICOLA - BRC' / 'GRANJA LOS PINOS SL').mkdir(parents=True)
    (tmp_path / 'CARCO GRUP SRL').mkdir()
    cf.forget_listing()
    r = cf.resolve_client_folder(tmp_path, ['CASA OLEARIA ITALIANA S.P.A'], 'CASA OLEARIA ITALIANA S.P.A')
    assert r.exists and r.path.parent.name == 'GRUPPO Marseglia - BRC'
    assert cf.resolve_client_folder(tmp_path, ['ITAL BI OIL S.R.L.'], 'x').exists
    assert cf.resolve_client_folder(tmp_path, ['GRANJA LOS PINOS S.L.'], 'x').exists
    assert cf.is_group_folder('CEREAL DOCKS Group') and cf.is_group_folder('Groupe Y')
    assert not cf.is_group_folder('CARCO GRUP SRL')            # firma romaneasca, nu folder de grup


def test_nwce_group_wins_over_open_contracts_group(cfg):
    """M.B. MANGIMI / MIGNINI scosi din grup in NWCE (n/a), dar inca "MB MANGIMI GROUP" in Open Contracts (VAT Italy)."""
    import os
    os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
    QtWidgets = pytest.importorskip('PyQt5.QtWidgets')
    _app = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    assert _app is not None
    from creditapp.portfolio import Counterparty
    from creditapp.ui.models import ClientsModel

    class Pf:
        counterparties = {
            '76019551': Counterparty(partner='76019551', name='M.B. MANGIMI S.P.A.', vat='IT00139950406', group='MB MANGIMI GROUP'),
            '76019553': Counterparty(partner='76019553', name='MIGNINI E PETRINI S.R.L.', vat='IT01659710543', group='MB MANGIMI GROUP'),
            '76000001': Counterparty(partner='76000001', name='FARA NWCE A', vat='IT00000000011', group='GRUP X'),
            '76000002': Counterparty(partner='76000002', name='FARA NWCE B', vat='IT00000000022', group='GRUP X'),
        }
    rows = [lb.NwceRow(5913, {'company_code': '6675 - Italy', 'customer_code': 76019551.0, 'name': 'M.B. MANGIMI S.P.A.',
                              'vat': 'IT00139950406', 'group': 'n/a'}),
            lb.NwceRow(6136, {'company_code': '6675 - Italy', 'customer_code': 76019553.0, 'name': 'MIGNINI E PETRINI S.P.A.',
                              'vat': 'IT01659710543', 'group': 'n/a'})]
    snap = lb.Snapshot(rows, {}, dt.datetime.now(), 'test').index('IT')
    m = ClientsModel()
    m.load(Pf(), {}, snap, '6675 - Italy', 'IT', cfg)
    by = m.by_partner
    assert len(by['76019551'].group_rows) == 1 and len(by['76019553'].group_rows) == 1     # NWCE: n/a -> separati
    assert len(by['76000001'].group_rows) == 2                                             # fara NWCE: grupul din Open Contracts


# ---------------------------------------------------------------- Annual Review: printscreen din scorecard la Financials
def test_annual_review_uses_summary_picture_or_falls_back(monkeypatch, tmp_path):
    import base64
    from docx import Document
    from creditapp import review_doc
    png = base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==')
    c = groups.ReviewCounterparty(name='CLIENT TEST', grade=8, open_usd=1, mtm_usd=1, total_usd=2, new_open_usd=1, new_mtm_usd=1, new_total_usd=2)
    data = {'group': 'CLIENT TEST', 'total_new_usd': 2, 'grade': 8, 'counterparties': [c], 'report': None, 'analyst': 'IS',
            'scorecard_file': r'C:\x\Scorecard CLIENT TEST 2025.xlsx'}

    def pic(path, out):
        out.write_bytes(png)
        return out
    monkeypatch.setattr(review_doc, 'summary_picture', pic)
    review_doc.build(tmp_path / 'a.docx', data)
    d = Document(str(tmp_path / 'a.docx'))
    assert len(d.inline_shapes) == 1 and len(d.tables) == 1          # poza in loc de tabelul foii Summary
    # poza nu se poate face -> tabelul foii Summary (daca scorecardul se poate citi), documentul se genereaza oricum
    monkeypatch.setattr(review_doc, 'summary_picture', lambda path, out: None)
    monkeypatch.setattr(review_doc, 'scorecard_summary', lambda path: [(12, ['Sales', '', '1', '2', '3'])])
    review_doc.build(tmp_path / 'b.docx', data)
    d = Document(str(tmp_path / 'b.docx'))
    assert len(d.inline_shapes) == 0 and len(d.tables) == 2


def test_annual_review_follows_the_approved_model(monkeypatch, tmp_path):
    """Modelul Annual Review aprobat de analist (M.B. MANGIMI, 19.10.2026)."""
    from docx import Document
    from creditapp import review_doc
    assert review_doc.commodity_families({'00 Soybean meal 48% GMO': 49, 'Any Corn': 31, 'Any Feed Wheat': 18, 'IT Feed Wheat': 1,
                                          '00 Soybean meal hipro': 12, 'Any Soybean crude oil GMO': 7}) == ['SBM', 'Corn', 'Wheat', 'Crude oil']
    rep = {'companySummary': {'businessName': 'MB MANGIMI SPA', 'country': 'IT',
                              'mainActivity': {'description': 'Manufacture of prepared feeds for farm animals'}},
           'alternateSummary': {'contactAddress': {'city': 'LONGIANO'}, 'incorporationDate': '1966-05-25T00:00:00Z'},
           'otherInformation': {'employeesInformation': [{'numberOfEmployees': 63}]}}
    assert review_doc._about_text(rep).startswith(' is an Italian company founded in 1966 and headquartered in Longiano, Italy.')
    monkeypatch.setattr(review_doc, 'summary_picture', lambda path, out: None)
    monkeypatch.setattr(review_doc, 'scorecard_summary', lambda path: None)
    monkeypatch.setattr(review_doc, 'scorecard_figures', lambda path: {'year': 2025, 'equity': 18_536_200, 'net_income': 1_421_555,
                                                                        'equity30': 5_560_860, 'grade': 8})
    c = groups.ReviewCounterparty(name='M.B. MANGIMI S.P.A', grade=8, open_usd=5_000_000, mtm_usd=2_800_000, total_usd=7_800_000,
                                  new_open_usd=5_060_000, new_mtm_usd=2_800_000, new_total_usd=7_860_000)
    data = {'group': 'M.B. MANGIMI S.P.A.', 'total_new_usd': 7_860_000, 'grade': 8, 'grade_source': 'scorecard Creditsafe',
            'counterparties': [c], 'report': None, 'analyst': 'IS', 'compliance': 'OK', 'insurance_usd': 3_000_000,
            'scorecard_file': r'C:\x\Scorecard.xlsx', 'limit_change': 'same', 'authority': 'GLOBAL',
            'relationship': ['Commercial relationship since 2014.', 'Payment terms: Max. 30 Days.']}
    review_doc.build(tmp_path / 'ar.docx', data)
    text = [p.text for p in Document(str(tmp_path / 'ar.docx')).paragraphs]
    assert 'Total Limit Requested: USD 7.9 million (equity scenario)' in text and 'Grade: 8' in text
    assert 'Latest Fiscal Year: December 2025' in text
    assert not any(t.startswith('Approval required') for t in text)                     # nu apare in model
    assert any('we recommend maintaining the existing credit limit for the next 12 months, with an adjustment to reflect '
               'the exchange rate evolution.' in t for t in text)
    assert 'External Credit Ratings' not in text                                         # fara ratinguri: fara sectiune
    assert "Shareholders' equity of approximately USD 18.5 million;" in text
    assert 'Net result of approximately USD 1.4 million in FY2025;' in text
    assert text[-1] == 'I support the requested combined limit of USD 7.9 million (Grade 8, equity scenario) for M.B. MANGIMI S.P.A.'


# ---------------------------------------------------------------- aprobare pe alt canal: NWCE da, SAP la alegere
def _escalated_ev():
    ev = pipeline.Evaluation(partner='99000003', name='CLIENT MARE')
    ev.customer_code, ev.currency, ev.company_code, ev.scorecard = '99000003', 'EUR', '6675 - Italy', {'grade': 8}
    ev.nwce_row = {'sheet_row': 10, 'values': {'open_kloc': 5000.0, 'open_kusd': 5800.0, 'mtm_kusd': 2800.0, 'total_kusd': 8600.0,
                                               'grading': 8.0, 'approval_level': 'LOCAL', 'payment_term': 'Max. 30 Days'}}
    ev.review = {'route': 'escalate', 'new_open_local': 5_000_000, 'new_open_kusd': 5860, 'mtm_kusd': 2800, 'usd_rate': 1.172}
    ev.state = 'evaluated'
    return ev


def test_external_approval_decision_without_sap(cfg):
    from creditapp import review
    ev = _escalated_ev()
    dec, auth, rv = review.external_decision(ev, cfg, 1.172, 0.0, 'BEMEA - Aylin', dt.date(2026, 10, 20), False, 'Approved by email')
    assert dec['sap_skip'] is True and dec['external_approval'] == {'by': 'BEMEA - Aylin', 'on': '2026-10-20'}
    assert dec['approved_on'] == '2026-10-20' and dec['limit_eur'] == 5_000_000 and 'comments' in dec['fields']
    assert dec['comments'] == 'Approved by email' and dec['approval_level']        # nivelul de aprobare se scrie in NWCE
    dec2, _a, _r = review.external_decision(ev, cfg, 1.172, 0.0, 'GLOBAL', dt.date(2026, 10, 20), True)
    assert dec2['sap_skip'] is False and 'comments' not in dec2['fields']


def test_sap_skip_finishes_after_nwce_and_can_be_changed(cfg):
    ctx = pipeline.Context(cfg, _DB(), None)
    ev = _escalated_ev()
    ev.decision, ev.state = {'limit_eur': 5_000_000, 'sap_skip': True, 'fields': []}, 'approved'
    ev.nwce = {'status': 'ok'}
    pipeline._maybe_done(ev)
    assert ev.state == 'done' and pipeline.sap_skipped(ev)                     # gata fara SAP
    pipeline.set_sap_skip(ctx, ev, False)                                      # analistul vrea totusi SAP
    assert ev.state == 'approved' and not pipeline.sap_skipped(ev)
    pipeline.set_sap_skip(ctx, ev, True)
    assert ev.state == 'done'
    ev.sap = {'status': 'ok'}                                                  # plecat deja in SAP: nu se mai schimba
    pipeline.set_sap_skip(ctx, ev, False)
    assert pipeline.sap_skipped(ev)


def test_stage_and_dialog_for_external_approval(cfg):
    import os
    os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
    QtWidgets = pytest.importorskip('PyQt5.QtWidgets')
    _app = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    assert _app is not None
    from creditapp.portfolio import Counterparty
    from creditapp.ui import dialogs
    from creditapp.ui.models import REVIEWED_STAGES, Row, stage
    r = Row(Counterparty(partner='99000003', name='CLIENT MARE'))
    r.ev = _escalated_ev()
    assert stage(r, '6675 - Italy') == 'escalate'
    r.ev.decision, r.ev.state, r.ev.nwce = {'limit_eur': 1, 'sap_skip': True}, 'approved', {'status': 'ok'}
    assert stage(r, '6675 - Italy') == 'done_no_sap' and 'done_no_sap' in REVIEWED_STAGES
    r.ev.decision['sap_skip'] = False
    assert stage(r, '6675 - Italy') == 'sap'
    dlg = dialogs.ExternalApprovalDialog(None, [['CLIENT MARE', '6675', '5.000.000 EUR', '2.800.000', 8, '8.660.000', 'BEMEA - Aylin']],
                                         'BEMEA - Aylin', cfg.get('sap', 'afterExternalApproval'))
    v = dlg.values()
    assert v['by'] == 'BEMEA - Aylin' and v['write_sap'] is False and v['on'] == dt.date.today()   # implicit: fara SAP


def test_old_config_global_is_renamed_to_global_alex(tmp_path):
    """BEMEA - Aylin si GLOBAL - Alex sunt niveluri diferite; config.json-urile vechi ("GLOBAL") se actualizeaza la incarcare."""
    import json
    from creditapp import rules
    from creditapp.config import Config
    p = tmp_path / 'config.json'
    p.write_text(json.dumps({'approval': {'chainAbove': ['Valentina / Bea', 'BEMEA - Aylin', 'GLOBAL'],
                                          'matrix': [{'name': 'Ionut Spridon', 'nwceLevel': 'LOCAL', 'limits': [5500000] * 10 + [0]},
                                                     {'name': 'Valentina / Bea', 'nwceLevel': 'LOCAL', 'limits': [10000000] * 10 + [0]},
                                                     {'name': 'BEMEA - Aylin', 'nwceLevel': 'BEMEA', 'limits': [20000000] * 10 + [0]},
                                                     {'name': 'GLOBAL', 'nwceLevel': 'GLOBAL', 'limits': [60000000] * 10 + [0]}]}}),
                 encoding='utf-8')
    cfg = Config.load(p)
    assert cfg.get('approval', 'chainAbove')[-1] == 'GLOBAL - Alex'
    a = rules.approval_authority(6, 30_000_000, cfg)
    assert a.name == 'GLOBAL - Alex' and a.nwce_level == 'GLOBAL'
    b = rules.approval_authority(6, 15_000_000, cfg)
    assert b.name == 'BEMEA - Aylin' and b.nwce_level == 'BEMEA'


# ---------------------------------------------------------------- Creditsafe: acelasi VAT, sedii vechi radiate
def _casa_olearia(statuses):
    ids = ['IT-0-VR401686', 'IT-0-BR66237', 'IT-0-MI1946204', 'IT-0-VE449671']
    return [{'id': i, 'name': 'CASA OLEARIA ITALIANA S.P.A.', 'status': s, 'vatNo': ['01458780747'], 'address': {},
             'dateOfLatestAccounts': '2025-12-31T00:00:00Z'} for i, s in zip(ids, statuses)]


def _prepare_with(cfg, res):
    from creditapp.portfolio import Counterparty

    class Cs:
        def find_by_vat(self, vat, country):
            return res

        def search(self, *a, **k):
            return []
    ctx = pipeline.Context(cfg, _DB(), Cs())
    return pipeline.prepare(ctx, Counterparty(partner='74012187', name='CASA OLEARIA ITALIANA S.P.A', vat='IT01458780747'))


def test_only_registered_companies_count(cfg):
    ev = _prepare_with(cfg, _casa_olearia(['NonActive', 'NonActive', 'NonActive', 'Active']))
    assert ev.state == 'prepared' and ev.connect_id == 'IT-0-VE449671'           # singura Registered / Current HQ
    assert ev.cs_candidates[0]['id'] == 'IT-0-VE449671'                           # inregistratele primele in lista
    assert not any(w.startswith('Creditsafe a gasit') for w in ev.warnings)       # nimic de decis: fara fereastra
    assert any('Celelalte 3 sunt sedii vechi, radiate' in w for w in ev.warnings)


def test_several_registered_take_any_none_registered_asks(cfg):
    ev = _prepare_with(cfg, _casa_olearia(['Active', 'NonActive', 'Registered', 'NonActive']))
    assert ev.connect_id in ('IT-0-VR401686', 'IT-0-MI1946204')
    assert not any(w.startswith('Creditsafe a gasit') for w in ev.warnings)
    ev = _prepare_with(cfg, _casa_olearia(['NonActive'] * 4))
    assert any(w.startswith('Creditsafe a gasit 4 firme') and 'niciuna inregistrata' in w for w in ev.warnings)


# ---------------------------------------------------------------- Proces initiat -> "Evalueaza din nou"
def test_copy_to_destination_replaces_or_falls_back_when_open(tmp_path, monkeypatch):
    from creditapp import fsutil
    src, dst = tmp_path / 'new.xlsx', tmp_path / 'out' / 'Scorecard X 2025.xlsx'
    dst.parent.mkdir()
    src.write_text('nou')
    dst.write_text('vechi')
    assert fsutil.copy_to_destination(src, dst, replace=True) == dst and dst.read_text() == 'nou'
    assert fsutil.copy_to_destination(src, dst).name == 'Scorecard X 2025 (2).xlsx'           # fara replace: alaturi, ca inainte
    real = fsutil.copy_file

    def locked(s, d):
        if str(d) == str(dst):
            raise OSError('The process cannot access the file because it is being used by another process')
        return real(s, d)
    monkeypatch.setattr(fsutil, 'copy_file', locked)
    out = fsutil.copy_to_destination(src, dst, replace=True)                                   # deschis in Excel
    assert out != dst and out.exists() and dst.read_text() == 'nou'


def test_redo_leaves_process_tab_and_forces_new_report_and_scorecard(cfg, monkeypatch):
    import os
    os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
    pytest.importorskip('PyQt5.QtWidgets')
    from creditapp import scorecard
    from creditapp.portfolio import Counterparty
    from creditapp.ui.models import PROCESS_STAGES, Row, stage
    ctx = pipeline.Context(cfg, _DB(), None)
    r = Row(Counterparty(partner='99000004', name='CLIENT REFACUT'))
    r.ev = _escalated_ev()
    r.ev.review['route'] = 'auto'
    assert stage(r, '6675 - Italy') in PROCESS_STAGES
    pipeline.mark_redo(ctx, r.ev)
    assert stage(r, '6675 - Italy') not in PROCESS_STAGES + ('escalate',)                     # iese din fila
    assert pipeline.wants_redo(r.ev) and r.ev.decision is None
    seen = {}
    monkeypatch.setattr(scorecard, 'fill', lambda *a, replace=False, **k: seen.setdefault('replace', replace))
    pipeline._fill_with_restart(ctx, {}, None, 'd', 'f.xlsx', replace=True)
    assert seen['replace'] is True
