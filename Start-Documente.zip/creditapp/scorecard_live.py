"""Scorecardul clientului deschis "live": analistul schimba criteriile subiective si vede imediat grade-ul recalculat
de Excel (aceeasi formula ca in fisier). La "Next" fisierul se salveaza cu valorile alese; la anulare se inchide fara salvare."""
from pathlib import Path

from . import log
from .errors import AppError
from .excel_com import XL_CALC_AUTO, ExcelApp, retry
from .scorecard import CRITERIA_CELLS, POINTS_CELL

_log = log.get('scorecard')

# celulele de intrare ale criteriilor subiective (foaia Scale&Subjective) - aceleasi ca la completarea automata
INPUT_CELLS = {'financial_reporting': 'D20', 'experience': 'H20', 'payment': 'D28'}   # 14. Country Rating (H37): nu se schimba


class LiveScorecard:
    def __init__(self, path, excel=None):
        """excel: o instanta ExcelApp reutilizata (mai rapid la modificari succesive); altfel se porneste una proprie."""
        self.path = Path(path)
        self.wb = None
        if not self.path.exists():
            raise AppError('TEMPLATE', f'Scorecard not found: {self.path}')
        self.own_excel = excel is None
        self.excel = excel or ExcelApp(visible=False)
        try:
            self.wb = self.excel.open(self.path)
            # fiecare apel catre Excel cu reincercare: imediat dupa deschidere Excel poate respinge comenzile cateva clipe
            if retry(lambda: self.wb.ReadOnly):
                raise AppError('NO_ACCESS', f'Scorecardul e deschis în alt Excel ({self.path.name}). Închide-l și încearcă din nou.')
            retry(lambda: setattr(self.excel.xl, 'Calculation', XL_CALC_AUTO))
            self.ss = retry(lambda: self.wb.Worksheets('Scale&Subjective'))
            self.summ = retry(lambda: self.wb.Worksheets('Summary'))
        except Exception:
            self.close()
            raise
        self.changed = False

    def inputs(self):
        return retry(lambda: {k: str(self.ss.Range(a).Text).strip() for k, a in INPUT_CELLS.items()})

    def set(self, **values):
        """Scrie criteriile si recalculeaza. Intoarce rezultatul (grade, scala, puncte, equity, 30% equity)."""
        for k, v in values.items():
            if k in INPUT_CELLS and v not in (None, ''):
                retry(lambda a=INPUT_CELLS[k], x=v: setattr(self.ss.Range(a), 'Formula', str(x)))
                self.changed = True
        retry(lambda: self.excel.xl.Calculate())
        return self.result()

    def result(self):
        return retry(self._result)

    def _result(self):
        scale = str(self.summ.Range('D6').Text).strip()
        cell = POINTS_CELL.get(scale)

        def num(addr):
            v = self.summ.Range(addr).Value2
            return float(v) if isinstance(v, (int, float)) else None
        return {
            'grade': str(self.summ.Range('E6').Text).strip(), 'scale': scale,
            'points': str(self.ss.Range(cell).Text).strip() if cell else '',
            'equity_usd': num('D18'), 'equity30_usd': num('D20'),
            'criteria': {k: str(self.ss.Range(a).Text).strip() for k, a in CRITERIA_CELLS.items()},
        }

    def save(self):
        retry(lambda: self.summ.Activate())
        retry(lambda: self.wb.Save())
        self.changed = False

    def close(self):
        self.ss = self.summ = None          # referintele COM la foi: altfel Excel nu se poate inchide (asteptare + oprire fortata)
        try:
            if getattr(self, 'wb', None) is not None:
                self.wb.Close(False)
        except Exception:
            pass
        self.wb = None
        if not self.own_excel:
            return
        try:
            self.excel.quit()
        except Exception as e:
            _log.warning('Excel quit: %s', e)
