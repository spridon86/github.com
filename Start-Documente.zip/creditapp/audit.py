"""Baza de date locala (SQLite, data/creditlimits.db): evaluari, evenimente si orice modificare
facuta in NWCE / SAP, cu valoarea veche si cea noua. Nimic nu se sterge."""
import datetime as dt
import json
import sqlite3
import threading

from . import paths

SCHEMA = """
CREATE TABLE IF NOT EXISTS evaluations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    partner TEXT NOT NULL,
    name TEXT,
    created TEXT NOT NULL,
    updated TEXT NOT NULL,
    state TEXT NOT NULL,
    data TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_eval_partner ON evaluations(partner, id);
CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    evaluation_id INTEGER,
    partner TEXT,
    ts TEXT NOT NULL,
    level TEXT NOT NULL,
    step TEXT,
    message TEXT,
    details TEXT
);
CREATE INDEX IF NOT EXISTS ix_events_eval ON events(evaluation_id);
CREATE TABLE IF NOT EXISTS changes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    evaluation_id INTEGER,
    partner TEXT,
    ts TEXT NOT NULL,
    target TEXT NOT NULL,
    field TEXT,
    old_value TEXT,
    new_value TEXT,
    status TEXT,
    message TEXT
);
CREATE INDEX IF NOT EXISTS ix_changes_partner ON changes(partner);
"""


def _now():
    return dt.datetime.now().isoformat(timespec='seconds')


def _json_default(o):
    if isinstance(o, (dt.date, dt.datetime)):
        return o.isoformat()
    if hasattr(o, '__fspath__'):
        return str(o)
    if hasattr(o, '__dict__'):
        return o.__dict__
    return str(o)


class AuditDB:
    def __init__(self, path=None):
        paths.ensure_dirs()
        self.path = path or paths.DB_FILE
        self._lock = threading.RLock()
        self.conn = sqlite3.connect(str(self.path), check_same_thread=False, timeout=30)
        self.conn.row_factory = sqlite3.Row
        with self._lock:
            self.conn.executescript(SCHEMA)
            self.conn.commit()

    def close(self):
        with self._lock:
            self.conn.close()

    # --- evaluari
    def save_evaluation(self, ev):
        """Insereaza sau actualizeaza (ev.id). Intoarce id-ul."""
        data = json.dumps(ev.to_dict(), default=_json_default, ensure_ascii=False)
        with self._lock:
            if ev.id:
                self.conn.execute('UPDATE evaluations SET name=?, updated=?, state=?, data=? WHERE id=?',
                                  (ev.name, _now(), ev.state, data, ev.id))
            else:
                cur = self.conn.execute('INSERT INTO evaluations(partner, name, created, updated, state, data) VALUES (?,?,?,?,?,?)',
                                        (ev.partner, ev.name, ev.created or _now(), _now(), ev.state, data))
                ev.id = cur.lastrowid
            self.conn.commit()
        return ev.id

    def latest_evaluations(self):
        """partner -> (id, created, state, data dict) pentru ultima evaluare a fiecarui partener."""
        with self._lock:
            rows = self.conn.execute(
                'SELECT e.* FROM evaluations e JOIN (SELECT partner, MAX(id) mid FROM evaluations GROUP BY partner) m ON e.id = m.mid').fetchall()
        return {r['partner']: (r['id'], r['created'], r['state'], json.loads(r['data'])) for r in rows}

    def history(self, partner):
        with self._lock:
            return [dict(r) for r in self.conn.execute(
                'SELECT id, created, updated, state FROM evaluations WHERE partner=? ORDER BY id DESC', (partner,)).fetchall()]

    # --- evenimente
    def event(self, ev_id, partner, level, step, message, details=''):
        with self._lock:
            self.conn.execute('INSERT INTO events(evaluation_id, partner, ts, level, step, message, details) VALUES (?,?,?,?,?,?,?)',
                              (ev_id, partner, _now(), level, step, message, details))
            self.conn.commit()

    def events(self, ev_id):
        with self._lock:
            return [dict(r) for r in self.conn.execute(
                'SELECT ts, level, step, message, details FROM events WHERE evaluation_id=? ORDER BY id', (ev_id,)).fetchall()]

    # --- modificari NWCE / SAP
    def change(self, ev_id, partner, target, field, old, new, status, message=''):
        with self._lock:
            self.conn.execute('INSERT INTO changes(evaluation_id, partner, ts, target, field, old_value, new_value, status, message) VALUES (?,?,?,?,?,?,?,?,?)',
                              (ev_id, partner, _now(), target, field, None if old is None else str(old), None if new is None else str(new), status, message))
            self.conn.commit()

    def changes(self, partner=None, since=None):
        q, args = 'SELECT * FROM changes WHERE 1=1', []
        if partner:
            q += ' AND partner=?'
            args.append(partner)
        if since:
            q += ' AND ts>=?'
            args.append(since)
        with self._lock:
            return [dict(r) for r in self.conn.execute(q + ' ORDER BY id', args).fetchall()]
