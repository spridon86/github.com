"""Annual Review (Word) pentru un client / grup: datele documentului (relatia cu Bunge, cifra de afaceri, financiarele din
scorecard...) si salvarea in folderul clientului. Folosit de Credit Limits Tool (revizuire / evaluare de grup) si de
"Documente client" (reinnoire: limitele noi = cele actuale)."""
import datetime as dt
import json
import re
from pathlib import Path

from . import client_folders, fsutil, groups, invoices, limits_book, log, paths, review_doc, rules

_log = log.get('annual_review')


def scorecard_file(ev):
    """Scorecardul evaluarii; daca a fost sters / redenumit (ex. duplicatul "(2)"), cel mai nou Scorecard*.xlsx din folderul clientului."""
    if ev is None:
        return None
    p = (ev.files or {}).get('scorecard')
    if p and Path(p).exists():
        return p
    for folder in {Path(p).parent if p else None, Path(ev.dest_dir) if ev.dest_dir else None} - {None}:
        found = sorted(folder.glob('Scorecard*.xlsx'), key=lambda f: f.stat().st_mtime, reverse=True) if folder.is_dir() else []
        if found:
            return str(found[0])
    return p


def load_invoices(cfg):
    """Rezumatul facturilor (din cache; refacut doar daca All Invoices s-a schimbat) - pentru "Turnover"; None daca nu se poate."""
    try:
        return invoices.load(Path(paths.expand(cfg.get('portfolio', 'invoicesPath'))))
    except Exception as e:
        _log.warning('Turnover: invoices not loaded (%s)', e)
        return None


def relationship(lines, inv):
    """Relationship with Bunge (modelul aprobat): since / Commodity / Payment terms / Turnover / Payment behaviour."""
    rel = []
    first = None
    for m in lines:
        for d in (m.row.cp.first_contract, (m.row.cp.payment.first_activity if m.row.cp.payment else None)):
            if d and (first is None or d < first):
                first = d
    ev_exp = next((m.row.ev.inputs.get('experience', {}).get('why') for m in lines if m.row.ev and m.row.ev.inputs), None)
    since = re.search(r'Relatie din \d{2}\.\d{2}\.(\d{4})', ev_exp or '')
    if since or first:
        rel.append(f'Commercial relationship since {since.group(1) if since else first.year}.')
    counts = {}
    for m in lines:
        for k, n in (m.row.cp.commodities or {}).items():
            counts[k] = counts.get(k, 0) + n
    fams = review_doc.commodity_families(counts)
    rel.append('Commodity: ' + (', '.join(fams) if fams else '[de completat]'))
    terms = sorted({str(m.row.nwce.get('payment_term')).strip() for m in lines if m.row.nwce and m.row.nwce.get('payment_term')})
    if terms:
        rel.append('Payment terms: ' + ', '.join(terms) + '.')
    ty = dt.date.today().year - 1
    turn = [invoices.turnover_usd(inv, (limits_book._code(m.row.nwce.get('customer_code')) if m.row.nwce else '') or m.row.cp.partner,
                                  m.row.cp.vat, ty) for m in lines]
    turn = [t for t in turn if t is not None]
    if turn:
        t = sum(turn) / 1e6
        rel.append(f'Turnover {ty}: {t:,.0f} Mio USD' if t >= 10 else f'Turnover {ty}: {t:,.1f} Mio USD')
    else:
        rel.append(f'Turnover {ty}: [de completat] Mio USD')
    pbs = [m.row.cp.payment for m in lines if m.row.cp.payment]
    if pbs:
        rel.append(f'Payment behaviour: {pbs[0].trend_text or pbs[0].trend or "[de completat]"}')
    return rel


def create(cfg, data, inv=None, replace=False):
    """Genereaza Annual Review-ul. data: title, grade, grade_source, lines (groups.MemberLine), authority, compliance,
    parent_ev, limit_change, equity_scenario, optional dest_dir (folderul unde se salveaza).
    replace=True: inlocuieste documentul cu acelasi nume (daca nu e deschis in Word), in loc de "... (2)". Intoarce calea."""
    lines = data['lines']
    pev = data.get('parent_ev')
    sc_file = scorecard_file(pev)
    if sc_file and str(data.get('grade_source') or '').startswith('scorecard'):
        # gradul din scorecardul curent (poate fi recalculat dupa evaluare) - acelasi ca in printscreen-ul de la Financials
        g = review_doc.scorecard_figures(sc_file).get('grade')
        if g:
            data = dict(data, grade=g)
    cps = groups.review_counterparties(lines, data['grade'])
    report = None
    if pev and pev.report_json:
        try:
            report = json.loads(Path(pev.report_json).read_text(encoding='utf-8'))['report']
        except (OSError, ValueError, KeyError) as e:     # fara raport: documentul iese fara financiare
            _log.warning('Annual review without financials (%s)', e)
    fy = ''
    if report:
        from . import mapping
        st = mapping.statements(report, 1)
        if st:
            fy = mapping.parse_date(st[0]['yearEndDate']).strftime('%B %Y')
    ins = 0.0
    for m in lines:
        v = m.row.nwce.get('insurance') if m.row.nwce else None
        if isinstance(v, (int, float)):
            ins += float(v) * 1000
    a = data.get('authority')
    doc_data = {
        'group': data['title'], 'total_new_usd': sum(m.new_total_usd for m in lines), 'grade': data['grade'],
        'grade_source': data.get('grade_source'), 'compliance': data.get('compliance') or 'OK', 'fiscal_year': fy,
        'counterparties': cps, 'authority': a.text_en() if a else '', 'relationship': relationship(lines, inv),
        'report': report, 'analyst': cfg.get('analyst', 'name'), 'insurance_usd': ins, 'scorecard_file': sc_file,
        'limit_change': data.get('limit_change'),
        'equity_scenario': data.get('equity_scenario', ((pev.review or {}).get('equity_scenario') if pev else False)),
    }
    year = dt.date.today().year
    if data.get('dest_dir'):
        dest = Path(data['dest_dir'])
    else:
        lead = lines[0].row if lines else None
        names = [data['title']] + ([lead.cp.name] if lead else [])
        dest = client_folders.resolve_client_folder(cfg.counterparties_root, names, data['title']).path / str(year)
    dest.mkdir(parents=True, exist_ok=True)
    out = dest / f'Annual Review {fsutil.safe_name(data["title"])} {year}.docx'
    if out.exists() and (not replace or _locked(out)):
        out = fsutil.unique_path(out)              # pastrat; deschis in Word -> alaturi, cu nume liber
    review_doc.build(out, doc_data)
    return out


def _locked(path):
    try:
        with open(path, 'r+b'):
            return False
    except OSError:
        return True


def renewal(cfg, firm_rows, cp, ev, title, inv=None, replace=True):
    """Annual Review de reinnoire (din "Documente client"): toate randurile NWCE ale firmei, limitele noi = cele actuale,
    gradul din scorecard (sau din NWCE), cine aproba din matricea "Limits by grade". firm_rows: randurile NWCE ale firmei."""
    from types import SimpleNamespace
    rows = [SimpleNamespace(cp=cp, nwce=n, ev=ev) for n in firm_rows]
    lines = groups.member_lines(rows)
    if ev is not None and ev.grade is not None:
        grade, src = ev.grade, 'scorecard Creditsafe'
    else:
        grade = next((rules.grade_number(n.get('grading')) for n in firm_rows if rules.grade_number(n.get('grading'))), None)
        src = 'NWCE'
    a = rules.approval_authority(grade, sum(m.new_total_usd for m in lines), cfg) if grade else None
    data = {'title': title, 'grade': grade or '[de completat]', 'grade_source': src, 'lines': lines, 'authority': a,
            'compliance': 'OK', 'parent_ev': ev, 'limit_change': 'same', 'equity_scenario': False,
            'dest_dir': ev.dest_dir if ev is not None and ev.dest_dir else None}
    return create(cfg, data, inv, replace=replace)
