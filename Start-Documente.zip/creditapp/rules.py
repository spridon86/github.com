"""Reguli de propunere (toate configurabile in config.json, toate explicate in interfata):

- 10. Experience with Counterparty   <- cea mai veche urma a relatiei (folder client, contracte, plati)
- 11. Payments Behavior              <- foaia "Payment behaviour report" (zile de intarziere)
- 14. Country Rating                 <- tabel pe tari (criteriul din scorecard)
- limita noua propusa                <- varful de expunere + buffer, plafonat la X% din capitalurile proprii
- Valid till, conversia K EUR -> KUSD
"""
import calendar
import datetime as dt
import math
from dataclasses import dataclass, field


# ---------------------------------------------------------------- 11. Payments Behavior
def payment_grade(pb, cfg):
    """(litera, explicatie) din comportamentul de plata. pb = PaymentBehaviour sau None."""
    p = cfg.get('paymentBehaviour')
    if pb is None:
        return 'C', 'Fara istoric in "Payment behaviour report" -> C (Prepaid / New no data).'
    inv_r = int(pb.recent_invoices or 0)
    inv_b = int(pb.baseline_invoices or 0)
    if inv_r + inv_b < p['minInvoices']:
        # restantele / platile returnate conteaza si cu putine facturi: cel putin D (regula din README)
        return _overdue_floor('C', f'Doar {inv_r + inv_b} facturi platite in 15 luni -> date insuficiente -> C.', pb, p)
    if inv_r >= p['minInvoices'] and pb.recent_days_late is not None:
        days, basis = float(pb.recent_days_late), f'ultimele 3 luni ({inv_r} facturi)'
    elif pb.baseline_days_late is not None:
        days, basis = float(pb.baseline_days_late), f'cele 12 luni anterioare ({inv_b} facturi)'
    else:
        days, basis = float(pb.recent_days_late or 0), f'ultimele 3 luni ({inv_r} facturi)'
    if days <= p['maxDaysA']:
        grade = 'A'
    elif days <= p['maxDaysB']:
        grade = 'B'
    elif days <= p['maxDaysD']:
        grade = 'D'
    else:
        grade = 'E'
    why = f'Intarziere medie {days:.1f} zile in {basis} -> {grade}.'
    grade, why = _overdue_floor(grade, why, pb, p)
    if pb.trend_text:
        why += f' Trend: {pb.trend_text}.'
    return grade, why


def _overdue_floor(grade, why, pb, p):
    """Restanta > oldestOverdueForD zile sau plati returnate -> cel putin D (A / B / C devin D)."""
    if grade not in ('A', 'B', 'C'):
        return grade, why
    if (pb.oldest_overdue_days or 0) > p['oldestOverdueForD']:
        return 'D', why + f' Dar are factura restanta de {pb.oldest_overdue_days:.0f} zile -> D.'
    if (pb.payment_returns or 0) > 0:
        return 'D', why + f' Dar are {pb.payment_returns:.0f} plati returnate (RiBa/banca) in 12 luni -> D.'
    return grade, why


# ---------------------------------------------------------------- 10. Experience
def experience_grade(first_date, cfg, as_of=None):
    """(litera, ani, explicatie) din data primei relatii cunoscute."""
    if not first_date:
        return 'E', 0.0, 'Nicio urma a relatiei (folder, contracte, plati) -> E (Nou).'
    as_of = as_of or dt.date.today()
    years = max(0.0, (as_of - first_date).days / 365.25)
    t = cfg.get('experience')
    if years >= t['A']:
        g = 'A'
    elif years >= t['B']:
        g = 'B'
    elif years >= t['C']:
        g = 'C'
    elif years >= t['D']:
        g = 'D'
    else:
        g = 'E'
    return g, years, f'Relatie din {first_date:%d.%m.%Y} ({years:.1f} ani) -> {g}.'


# ---------------------------------------------------------------- 14. Country rating
def country_rating(country_iso, cfg):
    return cfg.get('scorecard', 'countryRatings', default={}).get((country_iso or '').upper())


# ---------------------------------------------------------------- date si conversii
def add_months(d, months):
    m = d.month - 1 + months
    y = d.year + m // 12
    m = m % 12 + 1
    return dt.date(y, m, min(d.day, calendar.monthrange(y, m)[1]))


def end_of_month(d):
    return dt.date(d.year, d.month, calendar.monthrange(d.year, d.month)[1])


def valid_till(approved_on, months):
    """Valid till = ultima zi a lunii, peste N luni (ex. aprobat 04.03.2026 -> 31.03.2027)."""
    return end_of_month(add_months(approved_on, months))


def _step_for(value, cfg):
    for limit, step in cfg.get('limitPolicy', 'roundingSteps'):
        if limit is None or value <= limit:
            return step
    return 1


def round_up(value, cfg):
    """Rotunjire in sus la pasul configurat (ex. sub 100k -> 5k, sub 1M -> 10k, peste -> 50k)."""
    if value <= 0:
        return 0
    step = _step_for(value, cfg)
    return int(math.ceil(value / step - 1e-9) * step)


def k_usd(limit_eur, eur_usd, rounding=10):
    """Limita EUR -> KUSD rotunjit (ca in NWCE: 800 KEUR -> 900 KUSD)."""
    if not limit_eur:
        return 0
    k = limit_eur / 1000.0 * eur_usd
    # jumatatea se rotunjeste in sus, ca in Excel (round() din Python rotunjeste spre par: 845 -> 840)
    return int(math.floor(k / rounding + 0.5) * rounding) if rounding else round(k, 1)


def k_local(limit_eur):
    if not limit_eur:
        return 0
    k = limit_eur / 1000.0
    return int(k) if float(k).is_integer() else round(k, 1)


def _m(v):
    """Suma in format romanesc: 1.250.000"""
    return f'{float(v):,.0f}'.replace(',', '.')


# ---------------------------------------------------------------- limita propusa
@dataclass
class LimitProposal:
    proposed: int
    current: float
    need: int
    cap: int = None
    lines: list = field(default_factory=list)      # explicatia pas cu pas
    warnings: list = field(default_factory=list)


def propose_limit(current_limit, peak_exposure, equity_eur, grade, cs_limit_eur, cfg, currency='EUR'):
    p = cfg.get('limitPolicy')
    current = float(current_limit or 0)
    peak = max(0.0, float(peak_exposure or 0))
    lines, warns = [], []

    need = round_up(peak * (1 + p['exposureBuffer']), cfg) if peak > 0 else 0
    if peak > 0:
        lines.append(f'Varf de expunere {_m(peak)} {currency} + {p["exposureBuffer"]:.0%} buffer -> necesar {_m(need)} {currency}.')
    else:
        lines.append('Nu exista expunere viitoare in "Open Contracts".')

    cap = None
    if p['useEquityCap'] and equity_eur is not None:
        if equity_eur <= 0:
            warns.append(f'Capitaluri proprii negative / zero ({_m(equity_eur)} {currency}) - limita neacoperita de equity.')
            cap = 0
        else:
            cap = int(equity_eur * p['equityCapPct'])
            lines.append(f'Plafon {p["equityCapPct"]:.0%} din capitalurile proprii ({_m(equity_eur)} {currency}) = {_m(cap)} {currency}.')
    elif p['useEquityCap']:
        lines.append('Capitaluri proprii necunoscute (fara bilant) - fara plafon din equity.')

    if need == 0:
        proposed = int(current)
        lines.append(f'Se pastreaza limita curenta: {_m(current)} {currency}.')
    elif cap is not None and cap < need:
        step = _step_for(cap, cfg)
        proposed = int(cap // step * step) if cap > 0 else 0     # rotunjit in jos: nu depaseste plafonul
        lines.append(f'Necesarul depaseste plafonul -> propus {_m(proposed)} {currency}.')
        warns.append(f'Expunerea necesita {_m(need)} {currency}, dar plafonul din equity este {_m(cap)} {currency} - '
                     f'diferenta de {_m(need - proposed)} {currency} trebuie acoperita (garantii / asigurare / prepayment) sau aprobata la nivel superior.')
    else:
        proposed = need
        lines.append(f'Propus = necesarul: {_m(proposed)} {currency}.')

    if p['keepCurrentIfHigher'] and current > proposed:
        lines.append(f'Limita curenta ({_m(current)}) e mai mare - se pastreaza (setare keepCurrentIfHigher).')
        proposed = int(current)

    if grade is not None:
        try:
            g = int(grade)
        except (TypeError, ValueError):
            g = None
        if g is not None and g >= p['gradeWarningFrom']:
            warns.append(f'Grad scorecard {g} (risc ridicat) - recomandat: garantii / asigurare / prepayment.')
    if cs_limit_eur and proposed > float(cs_limit_eur):
        warns.append(f'Propunerea ({_m(proposed)}) depaseste limita recomandata de Creditsafe ({_m(float(cs_limit_eur))} {currency}).')
    if current and proposed != current:
        delta = proposed - current
        lines.append(f'Fata de limita curenta {_m(current)} {currency}: {"+" if delta > 0 else ""}{_m(delta)} {currency}.')
    return LimitProposal(proposed=int(proposed), current=current, need=need, cap=cap, lines=lines, warnings=warns)


# ---------------------------------------------------------------- matricea de aprobare
REGIONS = {'6675': 'ITA', '7020': 'NL', '6575': 'HU', '7179': 'RO', '7182': 'RO', '7425': 'ES', '7439': 'ES', '7433': 'ES',
           '7125': 'PT', '6450': 'FR', '6500': 'DE', '6501': 'DE', '6503': 'DE', '6202': 'BG'}


def region_of(company_code):
    prefix = str(company_code or '').split(' ')[0]
    return REGIONS.get(prefix, (str(company_code or '').split(' - ', 1)[-1] or prefix)[:12])


def grade_number(grade):
    """5 / 5.0 / '5' / 'Intuitive 9' -> 5 / 9; altfel None."""
    if grade is None or grade == '':
        return None
    if isinstance(grade, (int, float)):
        g = int(grade)
    else:
        import re
        m = re.search(r'\d+', str(grade))
        if not m:
            return None
        g = int(m.group(0))
    return g if 1 <= g <= 11 else None


@dataclass
class Authority:
    grade: int
    total: float
    name: str = ''              # cine aproba (primul nivel din lant suficient)
    nwce_level: str = ''        # valoarea din coloana "Approval level" a NWCE
    limit: float = 0
    no_trade: bool = False
    exceeds_all: bool = False
    chain: list = field(default_factory=list)      # [(nume, limita, ok)]

    def text_en(self):
        if self.no_trade:
            return f'Grade {self.grade} = No Trade.'
        if self.exceeds_all:
            return f'Grade {self.grade}: total USD {self.total / 1e6:,.1f} million exceeds the GLOBAL authority - special escalation.'
        return f'{self.name} (Grade {self.grade}: authority up to USD {self.limit / 1e6:,.1f} million)'

    def text(self):
        mil = f'{self.total / 1e6:,.1f}'.replace(',', ' ').replace('.', ',')       # 7,9 mil. $
        if self.no_trade:
            return f'Grade {self.grade} = No Trade: limita nu se poate aproba.'
        if self.exceeds_all:
            return f'Total {mil} mil. $ peste limita GLOBAL (grade {self.grade}): escaladare specială.'
        return f'Aprobă {self.name}. Total {mil} mil. $, grade {self.grade}.'


def approval_authority(grade, total_usd, cfg):
    """Cine trebuie sa aprobe limita totala (USD) pentru gradul dat - matricea "Limits by grade"."""
    g = grade_number(grade)
    if g is None:
        return None
    a = cfg.get('approval')
    rows = {r['name']: r for r in a['matrix']}
    chain_names = [a.get('analystRow')] + list(a.get('chainAbove') or [])
    chain = [rows[n] for n in chain_names if n in rows]
    res = Authority(grade=g, total=float(total_usd or 0))
    if g >= 11:
        res.no_trade = True
        res.chain = [(r['name'], 0, False) for r in chain]
        return res
    found = None
    for r in chain:
        lim = float(r['limits'][g - 1] or 0)
        ok = res.total <= lim
        res.chain.append((r['name'], lim, ok))
        if ok and found is None:
            found = r
    if found is None:
        res.exceeds_all = True
        last = chain[-1] if chain else {'name': '', 'nwceLevel': '', 'limits': [0] * 11}
        res.name, res.nwce_level, res.limit = last['name'], last.get('nwceLevel', ''), float(last['limits'][g - 1] or 0)
    else:
        res.name, res.nwce_level, res.limit = found['name'], found.get('nwceLevel', ''), float(found['limits'][g - 1] or 0)
    return res
