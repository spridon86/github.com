"""Fereastra principala: flux ghidat in 5 pasi, tabel simplu, panou lateral cu pasul urmator pentru clientul selectat."""
import concurrent.futures as cf
import datetime as dt
import html
import os
from pathlib import Path

from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QCursor, QDesktopServices, QFont, QFontMetrics, QKeySequence
from PyQt5.QtWidgets import (QAbstractItemView, QActionGroup, QApplication, QComboBox, QDialog, QFrame, QHBoxLayout, QHeaderView,
                             QLabel, QLineEdit, QMainWindow, QMenu, QMessageBox, QProgressBar, QPushButton, QShortcut, QSplitter,
                             QTabBar, QTableView, QVBoxLayout, QWidget)

from .. import __version__, creditsafe, errors, fx, limits_book, log, paths, pipeline, portfolio
from ..audit import AuditDB
from ..creditsafe_web import has_credentials, make_client
from ..errors import AppError
from . import dialogs
from .charts import ExposureChart
from .models import (CHIP_ROLE, COL, COLUMNS, PARTNER_ROLE, PROCESS_STAGES, SIMPLE_COLUMNS, TAB_COLUMNS, ClientsFilter, ClientsModel,
                     fmt_date, fmt_money, stage)
from .side_panel import DetailsDialog, SidePanel
from .widgets import (APP_STYLE, FONT, Chip, ChipDelegate, ComboDelegate, DateDelegate, GradeDelegate, GroupHeader, GuideDialog,
                      MoneyDelegate, PillDelegate, next_colors, nwce_status_colors)
from .worker import Worker

_log = log.get('ui')

# varianta A: patru file (numarul de clienti se adauga automat); "Toti clientii" = cautarea de sus
TABS = [('month', 'De revizuit'), ('process', 'În lucru'), ('approval', 'La aprobare'), ('reviewed', 'Gata')]
TAB_VIEW = {'month': 'month', 'process': 'process', 'approval': 'escalate', 'reviewed': 'reviewed', 'search': 'everyone'}


class MainWindow(QMainWindow):
    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        self.db = AuditDB()
        self.cs = make_client(cfg)
        self.portfolio = None
        self.nwce = None
        self.eur_usd, self.eur_usd_src = float(cfg.get('fx', 'eurUsdFallback')), 'config'
        self.credits = None
        self.worker = None
        self.overrides = {}
        self.setWindowTitle(f'Credit Limits Tool {__version__} - {cfg.get("analyst", "name")}')
        self.resize(1720, 1000)
        self.setStyleSheet(APP_STYLE)
        self._build()
        QTimer.singleShot(150, lambda: self.load_data(refresh_nwce=False))

    # ================================================================ UI
    def _build(self):
        """Varianta A: bara de sus (nume, cautare, Creditsafe / NWCE), 4 file, tabel cu 6 coloane + panoul clientului
        in dreapta, un singur buton verde jos. Lista "TBD by", filtrele si ghidul sunt in meniul de sus."""
        self._build_menus()
        central = QWidget()
        central.setObjectName('central')
        self.setCentralWidget(central)
        v = QVBoxLayout(central)
        v.setContentsMargins(14, 12, 14, 8)
        v.setSpacing(0)
        self.flt = {'over': False, 'show_blocked': False, 'sales': False, 'eval_sheet': False, 'bu': '', 'all_cols': False}
        # lista "TBD by" aleasa din meniul "Lista" (combobox-ul ramane ca suport de date, nu se afiseaza)
        self.f_tbd = QComboBox()
        self.f_tbd.addItem('Toți (Open Contracts ITA)', '')
        self.f_tbd.currentIndexChanged.connect(self._tbd_changed)
        self.f_tbd.setVisible(False)

        # --- bara de sus: nume + cautare + Creditsafe / NWCE
        appbar = QFrame()
        appbar.setObjectName('appbar')
        head = QHBoxLayout(appbar)
        head.setContentsMargins(14, 10, 14, 10)
        head.setSpacing(12)
        t = QLabel('Credit Limits')
        t.setObjectName('title')
        head.addWidget(t)
        self.f_text = QLineEdit()
        self.f_text.setObjectName('search')
        self.f_text.setPlaceholderText('Caută client, VAT sau cod…')
        self.f_text.setClearButtonEnabled(True)
        self.f_text.textChanged.connect(self._search_changed)
        head.addWidget(self.f_text, 1)
        self.chip_cs, self.chip_nwce = Chip(), Chip()
        self.chip_cs.set(None, 'Creditsafe …')
        self.chip_nwce.set(None, 'NWCE …')
        self.chip_cs.clicked.connect(self.change_password)
        self.chip_nwce.clicked.connect(lambda: self.load_data(refresh_nwce=True))
        head.addWidget(self.chip_cs)
        head.addWidget(self.chip_nwce)
        v.addWidget(appbar)

        # --- filele: De revizuit | In lucru | La aprobare | Gata
        tabwrap = QFrame()
        tabwrap.setObjectName('tabwrap')
        tl = QHBoxLayout(tabwrap)
        tl.setContentsMargins(14, 0, 14, 0)
        self.tabbar = QTabBar()
        self.tabbar.setObjectName('steps')
        self.tabbar.setExpanding(False)
        self.tabbar.setDrawBase(False)
        self.tabbar.setElideMode(Qt.ElideNone)
        self.tabbar.setUsesScrollButtons(False)
        tf = QFont(FONT)
        tf.setPointSizeF(9.5)
        tf.setWeight(QFont.DemiBold)
        self.tabbar.setFont(tf)          # latimea filelor se calculeaza dupa acest font (stylesheet-ul nu schimba grosimea)
        for _key, label in TABS:
            self.tabbar.addTab(label)
        self.tabbar.setCurrentIndex(0)            # se porneste pe "De revizuit"
        self.tabbar.currentChanged.connect(self._tab_changed)
        tl.addWidget(self.tabbar)
        tl.addStretch(1)
        self.lbl_search = QLabel('')
        self.lbl_search.setObjectName('muted')
        tl.addWidget(self.lbl_search)
        v.addWidget(tabwrap)

        # --- tabel (stanga) + clientul selectat (dreapta)
        split = QSplitter(Qt.Horizontal)
        split.setHandleWidth(1)
        split.setChildrenCollapsible(False)
        v.addWidget(split, 1)
        self.model = ClientsModel(self)
        self.proxy = ClientsFilter(self)
        self.proxy.setSourceModel(self.model)
        self.table = QTableView()
        self.table.setHorizontalHeader(GroupHeader([label for _k, label in COLUMNS], self.table))
        self.table.setModel(self.proxy)
        self.table.setSortingEnabled(True)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.table.setShowGrid(False)                 # doar linia de sub fiecare rand, ca in macheta
        self.table.setAlternatingRowColors(False)
        self.table.setWordWrap(False)
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(30)
        hh = self.table.horizontalHeader()
        hh.setSectionResizeMode(QHeaderView.Interactive)
        hh.setStretchLastSection(True)
        hh.setContextMenuPolicy(Qt.CustomContextMenu)
        hh.customContextMenuRequested.connect(self._header_menu)
        hh.sectionClicked.connect(self._header_clicked)
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self._row_menu)
        self.table.setItemDelegateForColumn(COL['a_step'], ChipDelegate(self.table, CHIP_ROLE))
        self.table.setItemDelegateForColumn(COL['next'], PillDelegate(self.table, next_colors))
        self.table.setItemDelegateForColumn(COL['status'], PillDelegate(self.table, nwce_status_colors))
        from .. import mapping
        self.table.setItemDelegateForColumn(COL['m_fin'], ComboDelegate([(x, x) for x in mapping.FINANCIAL_REPORTING_OPTIONS], self.table))
        self.table.setItemDelegateForColumn(COL['m_exp'], ComboDelegate(list(mapping.EXPERIENCE_OPTIONS.items()), self.table))
        self.table.setItemDelegateForColumn(COL['m_pay'], ComboDelegate(list(mapping.PAYMENT_OPTIONS.items()), self.table))
        # valorile noi: in tabel ("Propus", "Grade") sau in panoul din dreapta (Open, MTM, Valabil pana, Grade, criteriile)
        for k in ('n_open', 'n_mtm', 'a_prop'):
            self.table.setItemDelegateForColumn(COL[k], MoneyDelegate(self.table))
        self.table.setItemDelegateForColumn(COL['n_valid'], DateDelegate(self.table))
        for k in ('n_grade', 'a_grade'):
            self.table.setItemDelegateForColumn(COL[k], GradeDelegate(self.table))
        self.table.setEditTriggers(QAbstractItemView.DoubleClicked | QAbstractItemView.SelectedClicked | QAbstractItemView.EditKeyPressed)
        self.model.edited.connect(self._cell_edited)
        # bifa pe un client -> butonul de jos arata imediat cati sunt bifati
        self.model.dataChanged.connect(
            lambda tl_, br, roles=None: self._update_action() if tl_.column() <= COL['check'] <= br.column() else None)
        widths = {'check': 30, 'status': 128, 'company': 145, 'bp': 72, 'partner': 78, 'supplier': 70, 'name': 250, 'vat': 110,
                  'grp': 90, 'grading': 60, 'tbd': 80, 'analyst': 55, 'compliance': 80, 'payment_term': 105, 'open_kusd': 80,
                  'open_kloc': 95, 'mtm_kusd': 70, 'kusd': 80, 'approved': 105, 'valid': 105, 'level': 80, 'trader': 140,
                  'comments': 140, 'next': 190, 'pay_beh': 330, 'state': 120, 'group_kusd': 105, 'grade': 75, 'proposed': 85, 'ratio': 80,
                  'r_exp': 120, 'r_active': 60, 'r_cs': 85, 'm_fin': 120, 'm_exp': 105, 'm_pay': 100, 'r_open': 115,
                  'r_total': 105, 'r_auth': 150, 'r_eq': 95, 'r_ar': 105, 'o_open': 95, 'n_open': 95, 'o_mtm': 85,
                  'n_mtm': 85, 'o_grade': 55, 'n_grade': 55, 'o_valid': 92, 'n_valid': 92, 'eq30': 170, 'cs_sc': 175,
                  'a_client': 480, 'a_now': 150, 'a_prop': 150, 'a_valid': 140, 'a_grade': 80, 'a_step': 240}
        hh.setDefaultAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        hf = QFont(self.font())
        hf.setBold(True)
        fm = QFontMetrics(hf)
        self._default_widths = {}
        for i, (k, label) in enumerate(COLUMNS):     # antetul intreg vizibil (numele din excel sunt lungi)
            grp, _, sub = label.rpartition('|')
            need = max(fm.horizontalAdvance(sub), fm.horizontalAdvance(grp) // 2 if grp else 0) + 16
            self._default_widths[k] = max(int(widths.get(k, 80) * 0.85), need)
        # latimile salvate de analist (la zoom 100%) + zoom-ul salvat
        saved = self.cfg.get('ui', 'columnWidths', default={}) or {}
        self._widths = {k: int(saved.get(k, w)) for k, w in self._default_widths.items()}
        self.zoom = float(self.cfg.get('ui', 'zoom', default=1.0) or 1.0)
        self._base_font = QFont(self.font())
        self._applying_widths = False
        self._save_ui_timer = QTimer(self)
        self._save_ui_timer.setSingleShot(True)
        self._save_ui_timer.timeout.connect(self._save_ui)
        hh.sectionResized.connect(self._column_resized)
        self.table.viewport().installEventFilter(self)          # Ctrl + rotita = zoom
        self.table.selectionModel().currentRowChanged.connect(lambda *_: self.show_details())
        self.table.doubleClicked.connect(self._double_clicked)
        split.addWidget(self.table)
        self.side = SidePanel()
        self.side.edited.connect(self._side_edit)
        self.side.folder.connect(self.open_folder)
        self.side.details.connect(self.show_full_details)
        split.addWidget(self.side)
        split.setStretchFactor(0, 1)
        split.setStretchFactor(1, 0)
        split.setSizes([1180, 370])
        # "Toate detaliile": pagina completa, graficul de expunere si istoricul (fostul panou de jos)
        self.chart = ExposureChart()
        self.details_dlg = DetailsDialog(self, self.chart)
        self.details = self.details_dlg.details
        self.details.anchorClicked.connect(self._link)
        self.journal = self.details_dlg.journal
        self._apply_columns()
        self._apply_zoom()

        # --- jos: cati sunt bifati + un singur buton (verde) pentru fila curenta
        foot = QFrame()
        foot.setObjectName('footbar')
        bar = QHBoxLayout(foot)
        bar.setContentsMargins(14, 9, 14, 9)
        bar.setSpacing(10)
        self.lbl_count = QLabel('')
        self.lbl_count.setObjectName('muted')
        bar.addWidget(self.lbl_count)
        bar.addStretch(1)
        self.act2 = QPushButton('')
        self.act2.setVisible(False)
        self.act2.clicked.connect(self._tab_action2)
        bar.addWidget(self.act2)
        self.act = QPushButton('')
        self.act.setObjectName('primary')
        self.act.clicked.connect(self._tab_action)
        bar.addWidget(self.act)
        v.addWidget(foot)

        # --- bara de stare
        sb = self.statusBar()
        self.status = QLabel('Pornire...')
        sb.addWidget(self.status, 1)
        self.lbl_fx = QLabel('')
        self.lbl_fx.setObjectName('muted')
        sb.addPermanentWidget(self.lbl_fx)
        self.progress = QProgressBar()
        self.progress.setFixedWidth(240)
        self.progress.setMaximumHeight(14)
        self.progress.setTextVisible(False)
        sb.addPermanentWidget(self.progress)
        self.b_stop = QPushButton('Stop')
        self.b_stop.setEnabled(False)
        self.b_stop.clicked.connect(self.stop_job)
        sb.addPermanentWidget(self.b_stop)

        QShortcut(QKeySequence('Ctrl+F'), self, activated=self.f_text.setFocus)
        QShortcut(QKeySequence('Space'), self.table, activated=self._toggle_selected)
        QShortcut(QKeySequence('Return'), self.table, activated=self.open_decision)
        QShortcut(QKeySequence('F1'), self, activated=self.show_guide)
        QShortcut(QKeySequence('F5'), self, activated=lambda: self.load_data(refresh_nwce=False))
        for seq, dz in (('Ctrl++', 0.1), ('Ctrl+=', 0.1), ('Ctrl+-', -0.1)):
            QShortcut(QKeySequence(seq), self, activated=lambda dz=dz: self._set_zoom(self.zoom + dz))
        QShortcut(QKeySequence('Ctrl+0'), self, activated=lambda: self._set_zoom(1.0))

    def _build_menus(self):
        mb = self.menuBar()
        m = mb.addMenu('&Date')
        self.a_reload = m.addAction('Reîncarcă clienții (Open Contracts)   F5', lambda: self.load_data(refresh_nwce=False))
        self.a_nwce = m.addAction('Reîncarcă NWCE de pe SharePoint (~20 s)', lambda: self.load_data(refresh_nwce=True))
        m.addSeparator()
        m.addAction('Export rezumat Excel', self.export_summary)
        m.addAction('Istoric modificări NWCE / SAP', self.show_changes)
        m.addAction('Deschide folderul cu date și jurnale', lambda: os.startfile(str(paths.DATA_DIR)))
        self.m_list = mb.addMenu('Listă')            # lista "TBD by" (se completeaza dupa incarcarea NWCE)
        self.m_filters = mb.addMenu('&Filtre')
        self.m_filters.aboutToShow.connect(lambda: self._fill_filters_menu(self.m_filters))
        m = mb.addMenu('&SAP')
        m.addAction('Probă (nu salvează)', lambda: self.run_sap(dry_run=True))
        m.addAction('Salvează limitele în SAP', lambda: self.run_sap(dry_run=False))
        m.addSeparator()
        m.addAction('Import înregistrare SAP (.vbs)...', self.import_sap)
        m = mb.addMenu('Se&tări')
        m.addAction('Setări...', self.open_settings)
        m.addAction('Parola Creditsafe...', self.change_password)
        m = mb.addMenu('&Ajutor')
        m.addAction('Ghid rapid   F1', self.show_guide)

    # ================================================================ file, filtre, meniuri
    def _apply_columns(self, *_):
        full = self.flt['all_cols']
        cols = TAB_COLUMNS.get(self._mode(), SIMPLE_COLUMNS)
        for i, (k, _label) in enumerate(COLUMNS):
            self.table.setColumnHidden(i, not full and k not in cols)
        self.table.horizontalHeader().two_rows = full     # doua randuri doar cu toate coloanele (perechi "Veche | Noua")
        self._apply_zoom()
        # ordinea din fila (ex. Open veche langa Open noua) - mutare vizuala, modelul ramane neschimbat
        hh = self.table.horizontalHeader()
        for pos, k in enumerate(cols):
            cur = hh.visualIndex(COL[k])
            if cur != pos:
                hh.moveSection(cur, pos)
        hh.viewport().update()

    def _header_menu(self, pos):
        m = QMenu(self)
        m.addAction('Latimi implicite pentru toate coloanele', self._reset_widths)
        m.addAction(f'Zoom 100% (acum {round(self.zoom * 100)}%)   Ctrl+0', lambda: self._set_zoom(1.0))
        m.addSeparator()
        for i, (k, label) in enumerate(COLUMNS):
            if not label:
                continue
            a = m.addAction(label.replace('|', ' - '))
            a.setCheckable(True)
            a.setChecked(not self.table.isColumnHidden(i))
            a.toggled.connect(lambda on, col=i: self.table.setColumnHidden(col, not on))
        m.exec_(self.table.horizontalHeader().mapToGlobal(pos))

    # ---------------------------------------------------------------- latimi coloane + zoom
    def _apply_zoom(self):
        """Font, inaltimea randurilor, antetul si latimile coloanelor dupa zoom (Ctrl + rotita / Ctrl +/-/0)."""
        z = self.zoom
        f = QFont(self._base_font)
        f.setPointSizeF(max(5.0, self._base_font.pointSizeF() * z))
        self.table.setFont(f)
        hf = QFont(f)
        hf.setBold(True)
        hh = self.table.horizontalHeader()
        hh.setFont(hf)
        two = getattr(hh, 'two_rows', True)
        hh.setMinimumHeight(QFontMetrics(hf).height() * (2 if two else 1) + (8 if two else 14))
        hh.setMaximumHeight(hh.minimumHeight())
        self.table.verticalHeader().setDefaultSectionSize(max(16, round(30 * z)))
        for w in (getattr(self, 'details', None), getattr(self, 'journal', None)):
            if w is not None:
                w.setFont(f)
        self._applying_widths = True
        try:
            for i, (k, _label) in enumerate(COLUMNS):
                self.table.setColumnWidth(i, max(18, round(self._widths.get(k, 80) * z)))
        finally:
            self._applying_widths = False
        hh.viewport().update()

    def _set_zoom(self, z):
        self.zoom = round(min(2.0, max(0.6, z)), 2)
        self._apply_zoom()
        self.set_status(f'Zoom {round(self.zoom * 100)}%  (Ctrl + rotita mouse / Ctrl + / Ctrl - / Ctrl 0)')
        self._save_ui_timer.start(1500)

    def _column_resized(self, logical, _old, new):
        if self._applying_widths or not (0 <= logical < len(COLUMNS)) or new <= 0:
            return
        self._widths[COLUMNS[logical][0]] = max(18, round(new / (self.zoom or 1)))
        self._save_ui_timer.start(1500)

    def _reset_widths(self):
        self._widths = dict(self._default_widths)
        self._apply_zoom()
        self._save_ui_timer.start(500)

    def _save_ui(self):
        changed = {k: w for k, w in self._widths.items() if w != self._default_widths.get(k)}
        self.cfg.set(changed, 'ui', 'columnWidths')
        self.cfg.set(self.zoom, 'ui', 'zoom')
        try:
            self.cfg.save()
        except Exception as e:
            _log.warning('UI settings not saved: %s', e)

    def eventFilter(self, obj, event):
        from PyQt5.QtCore import QEvent
        if event.type() == QEvent.Wheel and event.modifiers() & Qt.ControlModifier and obj is self.table.viewport():
            step = 0.1 if event.angleDelta().y() > 0 else -0.1
            self._set_zoom(self.zoom + step)
            return True
        return super().eventFilter(obj, event)

    def _header_clicked(self, col):
        if col == COL['check']:       # click pe antetul coloanei de bife = bifeaza / debifeaza tot ce se vede
            vis = [self.model.by_partner[self.proxy.data(self.proxy.index(i, 0), PARTNER_ROLE)] for i in range(self.proxy.rowCount())]
            self._check_visible(not all(r.checked for r in vis) if vis else True)

    def _fill_filters_menu(self, m):
        """Meniul "Filtre" (sus): peste limita, blocati / inactivi, vanzari, foaia "To Evaluate", BU, toate coloanele."""
        m.clear()
        for key, label in (('over', 'Doar peste limită (expunere Italia)'), ('show_blocked', 'Arată și blocații / inactivii'),
                           ('sales', 'Doar vânzări (S)'), ('eval_sheet', 'Doar foaia "To Evaluate"'),
                           ('all_cols', 'Arată toate coloanele (ca în excelul NWCE)')):
            a = m.addAction(label)
            a.setCheckable(True)
            a.setChecked(bool(self.flt[key]))
            a.toggled.connect(lambda on, k=key: self._set_flt(k, on))
        bus = sorted({r.cp.business_unit for r in self.model.rows if r.cp.business_unit})
        if bus:
            sub = m.addMenu('BU: ' + (self.flt['bu'] or 'toate'))
            for b in [''] + bus:
                a = sub.addAction(b or 'toate')
                a.setCheckable(True)
                a.setChecked(self.flt['bu'] == b)
                a.triggered.connect(lambda _c=False, val=b: self._set_flt('bu', val))

    def _set_flt(self, key, value):
        self.flt[key] = value
        active = [k for k in ('over', 'show_blocked', 'sales', 'eval_sheet') if self.flt[k]] + (['bu'] if self.flt['bu'] else [])
        self.m_filters.setTitle(f'Filtre ({len(active)})' if active else 'Filtre')
        if key == 'all_cols':
            self._apply_columns()
        else:
            self._filter()

    def _row_menu(self, pos):
        idx = self.table.indexAt(pos)
        if not idx.isValid():
            return
        r = self.model.by_partner.get(self.proxy.data(idx, PARTNER_ROLE))
        if not r:
            return
        self.table.setCurrentIndex(idx)
        ev = r.ev
        files = (ev.files or {}) if ev else {}
        st = stage(r, self.model.sap_company)
        m = QMenu(self)
        # revizuire completa (expunere, activ, Creditsafe + scorecard, limite noi, autoritate) - si ca reluare
        if st in PROCESS_STAGES + ('escalate',):
            # in lucru: clientul iese din fila; la urmatoarea revizuire raport Creditsafe nou + scorecard refacut
            a = m.addAction('Evalueaza din nou (raport Creditsafe nou + scorecard nou)...', self.redo_evaluation)
            a.setEnabled(self._redo_allowed(r))
        else:
            a = m.addAction('Revizuieste acest client (din nou)', lambda: self.start_review([r]))
            a.setEnabled(r.nwce is not None and st not in ('write', 'sap'))
        a = m.addAction('Evaluare grup / Annual Review...', self.open_group)
        a.setEnabled(r.nwce is not None)
        m.addSeparator()
        m.addAction('Deschide folderul clientului', self.open_folder)
        a = m.addAction('Deschide scorecardul', lambda: self.open_file('scorecard'))
        a.setEnabled(bool(files.get('scorecard')))
        a = m.addAction('Deschide PDF-ul Creditsafe', lambda: self.open_file('pdf'))
        a.setEnabled(bool(files.get('pdf')))
        m.addSeparator()
        approved = ev is not None and ev.state in ('approved', 'done') and bool(ev.decision)
        a = m.addAction('Scrie in NWCE acum', lambda: self.write_nwce(rows=[r]))
        a.setEnabled(approved and (ev.nwce or {}).get('status') != 'ok')
        sap_ok = approved and (ev.nwce or {}).get('status') == 'ok' and (ev.sap or {}).get('status') != 'ok' \
            and not (ev.decision or {}).get('inactivate') and not pipeline.sap_skipped(ev)
        sap_unsure = sap_ok and pipeline.sap_sent(ev)
        a = m.addAction('Trimite in SAP...', lambda: self.run_sap(dry_run=False, rows=[r]))
        a.setEnabled(sap_ok and not sap_unsure)
        a = m.addAction('Proba SAP (nu trimite nimic)', lambda: self.run_sap(dry_run=True, rows=[r]))
        a.setEnabled(sap_ok and not sap_unsure)
        if sap_unsure:
            m.addAction('SAP: confirma trimiterea (cazul exista in SAP)', lambda: self.sap_confirm(r, True))
            m.addAction('SAP: permite retrimiterea (cazul NU exista in SAP)...', lambda: self.sap_confirm(r, False))
        # "Transcrie in SAP" pe o decizie aprobata, cat timp nu a plecat in SAP (ex. aprobata pe alt canal)
        if approved and not (ev.decision or {}).get('inactivate') and not pipeline.sap_sent(ev):
            if pipeline.sap_skipped(ev):
                m.addAction('SAP: transcrie totusi aceasta decizie...', lambda: self.toggle_sap_skip(r, False))
            else:
                m.addAction('SAP: nu transcrie (aprobat pe alt canal)', lambda: self.toggle_sap_skip(r, True))
        a = m.addAction('Inregistreaza aprobarea (aprobat pe alt canal)...', lambda: self.record_approval([r]))
        a.setVisible(st == 'escalate')
        m.addSeparator()
        a = m.addAction('Reface in NWCE valorile de dinainte (anuleaza scrierea)...', lambda: self.restore_nwce(r))
        a.setEnabled(ev is not None and (ev.nwce or {}).get('status') == 'ok' and bool(pipeline.restore_plan(ev)))
        a = m.addAction('Anulează (înapoi la „De revizuit”)...', self.cancel_progress)
        a.setEnabled(ev is not None and ev.state != 'cancelled' and st not in ('new', 'valid', 'na', 'inactive'))
        a = m.addAction('Inactiveaza...', self.inactivate)
        a.setEnabled(r.nwce is not None and not r.cp.inactive)
        m.exec_(self.table.viewport().mapToGlobal(pos))

    def toggle_sap_skip(self, r, skip):
        if self.busy() or r.ev is None:
            return
        if not skip and QMessageBox.question(
                self, 'SAP', f'{r.ev.name}: transcrii decizia in SAP?\n\nIn SAP modificarea porneste din nou workflow-ul de aprobare '
                '(chiar daca aprobarea a fost deja data pe alt canal).') != QMessageBox.Yes:
            return
        pipeline.set_sap_skip(self._ui_ctx(), r.ev, skip)
        self.model.update_evaluation(r.ev)
        self._filter()
        self.refresh_steps()
        self.show_details()
        self.set_status(f'{r.ev.name}: ' + ('SAP nu se transcrie.' if skip else 'se transcrie in SAP (click-dreapta → Trimite in SAP).'), 'ok')

    def sap_confirm(self, r, sent):
        """Dupa o eroare DUPA rotita: analistul a verificat in SAP daca cazul de aprobare exista."""
        if self.busy() or r.ev is None:
            return
        if not sent and QMessageBox.question(
                self, 'SAP', f'{r.ev.name}: confirmi ca in SAP NU exista cererea de modificare a limitei?\n\n'
                'Daca exista si retrimiti, se creeaza un caz de aprobare dublu.') != QMessageBox.Yes:
            return
        pipeline.sap_confirm_manual(self._ui_ctx(), r.ev, sent)
        self.model.update_evaluation(r.ev)
        self._filter()
        self.refresh_steps()
        self.show_details()
        self.set_status(f'{r.ev.name}: ' + ('trimiterea SAP confirmata.' if sent else 'retrimiterea in SAP e permisa.'), 'ok')

    def restore_nwce(self, r):
        """Anuleaza ultima scriere a tool-ului in NWCE (ex. o inactivare gresita): pune la loc valorile de dinainte."""
        if self.busy():
            return
        ev = r.ev
        plan = pipeline.restore_plan(ev)
        if not plan:
            return
        rows = [[ev.customer_name or ev.name, limits_book.LABELS.get(k, k), new, old] for k, (new, old) in plan.items()]
        dlg = dialogs.TableDialog(self, 'Refacere NWCE',
                                  f'Se pun la loc in NWCE (rand {(ev.nwce or {}).get("sheet_row")}) valorile de dinainte de scrierea tool-ului '
                                  f'din {fmt_date((ev.nwce or {}).get("at"))}. Daca randul a fost modificat intre timp de altcineva, '
                                  'nu se scrie nimic. SAP nu se atinge (o limita trimisa in SAP se reface manual).',
                                  ['Client', 'Camp', 'Acum (scris de tool)', 'Se pune la loc'], rows, ok_text='Reface in NWCE')
        if dlg.exec_() != QDialog.Accepted:
            return

        def job(w):
            u = pipeline.restore_nwce(self.ctx(w), ev)
            try:
                snap = limits_book.Snapshot.load_cache(self.cfg.get('portfolio', 'country'))
            except Exception:
                snap = None
            return u, snap

        def done(res):
            u, snap = res
            if snap:
                self.nwce = snap
                self.model.set_nwce(snap, self.cfg.get('limitsBook', 'companyCode'), self.cfg.get('portfolio', 'country'))
            self.model.update_evaluation(ev)
            self._filter()
            self.refresh_steps()
            self.show_details()
            if u.ok:
                self.set_status(f'{ev.name}: valorile de dinainte au fost puse la loc in NWCE.', 'ok')
                QMessageBox.information(self, 'Refacere NWCE', f'{ev.name}: {u.message or "refacut si verificat"}\n\n'
                                        'Clientul a revenit în „De revizuit”.')
            else:
                QMessageBox.warning(self, 'Refacere NWCE', f'{ev.name}: NU s-a refacut.\n\n{u.message}')

        self.start_job(job, on_done=done, name='nwce-restore')

    @staticmethod
    def _redo_allowed(r):
        """Se poate reevalua daca decizia nu a ajuns inca in NWCE / SAP (altfel: intai "Reface in NWCE" / anulare)."""
        ev = r.ev
        return ev is not None and ev.state != 'cancelled' and (ev.nwce or {}).get('status') != 'ok' and not pipeline.sap_sent(ev)

    def redo_evaluation(self):
        """Proces initiat / Necesita aprobare -> "Evalueaza din nou": clientii bifati (sau cel selectat) ies din fila si revin
        in "De evaluat" (sau "Toti clientii"); la urmatoarea revizuire: raport Creditsafe nou + scorecard refacut."""
        if self.busy():
            return
        sel = [r for r in self.model.checked_rows() if r in self._visible_rows()]
        cur = self.current_row()
        rows = sel if (cur in sel or not cur) else [cur]
        ok = [r for r in rows if self._redo_allowed(r)]
        skip = [r for r in rows if r not in ok and r.ev is not None]
        if not ok:
            if skip:
                QMessageBox.information(self, 'Evalueaza din nou', 'Decizia acestor clienti e deja scrisa in NWCE / trimisa in SAP - '
                                        'foloseste intai "Reface in NWCE valorile de dinainte":\n\n' + '\n'.join(f'- {r.cp.name}' for r in skip[:12]))
            return
        msg = (f'Evaluez din nou {len(ok)} clienți: ies din „{dict(TABS).get(self._tab_key(), "")}” și revin bifați în „De revizuit” '
               '(sau în căutare, dacă limita nu expiră luna asta).\n\nLa „Revizuiește bifații”: raport Creditsafe nou și scorecard '
               'refăcut (îl înlocuiește pe cel vechi). Criteriile alese de tine rămân.\n\n'
               + '\n'.join(f'- {r.cp.name}' for r in ok[:12]) + (f'\n... (+{len(ok) - 12})' if len(ok) > 12 else ''))
        if skip:
            msg += '\n\nSarite (deja scrise in NWCE / SAP):\n' + '\n'.join(f'- {r.cp.name}' for r in skip[:8])
        if QMessageBox.question(self, 'Evalueaza din nou', msg) != QMessageBox.Yes:
            return
        ctx = self._ui_ctx()
        for r in ok:
            pipeline.mark_redo(ctx, r.ev)
            self.model.update_evaluation(r.ev)
        self.model.set_checked({r.cp.partner for r in ok}, True)
        self._filter()
        self.refresh_steps()
        self.show_details()
        self.set_status(f'{len(ok)} client(i) scoși din filă - în „De revizuit” (sau în căutare), bifați: „Revizuiește bifații” '
                        'descarca raport Creditsafe nou si reface scorecardul.', 'ok')

    def cancel_progress(self):
        """Anuleaza ce a plecat mai departe fara voia analistului (decizie aprobata automat, Annual Review, inactivare,
        criterii de completat): clientul revine unde il pune NWCE. Ce s-a scris deja in NWCE / SAP NU se poate anula
        automat - se spune clar ce e de refacut manual."""
        sel = [r for r in self.model.checked_rows() if r in self._visible_rows()]
        cur = self.current_row()
        rows = sel if (cur in sel or not cur) else [cur]
        rows = [r for r in rows if r.ev is not None and r.ev.state != 'cancelled']
        if not rows:
            return
        written = [r for r in rows if (r.ev.nwce or {}).get('status') == 'ok' or pipeline.sap_sent(r.ev)]
        ok = [r for r in rows if r not in written]
        lines = []
        for r in written:
            ev = r.ev
            parts = []
            if (ev.nwce or {}).get('status') == 'ok':
                parts.append('scris in NWCE')
            if pipeline.sap_sent(ev):
                case = (ev.sap or {}).get('case_number')
                parts.append(('trimis in SAP' if (ev.sap or {}).get('status') == 'ok' else 'posibil trimis in SAP')
                             + (f' (caz {case})' if case else ''))
            lines.append(f'- {r.cp.name}: deja {" si ".join(parts)} - refa manual (valorile vechi: Date → Istoric modificari)')
        msg = (f'Anulez {len(ok)} client(i): decizia / ruta de revizuire se sterg, clientul revine în „De revizuit”. '
               'Fisierele generate (scorecard, PDF, Annual Review) raman in folderul clientului.\n\n'
               + '\n'.join(f'- {r.cp.name}' for r in ok[:12]) + (f'\n... (+{len(ok) - 12})' if len(ok) > 12 else ''))
        if lines:
            msg += '\n\nNU se pot anula automat:\n' + '\n'.join(lines[:12])
        if not ok:
            QMessageBox.information(self, 'Anuleaza', msg)
            return
        if QMessageBox.question(self, 'Anuleaza', msg) != QMessageBox.Yes:
            return
        ctx = self._ui_ctx()
        for r in ok:
            ev = r.ev
            ev.state = 'cancelled'
            ev.decision = None
            ev.review = None
            pipeline.log_event(ctx, ev, 'INFO', 'Anulat', 'Anulat de analist - clientul revine la revizuire')
            self.db.save_evaluation(ev)
            self.model.update_evaluation(ev)
        self._filter()
        self.refresh_steps()
        self.set_status(f'Anulat: {len(ok)} client(i) - înapoi în „De revizuit”.', 'ok')

    def _tab_key(self):
        i = self.tabbar.currentIndex()
        return TABS[i][0] if 0 <= i < len(TABS) else 'month'

    def _mode(self):
        """Ce arata tabelul: cautarea (toti clientii, toate listele) cand e scris ceva sus, altfel fila curenta."""
        return 'search' if self.f_text.text().strip() else self._tab_key()

    def _tab_changed(self, _i):
        if self.f_text.text():
            self.f_text.blockSignals(True)          # click pe o fila = inapoi din cautare la fila
            self.f_text.clear()
            self.f_text.blockSignals(False)
            self.lbl_search.setText('')
        self._apply_columns()
        self._filter()

    def _search_changed(self, text):
        t = text.strip()
        self.lbl_search.setText(f'Rezultate în toți clienții pentru „{t}”' if t else '')
        self._apply_columns()
        self._filter()

    def refresh_steps(self):
        c = self.proxy.stage_counts() if self.model.rows else {}
        counts = {'month': c.get('month', 0), 'process': c.get('process', 0), 'approval': c.get('escalate', 0),
                  'reviewed': c.get('reviewed', 0)}
        for i, (key, label) in enumerate(TABS):
            n = counts.get(key)
            self.tabbar.setTabText(i, f'{label}  {n}' if n else label)
        self._update_action()
        self._update_count()

    def _visible_rows(self):
        return [self.model.by_partner[self.proxy.data(self.proxy.index(i, 0), PARTNER_ROLE)] for i in range(self.proxy.rowCount())]

    def _update_action(self):
        """Un singur buton (verde) pentru ce arata tabelul; al doilea doar unde e nevoie."""
        mode = self._mode()
        vis = self._visible_rows()
        picked = [r for r in self.model.checked_rows() if r in vis]
        self.act2.setVisible(False)
        self.act.setVisible(True)
        if mode in ('month', 'search'):
            todo = self._month_rows(vis) if mode == 'month' else [r for r in vis if self._can_start(r)]
            n = len([r for r in picked if r in todo])
            self.act.setText(f'Revizuiește bifații ({n})' if n else 'Bifează clienții de revizuit')
            self.act.setEnabled(n > 0)
            self.act.setToolTip('Expunere → activ? → Creditsafe + scorecard → limita nouă → cine aprobă.')
        elif mode == 'process':
            ready = [r for r in picked if self._next_ready(r)]
            self.act.setText(f'Trimite bifații în NWCE + SAP ({len(ready)})' if ready else 'Bifează clienții de trimis')
            self.act.setEnabled(bool(ready))
            self.act.setToolTip('În autoritatea ta: se scriu în NWCE și SAP. Peste: merg la „La aprobare” (Annual Review).')
            redo = [r for r in picked if self._redo_allowed(r)]
            self.act2.setText(f'Evaluează din nou ({len(redo)})' if redo else 'Evaluează din nou')
            self.act2.setToolTip('Clienții bifați ies din „În lucru”; la următoarea revizuire: raport Creditsafe nou + scorecard refăcut.')
            self.act2.setVisible(True)
            self.act2.setEnabled(bool(redo))
        elif mode == 'approval':
            ready = [r for r in picked if stage(r, self.model.sap_company) == 'escalate']
            self.act.setText(f'Am primit aprobarea ({len(ready)})' if ready else 'Bifează clienții aprobați')
            self.act.setEnabled(bool(ready))
            self.act.setToolTip('Se scrie în NWCE; alegi dacă se transcrie și în SAP.')
            self.act2.setText('Deschide folderul')
            self.act2.setVisible(True)
            self.act2.setEnabled(bool(vis))
        else:
            self.act.setVisible(False)
        self._update_count()

    def _tab_action(self):
        mode = self._mode()
        vis = self._visible_rows()
        picked = [r for r in self.model.checked_rows() if r in vis]
        if mode in ('month', 'search'):
            todo = self._month_rows(vis) if mode == 'month' else [r for r in vis if self._can_start(r)]
            rows = [r for r in picked if r in todo]
            if not rows:
                return          # doar clientii bifati de analist
            names = '\n'.join(f'- {r.cp.name}' for r in rows[:10]) + (f'\n... (+{len(rows) - 10})' if len(rows) > 10 else '')
            if QMessageBox.question(self, 'Revizuire', f'Revizuiesc {len(rows)} clienți?\n\n{names}') != QMessageBox.Yes:
                return
            self.start_review(rows[:100])
        elif mode == 'process':
            self.next_rows([r for r in picked if self._next_ready(r)])
        elif mode == 'approval':
            self.record_approval([r for r in picked if stage(r, self.model.sap_company) == 'escalate'])

    def _tab_action2(self):
        """Al doilea buton de jos: "In lucru" -> Evalueaza din nou; "La aprobare" -> folderul clientului."""
        if self._mode() == 'process':
            self.redo_evaluation()
            return
        if self._mode() != 'approval':
            return
        vis = self._visible_rows()
        r = self.current_row() or (vis[0] if vis else None)
        if r and r.ev:
            doc = (r.ev.review or {}).get('review_doc')
            folder = r.ev.dest_dir or (str(Path(doc).parent) if doc else '')
            if folder:
                dialogs.open_path(folder)
                return
        self.open_folder()

    def record_approval(self, rows):
        """Aprobarea a venit pe alt canal (manager / EMEA / global): decizia (limitele din "Necesita aprobare") se scrie in
        NWCE; in SAP doar daca analistul bifeaza "Transcrie si in SAP" (acolo ar porni din nou workflow-ul de aprobare)."""
        from .. import review
        rows = [r for r in rows if r.ev is not None and r.ev.review]
        if not rows or self._writing('aprobarea'):
            return
        rates, lines = {}, []
        for r in rows:
            rv = r.ev.review or {}
            nv = self.model.new_values(r)
            lines.append([r.cp.name, r.cp.company_code or self.model.sap_company, f'{fmt_money(nv.get("open"))} {r.ev.currency or "EUR"}',
                          fmt_money(nv.get('mtm_usd')), nv.get('grade') or rv.get('grade_used') or '',
                          fmt_money(rv.get('group_total_usd') or rv.get('total_usd')), rv.get('authority') or ''])
        approvers = list(dict.fromkeys((r.ev.review or {}).get('authority') or '' for r in rows))
        dlg = dialogs.ExternalApprovalDialog(self, lines, approvers[0] if len(approvers) == 1 else '',
                                             self.cfg.get('sap', 'afterExternalApproval', default=False))
        if dlg.exec_() != QDialog.Accepted or self._writing('aprobarea'):
            return
        v = dlg.values()
        ctx = self._ui_ctx()
        ok, nofx = [], []
        for r in rows:
            ev = r.ev
            rate = self._usd_rate(ev.currency, rates)
            if not (rate or (ev.review or {}).get('usd_rate')):
                nofx.append(r)
                continue
            others = sum(g.kusd for g in r.group_rows if g.cp is not r.cp) * 1000 if r.group_rows else 0.0
            dec, _auth, rv = review.external_decision(ev, self.cfg, rate, others, v['by'], v['on'], v['write_sap'], v['comment'])
            rv['route'] = 'escalate'
            ev.review, ev.decision, ev.state = rv, dec, 'approved'
            ev.nwce = ev.sap = None
            pipeline.log_event(ctx, ev, 'INFO', 'Aprobare', f'Aprobat de {v["by"]} la {v["on"]:%d.%m.%Y}: Open {fmt_money(dec["limit_eur"])} '
                               f'{ev.currency}, MTM {fmt_money((dec.get("mtm_kusd") or 0) * 1000)} USD, grade {dec["grading"]} - '
                               + ('NWCE + SAP' if v['write_sap'] else 'doar NWCE (netranscris in SAP)'))
            self.db.save_evaluation(ev)
            self.model.update_evaluation(ev)
            ok.append(r)
        self._filter()
        self.refresh_steps()
        self._auto_write(ok)
        self.set_status(f'Aprobare inregistrata pentru {len(ok)} client(i): NWCE se scrie automat'
                        + (', apoi SAP.' if v['write_sap'] else '; SAP nu se transcrie.'), 'ok')
        if nofx:
            QMessageBox.warning(self, 'Aprobare', 'Cursul BCE nu e disponibil pentru moneda acestor clienti - nu s-au inregistrat:\n\n'
                                + '\n'.join(f'- {r.cp.name} ({r.ev.currency})' for r in nofx[:15]))

    def _can_start(self, r):
        """Un client poate intra in revizuire daca nu e deja in lucru / la aprobare (din "Toti clientii")."""
        st = stage(r, self.model.sap_company)
        return r.nwce is not None and st not in ('manual', 'decide', 'write', 'sap', 'inactive_todo', 'escalate', 'inactive')

    def _next_ready(self, r):
        """In "Proces initiat", gata de Next: revizuit, cu grad (scorecard sau NWCE) si fara decizie aprobata inca."""
        ev = r.ev
        if ev is None or ev.state not in ('evaluated', 'evaluated_manual'):
            return False
        rv = ev.review or {}
        return bool(rv) and rv.get('route') != 'inactive' and (ev.grade is not None or rv.get('grade_used') or (rv.get('edit') or {}).get('grade'))

    def next_rows(self, rows):
        """Next: limitele (propuse sau schimbate de analist) + grade-ul -> autoritate. In autoritate: decizie aprobata,
        NWCE + SAP automat. Peste: Annual Review in folderul clientului (Necesita aprobare)."""
        from .. import review
        if not rows:
            return
        rates, ok, esc, nofx = {}, [], [], []
        ctx = self._ui_ctx()
        for r in rows:
            ev = r.ev
            rate = self._usd_rate(ev.currency, rates)
            if not (rate or (ev.review or {}).get('usd_rate')):
                # fara curs BCE: Open limit KUSD ar ramane cel vechi (sau 0) langa limita noua -> nu se aproba
                nofx.append(r)
                continue
            others = sum(g.kusd for g in r.group_rows if g.cp is not r.cp) * 1000 if r.group_rows else 0.0
            dec, auth, rv = review.finalize(ev, self.cfg, rate, others)
            ev.review = rv
            if auth is not None and not auth.no_trade and not auth.exceeds_all and auth.name == self.cfg.get('approval', 'analystRow'):
                ev.decision = dec
                ev.state = 'approved'
                ev.nwce = ev.sap = None
                pipeline.log_event(ctx, ev, 'INFO', 'Next', f'Aprobat: Open {fmt_money(dec["limit_eur"])} {ev.currency}, MTM '
                                   f'{fmt_money((dec.get("mtm_kusd") or 0) * 1000)} USD, grade {dec["grading"]}, valid till '
                                   f'{fmt_date(dt.date.fromisoformat(dec["valid_till"]))} - {auth.name}')
                ok.append(r)
            else:
                rv['route'] = 'escalate'
                try:
                    rv['review_doc'] = str(self._review_doc_for(r, ev, rv))
                except Exception as e:
                    _log.exception('Annual review failed')
                    rv['review_doc_error'] = str(e)
                pipeline.log_event(ctx, ev, 'INFO', 'Next', f'Peste autoritate: {rv.get("authority_text")} - Annual Review in folderul clientului')
                esc.append(r)
            self.db.save_evaluation(ev)
            self.model.update_evaluation(ev)
        self._filter()
        self.refresh_steps()
        self._auto_write(ok)
        self.set_status(f'Next: {len(ok)} in autoritatea ta (NWCE + SAP in fundal), {len(esc)} necesita aprobare (Annual Review).',
                        'ok')
        if nofx:
            QMessageBox.warning(self, 'Next', 'Cursul BCE nu e disponibil pentru moneda acestor clienti, deci Open limit KUSD nu se '
                                'poate calcula. Nu s-au aprobat - reincearca dupa ce cursul e disponibil:\n\n'
                                + '\n'.join(f'- {r.cp.name} ({r.ev.currency})' for r in nofx[:15]))

    def _sap_auto(self):
        """SAP in fundal doar dupa o prima trimitere reala reusita (sap.verified) si daca nu e oprit din config."""
        return bool(self.cfg.get('sap', 'autoSubmit', default=True) and self.cfg.get('sap', 'verified', default=False))

    def _auto_write(self, rows):
        """Dupa revizuire: deciziile aprobate (in autoritate + inactivari) se scriu in NWCE fara butoane / confirmari;
        apoi SAP, daca e activat. Erorile raman vizibile in "Proces initiat"."""
        rows = [r for r in rows if r.ev and r.ev.state == 'approved' and (r.ev.nwce or {}).get('status') != 'ok']
        if rows:
            self.write_nwce(rows=rows, auto=True)

    def _month_rows(self, vis):
        from .. import review
        return [r for r in vis if stage(r, self.model.sap_company) in ('new', 'error') and review.expiring(r.nwce)]

    def _double_clicked(self, idx):
        key = COLUMNS[self.proxy.mapToSource(idx).column()][0]
        if key in ('m_fin', 'm_exp', 'm_pay'):
            return          # editarea criteriului (delegatul)
        # fara ferestre separate: limitele, grade-ul si subiectivele se modifica direct in celulele din "Proces initiat"

    def _cell_edited(self, r, key, value):
        """O valoare schimbata direct in tabel ("Proces initiat"): subiectivele se scriu in scorecardul clientului si
        Excel recalculeaza grade-ul; limitele / valabilitatea / grade-ul se recalculeaza fata de autoritate si 30% equity."""
        from ..scorecard_live import LiveScorecard
        from .models import MANUAL_COLS
        ev = r.ev
        if key in MANUAL_COLS:
            crit = MANUAL_COLS[key]
            self.overrides.setdefault(r.cp.partner, {})[crit] = value      # si la o reevaluare ulterioara
            path = (ev.files or {}).get('scorecard') if ev.grade is not None else None
            if not path:
                self.set_status(f'{ev.name}: {crit} = {value} salvat (fara scorecard - grade-ul ramane cel din coloana "Nou").', 'ok')
            if path:
                QApplication.setOverrideCursor(QCursor(Qt.WaitCursor))
                self.set_status(f'{ev.name}: recalculez scorecardul ({crit} = {value})...')
                QApplication.processEvents()
                try:
                    lv = LiveScorecard(path, excel=self._shared_excel())
                    try:
                        res = lv.set(**{crit: value})
                        lv.save()
                    finally:
                        lv.close()
                    sc = dict(ev.scorecard or {})
                    old = sc.get('grade')
                    sc.update(grade=res.get('grade'), scale=res.get('scale'), points=res.get('points'), criteria=res.get('criteria'))
                    if res.get('equity_usd') is not None:
                        sc['equity_usd'] = f'{res["equity_usd"]:,.0f}'
                    ev.scorecard = sc
                    pipeline.log_event(self._ui_ctx(), ev, 'INFO', 'Scorecard',
                                       f'{crit} = {value}: grade {old} → {res.get("grade")} ({res.get("points")} puncte) - salvat in scorecard')
                    self.set_status(f'{ev.name}: grade {old} → {res.get("grade")} ({res.get("points")} puncte).', 'ok')
                except Exception as e:
                    _log.exception('Live scorecard failed')
                    self._close_shared_excel()
                    # scorecardul nu s-a recalculat: criteriul revine la valoarea de dinainte (altfel tabelul si grade-ul nu se potrivesc)
                    self.model.undo_manual(r)
                    self.overrides.get(r.cp.partner, {}).pop(crit, None)
                    self.set_status(f'{ev.name}: criteriul nu s-a schimbat - scorecardul nu s-a putut recalcula.', 'warn')
                    f = errors.friendly(e)
                    self._error_box(dict(f, action=f'Alegerea nu s-a salvat (criteriul a rămas cel de dinainte). {f["action"]}'))
                finally:
                    QApplication.restoreOverrideCursor()
        self._preview(r)
        self.db.save_evaluation(ev)
        self.model.update_evaluation(ev)
        self.refresh_steps()
        if self.current_row() is r:
            self.show_details()

    def _preview(self, r):
        """Recalculeaza pe rand (fara sa aprobe nimic): total USD, autoritate, 30% equity, equity scenario."""
        from .. import review
        ev = r.ev
        rate = self._usd_rate(ev.currency, {})
        others = sum(g.kusd for g in r.group_rows if g.cp is not r.cp) * 1000 if r.group_rows else 0.0
        _dec, auth, rv = review.finalize(ev, self.cfg, rate, others)
        rv['would_escalate'] = not (auth is not None and not auth.no_trade and not auth.exceeds_all
                                    and auth.name == self.cfg.get('approval', 'analystRow'))
        if rv.get('route') == 'escalate' and not rv['would_escalate']:
            rv['route'] = 'auto'       # limita scazuta in autoritate: din "Necesita aprobare" inapoi in "Proces initiat"
        ev.review = rv

    def _shared_excel(self):
        """O singura instanta Excel pentru modificarile din tabel (se inchide singura dupa 2 minute fara folosire)."""
        from ..excel_com import ExcelApp
        xl = getattr(self, '_xl', None)
        if xl is not None:
            try:
                _ = xl.xl.Version
            except Exception:
                self._close_shared_excel()
                xl = None
        if xl is None:
            self._xl = xl = ExcelApp(visible=False)
        if not hasattr(self, '_xl_timer'):
            self._xl_timer = QTimer(self)
            self._xl_timer.setSingleShot(True)
            self._xl_timer.timeout.connect(self._close_shared_excel)
        self._xl_timer.start(120_000)
        return xl

    def _close_shared_excel(self):
        xl, self._xl = getattr(self, '_xl', None), None
        if xl is not None:
            try:
                xl.quit()
            except Exception as e:
                _log.warning('Shared Excel quit: %s', e)

    # ================================================================ revizuirea lunara
    def start_review(self, rows):
        if self.busy() or not rows:
            return
        from .. import invoices, review

        stale = self.nwce is None or (dt.datetime.now() - self.nwce.loaded_at).total_seconds() > 300

        def job(w):
            snap = None
            if stale:          # revizuirea porneste de la NWCE proaspat (corecturile facute manual intre timp)
                w.report('Recitesc NWCE de pe SharePoint inainte de revizuire (~20 s)...')
                try:
                    snap = limits_book.load(self.cfg, use_cache=False)
                except Exception as e:
                    _log.warning('NWCE refresh before review failed: %s', e)
            path = Path(paths.expand(self.cfg.get('portfolio', 'invoicesPath')))
            try:
                return invoices.load(path, progress=w.report), snap
            except Exception as e:
                _log.warning('Invoices not loaded: %s', e)
                return None, snap

        def loaded(res):
            nonlocal rows
            inv, snap = res
            if snap is not None:
                partners = [r.cp.partner for r in rows]
                self.nwce = snap
                self.model.load(self.portfolio, self.db.latest_evaluations(), snap, self.cfg.get('limitsBook', 'companyCode'),
                                self.cfg.get('portfolio', 'country'), self.cfg)
                self._filter()
                self._update_labels()
                rows = [self.model.by_partner[p] for p in partners if p in self.model.by_partner]
                rows = [r for r in rows if stage(r, self.model.sap_company) not in ('write', 'sap')]
                if not rows:
                    self.set_status('NWCE recitit: clientii bifati nu mai sunt de revizuit.', 'warn')
                    return
            self.invoices = inv
            months = int(self.cfg.get('review', 'invoiceMonths', default=24) or 24)
            ctx = self._ui_ctx()
            active, inactive = [], []
            self._review_info = getattr(self, '_review_info', {})
            for r in rows:
                exp, label = review.next_month_exposure(r.cp)
                act, why = review.activity(r.cp, exp, inv, months, portfolio=self.portfolio,
                                           country=self.cfg.get('portfolio', 'country'))
                self._review_info[r.cp.partner] = {'exposure': exp, 'exposure_month': label, 'active': act, 'active_why': why}
                (active if act is not False else inactive).append(r)
            for r in inactive:
                ev = pipeline.new_evaluation(ctx, r.cp)
                ev.review = dict(self._review_info[r.cp.partner], route='inactive')
                pipeline.log_event(ctx, ev, 'INFO', 'Revizuire', f'Fara activitate: {ev.review["active_why"]} - inactivare automata in NWCE')
                # fara expunere si fara facturi pe 2 ani: inactivare (0 la limite, date goale) scrisa automat in NWCE
                ev.decision = pipeline.inactivation_decision(ctx, ev, 'Fara expunere si fara facturi in ultimii 2 ani')
                ev.state = 'approved'
                self.db.save_evaluation(ev)
                self.model.update_evaluation(ev)
            if inv is None:
                self.set_status('Atentie: fisierul de facturi nu a putut fi citit - clientii fara expunere NU s-au inactivat '
                                '(activitatea nu se poate verifica); merg mai departe in revizuire.', 'warn')
            self._auto_queue = [r for r in inactive if r.nwce is not None]
            # scorecard doar pentru limite mari: Open + MTM nou sub prag (implicit 350.000 USD) -> fara scorecard
            rates, limit_usd = {}, int(float(self.cfg.get('review', 'scorecardMinUsd', default=350000) or 0))
            for r in active:
                o = self.overrides.setdefault(r.cp.partner, {})
                o.pop('skip_scorecard', None)
                if r.nwce is None:
                    continue
                need, total = review.needs_scorecard(r.nwce, self._review_info[r.cp.partner]['exposure'], self.cfg,
                                                     self._usd_rate(r.cp.currency, rates))
                self._review_info[r.cp.partner]['limit_usd'] = total
                if not need:
                    o['skip_scorecard'] = f'Open + MTM {fmt_money(total)} USD sub pragul de {fmt_money(limit_usd)} USD'
            if active:
                self.evaluate(rows=active, after=self._after_review)
            else:
                self._filter()
                self.refresh_steps()
                q, self._auto_queue = self._auto_queue, []
                self._auto_write(q)

        self.start_job(job, on_done=loaded, name='invoices')

    def _after_review(self, results):
        from .. import review
        rates = {}
        n_auto = n_esc = n_man = n_err = 0
        for ev in results:
            r = self.model.by_partner.get(ev.partner)
            if r is None:
                continue
            info = getattr(self, '_review_info', {}).get(ev.partner)
            if info is None:
                exp, label = review.next_month_exposure(r.cp)
                info = {'exposure': exp, 'exposure_month': label, 'active': True, 'active_why': 'reevaluare'}
            if ev.state == 'error':
                ev.review = dict(info, route='error')
                n_err += 1
                self.db.save_evaluation(ev)
                self.model.update_evaluation(ev)
                continue
            rate = self._usd_rate(ev.currency, rates)
            rv = review.plan(ev, r.cp, r.group_rows, self.cfg, rate, info['exposure'])
            rv.update(info)
            rv['manual'] = dict((r.ev.review or {}).get('manual', {})) if r.ev is not ev and r.ev else {}
            ev.review = rv
            # propunerea afisata peste tot = cea din revizuire (reinnoire / expunerea din luna urmatoare), nu varf + 10%
            old_p = ev.proposal or {}
            ev.proposal = {'proposed': rv['new_open_local'], 'current': float(((ev.nwce_row or {}).get('values') or {}).get('open_kloc') or 0) * 1000,
                           'need': rv.get('exposure'), 'cap': None, 'peak': old_p.get('peak'), 'peak_week': old_p.get('peak_week'),
                           'lines': [f'Varf expunere de saptamana viitoare ({rv.get("exposure_month", "")}): {fmt_money(rv.get("exposure"))}',
                                     rv.get('limit_why', '')],
                           'warnings': [w for w in old_p.get('warnings', []) if 'Grad' in w or 'equity' in w.lower()]}
            if ev.grade is None:
                # fara financiare: scorecardul nu se poate completa -> se sare la etapa urmatoare cu gradul din NWCE
                skipped = (ev.inputs or {}).get('scorecard_skipped')
                min_usd = fmt_money(float(self.cfg.get('review', 'scorecardMinUsd', default=350000) or 0))
                if rv.get('grade_used'):
                    rv['note'] = (f'Fără scorecard: limita e sub {min_usd} $. Rămâne grade {rv["grade_used"]} din NWCE.' if skipped else
                                  f'Creditsafe nu are bilanț, deci fără scorecard. Rămâne grade {rv["grade_used"]} din NWCE.')
                    pipeline.log_event(self._ui_ctx(), ev, 'INFO', 'Revizuire', rv['note'])
                else:
                    rv['route'] = 'manual'
                    rv['note'] = (f'Fără scorecard: limita e sub {min_usd} $' if skipped else 'Creditsafe nu are bilanț') + \
                        ', iar NWCE nu are grade. Alege grade-ul în dreapta.'
            elif review.manual_needed(ev):
                rv['route'] = 'manual'
            if rv['route'] == 'auto':
                # propunerea ramane in "Proces initiat": analistul o verifica / ajusteaza si apasa Next
                n_auto += 1
                pipeline.log_event(self._ui_ctx(), ev, 'INFO', 'Revizuire',
                                   f'Grade {rv.get("grade_used")}, total {fmt_money(rv["total_usd"])} USD - in autoritatea ta ({rv["authority"]}): '
                                   'propunere gata de Next')
            elif rv['route'] == 'escalate':
                n_esc += 1
                try:
                    rv['review_doc'] = str(self._review_doc_for(r, ev, rv))
                    pipeline.log_event(self._ui_ctx(), ev, 'INFO', 'Revizuire',
                                       f'Peste autoritate: {rv["authority_text"]} Annual Review: {rv["review_doc"]}')
                except Exception as e:
                    _log.exception('Annual review failed')
                    rv['review_doc_error'] = str(e)
                    pipeline.log_event(self._ui_ctx(), ev, 'ERROR', 'Revizuire', f'Peste autoritate; Annual Review NU s-a generat: {e}')
            else:
                n_man += 1
            self.db.save_evaluation(ev)
            self.model.update_evaluation(ev)
        self._filter()
        self.refresh_steps()
        # in autoritate + inactivari -> NWCE (si SAP, daca e activat) in fundal, fara butoane
        queue = [self.model.by_partner[ev.partner] for ev in results
                 if ev.partner in self.model.by_partner and ev.state == 'approved'] + list(getattr(self, '_auto_queue', []))
        self._auto_queue = []
        n_inact = len([r for r in queue if (r.ev.decision or {}).get('inactivate')])
        self._auto_write(queue)
        text = (f'Revizuire terminata: {n_auto} in autoritatea ta, {n_esc} necesita aprobare, {n_man} de completat, '
                f'{n_inact} inactivati, {n_err} cu eroare.')
        self.set_status(text, 'warn' if (n_man or n_err) else 'ok')
        QMessageBox.information(self, 'Revizuire', 'Revizuire terminată:\n\n'
                                f'În autoritatea ta:  {n_auto}   („În lucru” - verifici și trimiți)\n'
                                f'La aprobare:  {n_esc}   (Annual Review)\n'
                                f'De completat:  {n_man}\n'
                                f'Inactivati:  {n_inact}\n'
                                f'Cu eroare:  {n_err}')

    def recalc_manual(self, rows):
        if not rows:
            return
        for r in rows:
            o = self.overrides.setdefault(r.cp.partner, {})
            o['connect_id'] = r.ev.connect_id
            o['candidates'] = r.ev.cs_candidates
            for crit, val in ((r.ev.review or {}).get('manual') or {}).items():
                o[crit] = val
            self._review_info = getattr(self, '_review_info', {})
            self._review_info[r.cp.partner] = {k: (r.ev.review or {}).get(k) for k in ('exposure', 'exposure_month', 'active', 'active_why')}
        self.evaluate(rows=rows, after=self._after_review)

    def _review_doc_for(self, r, ev, rv):
        """Annual Review pentru un client (sau tot grupul lui) - salvat in folderul clientului, nu se deschide."""
        from .. import groups, rules
        rows = [x for x in r.group_rows if x.nwce is not None] or [r]
        lines = groups.member_lines(rows)
        for m in lines:
            if m.row is r:
                m.new_open_usd = rv['new_open_kusd'] * 1000
                m.new_mtm_usd = rv['mtm_kusd'] * 1000
        grade = ev.grade if ev.grade is not None else rv.get('grade_used')
        src = 'scorecard Creditsafe' if ev.grade is not None else 'NWCE (Creditsafe fara bilant - scorecard nefacut)'
        a = rules.approval_authority(grade, sum(m.new_total_usd for m in lines), self.cfg)
        # Overview: limita in moneda locala (Open) si MTM fata de cele actuale - aceeasi / crestere / scadere
        vals = (ev.nwce_row or {}).get('values') or {}
        cur = (round(float(vals.get('open_kloc') or 0) * 1000), round(float(vals.get('mtm_kusd') or 0) * 1000))
        new = (round(float(rv.get('new_open_local') or 0)), round(float(rv.get('mtm_kusd') or 0) * 1000))
        change = 'same' if new == cur else ('up' if sum(new) > sum(cur) else 'down')
        data = {'title': r.group_name or r.cp.name, 'grade': grade, 'grade_source': src, 'lines': lines,
                'authority': a, 'compliance': 'OK', 'parent_ev': ev, 'limit_change': change,
                'equity_scenario': rv.get('equity_scenario')}
        return self._make_review(data, open_doc=False)

    def _apply_inactivation_rows(self, rows):
        rows = [r for r in rows if r.nwce is not None and not r.cp.inactive]
        if not rows:
            return
        if QMessageBox.question(self, 'Inactivare', f'Inactivez {len(rows)} randuri (0 la limite, date goale in NWCE)? '
                                'Se scrie automat în NWCE.') != QMessageBox.Yes:
            return
        self._apply_inactivation(rows)

    def _update_side(self, r):
        self._update_action()

    def show_guide(self):
        GuideDialog(self).exec_()
        if not self.cfg.get('ui', 'guideShown'):
            self.cfg.set(True, 'ui', 'guideShown')
            try:
                self.cfg.save()
            except OSError:
                pass

    # ================================================================ helpers
    def set_status(self, text, level='info'):
        text = errors.short_text(text, 400)
        color = {'ok': '#1B5E20', 'warn': '#9C5700', 'error': '#B71C1C'}.get(level, '#333333')
        self.status.setStyleSheet(f'font-weight:bold;padding:2px 6px;color:{color}')
        self.status.setText(text)

    def busy(self):
        if getattr(self, '_job_active', False):
            QMessageBox.information(self, 'Ocupat', 'O operatie ruleaza deja. Asteapta sa se termine sau apasa Stop (jos, dreapta).')
            return True
        return False

    def _action_widgets(self):
        return (self.act, self.act2, self.a_reload, self.a_nwce)

    def start_job(self, fn, *args, on_done=None, on_item=None, name='job', **kwargs):
        w = Worker(fn, *args, name=name, **kwargs)
        w.progress.connect(self._on_progress)
        if on_item:
            w.item.connect(on_item)
        w.done.connect(lambda res: self._job_finished(res, on_done))
        w.failed.connect(self._job_failed)
        # Rezultatul (done) soseste cat firul inca se inchide; urmatorul job porneste chiar din on_done.
        # Firul vechi trebuie tinut in viata pana la "finished" - altfel Qt opreste aplicatia
        # ("QThread: Destroyed while thread is still running", crash 0xc0000409 in Qt5Core).
        self._threads = getattr(self, '_threads', set())
        self._threads.add(w)
        w.finished.connect(lambda w=w: self._threads.discard(w))
        self._job_active = True
        self._job_name = name
        self.worker = w
        for b in self._action_widgets():
            b.setEnabled(False)
        self.b_stop.setEnabled(True)
        self.progress.setRange(0, 0)
        w.start()

    def _on_progress(self, text, done, total):
        self.set_status(text)
        if total and total > 0:
            self.progress.setRange(0, total)
            self.progress.setValue(max(0, done))
        else:
            self.progress.setRange(0, 0)

    def _job_end(self):
        self._job_active = False
        self._job_name = ''
        for b in self._action_widgets():
            b.setEnabled(True)
        self.b_stop.setEnabled(False)
        self.progress.setRange(0, 1)
        self.progress.setValue(0)
        # scrierile NWCE automate amanate cat rula alt job (orice job, si cand a esuat) - dupa on_done
        QTimer.singleShot(0, self._flush_pending_write)

    def _flush_pending_write(self):
        pend = getattr(self, '_pending_write', [])
        if pend and not getattr(self, '_job_active', False):
            self._pending_write = []
            self._auto_write(pend)

    def _writing(self, what='decizia'):
        """True (cu mesaj) cat timp ruleaza o scriere NWCE / SAP: evaluarile din lot nu se modifica in paralel."""
        if getattr(self, '_job_active', False) and getattr(self, '_job_name', '') in ('nwce', 'sap', 'nwce-restore'):
            QMessageBox.information(self, 'Asteapta', f'Se scrie acum in NWCE / SAP. Modifica {what} dupa ce se termina.')
            return True
        return False

    def _job_finished(self, res, on_done):
        self._job_end()
        if on_done:
            try:
                on_done(res)
            except Exception as e:
                _log.exception('on_done failed')
                self.show_error(e)
        self.refresh_steps()
        self.show_details()

    def _job_failed(self, f):
        self._job_end()
        self.refresh_steps()
        if f['code'] == 'CANCELLED':
            self.set_status('Oprit de utilizator.', 'warn')
            return
        self.set_status(f['title'], 'error')
        self._error_box(f)

    def show_error(self, exc):
        self._error_box(errors.friendly(exc))

    def _error_box(self, f):
        """Mesaj scurt: ce s-a intamplat + ce ai de facut. Detaliile tehnice doar la "Show Details"."""
        box = QMessageBox(QMessageBox.Warning, f['title'], f'<b>{html.escape(f["title"])}</b><br><br>{html.escape(f["action"])}', parent=self)
        if f.get('details'):
            box.setDetailedText(f['details'])
        box.exec_()

    def stop_job(self):
        if self.worker:
            self.worker.cancel()
            self.set_status('Se opreste dupa pasul curent...', 'warn')

    def ctx(self, w):
        return pipeline.Context(self.cfg, self.db, self.cs, self.nwce, self.portfolio, progress=w.report, cancel=w.cancelled)

    def current_row(self):
        idx = self.table.currentIndex()
        if not idx.isValid():
            return None
        p = self.proxy.data(idx, PARTNER_ROLE)
        return self.model.by_partner.get(p)

    def target_rows(self):
        """Clientii bifati; daca nu e niciunul bifat - cei selectati in tabel."""
        rows = self.model.checked_rows()
        if rows:
            return rows
        sel = self.table.selectionModel().selectedRows()
        return [self.model.by_partner[self.proxy.data(i, PARTNER_ROLE)] for i in sel]

    def _toggle_selected(self):
        for i in self.table.selectionModel().selectedRows():
            r = self.model.by_partner[self.proxy.data(i, PARTNER_ROLE)]
            r.checked = not r.checked
        self.model._all_changed()
        self.refresh_steps()

    def _check_visible(self, value, all_rows=False):
        if all_rows:
            for r in self.model.rows:
                r.checked = value
        else:
            for i in range(self.proxy.rowCount()):
                self.model.by_partner[self.proxy.data(self.proxy.index(i, 0), PARTNER_ROLE)].checked = value
        self.model._all_changed()
        self.refresh_steps()

    def _filter(self):
        p = self.proxy
        p.text = self.f_text.text().strip()
        p.only_over = self.flt['over']
        p.only_list = self.flt['eval_sheet']
        p.hide_blocked = not self.flt['show_blocked']
        p.only_sales = self.flt['sales']
        p.bu = self.flt['bu']
        p.state = ''
        p.view = TAB_VIEW[self._mode()]
        p.tbd = self.f_tbd.currentData() or ''
        p.refresh()
        self.refresh_steps()

    def _tbd_changed(self):
        self._filter()

    def _fill_tbd(self):
        cur = self.f_tbd.currentData()
        owners = set(self.model.tbd_owners()) | (set(self.nwce.tbd_owners()) if self.nwce else set())
        self.f_tbd.blockSignals(True)
        self.f_tbd.clear()
        self.f_tbd.addItem('Toți (Open Contracts ITA)', '')
        me = (self.cfg.get('analyst', 'initials') or '').upper()
        for o in sorted(owners, key=lambda x: (x != me, x)):
            self.f_tbd.addItem(f'{"Lista mea - " if o == me else "TBD by "}{o}  ({self.model.tbd_count(o)} rânduri)', o)
        want = cur if cur is not None and getattr(self, '_tbd_init', False) else me
        i = self.f_tbd.findData(want)
        self.f_tbd.setCurrentIndex(max(0, i))
        self.f_tbd.blockSignals(False)
        self._tbd_init = True
        self._fill_list_menu()

    def _fill_list_menu(self):
        """Meniul "Lista" (sus): lista ta din coloana "TBD by" a NWCE, listele colegilor sau toti clientii din Italia."""
        m = self.m_list
        m.clear()
        group = QActionGroup(m)
        group.setExclusive(True)
        for i in range(self.f_tbd.count()):
            a = m.addAction(self.f_tbd.itemText(i))
            a.setCheckable(True)
            a.setChecked(i == self.f_tbd.currentIndex())
            group.addAction(a)
            a.triggered.connect(lambda _c=False, idx=i: self._pick_list(idx))
        cur = self.f_tbd.currentData()
        me = (self.cfg.get('analyst', 'initials') or '').upper()
        m.setTitle('Listă: ' + ('a mea' if cur == me else (cur or 'toți (Italia)')))

    def _pick_list(self, idx):
        self.f_tbd.setCurrentIndex(idx)        # -> _tbd_changed -> _filter
        self._fill_list_menu()

    def _update_count(self):
        vis = self._visible_rows()
        n_checked = len([r for r in self.model.checked_rows() if r in vis])
        clients = len(getattr(self.proxy, '_visible', ()))
        self.lbl_count.setText(f'{n_checked} bifați · {clients} clienți')

    def _link(self, url):
        p = url.toLocalFile() or url.toString()
        if not dialogs.open_path(p):
            QDesktopServices.openUrl(url)

    # ================================================================ incarcare
    def load_data(self, refresh_nwce=False):
        if self.busy():
            return

        def job(w):
            out = {'notes': []}
            w.report('Citesc lista de clienti (Open Contracts ITA)...')
            out['portfolio'] = portfolio.load(self.cfg.portfolio_path, self.cfg, progress=w.report)
            w.report('Citesc excelul de limite NWCE' + (' de pe SharePoint (~20 s)...' if refresh_nwce or not self.nwce else '...'))
            try:
                out['nwce'] = limits_book.load(self.cfg, use_cache=not refresh_nwce)
            except Exception as e:
                out['nwce'] = None
                out['notes'].append('NWCE nu a putut fi citit: ' + errors.short_text(getattr(e, 'message', e), 160))
            w.report('Curs EUR/USD (BCE)...')
            out['fx'] = fx.eur_usd_today(self.cfg)
            out['credits'] = None
            out['cs_error'] = ''
            if has_credentials(self.cfg):
                w.report('Login Creditsafe (app.creditsafe.com)...')
                try:
                    out['credits'] = self.cs.credits(self.cfg.get('portfolio', 'country'))
                except Exception as e:
                    out['cs_error'] = errors.short_text(getattr(e, 'message', e), 160)
                    out['notes'].append('Creditsafe: ' + out['cs_error'])
            else:
                out['cs_error'] = 'lipseste parola'
                out['notes'].append('Creditsafe: lipseste parola - meniul Setari → Parola Creditsafe.')
            return out

        def done(out):
            self.portfolio = out['portfolio']
            if out['nwce'] is not None:
                self.nwce = out['nwce']
            self.eur_usd, self.eur_usd_src = out['fx']
            self.credits = out['credits']
            self._cs_error = out['cs_error']
            company = self.cfg.get('limitsBook', 'companyCode')
            country = self.cfg.get('portfolio', 'country')
            # evaluarile recitite acum (nu cele de la pornirea jobului): editarile facute in timpul incarcarii raman
            self.model.load(self.portfolio, self.db.latest_evaluations(), self.nwce, company, country, self.cfg)
            self._fill_tbd()
            self._filter()
            self.table.sortByColumn(COL['valid'], Qt.AscendingOrder)
            self._update_action()
            self._update_labels()
            notes = out['notes'] + self.portfolio.notes
            msg = f'Date incarcate: {len(self.portfolio)} clienti Open Contracts, {len(self.nwce.rows) if self.nwce else 0} randuri NWCE.'
            if notes:
                msg += '  ' + ' | '.join(notes)
            self.set_status(msg, 'warn' if notes else 'ok')
            self.show_details()
            if not self.cfg.get('ui', 'guideShown'):
                QTimer.singleShot(300, self.show_guide)
            # pornire rapida din copia locala, apoi NWCE proaspat de pe SharePoint, in fundal (modificarile colegilor / ale tale)
            if not refresh_nwce and self.nwce is not None and \
                    (dt.datetime.now() - self.nwce.loaded_at).total_seconds() > 120:
                QTimer.singleShot(500, self.refresh_nwce_bg)

        self.start_job(job, on_done=done, name='load')

    def refresh_nwce_bg(self):
        """Reciteste NWCE de pe SharePoint in fundal si reface lista (si randurile TBD noi)."""
        if getattr(self, '_job_active', False):
            QTimer.singleShot(5000, self.refresh_nwce_bg)     # dupa jobul curent
            return

        def job(w):
            w.report('Actualizez NWCE de pe SharePoint (~20 s)...')
            return limits_book.load(self.cfg, use_cache=False)

        def done(snap):
            self.nwce = snap
            company = self.cfg.get('limitsBook', 'companyCode')
            country = self.cfg.get('portfolio', 'country')
            self.model.load(self.portfolio, self.db.latest_evaluations(), snap, company, country, self.cfg)
            self._fill_tbd()
            self._filter()
            self._update_labels()
            self.show_details()
            self.set_status(f'NWCE actualizat de pe SharePoint: {len(snap.rows)} randuri ({snap.loaded_at:%d.%m %H:%M}).', 'ok')

        self.start_job(job, on_done=done, name='nwce-refresh')

    def _update_labels(self):
        c = self.credits
        if c:
            left = 'nelimitat' if c.get('unlimited') else f'{c["left"]:,}'.replace(',', '.')
            low = not c.get('unlimited') and c['left'] <= int(self.cfg.get('creditsafe', 'lowCreditsWarning'))
            exp = f' (expiră {c["expires"]:%d.%m.%Y})' if c.get('expires') else ''
            self.chip_cs.set('warn' if low else 'ok', f'Creditsafe: {left} rapoarte' if low else 'Creditsafe OK',
                             f'{left} rapoarte rămase{exp}. Conectat la {self._cs_label()}.\nClick = schimbă parola.')
        else:
            err = getattr(self, '_cs_error', '')
            self.chip_cs.set('bad', 'Creditsafe: neconectat', f'{err}\nClick = introdu parola Creditsafe.')
        self.lbl_fx.setText(f'EUR/USD {self.eur_usd:.4f}' + ('' if self.eur_usd_src == 'ECB' else f' ({self.eur_usd_src})'))
        if self.nwce:
            fresh = not self.nwce.from_cache and self.nwce.loaded_at.date() == dt.date.today()
            src = 'copie locală' if self.nwce.from_cache else 'SharePoint'
            self.chip_nwce.set('ok' if fresh else 'info', 'NWCE la zi' if fresh else f'NWCE: copie {self.nwce.loaded_at:%d.%m %H:%M}',
                               f'{len(self.nwce.rows)} rânduri, citit {self.nwce.loaded_at:%d.%m.%Y %H:%M} din {src}.\n'
                               'Click = recitește de pe SharePoint.')
        else:
            self.chip_nwce.set('bad', 'NWCE necitit', 'Click = citește de pe SharePoint.')

    def _cs_label(self):
        return 'app.creditsafe.com' if getattr(self.cs, 'mode', 'api') == 'web' else f'Creditsafe API ({self.cfg["environment"]})'

    # ================================================================ detalii
    def show_details(self):
        r = self.current_row()
        self._update_side(r)
        self.side.show_row(r, self.model)
        if self.details_dlg.isVisible():
            self._fill_details(r)

    def show_full_details(self):
        """"Toate detaliile": pagina completa a clientului, graficul de expunere si istoricul."""
        r = self.current_row()
        if not r:
            return
        self._fill_details(r)
        self.details_dlg.setWindowTitle(f'Toate detaliile – {r.cp.name}')
        self.details_dlg.show()
        self.details_dlg.raise_()

    def _side_edit(self, key, value):
        """O valoare schimbata in panoul din dreapta: aceeasi cale ca editarea in tabel (scorecard, autoritate, 30% equity)."""
        r = self.current_row()
        if r is None or key not in COL:
            return
        self.model.setData(self.model.index(self.model.rows.index(r), COL[key]), value, Qt.EditRole)

    def _fill_details(self, r):
        if not r:
            self.details.setHtml('<p style="color:#777">Selecteaza un client din tabel.</p>')
            self.chart.clear('Selecteaza un client.')
            self.journal.setHtml('')
            return
        cp, ev = r.cp, r.ev
        if ev:
            self.details.setHtml(dialogs.client_info_html(ev, cp, group=r.group_rows))
        else:
            self.details.setHtml(dialogs.client_info_html(None, cp, r.nwce, group=r.group_rows))
        self.chart.show_counterparty(cp, (ev.decision or {}).get('limit_eur') if ev and ev.decision else ((ev.proposal or {}).get('proposed') if ev else None))
        self._show_journal(r)

    def _show_journal(self, r):
        h = []
        hist = self.db.history(r.cp.partner)
        if hist:
            h.append('<h3>Evaluari</h3><table cellpadding=3>' + ''.join(
                f'<tr><td>#{x["id"]}</td><td>{fmt_date(x["created"])} {x["created"][11:16]}</td><td>{pipeline.STATE_LABELS.get(x["state"], x["state"])}</td></tr>' for x in hist) + '</table>')
        if r.ev and r.ev.id:
            evs = self.db.events(r.ev.id)
            if evs:
                h.append('<h3>Pasi (ultima evaluare)</h3><table cellpadding=2>' + ''.join(
                    f'<tr><td>{e["ts"][11:19]}</td><td><b>{html.escape(e["level"])}</b></td><td>{html.escape(e["step"] or "")}</td><td>{html.escape(e["message"] or "")}</td></tr>' for e in evs) + '</table>')
        ch = self.db.changes(r.cp.partner)
        if ch:
            h.append('<h3>Modificari NWCE / SAP</h3><table cellpadding=2>' + ''.join(
                f'<tr><td>{c["ts"][:16].replace("T", " ")}</td><td>{c["target"]}</td><td>{html.escape(c["field"] or "")}</td>'
                f'<td>{html.escape(c["old_value"] or "")} &rarr; <b>{html.escape(c["new_value"] or "")}</b></td><td>{c["status"]}</td></tr>' for c in ch) + '</table>')
        self.journal.setHtml(''.join(h) or '<p style="color:#777">Nicio evaluare inca.</p>')

    def open_folder(self):
        r = self.current_row()
        if not r:
            return
        ev = r.ev
        p = (ev.dest_dir or ev.folder) if ev else None
        if not p:
            from .. import client_folders
            root = self.cfg.counterparties_root
            res = client_folders.resolve_client_folder(root, [r.cp.name, r.nwce.name if r.nwce else ''], r.cp.name)
            p = str(res.path) if res.exists else root
        if not dialogs.open_path(p):
            self.set_status(f'Folderul nu exista: {p}', 'warn')

    def open_file(self, kind):
        r = self.current_row()
        p = ((r.ev.files or {}).get(kind) if r and r.ev else None)
        if not dialogs.open_path(p):
            self.set_status('Fisierul nu exista pentru clientul selectat (evalueaza-l intai).', 'warn')

    # ================================================================ 1. evaluare
    def evaluate(self, rows=None, after=None):
        if self.busy() or not self.portfolio:
            return
        rows = rows or self.target_rows()
        if not rows:
            QMessageBox.information(self, 'Evaluare', 'Bifeaza clientii de evaluat (coloana din stanga / tasta Space) sau selecteaza-i in tabel.')
            return
        if len(rows) > 100:
            QMessageBox.information(self, 'Evaluare', f'{len(rows)} clienti selectati - maximum 100 pe lot.')
            return
        cps = {r.cp.partner: r.cp for r in rows}

        def job(w):
            ctx = self.ctx(w)
            w.report(f'Caut {len(cps)} clienti in Creditsafe (gratuit)...', 0, len(cps))
            preps = [None] * len(rows)
            with cf.ThreadPoolExecutor(max_workers=6, thread_name_prefix='search') as pool:
                futs = {pool.submit(pipeline.prepare, ctx, r.cp, self.overrides.get(r.cp.partner)): i for i, r in enumerate(rows)}
                for n, f in enumerate(cf.as_completed(futs), 1):
                    preps[futs[f]] = f.result()
                    w.report(f'Caut in Creditsafe: {n}/{len(rows)}', n, len(rows))
            credits = None
            try:
                credits = self.cs.credits(self.cfg.get('portfolio', 'country'))
            except Exception:
                pass
            return preps, credits

        def prepared(res):
            preps, credits = res
            self.credits = credits or self.credits
            self._update_labels()
            # fereastra de confirmare doar cand e ceva de decis (firma negasita / ambigua / fara VAT)
            clear = all(ev.state == 'prepared' and not any(w.startswith('Creditsafe a gasit') for w in ev.warnings) for ev in preps)
            if clear and not self.cfg.get('creditsafe', 'alwaysConfirm'):
                sel, force = preps, False
            else:
                dlg = dialogs.PrepareDialog(self, preps, self.cs, credits, self.cfg)
                if dlg.exec_() != QDialog.Accepted:
                    self.set_status('Evaluare anulata - nu s-a deschis niciun raport.', 'warn')
                    return
                sel = dlg.selected()
                force = dlg.force_refresh()
            for ev in sel:
                o = self.overrides.setdefault(ev.partner, {})
                # "Evalueaza din nou" (din Proces initiat): raport Creditsafe nou + scorecardul vechi inlocuit
                row = self.model.by_partner.get(ev.partner)
                redo = pipeline.wants_redo(row.ev if row else None)
                o['force_refresh'] = force or redo
                o['replace_scorecard'] = redo
            self._run_evaluation(sel, cps, after)

        self.start_job(job, on_done=prepared, name='prepare')

    def _run_evaluation(self, preps, cps, after=None):
        overrides = {k: dict(v) for k, v in self.overrides.items()}

        def job(w):
            ctx = self.ctx(w)
            try:
                return pipeline.evaluate_all(ctx, preps, cps, overrides, on_done=lambda ev: w.item.emit(ev))
            finally:
                ctx.close()

        def item(ev):
            self.model.update_evaluation(ev)
            r = self.current_row()
            if r and r.cp.partner == ev.partner:
                self.show_details()

        def done(results):
            for ev in results:
                o = self.overrides.get(ev.partner)
                if o:
                    o.pop('force_refresh', None)
                    o.pop('replace_scorecard', None)
                    o.pop('skip_scorecard', None)       # valabil doar pentru revizuirea curenta
            if after:
                after(results)
                return
            ok = sum(1 for e in results if e.state == 'evaluated' and not e.warnings)
            warn = sum(1 for e in results if e.state in ('evaluated', 'evaluated_manual') and (e.warnings or e.state == 'evaluated_manual'))
            err = sum(1 for e in results if e.state == 'error')
            try:
                self.credits = self.cs.credits(self.cfg.get('portfolio', 'country'))
            except Exception:
                pass
            self._update_labels()
            self._filter()
            text = f'Evaluare terminata: {ok} ok, {warn} de verificat, {err} cu eroare. Dublu-click pe un client pentru decizie.'
            self.set_status(text, 'error' if err else ('warn' if warn else 'ok'))
            if err:
                lines = [f'- {e.name}: {e.error["title"]} -> {e.error["action"]}' for e in results if e.state == 'error'][:15]
                QMessageBox.warning(self, 'Evaluare', text + '\n\n' + '\n'.join(lines))

        self.start_job(job, on_done=done, on_item=item, name='evaluate')

    # ================================================================ 2. decizie
    def _decision_dialog(self, r, parent=None):
        from .. import fx
        ev = r.ev
        rate = self.eur_usd if (ev.currency or 'EUR') == 'EUR' else (fx.usd_per_unit(ev.currency) or 0)
        return dialogs.DecisionDialog(parent or self, ev, r.cp, self.cfg, rate, self.nwce, self.nwce.dropdowns if self.nwce else {},
                                      group=r.group_rows)

    def open_decision(self):
        r = self.current_row()
        if not r:
            return
        ev = r.ev
        if not ev or ev.state not in ('evaluated', 'evaluated_manual', 'approved', 'done'):
            QMessageBox.information(self, 'Decizie', 'Clientul trebuie evaluat intai (butonul 1).' if not ev or ev.state != 'error'
                                    else f'Ultima evaluare are eroare:\n{ev.error["title"]}\n\n{ev.error["action"]}')
            return
        if ev.state == 'done' and QMessageBox.question(self, 'Decizie', 'Decizia a fost deja scrisa in NWCE si SAP. Deschizi o decizie noua pentru acest client?') != QMessageBox.Yes:
            return
        if self._writing():
            return
        dlg = self._decision_dialog(r)
        res = dlg.exec_()
        if res == QDialog.Accepted and self._writing():      # o scriere a pornit cat era deschisa fereastra
            return
        self._decision_result(r, dlg, res)

    def _decision_result(self, r, dlg, res):
        ev = r.ev
        if res == dialogs.DecisionDialog.REGENERATE:
            self.overrides.setdefault(ev.partner, {}).update(dlg.overrides)
            self._regenerate(ev, r.cp)
            return
        if res != QDialog.Accepted:
            return
        if dlg.unapproved:
            ev.state = 'evaluated' if ev.scorecard else 'evaluated_manual'
            pipeline.log_event(self._ui_ctx(), ev, 'INFO', 'Decizie', 'Aprobare retrasa')
        else:
            new = dlg.decision()
            old = dict(ev.decision or {})
            changed = {k: v for k, v in new.items() if k != 'approved_at' and old.get(k) != v}
            if old and changed and ((ev.nwce or {}).get('status') == 'ok' or (ev.sap or {}).get('status') == 'ok'):
                QMessageBox.information(self, 'Decizie', 'Decizia s-a schimbat dupa ce a fost scrisa - va trebui scrisa din nou in NWCE / SAP.')
            if changed or not old:
                ev.nwce = None if changed else ev.nwce
                ev.sap = None if changed else ev.sap
            ev.decision = new
            ev.state = 'approved'
            pipeline.log_event(self._ui_ctx(), ev, 'INFO', 'Decizie',
                               f'Aprobat: limita {fmt_money(new["limit_eur"])} EUR ({new["open_kloc"]} K EUR / {new["open_kusd"]} KUSD), valid till {fmt_date(new["valid_till"])}, grading {new["grading"]}')
        self.db.save_evaluation(ev)
        self.model.update_evaluation(ev)
        self.show_details()
        self.set_status(f'{ev.name}: decizie {"retrasa" if dlg.unapproved else "aprobata - NWCE se scrie automat"}.', 'ok')
        self._filter()
        self.refresh_steps()
        if not dlg.unapproved:
            self._auto_write([r])

    # ================================================================ grup
    def open_group(self):
        r = self.current_row()
        if not r:
            QMessageBox.information(self, 'Grup', 'Selecteaza un client din grup.')
            return
        rows = [x for x in r.group_rows if x.nwce is not None] or r.group_rows
        title = r.group_name or r.group_rows[0].cp.name
        from .group_dialog import GroupDialog
        dlg = GroupDialog(self, title, rows, self.cfg)
        dlg.on_review = self._make_review
        if dlg.exec_() == QDialog.Accepted and not self._writing('decizia de grup'):
            self._apply_group_decision(dlg.decision_data())

    def inactivate(self):
        # ca la "Anuleaza": bifele vizibile daca includ randul curent, altfel doar randul curent (click-dreapta)
        sel = [r for r in self.model.checked_rows() if r in self._visible_rows()]
        cur = self.current_row()
        rows = sel if (cur in sel or not cur) else [cur]
        todo = [r for r in rows if r.nwce is not None and not r.cp.inactive]
        skip = [r for r in rows if r not in todo]
        if not todo:
            QMessageBox.information(self, 'Inactivare', 'Bifeaza / selecteaza randuri active din NWCE (cele fara rand NWCE sau deja INACTIVE nu se pot inactiva).')
            return
        lines = []
        for r in todo:
            n = r.nwce
            lines.append([r.cp.name, n.company_code, limits_book.display('payment_term', n.get('payment_term')),
                          limits_book.display('open_kusd', n.get('open_kusd')), limits_book.display('mtm_kusd', n.get('mtm_kusd')),
                          limits_book.display('total_kusd', n.get('total_kusd')), limits_book.display('valid_till', n.get('valid_till'))])
        dlg = dialogs.TableDialog(self, 'Inactivare in NWCE',
                                  f'{len(todo)} randuri vor primi 0 in Payment Term si in toate limitele, iar Approved on / Valid till se golesc '
                                  '-> STATUS devine INACTIVE (managerul le trimite lunar la inactivare). Dupa confirmare se scrie '
                                  'AUTOMAT in NWCE (imediat). SAP nu se modifica.'
                                  + (f'  ({len(skip)} randuri sarite: fara NWCE sau deja inactive)' if skip else ''),
                                  ['Client', 'Companie', 'Payment Term', 'Open KUSD', 'MTM KUSD', 'Total KUSD', 'Valid till'], lines,
                                  ok_text=f'Inactiveaza {len(todo)} randuri', danger=True)
        if dlg.exec_() != QDialog.Accepted or self._writing('inactivarea'):
            return
        self._apply_inactivation([r for r in todo])

    def _apply_inactivation(self, rows, comment=''):
        ctx = self._ui_ctx()
        done = []
        for r in rows:
            ev = r.ev if (r.ev and r.ev.state != 'error') else None
            if ev is None:
                ev = pipeline.new_evaluation(ctx, r.cp)
                ev.state = 'evaluated_manual'
                self.db.save_evaluation(ev)
            ev.decision = pipeline.inactivation_decision(ctx, ev, comment)
            ev.state = 'approved'
            ev.nwce = ev.sap = None
            pipeline.log_event(ctx, ev, 'INFO', 'Inactivare', f'Inactivare aprobata ({r.nwce.company_code if r.nwce else ""})')
            self.db.save_evaluation(ev)
            self.model.update_evaluation(ev)
            done.append(r.cp.partner)
        self.model.set_checked(set(done), True)
        self._update_count()
        self.show_details()
        self.set_status(f'{len(done)} inactivari aprobate - se scriu automat in NWCE.', 'ok')
        self._auto_write([r for r in rows if r.cp.partner in set(done)])
        return done

    def _usd_rate(self, ccy, cache):
        from .. import fx
        ccy = (ccy or 'EUR').upper()
        if ccy not in cache:
            cache[ccy] = self.eur_usd if ccy == 'EUR' else fx.usd_per_unit(ccy)
        return cache[ccy]

    def _apply_group_decision(self, data):
        ctx = self._ui_ctx()
        a = data['authority']
        rates, done, skipped = {}, [], []
        # peste autoritatea analistului: aprobarea a venit pe alt canal -> analistul alege daca se transcrie si in SAP
        external = a.name != self.cfg.get('approval', 'analystRow')
        write_sap = True
        if external:
            default = QMessageBox.Yes if self.cfg.get('sap', 'afterExternalApproval', default=False) else QMessageBox.No
            write_sap = QMessageBox.question(
                self, 'SAP', f'Decizia de grup e aprobata de {a.name} (pe alt canal).\n\nO transcrii si in SAP?\n'
                'Da = NWCE + SAP (in SAP porneste din nou workflow-ul de aprobare).\nNu = doar NWCE.',
                QMessageBox.Yes | QMessageBox.No, default) == QMessageBox.Yes
        zero = [m for m in data['lines'] if m.row.nwce is not None and m.new_open_usd == 0 and m.new_mtm_usd == 0 and m.other_usd == 0]
        if zero:
            done += self._apply_inactivation([m.row for m in zero if not m.row.cp.inactive], data['comments'] if data['write_comments'] else '')
        for m in data['lines']:
            r = m.row
            if m in zero:
                continue
            if r.nwce is None:
                skipped.append(f'{m.name}: nu are rand in NWCE')
                continue
            ev = r.ev if (r.ev and r.ev.state not in ('error',)) else None
            if ev is None:
                ev = pipeline.new_evaluation(ctx, r.cp)
                ev.state = 'evaluated_manual'
                self.db.save_evaluation(ev)
            rate = self._usd_rate(ev.currency, rates)
            if not rate:
                skipped.append(f'{m.name}: lipseste cursul BCE pentru {ev.currency}')
                continue
            kloc = int(round(m.new_open_usd / rate / 1000.0))
            fields = ['open_kloc', 'open_kusd', 'mtm_kusd', 'grading', 'approval_level', 'approved_on', 'valid_till', 'analyst']
            if data['write_comments'] and data['comments']:
                fields.append('comments')
            vals = (ev.nwce_row or {}).get('values') or {}
            ev.decision = {
                'limit_eur': kloc * 1000, 'currency': ev.currency, 'eur_usd': rate, 'open_kloc': kloc,
                'open_kusd': int(round(m.new_open_usd / 1000.0)), 'mtm_kusd': int(round(m.new_mtm_usd / 1000.0)),
                'payment_term': vals.get('payment_term') or '', 'approval_level': a.nwce_level, 'grading': data['grade'],
                'approved_on': data['approved_on'].isoformat(), 'valid_till': data['valid_till'].isoformat(),
                'comments': data['comments'], 'fields': fields, 'sheet_row': r.nwce.sheet_row, 'new_row': False,
                'approved_at': dt.datetime.now().isoformat(timespec='seconds'),
                'group': data['title'], 'group_total_usd': sum(x.new_total_usd for x in data['lines']), 'authority': a.name,
                'grade_source': data['grade_source'], 'sap_skip': not write_sap,
                'external_approval': {'by': a.name, 'on': data['approved_on'].isoformat()} if external else None,
            }
            ev.state = 'approved'
            ev.nwce = ev.sap = None
            pipeline.log_event(ctx, ev, 'INFO', 'Decizie grup',
                               f'{data["title"]}: grade {data["grade"]}, open {fmt_money(m.new_open_usd)} USD, MTM {fmt_money(m.new_mtm_usd)} USD, '
                               f'total grup {fmt_money(ev.decision["group_total_usd"])} USD, aproba {a.name}')
            self.db.save_evaluation(ev)
            self.model.update_evaluation(ev)
            done.append(r.cp.partner)
        self.model.set_checked(set(done), True)
        self._update_count()
        self.show_details()
        text = f'Decizie de grup {data["title"]}: {len(done)} randuri aprobate ({a.text()}) - NWCE se scrie automat.'
        self.set_status(text, 'warn' if skipped else 'ok')
        self._filter()
        self.refresh_steps()
        self._auto_write([self.model.by_partner[p] for p in done if p in self.model.by_partner])
        if skipped:
            QMessageBox.warning(self, 'Grup', text + '\n\nNeaplicate:\n' + '\n'.join(skipped))

    @staticmethod
    def _scorecard_file(ev):
        """Scorecardul evaluarii (sau cel mai nou Scorecard*.xlsx din folderul clientului) - vezi annual_review.scorecard_file."""
        from .. import annual_review
        return annual_review.scorecard_file(ev)

    def _make_review(self, data, open_doc=True):
        """Annual Review (Word) in folderul clientului / grupului - acelasi document ca in "Documente client"."""
        from .. import annual_review
        try:
            if getattr(self, 'invoices', None) is None:
                self.invoices = annual_review.load_invoices(self.cfg)
            out = annual_review.create(self.cfg, data, self.invoices)
            if not open_doc:
                return out
            os.startfile(str(out))
            self.set_status(f'Annual Review generat: {out}', 'ok')
            return out
        except Exception as e:
            _log.exception('Annual review failed')
            if not open_doc:
                raise
            self.show_error(e)

    def _ui_ctx(self):
        return pipeline.Context(self.cfg, self.db, self.cs, self.nwce, self.portfolio)

    def _regenerate(self, ev, cp):
        if self.busy():
            return
        o = dict(self.overrides.get(ev.partner, {}))
        o['connect_id'] = ev.connect_id
        o['candidates'] = ev.cs_candidates

        def job(w):
            ctx = self.ctx(w)
            try:
                prep = pipeline.new_evaluation(ctx, cp, o)
                prep.connect_id, prep.cs_candidates, prep.state = ev.connect_id, ev.cs_candidates, 'prepared'
                prep.warnings = [x for x in ev.warnings if x.startswith('Creditsafe a gasit')]
                return pipeline.evaluate_all(ctx, [prep], {cp.partner: cp}, {cp.partner: o})
            finally:
                ctx.close()

        def done(res):
            nev = res[0]
            self.model.update_evaluation(nev)
            self.show_details()
            if nev.state == 'error':
                self.set_status(f'Regenerare esuata: {nev.error["title"]}', 'error')
                return
            self.set_status(f'Scorecard regenerat: grad {nev.grade}.', 'ok')
            self.open_decision()

        self.start_job(job, on_done=done, name='regenerate')

    # ================================================================ 3. NWCE
    def _approved(self, need, rows=None):
        rows = rows or self.model.checked_rows() or self.model.rows
        out = []
        for r in rows:
            ev = r.ev
            if ev and ev.state in ('approved', 'done') and ev.decision and need(ev):
                out.append((r, ev))
        return out

    def write_nwce(self, rows=None, auto=False):
        if auto and getattr(self, '_job_active', False):
            self._pending_write = list(getattr(self, '_pending_write', [])) + list(rows or [])   # dupa jobul curent
            return
        if not auto and self.busy():
            return
        items = self._approved(lambda ev: (ev.nwce or {}).get('status') != 'ok', rows)
        items = [(r, ev) for r, ev in items if ev.decision.get('sheet_row') or ev.decision.get('new_row')]
        if not items:
            if not auto:
                QMessageBox.information(self, 'NWCE', 'Nu exista decizii aprobate de scris in NWCE (sau lipseste randul NWCE in decizie).')
            return
        if auto:
            self._write_nwce_job(items, auto=True)
            return
        rows = []
        ctx = self._ui_ctx()
        for r, ev in items:
            changes = pipeline.decision_changes(ctx, ev)
            vals = (ev.nwce_row or {}).get('values') or {}
            target = 'RAND NOU' if ev.decision.get('new_row') else f'rand {ev.decision.get("sheet_row")}'
            for k, v in changes.items():
                new = limits_book.display(k, limits_book._excel_value(k, v))
                old = limits_book.display(k, vals.get(k))
                rows.append([ev.customer_name or ev.name, f'{ev.customer_code or "-"} | {ev.company_code}', target, limits_book.LABELS.get(k, k), old, new, '' if old == new else '◄ schimbat'])
        dlg = dialogs.TableDialog(self, 'Confirma scrierea in NWCE',
                                  f'Se vor scrie {len(items)} clienti in excelul NWCE de pe SharePoint (un singur salvat, apoi verificare). '
                                  'Daca altcineva a modificat intre timp un rand, acel client nu se scrie.',
                                  ['Client', 'Customer | companie', 'Rand', 'Camp', 'Acum', 'Nou', ''], rows, ok_text=f'Scrie {len(items)} randuri in NWCE')
        if dlg.exec_() != QDialog.Accepted:
            return
        self._write_nwce_job(items)

    def _write_nwce_job(self, items, auto=False):
        def job(w):
            c = self.ctx(w)
            evs = [ev for _r, ev in items]
            pipeline.apply_nwce(c, evs)
            try:
                snap = limits_book.Snapshot.load_cache(self.cfg.get('portfolio', 'country'))
            except Exception:
                snap = None
            return evs, snap

        def done(res):
            evs, snap = res
            if snap:
                self.nwce = snap
                self.model.set_nwce(snap, self.cfg.get('limitsBook', 'companyCode'), self.cfg.get('portfolio', 'country'))
                self._update_labels()
            for ev in evs:
                self.model.update_evaluation(ev)
            ok = [ev for ev in evs if (ev.nwce or {}).get('status') == 'ok']
            bad = [ev for ev in evs if (ev.nwce or {}).get('status') != 'ok']
            self.show_details()
            text = f'NWCE{" (automat)" if auto else ""}: {len(ok)} scrisi si verificati, {len(bad)} cu eroare.'
            self.set_status(text, 'error' if bad else 'ok')
            self._filter()
            self.refresh_steps()
            if bad:
                QMessageBox.warning(self, 'NWCE', text + '\n\n' + '\n'.join(f'- {ev.name}: {(ev.nwce or {}).get("message")}' for ev in bad))
            # SAP in fundal, doar pentru limite (nu inactivari) si doar dupa prima trimitere reala reusita
            sap_rows = [self.model.by_partner[ev.partner] for ev in ok
                        if ev.partner in self.model.by_partner and not (ev.decision or {}).get('inactivate') and not pipeline.sap_skipped(ev)]
            if auto and sap_rows and self._sap_auto():
                self.run_sap(dry_run=False, rows=sap_rows, auto=True)
            pend = getattr(self, '_pending_write', [])
            if pend:
                self._pending_write = []
                self._auto_write(pend)

        self.start_job(job, on_done=done, name='nwce')

    # ================================================================ 4. SAP
    def run_sap(self, dry_run, rows=None, auto=False):
        if auto and getattr(self, '_job_active', False):
            return
        if not auto and self.busy():
            return
        from .. import sap_gui
        try:
            tpl = sap_gui.load_template(self.cfg)
        except AppError as e:
            if auto:
                self.set_status(f'SAP automat oprit: {e.message}', 'error')
                return
            self.show_error(e)
            return
        # fara inactivari si fara deciziile aprobate pe alt canal marcate "nu se transcrie in SAP"
        items = self._approved(lambda ev: (ev.sap or {}).get('status') != 'ok' and not (ev.decision or {}).get('inactivate')
                               and not pipeline.sap_skipped(ev), rows)
        # trimise deja (eroare DUPA rotita): cazul poate exista in SAP -> nu se retrimit fara confirmarea analistului
        sent = [ev for _r, ev in items if pipeline.sap_sent(ev)]
        items = [(r, ev) for r, ev in items if not pipeline.sap_sent(ev)]
        if sent and not auto and not dry_run:
            QMessageBox.information(self, 'SAP', f'{len(sent)} client(i) au fost deja trimisi in SAP (eroarea a aparut DUPA rotita) '
                                    'si NU se retrimit, ca sa nu se creeze un caz dublu. Verifica in SAP, apoi click-dreapta pe client: '
                                    '"SAP: confirma trimiterea" sau "SAP: permite retrimiterea".\n\n'
                                    + '\n'.join(f'- {ev.name}' for ev in sent[:15]))
        sap_company = self.cfg.get('limitsBook', 'companyCode')
        other = [ev for _r, ev in items if (ev.company_code or sap_company) != sap_company]
        items = [(r, ev) for r, ev in items if (ev.company_code or sap_company) == sap_company]
        if other and not auto:
            QMessageBox.information(self, 'SAP', f'{len(other)} decizii sunt pe alte companii decat {sap_company} '
                                    '(inregistrarea SAP e pentru aceasta companie) - actualizeaza-le manual in SAP:\n'
                                    + '\n'.join(f'- {ev.name}: {ev.company_code}' for ev in other[:15]))
        if not items:
            if not auto:
                QMessageBox.information(self, 'SAP', 'Nu exista decizii aprobate de actualizat in SAP.')
            return
        if dry_run and len(items) > 1:
            cur = self.current_row()
            pick = [(r, ev) for r, ev in items if cur and r is cur]
            items = pick or items[:1]
        ctx = self._ui_ctx()
        rows = []
        for r, ev in items:
            v = pipeline.sap_values(ctx, ev)
            rows.append([ev.customer_name or ev.name, ev.customer_code or '-', v.get('bp') or '(lipsa BP in NWCE)', fmt_money(r.cp.limit), fmt_money(v['limit']), fmt_date(v['valid_to'])])
        if dry_run:
            intro = ('PROBA: se executa pasii inregistrati pana la Save, se citesc campurile si se iese cu /n FARA salvare. '
                     'SAP trebuie sa fie deschis si logat. Nu atinge SAP in timpul rularii.')
        else:
            intro = (f'Se vor SALVA limitele in SAP pentru {len(items)} clienti. Rularea se opreste la orice ecran / mesaj neasteptat, '
                     'inainte de Save. Se fac capturi de ecran in data\\sap_captures. Nu atinge SAP in timpul rularii.')
        if not auto:
            dlg = dialogs.TableDialog(self, 'SAP - ' + ('proba' if dry_run else 'confirma trimiterea'), intro,
                                      ['Client', 'Customer', 'BP', 'Limita curenta', 'Limita noua', 'Valid to'], rows,
                                      ok_text='Ruleaza proba' if dry_run else f'Trimite in SAP ({len(items)})', danger=not dry_run)
            if dlg.exec_() != QDialog.Accepted:
                return

        def job(w):
            c = self.ctx(w)
            out = []
            for n, (_r, ev) in enumerate(items, 1):
                c.check_cancel()
                w.report(f'SAP {"proba" if dry_run else "salvare"} {n}/{len(items)}: {ev.name}...', n - 1, len(items))
                pipeline.run_sap(c, ev, tpl, dry_run)
                out.append(ev)
                w.item.emit(ev)
                msg = (ev.sap or {}).get('message', '')
                if (ev.sap or {}).get('status') in ('error', 'dry_error') and any(t in msg for t in ('SAP nu este deschis', 'Scripting', 'Lipseste inregistrarea')):
                    break    # problema generala - nu are rost sa continuam
            return out

        def done(evs):
            ok = [ev for ev in evs if (ev.sap or {}).get('status') in ('ok', 'dry_ok')]
            bad = [ev for ev in evs if ev not in ok]
            self.show_details()
            text = f'SAP {"proba" if dry_run else "trimitere"}{" (automat)" if auto else ""}: {len(ok)} ok, {len(bad)} cu eroare.'
            self.set_status(text, 'error' if bad else 'ok')
            self._filter()
            self.refresh_steps()
            if not dry_run and ok and not self.cfg.get('sap', 'verified', default=False):
                # prima trimitere reala reusita: de acum SAP merge automat dupa NWCE
                self.cfg.set(True, 'sap', 'verified')
                try:
                    self.cfg.save()
                except Exception as e:
                    _log.warning('Config not saved: %s', e)
            if auto and not bad:
                return
            lines = []
            for ev in evs:
                s = ev.sap or {}
                before = ', '.join(f'{k}: {v}' for k, v in (s.get('before') or {}).items())
                after = ', '.join(f'{k}: {v}' for k, v in (s.get('after') or {}).items())
                lines.append(f'- {ev.name}: {s.get("message")}\n    inainte: {before or "-"}\n    pe ecran: {after or "-"}')
            QMessageBox.information(self, 'SAP', text + '\n\n' + '\n'.join(lines))

        self.start_job(job, on_done=done, on_item=lambda ev: self.model.update_evaluation(ev), name='sap')

    # ================================================================ altele
    def open_settings(self):
        dlg = dialogs.SettingsDialog(self, self.cfg)
        if dlg.exec_() == QDialog.Accepted:
            self._replace_cs()
            self.set_status('Setari salvate. Reincarc datele...', 'ok')
            self.load_data(refresh_nwce=False)

    def change_password(self):
        if self.busy():
            return
        dlg = dialogs.PasswordDialog(self, self.cfg)
        if dlg.exec_() != QDialog.Accepted or not dlg.pwd.text():
            return
        if getattr(self.cs, 'mode', 'api') == 'web':
            from .. import creditsafe_web
            creditsafe_web.save_credentials(self.cfg, dlg.user.text(), dlg.pwd.text())
        else:
            creditsafe.save_credentials(self.cfg, dlg.user.text(), dlg.pwd.text())
        self.cfg.save()
        self._replace_cs()

        def job(w):
            w.report('Verific login-ul Creditsafe...')
            self.cs.test_login()
            return self.cs.credits(self.cfg.get('portfolio', 'country'))

        def done(credits):
            self.credits = credits
            self._update_labels()
            self.set_status('Parola Creditsafe salvata si verificata (login reusit).', 'ok')

        self.start_job(job, on_done=done, name='login')

    def _replace_cs(self):
        old = self.cs
        self.cs = make_client(self.cfg)
        if hasattr(old, 'close'):
            old.close()

    def import_sap(self):
        dlg = dialogs.SapImportDialog(self, self.cfg, self.nwce)
        dlg.exec_()

    def show_changes(self):
        since = (dt.date.today() - dt.timedelta(days=90)).isoformat()
        ch = self.db.changes(since=since)
        rows = [[c['ts'][:16].replace('T', ' '), c['partner'], c['target'], c['field'], c['old_value'], c['new_value'], c['status'], c['message']] for c in reversed(ch)]
        dlg = dialogs.TableDialog(self, 'Istoric modificari (90 zile)', f'{len(rows)} modificari NWCE / SAP inregistrate local.',
                                  ['Data', 'Partner', 'Tinta', 'Camp', 'Vechi', 'Nou', 'Status', 'Mesaj'], rows, ok_text='Inchide')
        dlg.exec_()

    def export_summary(self):
        import openpyxl
        from openpyxl.styles import Font, PatternFill
        rows = [r for r in (self.model.checked_rows() or self.model.rows) if r.ev]
        if not rows:
            QMessageBox.information(self, 'Export', 'Nu exista clienti evaluati.')
            return
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = 'Rezumat'
        hdr = ['Customer Code', 'Companie', 'TBD', 'Total client KUSD (toate tarile)', 'Client', 'BU', 'Stare', 'Data evaluare', 'Limita curenta EUR', 'Varf expunere', 'Saptamana varf',
               'Grad', 'Scale', 'Puncte', 'Rating Creditsafe', 'Limita Creditsafe', 'Equity', 'Propus EUR', 'Aprobat EUR',
               'K EUR', 'KUSD', 'Valid till', 'NWCE', 'SAP', 'Avertismente', 'Eroare', 'Scorecard', 'PDF']
        ws.append(hdr)
        for c in ws[1]:
            c.font = Font(bold=True, color='FFFFFF')
            c.fill = PatternFill('solid', fgColor='005EB8')
        for r in rows:
            ev, cp = r.ev, r.cp
            sc, d, cs = ev.scorecard or {}, ev.decision or {}, ev.cs or {}
            ws.append([cp.customer_code, ev.company_code, cp.tbd, r.group_kusd, ev.customer_name or cp.name, cp.business_unit, ev.display_state, ev.created[:16].replace('T', ' '),
                       cp.limit, cp.peak_exposure, cp.peak_week, ev.grade, sc.get('scale'), sc.get('points'),
                       f'{cs.get("rating_common", "")} {cs.get("rating_score", "")}', cs.get('cs_limit'), cs.get('equity'),
                       (ev.proposal or {}).get('proposed'), d.get('limit_eur'), d.get('open_kloc'), d.get('open_kusd'), d.get('valid_till'),
                       (ev.nwce or {}).get('message'), (ev.sap or {}).get('message'), ' | '.join(ev.warnings),
                       (ev.error or {}).get('title'), (ev.files or {}).get('scorecard'), (ev.files or {}).get('pdf')])
        from openpyxl.utils import get_column_letter
        for col, w in zip((get_column_letter(i) for i in range(1, 40)), [12, 16, 6, 14, 38, 10, 22, 16, 14, 14, 12, 6, 14, 8, 16, 14, 14, 12, 12, 8, 8, 11, 30, 30, 50, 30, 40, 40]):
            ws.column_dimensions[col].width = w
        ws.freeze_panes = 'F2'
        ws.auto_filter.ref = ws.dimensions
        paths.OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        out = paths.OUTPUT_DIR / f'Rezumat_evaluari_{dt.datetime.now():%Y-%m-%d_%H%M}.xlsx'
        wb.save(out)
        os.startfile(str(out))
        self.set_status(f'Rezumat exportat: {out}', 'ok')

    def closeEvent(self, e):
        running = [w for w in set(getattr(self, '_threads', set())) | {self.worker} if w is not None and w.isRunning()]
        if running:
            if getattr(self, '_job_active', False) and QMessageBox.question(
                    self, 'Inchidere', 'O operatie ruleaza inca. Opresti si inchizi?') != QMessageBox.Yes:
                e.ignore()
                return
            for w in running:
                w.cancel()
            stuck = [w for w in running if not w.wait(30000)]
            if stuck:
                # firul inca scrie (NWCE / SAP / Excel): inchiderea acum ar taia DB-ul si Excelul de sub el
                QMessageBox.warning(self, 'Inchidere', 'Operatia curenta nu s-a oprit inca (un pas Excel / SAP / NWCE in curs). '
                                    'Asteapta sa se termine, apoi inchide din nou.')
                e.ignore()
                return
        if self._save_ui_timer.isActive():        # latimi / zoom schimbate chiar inainte de inchidere
            self._save_ui_timer.stop()
            self._save_ui()
        self._close_shared_excel()
        if hasattr(self.cs, 'close'):
            self.cs.close()
        self.db.close()
        e.accept()
