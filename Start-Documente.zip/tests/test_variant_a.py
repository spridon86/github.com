"""Varianta A a interfetei (aprobata 20.10.2026): eticheta "Pasul urmator", cele 4 file, coloanele, butonul de jos,
cautarea in toti clientii si modificarile din panoul din dreapta. Fereastra se construieste fara retea / Excel / SAP."""
import datetime as dt
import os

import pytest

os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
QtWidgets = pytest.importorskip('PyQt5.QtWidgets')

from creditapp import limits_book as lb, pipeline  # noqa: E402
from creditapp.portfolio import Counterparty  # noqa: E402


@pytest.fixture(scope='module')
def app():
    return QtWidgets.QApplication.instance() or QtWidgets.QApplication([])


def _row(cp, nwce=None, ev=None):
    from creditapp.ui.models import Row
    r = Row(cp)
    r.nwce, r.ev, r.group_rows = nwce, ev, [r]
    return r


def _nwce(code='76000001', valid=None, grading=8.0, kloc=1100.0):
    valid = valid or (dt.date.today() + dt.timedelta(days=10))
    return lb.NwceRow(10, {'status': 'UNDER REVIEW', 'company_code': '6675 - Italy', 'customer_code': float(code), 'name': 'CLIENT A',
                           'vat': 'IT0000000001', 'open_kloc': kloc, 'open_kusd': kloc * 1.17, 'mtm_kusd': 350.0, 'grading': grading,
                           'valid_till': lb.to_serial(valid)})


def _ev(state='evaluated', **review):
    ev = pipeline.Evaluation(partner='76000001', name='CLIENT A')
    ev.state, ev.customer_code, ev.currency = state, '76000001', 'EUR'
    ev.review = dict({'route': 'auto', 'authority': 'Ionut Spridon', 'new_open_local': 1_300_000, 'mtm_kusd': 350.0}, **review)
    return ev


def test_step_chip_texts_and_colors(app):
    from creditapp.ui.models import step_chip
    cp = Counterparty(partner='76000001', name='CLIENT A')
    assert step_chip(_row(cp, _nwce()), '6675 - Italy')[1] == 'warn'                                     # expira luna asta
    assert step_chip(_row(cp, _nwce()), '6675 - Italy')[0].startswith('Expiră')
    assert step_chip(_row(cp, _nwce(), _ev()), '6675 - Italy') == ('Aprobi tu', 'ok')
    assert step_chip(_row(cp, _nwce(), _ev(would_escalate=True, authority='BEMEA - Aylin')), '6675 - Italy') == ('Aprobă BEMEA - Aylin', 'warn')
    assert step_chip(_row(cp, _nwce(), _ev(route='escalate', authority='GLOBAL - Alex')), '6675 - Italy') == ('Aprobă GLOBAL - Alex', 'warn')
    manual = _ev(route='manual')
    manual.inputs = {'payment': {'grade': 'C', 'why': 'Fara istoric in "Payment behaviour report"'}}
    assert step_chip(_row(cp, _nwce(), manual), '6675 - Italy') == ('Alege criteriul Plăți', 'bad')
    w = _ev(state='approved')
    w.decision = {'limit_eur': 1}
    assert step_chip(_row(cp, _nwce(), w), '6675 - Italy') == ('Se scrie în NWCE…', 'info')
    w.nwce, w.sap = {'status': 'ok'}, {'status': 'error', 'submitted': True}
    assert step_chip(_row(cp, _nwce(), w), '6675 - Italy') == ('SAP: verifică', 'warn')
    w.decision['sap_skip'], w.state = True, 'done'
    assert step_chip(_row(cp, _nwce(), w), '6675 - Italy') == ('Gata · doar NWCE', 'ok')


@pytest.fixture
def window(app, monkeypatch, tmp_path, cfg):
    from creditapp.audit import AuditDB
    from creditapp.ui import main_window as mw

    class NoCs:
        mode = 'web'

        def close(self):
            pass
    monkeypatch.setattr(mw, 'AuditDB', lambda: AuditDB(tmp_path / 'db.sqlite'))
    monkeypatch.setattr(mw, 'make_client', lambda c: NoCs())
    monkeypatch.setattr(mw.MainWindow, 'load_data', lambda self, refresh_nwce=False: None)
    cfg.save = lambda *a, **k: None
    win = mw.MainWindow(cfg)

    class Pf:
        notes = []
        counterparties = {'76000001': Counterparty(partner='76000001', name='CLIENT A', vat='IT0000000001'),
                          '76000002': Counterparty(partner='76000002', name='ALTA FIRMA SRL', vat='IT0000000002')}

        def __len__(self):
            return 2
    rows = [_nwce(), lb.NwceRow(11, {'status': 'APPROVED', 'company_code': '6675 - Italy', 'customer_code': 76000002.0,
                                     'name': 'ALTA FIRMA SRL', 'vat': 'IT0000000002', 'open_kloc': 50.0, 'grading': 7.0,
                                     'valid_till': lb.to_serial(dt.date.today() + dt.timedelta(days=300))})]
    win.portfolio = Pf()
    win.nwce = lb.Snapshot(rows, {}, dt.datetime.now(), 'test').index('IT')
    win.model.load(win.portfolio, {}, win.nwce, '6675 - Italy', 'IT', cfg)
    win._fill_tbd()
    win._filter()
    yield win, mw
    win.db.close()


def test_four_tabs_columns_and_one_button(window):
    win, mw = window
    assert [win.tabbar.tabText(i).split('  ')[0] for i in range(win.tabbar.count())] == ['De revizuit', 'În lucru', 'La aprobare', 'Gata']
    visible = [k for i, (k, _l) in enumerate(mw.COLUMNS) if not win.table.isColumnHidden(i)]
    assert visible == ['check', 'a_client', 'a_now', 'a_valid', 'a_grade', 'a_step']
    assert win.proxy.rowCount() == 1                                    # doar clientul care expira
    assert win.act.text() == 'Bifează clienții de revizuit' and not win.act.isEnabled()
    win.model.by_partner['76000001'].checked = True
    win.model._all_changed()
    win.refresh_steps()
    assert win.act.text() == 'Revizuiește bifații (1)' and win.act.isEnabled()
    assert win.lbl_count.text().startswith('1 bifați')
    win.tabbar.setCurrentIndex(1)
    assert [k for i, (k, _l) in enumerate(mw.COLUMNS) if not win.table.isColumnHidden(i)][3] == 'a_prop'


def test_search_covers_all_clients_and_tab_click_clears_it(window):
    win, _mw = window
    win.f_text.setText('alta')
    assert win._mode() == 'search' and win.proxy.rowCount() == 1        # clientul valabil, din afara filei
    assert 'alta' in win.lbl_search.text()
    win.tabbar.setCurrentIndex(3)
    assert win.f_text.text() == '' and win._mode() == 'reviewed'


def test_side_panel_edit_goes_through_the_model(window):
    win, mw = window
    r = win.model.by_partner['76000001']
    ev = _ev()
    ev.id = None
    win.db.save_evaluation(ev)
    win.model.update_evaluation(ev)
    win.tabbar.setCurrentIndex(1)                                       # In lucru
    win.table.setCurrentIndex(win.proxy.index(0, mw.COL['a_client']))
    assert win.side.title.text() == 'CLIENT A' and win.side.edit_box.isVisibleTo(win.side)
    win.side._emit('n_open', 1_450_000.0)                               # ca si cum analistul a scris in "Open nou"
    assert r.ev.review['edit']['open'] == 1_450_000.0
    assert win.model.data(win.model.index(win.model.rows.index(r), mw.COL['a_prop'])) == '1.450.000 €'
