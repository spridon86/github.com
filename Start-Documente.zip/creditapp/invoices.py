"""Facturile din ultimii ani ("All Invoices.XLSX"): un client fara expunere in Open Contracts e totusi activ
daca a avut facturi in ultimele N luni. Fisierul are ~120.000 de randuri - se citeste o data si se pastreaza
un rezumat pe client (cache local, refacut doar cand fisierul se schimba)."""
import datetime as dt
import json
import re
import uuid
from pathlib import Path

from . import log, paths
from .errors import AppError
from .fsutil import copy_file

_log = log.get('invoices')
_CACHE = paths.LOCAL_DIR / 'invoices_summary.json'
CACHE_VERSION = 2       # 2: + cifra de afaceri pe an (USD) - un rezumat mai vechi se reface o data
INVOICE_TYPES = {'RV', 'DR', 'RI', 'DG', 'RL', 'RD'}     # facturi / note de debit (nu plati, nu compensari)


def _norm(h):
    return re.sub(r'\s+', ' ', str(h or '')).strip().lower()


def _vat_key(v):
    s = re.sub(r'[^A-Za-z0-9]', '', str(v or '')).upper()
    return s if re.search(r'\d{5,}', s) else ''


def load(path, progress=None):
    """{'by_account': {cont: [nr, ultima_data_iso, prima_data_iso]}, 'by_vat': {...}, 'source', 'mtime'} pentru toate facturile."""
    path = Path(path)
    if not path.exists():
        raise AppError('PORTFOLIO', f'Invoice file not found: {path}')
    mtime = path.stat().st_mtime
    try:
        c = json.loads(_CACHE.read_text(encoding='utf-8'))
        if c.get('source') == str(path) and abs(c.get('mtime', 0) - mtime) < 1 and c.get('version') == CACHE_VERSION:
            return c
    except (OSError, ValueError):
        pass
    say = progress or (lambda t: None)
    say('Citesc facturile (All Invoices, ~30 s, o singura data)...')
    import openpyxl
    paths.WORK_DIR.mkdir(parents=True, exist_ok=True)
    tmp = paths.WORK_DIR / f'invoices_{uuid.uuid4().hex[:8]}.xlsx'
    copy_file(path, tmp)
    by_acc, by_vat = {}, {}
    turn_acc, turn_vat = {}, {}          # cont / VAT -> {an: USD} (facturi minus note de credit, "Amount in loc.curr.2")
    try:
        wb = openpyxl.load_workbook(tmp, read_only=True, data_only=True)
        ws = wb.worksheets[0]
        rows = ws.iter_rows(values_only=True)
        hdr = {_norm(h): i for i, h in enumerate(next(rows)) if h}
        need = ['account', 'document date', 'document type']
        miss = [n for n in need if n not in hdr]
        if miss:
            raise AppError('PORTFOLIO', f'All Invoices: columns not found: {", ".join(miss)}')
        ia, idt, ity = hdr['account'], hdr['document date'], hdr['document type']
        iv = hdr.get('vat registration no.')
        iam = hdr.get('amount in local currency')
        iusd, icur2 = hdr.get('amount in loc.curr.2'), hdr.get('local currency 2')
        for r in rows:
            if ity >= len(r) or str(r[ity] or '').strip().upper() not in INVOICE_TYPES:
                continue
            d = r[idt]
            if isinstance(d, dt.datetime):
                d = d.date()
            if not isinstance(d, dt.date):
                continue
            acc = r[ia]
            if isinstance(acc, float) and acc.is_integer():
                acc = int(acc)          # 76021671.0 -> "76021671" (ca Customer Code din NWCE)
            keys = ((str(acc or '').strip(), by_acc, turn_acc), (_vat_key(r[iv]) if iv is not None else '', by_vat, turn_vat))
            usd = r[iusd] if iusd is not None and iusd < len(r) else None
            if isinstance(usd, (int, float)) and (icur2 is None or str(r[icur2] or '').strip().upper() == 'USD'):
                for key, _s, turn in keys:
                    if key:
                        y = turn.setdefault(key, {})
                        y[str(d.year)] = y.get(str(d.year), 0.0) + float(usd)
            if iam is not None and isinstance(r[iam], (int, float)) and r[iam] <= 0:
                continue      # note de credit (scad din cifra de afaceri, dar nu sunt "activitate")
            ds = d.isoformat()
            for key, store, _t in keys:
                if not key:
                    continue
                e = store.get(key)
                if e is None:
                    store[key] = [1, ds, ds]
                else:
                    e[0] += 1
                    if ds > e[1]:
                        e[1] = ds
                    if ds < e[2]:
                        e[2] = ds
        wb.close()
    finally:
        try:
            tmp.unlink()
        except OSError:
            pass
    if not by_acc:
        # coloana de data citita ca text / alt format: fara facturi, toti clientii fara expunere ar parea inactivi
        raise AppError('PORTFOLIO', 'All Invoices: no invoice rows could be read (check the "Document date" / "Document type" columns).')
    data = {'source': str(path), 'mtime': mtime, 'loaded_at': dt.datetime.now().isoformat(timespec='seconds'),
            'version': CACHE_VERSION, 'by_account': by_acc, 'by_vat': by_vat, 'latest': latest_invoice({'by_account': by_acc}),
            'turnover_account': turn_acc, 'turnover_vat': turn_vat}
    try:
        _CACHE.write_text(json.dumps(data), encoding='utf-8')
    except OSError:
        pass
    _log.info('Invoices summarised: %d accounts', len(by_acc))
    return data


STALE_DAYS = 90      # fisier de facturi fara nicio factura mai noua -> neactualizat, nu se decide inactivarea pe el


def turnover_usd(data, customer_code, vat, year):
    """Cifra de afaceri cu Bunge intr-un an (USD, facturi minus note de credit): dupa cont, altfel dupa VAT; None = fara date."""
    if not data:
        return None
    t = (data.get('turnover_account') or {}).get(str(customer_code or ''))
    if t is None:
        k = _vat_key(vat)
        for cand in ((k, k[2:] if re.match(r'^[A-Z]{2}', k) else 'IT' + k) if k else ()):
            t = (data.get('turnover_vat') or {}).get(cand)
            if t is not None:
                break
    return None if t is None else t.get(str(year))


def latest_invoice(data):
    """Data celei mai noi facturi din fisier (ISO) sau ''."""
    if data.get('latest'):
        return data['latest']
    return max((e[1] for e in (data.get('by_account') or {}).values()), default='')


def recent_activity(data, customer_code, vat, months=24, today=None):
    """(are_facturi, text) - facturi in ultimele `months` luni, dupa cont sau VAT.
    None = nu se poate decide (fisier lipsa / gol / neactualizat) -> clientul NU se inactiveaza automat."""
    if not data or not data.get('by_account'):
        return None, 'fisierul de facturi nu e incarcat'
    today = today or dt.date.today()
    latest = latest_invoice(data)
    if not latest or latest < (today - dt.timedelta(days=STALE_DAYS)).isoformat():
        return None, f'fisierul de facturi pare neactualizat (ultima factura {latest or "-"})'
    since = (today - dt.timedelta(days=int(months * 30.44))).isoformat()
    hits = []
    if customer_code and str(customer_code) in data['by_account']:
        hits.append(data['by_account'][str(customer_code)])
    k = _vat_key(vat)
    if k:
        for cand in (k, k[2:] if re.match(r'^[A-Z]{2}', k) else 'IT' + k):
            if cand in data['by_vat']:
                hits.append(data['by_vat'][cand])
    if not hits:
        return False, 'nicio factura gasita'
    last = max(h[1] for h in hits)
    n = sum(h[0] for h in hits)
    d = dt.date.fromisoformat(last)
    if last >= since:
        return True, f'facturi in ultimii {months // 12} ani (ultima {d:%d.%m.%Y})'
    return False, f'ultima factura {d:%d.%m.%Y} - mai veche de {months // 12} ani ({n} facturi in total)'
