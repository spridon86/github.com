"""Modelul tabelului de clienti: portofoliu + ultima evaluare + randul NWCE."""
import copy
import datetime as dt

from PyQt5.QtCore import QAbstractTableModel, QDate, QModelIndex, QSortFilterProxyModel, Qt, pyqtSignal
from PyQt5.QtGui import QBrush, QColor, QFont

from collections import Counter, defaultdict

from .. import groups as groups_mod, limits_book, portfolio as portfolio_mod, review as review_mod, rules as rules_mod
from ..pipeline import Evaluation, sap_sent

SORT_ROLE = Qt.UserRole + 1
PARTNER_ROLE = Qt.UserRole + 2

GREEN = QColor(198, 239, 206)
YELLOW = QColor(255, 235, 156)
RED = QColor(255, 199, 206)
BLUE = QColor(221, 235, 247)
GREY = QColor(235, 235, 235)
_MISSING = object()


def fmt_money(v):
    if v is None or v == '':
        return ''
    try:
        return f'{float(v):,.0f}'.replace(',', '.')
    except (TypeError, ValueError):
        return str(v)


def fmt_date(d):
    if not d:
        return ''
    if isinstance(d, str):
        try:
            d = dt.date.fromisoformat(d[:10])
        except ValueError:
            return d
    return d.strftime('%d.%m.%Y')


class Row:
    def __init__(self, cp):
        self.cp = cp
        self.ev = None              # Evaluation (ultima)
        self.ev_created = ''
        self.nwce = None            # NwceRow
        self.checked = False
        self.client = ''            # aceeasi firma pe toate companiile / tarile (VAT, altfel Customer Code)
        self.group = ''             # grupul de firme (NWCE "Group of companies") sau, fara grup, firma
        self.group_name = ''        # numele afisat al grupului de firme
        self.group_rows = []        # toate randurile grupului (inclusiv acesta) - limitele se aduna
        self.lead = True            # primul rand al grupului (Italia / Open Contracts daca exista)

    @property
    def kusd(self):
        """Total limit KUSD al randului NWCE (limitele se aduna pe toate companiile)."""
        v = self.nwce.get('total_kusd') if self.nwce else None
        return float(v) if isinstance(v, (int, float)) else 0.0

    @property
    def group_kusd(self):
        return sum(r.kusd for r in self.group_rows) if self.group_rows else self.kusd

    @property
    def group_companies(self):
        return sorted({(r.nwce.company_code if r.nwce else (r.cp.company_code or '')) for r in self.group_rows if r.nwce or r.cp.company_code})


def group_key(vat, customer_code, name, country='IT'):
    k = limits_book.vat_key(vat, country)
    if k:
        return 'VAT:' + k
    if customer_code:
        return 'CODE:' + str(customer_code)
    from ..client_folders import name_key
    return 'NAME:' + name_key(name)


def _skip_sibling(nr):
    """Randurile CBT / NO TRADE nu sunt limite - nu se adauga ca rand separat (decat daca au TBD)."""
    import re
    return bool(re.search(r'CBT|NO TRADE', nr.company_code or '', re.I))


COLUMNS = [
    ('check', ''),
    # --- excelul NWCE (foaia LIMITS), in aceeasi ordine
    ('status', 'STATUS'), ('company', 'Company code'), ('bp', 'BP code'), ('partner', 'Customer Code'), ('supplier', 'Supplier code'),
    ('name', 'Counterparty name'), ('vat', 'VAT code'), ('grp', 'Group of companies'), ('grading', 'Grading'), ('tbd', 'TBD by'),
    ('analyst', 'Analyst'), ('compliance', 'Last compliance check'), ('payment_term', 'Payment Term'), ('open_kusd', 'Open limit KUSD'),
    ('open_kloc', 'Open limit K loc. curr.'), ('mtm_kusd', 'MTM limit KUSD'), ('tons_oilseeds', 'Limits in tons /oilseeds'),
    ('tons_grains', 'Limits in tons/grains'), ('max_months', 'Max months fwd'), ('storage_tons', 'Storage in tons'),
    ('storage_kusd', 'Storage limit KUSD'), ('bond_tons', 'Transfer bond tons HU'), ('bond_kusd', 'Transfer bond KUSD HU'),
    ('kusd', 'Total limit KUSD'), ('approved', 'Approved on'), ('valid', 'Valid till'), ('insurance', 'Insurance KUSD /KEUR'),
    ('collateral', 'Collateral: PN/BG'), ('level', 'Approval level'), ('trader', 'Trader'), ('comments', 'Comments'),
    # --- tool: rezultatul fiecarui pas al revizuirii
    ('next', 'Ce urmeaza'), ('pay_beh', 'Comportament de plata'),
    # perechi vechi / nou (antet pe doua randuri: "Grup|Sub")
    ('o_open', 'Open limit|Veche'), ('n_open', 'Open limit|Noua'), ('o_mtm', 'MTM limit USD|Veche'), ('n_mtm', 'MTM limit USD|Noua'),
    ('o_grade', 'Grade|Vechi'), ('n_grade', 'Grade|Nou'), ('o_valid', 'Valid till|Veche'), ('n_valid', 'Valid till|Noua'),
    ('eq30', '30% Equity'), ('cs_sc', 'Creditsafe / Scorecard'),
    ('r_exp', 'Varf expunere (sapt. viitoare →)'), ('r_active', 'Activ?'), ('r_cs', 'Creditsafe'),
    ('grade', 'Grade nou'), ('m_fin', 'Subiective|9. Fin. reporting'), ('m_exp', 'Subiective|10. Experience'),
    ('m_pay', 'Subiective|11. Payments'),
    ('r_open', 'Open limit nou'), ('r_total', 'Total nou USD'), ('r_auth', 'Aproba'), ('r_eq', 'Equity scenario'),
    ('r_ar', 'Annual Review'),
    ('state', 'Evaluare'), ('group_kusd', 'Total grup KUSD'), ('countries', 'Tari'),
    ('proposed', 'Propus'), ('ratio', 'Varf/Limita ITA'), ('peak', 'Varf expunere ITA'), ('limit', 'Limita (loc.)'), ('months', 'Luni peste'),
    ('weeks', 'Sapt. peste'), ('breach', 'Prima depasire'), ('pay', 'Risc plata'), ('bu', 'BU'), ('ps', 'P/S'), ('nwce', 'NWCE scris'),
    ('sap', 'SAP'), ('block', 'Blocaj'),
    # --- varianta A: tabelul simplu (6 coloane pe fila)
    ('a_client', 'Client'), ('a_now', 'Limită acum'), ('a_prop', 'Propus'), ('a_valid', 'Valabil până'), ('a_grade', 'Grade'),
    ('a_step', 'Pasul următor'),
]
CHIP_ROLE = Qt.UserRole + 3            # nivelul etichetei din "Pasul urmator": ok / warn / bad / info / grey
# coloanele variantei A care se editeaza ca perechile vechi / noi ("Propus" = Open nou, "Grade" = grade nou)
ALIASES = {'a_prop': 'n_open', 'a_grade': 'n_grade'}
CURRENCY_SIGN = {'EUR': '€', 'USD': '$'}
# campurile NWCE afisate direct din randul excelului
NWCE_FIELDS = {'status': 'status', 'bp': 'bp_code', 'supplier': 'supplier_code', 'vat': 'vat', 'grading': 'grading',
               'analyst': 'analyst', 'compliance': 'compliance', 'payment_term': 'payment_term', 'open_kusd': 'open_kusd',
               'open_kloc': 'open_kloc', 'mtm_kusd': 'mtm_kusd', 'tons_oilseeds': 'tons_oilseeds', 'tons_grains': 'tons_grains',
               'max_months': 'max_months', 'storage_tons': 'storage_tons', 'storage_kusd': 'storage_kusd', 'bond_tons': 'bond_tons',
               'bond_kusd': 'bond_kusd', 'approved': 'approved_on', 'insurance': 'insurance', 'collateral': 'collateral',
               'level': 'approval_level', 'trader': 'trader', 'comments': 'comments'}
NUMERIC = {'open_kusd', 'open_kloc', 'mtm_kusd', 'tons_oilseeds', 'tons_grains', 'max_months', 'storage_tons', 'storage_kusd',
           'bond_tons', 'bond_kusd', 'kusd', 'insurance', 'group_kusd', 'countries', 'grade', 'proposed', 'ratio', 'peak', 'limit',
           'months', 'weeks', 'pay', 'r_exp', 'r_open', 'r_total'}
MANUAL_COLS = {'m_fin': 'financial_reporting', 'm_exp': 'experience', 'm_pay': 'payment'}   # 14. Country Rating: neatins de tool
EDIT_NEW = ('n_open', 'n_mtm', 'n_valid', 'n_grade')     # valorile noi editabile direct in tabel ("Proces initiat")
PAIR_KEYS = ('o_open', 'n_open', 'o_mtm', 'n_mtm', 'o_grade', 'n_grade', 'o_valid', 'n_valid', 'eq30', 'cs_sc')
NEW_GREEN = QColor('#E2F0D9')

# coloanele fiecarei file (restul se ascund; "Arata toate coloanele" din Filtre le arata pe toate)
NWCE_VIEW = ('check', 'status', 'company', 'bp', 'partner', 'name', 'vat', 'grading', 'tbd', 'analyst', 'payment_term',
             'open_kloc', 'open_kusd', 'mtm_kusd', 'kusd', 'approved', 'valid', 'level', 'trader', 'pay_beh', 'next')
TAB_COLUMNS = {
    'all': NWCE_VIEW,
    'month': NWCE_VIEW,
    'process': ('check', 'name', 'company', 'next', 'r_exp', 'r_active', 'cs_sc', 'o_open', 'n_open', 'o_mtm', 'n_mtm',
                'o_grade', 'n_grade', 'm_fin', 'm_exp', 'm_pay', 'o_valid', 'n_valid', 'r_total', 'eq30', 'r_auth',
                'r_eq', 'pay_beh'),
    'approval': ('check', 'name', 'company', 'cs_sc', 'o_open', 'n_open', 'o_mtm', 'n_mtm', 'o_grade', 'n_grade',
                 'r_total', 'eq30', 'r_auth', 'r_ar'),
    'reviewed': ('check', 'name', 'company', 'o_open', 'n_open', 'o_mtm', 'n_mtm', 'o_grade', 'n_grade', 'o_valid', 'n_valid',
                 'r_total', 'next'),
}
# varianta A: aceleasi 6 coloane pe fiecare fila (antet pe un rand); "Filtre → Arata toate coloanele" le arata pe toate
TAB_COLUMNS.update({
    'month': ('check', 'a_client', 'a_now', 'a_valid', 'a_grade', 'a_step'),
    'process': ('check', 'a_client', 'a_now', 'a_prop', 'a_grade', 'a_step'),
    'approval': ('check', 'a_client', 'a_now', 'a_prop', 'a_grade', 'a_step'),
    'reviewed': ('check', 'a_client', 'a_now', 'a_valid', 'a_grade', 'a_step'),
    'search': ('check', 'a_client', 'a_now', 'a_valid', 'a_grade', 'a_step'),
})
COL = {k: i for i, (k, _) in enumerate(COLUMNS)}


def money_ccy(v, ccy):
    """1.100.000 € / 1.250.000 HUF - suma cu moneda, ca in macheta."""
    if v is None or v == '':
        return ''
    return f'{fmt_money(v)} {CURRENCY_SIGN.get(ccy or "EUR", ccy or "")}'.strip()
SIMPLE_COLUMNS = ('check', 'status', 'company', 'partner', 'name', 'grading', 'open_kusd', 'mtm_kusd', 'kusd', 'valid', 'next', 'pay_beh', 'r_exp', 'r_active', 'r_cs', 'grade', 'm_fin', 'm_exp', 'm_pay', 'r_open', 'r_total', 'r_auth', 'r_eq', 'r_ar', 'nwce', 'sap')

# etapa fiecarui rand in flux -> textul din coloana "Pas urmator"
NEXT_TEXT = {
    'new': '② Evalueaza', 'error': '⚠ Eroare - vezi detalii', 'decide': '→ Verifica si Next (dublu-click)', 'write': '⏳ NWCE - se scrie automat',
    'sap': '⏳ SAP (automat / click-dreapta → Trimite)', 'done': '✔ Revizuit', 'done_manual_sap': '✔ NWCE scris (SAP manual - alta companie)',
    'inactive': 'Inactiv - nimic de facut', 'valid': '✔ Valabil', 'na': 'CBT / No trade', 'manual': '✎ Verifica subiectivele si Next (dublu-click)',
    'escalate': '⇧ Necesita aprobare', 'inactive_todo': '⊘ Fara activitate - inactivare in NWCE',
    'done_no_sap': '✔ NWCE scris (aprobat pe alt canal - netranscris in SAP)',
}
RENEW_DAYS = [30]          # din config (limitsBook.renewWithinDays), setat la incarcare
# filele: "Proces initiat" = tot ce e in lucru dupa pornirea revizuirii; "Revizuiti" = terminati (NWCE + SAP)
PROCESS_STAGES = ('manual', 'decide', 'write', 'sap', 'inactive_todo')
REVIEWED_STAGES = ('done', 'done_manual_sap', 'done_no_sap')


def payment_summary(pb):
    """Comportamentul de plata (Open Contracts ITA, "Payment behaviour report") pe intelesul tuturor."""
    if pb is None:
        return ''
    parts = []
    if pb.risk_score is not None:
        lvl = 'risc mare' if pb.risk_score >= 70 else ('risc mediu' if pb.risk_score >= 40 else 'risc mic')
        parts.append(f'{lvl} ({pb.risk_score:.0f}/100)')
    if pb.days_late_text:
        parts.append(f'intarziere {pb.days_late_text} zile')
    if pb.trend_text:
        parts.append(pb.trend_text)
    if pb.oldest_overdue_days:
        parts.append(f'restanta cea mai veche {pb.oldest_overdue_days:.0f} z')
    if pb.payment_returns:
        parts.append(f'{pb.payment_returns:.0f} plati returnate')
    return ' | '.join(parts)


def stage(r, sap_company=''):
    ev, cp = r.ev, r.cp
    if ev is None or ev.state == 'cancelled':        # anulat de analist: inapoi unde il pune NWCE (de regula "Luna aceasta")
        if cp.inactive:
            return 'inactive'
        v = limits_book.validity(r.nwce, RENEW_DAYS[0]) if r.nwce is not None else 'review'
        if v == 'valid' and not cp.over_limit:
            return 'valid'          # APPROVED si valabil: nimic de facut, orice ar scrie la "TBD by"
        return {'inactive': 'inactive', 'na': 'na'}.get(v, 'new')
    if ev.state == 'error':
        return 'error'
    if ev.state in ('evaluated', 'evaluated_manual', 'prepared', 'new'):
        if ev.state not in ('evaluated', 'evaluated_manual'):
            return 'new'
        route = (ev.review or {}).get('route')
        return {'manual': 'manual', 'escalate': 'escalate', 'inactive': 'inactive_todo'}.get(route, 'decide')
    d = ev.decision or {}
    if (ev.nwce or {}).get('status') != 'ok':
        return 'write'
    if d.get('inactivate'):
        return 'done'
    if d.get('sap_skip'):
        return 'done_no_sap'            # aprobat pe alt canal: in SAP ar porni din nou workflow-ul de aprobare
    if sap_company and ev.company_code and ev.company_code != sap_company:
        return 'done_manual_sap'
    if (ev.sap or {}).get('status') != 'ok':
        return 'sap'
    return 'done'


_CRIT_NAMES = {'payment': 'Plăți', 'experience': 'Experiență', 'financial_reporting': 'Fin. reporting'}


def step_chip(r, sap_company=''):
    """(text, nivel) pentru eticheta "Pasul urmator" din varianta A: un text scurt despre ce urmeaza pentru client."""
    st = stage(r, sap_company)
    ev, cp = r.ev, r.cp
    rv = (ev.review or {}) if ev else {}
    if st in ('new', 'error') and r.nwce is not None and not limits_book._code(r.nwce.get('customer_code')) and not cp.inactive:
        return 'Lipsește Customer Code', 'bad'
    if st == 'error':
        return 'Eroare – vezi detalii', 'bad'
    if st == 'new':
        vt = limits_book.from_serial(r.nwce.get('valid_till')) if r.nwce is not None else None
        if vt and vt < dt.date.today():
            return f'Expirat {vt:%d.%m.%Y}', 'bad'
        if vt:
            return f'Expiră {vt:%d.%m.%Y}', 'warn'
        return 'De revizuit', 'info'
    if st in ('decide', 'manual') and ev is not None and not rv:
        return 'Revizuiește din nou', 'bad'
    if st == 'manual':
        missing = review_mod.manual_needed(ev)
        if missing:
            return f'Alege criteriul {_CRIT_NAMES.get(missing[0], missing[0])}', 'bad'
        return 'Alege grade-ul', 'bad'
    if st == 'decide':
        who = rv.get('authority') or ''
        if rv.get('would_escalate'):
            return f'Aprobă {who}', 'warn'
        return 'Aprobi tu', 'ok'
    if st == 'inactive_todo':
        return 'De inactivat', 'warn'
    if st == 'escalate':
        return f'Aprobă {rv.get("authority") or "nivel superior"}', 'warn'
    if st == 'write':
        if (ev.nwce or {}).get('status') == 'error':
            return 'NWCE: eroare', 'bad'
        return 'Se scrie în NWCE…', 'info'
    if st == 'sap':
        s = ev.sap or {}
        if s.get('status') == 'error' and sap_sent(ev):
            return 'SAP: verifică', 'warn'
        if s.get('status') == 'error':
            return 'SAP: eroare', 'bad'
        return 'Se trimite în SAP…', 'info'
    if st == 'done':
        return ('Gata · inactivat' if (ev.decision or {}).get('inactivate') else 'Gata · NWCE + SAP'), 'ok'
    if st == 'done_no_sap':
        return 'Gata · doar NWCE', 'ok'
    if st == 'done_manual_sap':
        return 'SAP manual (altă companie)', 'warn'
    if st == 'valid':
        vt = limits_book.from_serial(r.nwce.get('valid_till')) if r.nwce is not None else None
        return (f'Valabil până la {vt:%d.%m.%Y}' if vt else 'Valabil'), 'ok'
    if st == 'inactive':
        return 'Inactiv', 'grey'
    if st == 'na':
        return (str(r.nwce.get('status') or '') if r.nwce is not None else ''), 'grey'
    return NEXT_TEXT.get(st, ''), 'grey'


class ClientsModel(QAbstractTableModel):
    edited = pyqtSignal(object, str, object)     # rand, criteriu, valoare (completare manuala in tabel)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.rows = []
        self.by_partner = {}
        self.groups = {}
        self.sap_company = ''
        self._bold = QFont()
        self._bold.setBold(True)

    # --- incarcare
    def load(self, portfolio, latest, nwce, company_code, country, cfg=None):
        """Randuri: clientii din Open Contracts (Italia, cu expunere) + randurile NWCE "TBD by" + toate randurile
        aceluiasi grup de firme / aceleiasi firme pe celelalte companii si tari (limitele se aduna)."""
        self.beginResetModel()
        self.sap_company = company_code
        if cfg is not None:
            RENEW_DAYS[0] = int(cfg.get('limitsBook', 'renewWithinDays', default=30) or 30)
            self.validity_months = int(cfg.get('limitsBook', 'validityMonths', default=12) or 12)
        old_checked = {r.cp.partner for r in self.rows if r.checked}
        self.rows = []
        for cp in sorted(portfolio.counterparties.values(), key=lambda c: (-(c.peak_vs_limit or 0), c.name)):
            r = Row(cp)
            if nwce:
                r.nwce, _ = nwce.pick(cp.partner, cp.vat, company_code, country)
                cp.tbd = limits_book.tbd_owner(r.nwce.get('tbd_by')) if r.nwce else ''
                cp.inactive = limits_book.is_inactive(r.nwce)
            r.client = group_key(cp.vat or (r.nwce.get('vat') if r.nwce else ''), cp.partner, cp.name, country)
            self.rows.append(r)
        nrows = nwce.rows if nwce else []
        nclient = {id(nr): group_key(nr.get('vat'), nr.customer_code, nr.name, country) for nr in nrows}
        # grupul de firme al fiecarei firme: cel mai des trecut in NWCE. NWCE e sursa oficiala - foaia "VAT Italy" din
        # Open Contracts conteaza doar pentru firmele fara niciun rand NWCE (altfel o firma scoasa din grup in NWCE
        # ar ramane in grup pana se actualizeaza si Open Contracts)
        votes, raw = defaultdict(Counter), defaultdict(list)
        for nr in nrows:
            g = groups_mod.norm_group(nr.get('group'), cfg)
            if g:
                votes[nclient[id(nr)]][g] += 1
                raw[g].append(nr.get('group'))
        in_nwce = set(nclient.values())
        for r in self.rows:
            if r.nwce is not None or r.client in in_nwce:
                continue
            g = groups_mod.norm_group(r.cp.group, cfg)
            if g:
                votes[r.client][g] += 1
                raw[g].append(r.cp.group)
        client_group = {c: v.most_common(1)[0][0] for c, v in votes.items()}

        def final(client):
            g = client_group.get(client)
            return 'GRP:' + g if g else client

        self.group_names = {'GRP:' + g: groups_mod.display_group(v) for g, v in raw.items()}
        for r in self.rows:
            r.group = final(r.client)
        if nwce:
            used = {id(r.nwce) for r in self.rows if r.nwce is not None}
            anchors = {r.group for r in self.rows}
            anchors |= {final(nclient[id(nr)]) for nr in nrows if limits_book.tbd_owner(nr.get('tbd_by'))}
            seen = Counter()
            for nr in sorted(nrows, key=lambda x: x.sheet_row):
                base = f'{nr.customer_code or "NWCE"}@{nr.company_code.split(" ")[0]}'
                seen[base] += 1
                if id(nr) in used:
                    continue
                gk = final(nclient[id(nr)])
                owner = limits_book.tbd_owner(nr.get('tbd_by'))
                if not owner and (gk not in anchors or _skip_sibling(nr) or gk.startswith('NAME:')):
                    continue
                key = base if seen[base] == 1 else f'{base}#{seen[base]}'     # cheie stabila intre incarcari
                cur = limits_book.company_currency(cfg, nr.company_code) if cfg else 'EUR'
                r = Row(portfolio_mod.counterparty_from_nwce(nr, key, cur, owner))
                r.cp.inactive = limits_book.is_inactive(nr)
                r.nwce = nr
                r.client = nclient[id(nr)]
                r.group = gk
                self.rows.append(r)
        grouped = {}
        for r in self.rows:
            grouped.setdefault(r.group, []).append(r)
        for gk, rows in grouped.items():
            rows.sort(key=lambda x: (x.cp.source != 'portfolio', x.cp.name, x.nwce.company_code if x.nwce else '', x.cp.partner))
            for i, r in enumerate(rows):
                r.group_rows = rows
                r.lead = i == 0
                r.group_name = self.group_names.get(gk, '')
            # aceeasi firma: platile / contractele din Italia valoreaza si pentru celelalte tari (expunerea NU)
            for src in [x.cp for x in rows if x.cp.source == 'portfolio']:
                for x in rows:
                    if x.cp.source == 'nwce' and x.client == group_key(src.vat, src.partner, src.name, country):
                        x.cp.payment = x.cp.payment or src.payment
                        x.cp.first_contract = x.cp.first_contract or src.first_contract
                        x.cp.vat = x.cp.vat or src.vat
        self.groups = grouped
        for i, r in enumerate(self.rows):
            r.idx = i
            r.checked = r.cp.partner in old_checked
            if r.cp.partner in latest:
                eid, created, state, data = latest[r.cp.partner]
                try:
                    r.ev = Evaluation.from_dict(data)
                    r.ev.id = eid
                    r.ev_created = created
                except Exception:
                    r.ev = None
        self.by_partner = {r.cp.partner: r for r in self.rows}
        self.endResetModel()

    def new_values(self, r):
        """Valorile noi ale clientului: din decizie (daca exista, ex. limita schimbata manual) altfel din revizuire.
        dict(open, mtm_usd, grade, valid, total_usd, equity30_usd) sau {} daca nu a fost revizuit."""
        ev = r.ev
        if ev is None or ev.state == 'cancelled':
            return {}
        rv = ev.review or {}
        d = ev.decision or {}
        if d.get('inactivate'):
            return {'open': 0, 'mtm_usd': 0, 'grade': None, 'valid': None, 'total_usd': 0, 'equity30_usd': None}
        if not rv and not d:
            return {}
        if d:
            mtm = d.get('mtm_kusd')
            out = {'open': d.get('limit_eur'), 'mtm_usd': float(mtm) * 1000 if isinstance(mtm, (int, float)) else None,
                   'grade': d.get('grading'), 'valid': d.get('valid_till'),
                   'total_usd': ((d.get('open_kusd') or 0) + (mtm or 0)) * 1000 if isinstance(d.get('open_kusd'), (int, float)) else rv.get('total_usd')}
        else:
            m = rv.get('mtm_kusd')
            edit = rv.get('edit') or {}
            if edit.get('open') is not None:
                rv = dict(rv, new_open_local=edit['open'])
            if edit.get('mtm_usd') is not None:
                m = edit['mtm_usd'] / 1000
            grade = edit.get('grade') or (ev.grade if ev.grade is not None else rv.get('grade_used'))
            if grade is None and r.nwce is not None:          # evaluari vechi fara grade_used: gradul din NWCE
                grade = rules_mod.grade_number(r.nwce.get('grading'))
            out = {'open': rv.get('new_open_local'), 'mtm_usd': float(m) * 1000 if isinstance(m, (int, float)) else None,
                   'grade': grade,
                   'valid': edit.get('valid') or rules_mod.valid_till(dt.date.today(), getattr(self, 'validity_months', 12)).isoformat(),
                   'total_usd': rv.get('total_usd')}
        eq = rv.get('equity_usd')
        out['equity30_usd'] = eq * 0.3 if isinstance(eq, (int, float)) else None
        return out

    def _simple_value(self, r, key, sort):
        """Coloanele variantei A (Client, Limita acum, Propus, Valabil pana, Grade, Pasul urmator)."""
        cp, n = r.cp, r.nwce
        if key == 'a_client':
            if sort or r.lead:
                return cp.name
            comp = n.company_code if n is not None else (cp.company_code or '')
            return f'   ↳ {cp.name}' + (f'  ·  {comp}' if comp else '')
        if key == 'a_now':
            v = n.get('open_kloc') if n is not None else None
            v = float(v) * 1000 if isinstance(v, (int, float)) else None
            return (v or 0) if sort else money_ccy(v, cp.currency)
        if key == 'a_prop':
            v = self.new_values(r).get('open')
            return (v or 0) if sort else money_ccy(v, cp.currency)
        if key == 'a_valid':
            d = limits_book.from_serial(n.get('valid_till')) if n is not None else None
            return (d.isoformat() if d else '') if sort else fmt_date(d)
        if key == 'a_grade':
            nv = self.new_values(r)
            g = nv.get('grade') if nv else None
            if g is None and n is not None:
                g = n.get('grading')
            num = rules_mod.grade_number(g)
            return (num or 99) if sort else (num if num else (g or '—' if n is not None else ''))
        if key == 'a_step':
            text, _level = step_chip(r, self.sap_company)
            return text
        return ''

    def _pair_value(self, r, key, sort):
        n = r.nwce
        if key.startswith('o_'):
            if n is None:
                return '' if not sort else 0
            if key == 'o_open':
                v = n.get('open_kloc')
                v = float(v) * 1000 if isinstance(v, (int, float)) else None
                return (v or 0) if sort else (f'{fmt_money(v)}{" " + r.cp.currency if r.cp.currency != "EUR" else ""}' if v is not None else '')
            if key == 'o_mtm':
                v = n.get('mtm_kusd')
                v = float(v) * 1000 if isinstance(v, (int, float)) else None
                return (v or 0) if sort else fmt_money(v)
            if key == 'o_grade':
                g = rules_mod.grade_number(n.get('grading'))
                return (g or 99) if sort else (g or '')
            d = limits_book.from_serial(n.get('valid_till'))
            return (d.isoformat() if d else '') if sort else fmt_date(d)
        nv = self.new_values(r)
        if key == 'eq30':
            e30, tot = nv.get('equity30_usd'), nv.get('total_usd')
            if e30 is None or tot is None:
                return '' if not sort else 0
            over = tot > e30
            return (1 if over else 0) if sort else (f'✖ PESTE 30% ({fmt_money(e30)})' if over else f'✔ sub 30% ({fmt_money(e30)})')
        if key == 'cs_sc':
            ev = r.ev
            if ev is None or not ev.connect_id or ev.state == 'cancelled':
                return ''
            cs = 'CS ✔' if (ev.files or {}).get('pdf') or ev.report_json else 'CS ?'
            if (ev.files or {}).get('scorecard') and ev.grade is not None:
                sc = 'Scorecard ✔'
            elif (ev.inputs or {}).get('scorecard_skipped'):
                sc = 'fara scorecard (<350k)'
            elif ev.state == 'evaluated_manual':
                sc = 'fara bilant'
            else:
                sc = ''
            return f'{cs} | {sc}' if sc else cs
        if not nv:
            return '' if not sort else 0
        if key == 'n_open':
            v = nv.get('open')
            return (v or 0) if sort else (f'{fmt_money(v)}{" " + r.cp.currency if r.cp.currency != "EUR" else ""}' if v is not None else '')
        if key == 'n_mtm':
            v = nv.get('mtm_usd')
            return (v or 0) if sort else fmt_money(v)
        if key == 'n_grade':
            g = nv.get('grade')
            return (g or 99) if sort else (g if g is not None else '')
        v = nv.get('valid')
        d = dt.date.fromisoformat(v) if isinstance(v, str) and v else None
        return (v or '') if sort else fmt_date(d)

    def _review_value(self, r, key, sort):
        ev = r.ev
        rv = (ev.review or {}) if ev else {}
        if key == 'r_exp':
            if rv.get('exposure') is not None:
                v = rv['exposure']
            elif r.cp.source == 'portfolio':
                v = review_mod.next_month_exposure(r.cp)[0]
            else:
                return '' if not sort else -1
            return v if sort else fmt_money(v)
        if key == 'r_active':
            a = rv.get('active')
            return {True: 'Da', False: 'Nu', None: '?'}.get(a, '') if 'active' in rv else ''
        if key == 'r_cs':
            if not ev or not ev.connect_id:
                return ''
            if ev.state == 'error':
                return 'eroare'
            return f'{(ev.cs or {}).get("rating_common", "")} {(ev.cs or {}).get("rating_score", "") or ""}'.strip() or 'ok'
        if key in MANUAL_COLS:
            if not ev or not ev.inputs:
                return ''
            crit = MANUAL_COLS[key]
            v = ev.inputs.get(crit)
            v = v if isinstance(v, str) else (v or {}).get('grade', '')
            return f'{v} ?' if v and crit in review_mod.manual_needed(ev) else v     # "?" = propus de tool, de confirmat
        if key == 'r_open':
            v = rv.get('new_open_local')
            return (v or 0) if sort else (f'{fmt_money(v)} {ev.currency}' if v is not None else '')
        if key == 'r_total':
            v = rv.get('total_usd')
            return (v or 0) if sort else fmt_money(v)
        if key == 'r_auth':
            route = rv.get('route')
            if route in ('auto', 'manual') and 'would_escalate' in rv:     # dupa o modificare in tabel
                return f'⇧ {rv.get("authority", "")} - Annual Review la Next' if rv['would_escalate'] else f'✔ {rv.get("authority", "")}'
            if route == 'auto':
                return f'✔ {rv.get("authority", "")}'
            if route == 'escalate':
                return f'⇧ {rv.get("authority", "")}'
            if route == 'manual':
                return 'de completat'
            return ''
        if key == 'r_eq':
            return 'DA' if rv.get('equity_scenario') else ('nu' if 'equity_scenario' in rv else '')
        if key == 'r_ar':
            return 'generat' if rv.get('review_doc') else ''
        return ''

    def tbd_owners(self):
        return sorted({r.cp.tbd for r in self.rows if r.cp.tbd})

    def tbd_count(self, owner):
        return sum(1 for r in self.rows if r.cp.tbd == owner and not r.cp.inactive)

    def set_nwce(self, nwce, company_code, country):
        for r in self.rows:
            if r.cp.source == 'nwce':
                r.nwce = nwce.row_by_sheet(r.cp.nwce_sheet_row) if nwce else None
            else:
                r.nwce, _ = nwce.pick(r.cp.partner, r.cp.vat, company_code, country) if nwce else (None, '')
        self._all_changed()

    def update_evaluation(self, ev):
        r = self.by_partner.get(ev.partner)
        if not r:
            return
        r.ev = ev
        r.ev_created = ev.created
        i = self.rows.index(r)
        self.dataChanged.emit(self.index(i, 0), self.index(i, len(COLUMNS) - 1))

    def _all_changed(self):
        if self.rows:
            self.dataChanged.emit(self.index(0, 0), self.index(len(self.rows) - 1, len(COLUMNS) - 1))

    def checked_rows(self):
        return [r for r in self.rows if r.checked]

    def set_checked(self, partners, value=True):
        for r in self.rows:
            if r.cp.partner in partners:
                r.checked = value
        self._all_changed()

    # --- Qt
    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.rows)

    def columnCount(self, parent=QModelIndex()):
        return len(COLUMNS)

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if orientation == Qt.Horizontal and role == Qt.DisplayRole:
            return COLUMNS[section][1]
        if orientation == Qt.Horizontal and role == Qt.ToolTipRole:
            return {
                'ratio': 'Varful de expunere / limita curenta (din "Weekly Exposure Italy")',
                'pay': 'Risk Score 0-100 din "Payment behaviour report" (mare = risc mare)',
                'valid': 'Valid till din excelul NWCE',
                'proposed': 'Limita propusa dupa evaluare (EUR)',
            }.get(COLUMNS[section][0])
        return None

    @staticmethod
    def editable_row(r):
        """Randul se poate modifica direct in tabel: revizuit, in lucru, fara decizie aprobata inca."""
        ev = r.ev
        return (ev is not None and ev.state in ('evaluated', 'evaluated_manual') and bool(ev.review)
                and (ev.review or {}).get('route') not in ('inactive', 'error'))

    def flags(self, index):
        f = Qt.ItemIsEnabled | Qt.ItemIsSelectable
        if index.column() == COL['check']:
            f |= Qt.ItemIsUserCheckable
        key = COLUMNS[index.column()][0]
        key = ALIASES.get(key, key)
        if key in MANUAL_COLS or key in EDIT_NEW:
            r = self.rows[index.row()]
            if self.editable_row(r):
                has_sc = bool((r.ev.files or {}).get('scorecard')) and r.ev.grade is not None
                if key in MANUAL_COLS:
                    f |= Qt.ItemIsEditable            # subiectivele: mereu; cu scorecard se recalculeaza grade-ul in Excel
                elif key == 'n_grade' and not has_sc:
                    f |= Qt.ItemIsEditable            # fara scorecard: grade-ul se poate schimba manual
                elif key in ('n_open', 'n_mtm', 'n_valid'):
                    f |= Qt.ItemIsEditable
        return f

    def _edit_value(self, r, key):
        """Valoarea pusa in editor (spin / data / lista)."""
        if key in MANUAL_COLS:
            v = (r.ev.inputs or {}).get(MANUAL_COLS[key])
            return v if isinstance(v, str) else (v or {}).get('grade', '')
        nv = self.new_values(r)
        if key == 'n_open':
            return float(nv.get('open') or 0)
        if key == 'n_mtm':
            return float(nv.get('mtm_usd') or 0)
        if key == 'n_grade':
            g = rules_mod.grade_number(nv.get('grade'))
            return int(g) if g else 0          # 0 = fara grade (editorul arata "—", nu un 6 presupus)
        v = nv.get('valid')
        return QDate.fromString(v, 'yyyy-MM-dd') if v else None

    def setData(self, index, value, role=Qt.EditRole):
        if index.column() == COL['check'] and role == Qt.CheckStateRole:
            self.rows[index.row()].checked = value == Qt.Checked
            self.dataChanged.emit(index, index)
            return True
        key = COLUMNS[index.column()][0]
        key = ALIASES.get(key, key)
        if role != Qt.EditRole or (key not in MANUAL_COLS and key not in EDIT_NEW):
            return False
        r = self.rows[index.row()]
        if not self.editable_row(r) or value in (None, ''):
            return False
        if key == 'n_grade' and not rules_mod.grade_number(value):
            return False            # 0 / in afara 1-11 = fara grade ales
        if key in ('n_open', 'n_mtm') and float(value) < 0:
            return False
        if key in MANUAL_COLS:
            crit = MANUAL_COLS[key]
            r.ev.inputs = r.ev.inputs or {}
            # valoarea de dinainte: se pune la loc daca recalcularea scorecardului esueaza (undo_manual)
            r.undo_manual = (crit, copy.deepcopy(r.ev.inputs.get(crit, _MISSING)),
                             copy.deepcopy((r.ev.review or {}).get('manual', {}).get(crit, _MISSING)))
            if crit == 'financial_reporting':
                r.ev.inputs[crit] = value
            else:
                r.ev.inputs.setdefault(crit, {})['grade'] = value
                r.ev.inputs[crit]['manual'] = True
            r.ev.review.setdefault('manual', {})[crit] = value
        else:
            edit = r.ev.review.setdefault('edit', {})
            if key == 'n_valid':
                edit['valid'] = value.toString('yyyy-MM-dd') if isinstance(value, QDate) else str(value)
            elif key == 'n_grade':
                edit['grade'] = int(value)
            else:
                edit['open' if key == 'n_open' else 'mtm_usd'] = float(value)
        self.edited.emit(r, key, value)          # fereastra principala: scorecard in Excel + autoritate / 30% equity
        self.dataChanged.emit(self.index(index.row(), 0), self.index(index.row(), len(COLUMNS) - 1))
        return True

    @staticmethod
    def undo_manual(r):
        """Pune la loc criteriul subiectiv de dinainte de ultima editare (scorecardul nu s-a putut recalcula)."""
        crit, prev_input, prev_manual = getattr(r, 'undo_manual', (None, None, None))
        if crit is None or r.ev is None:
            return None
        if prev_input is _MISSING:
            (r.ev.inputs or {}).pop(crit, None)
        else:
            r.ev.inputs[crit] = prev_input
        manual = (r.ev.review or {}).get('manual', {})
        if prev_manual is _MISSING:
            manual.pop(crit, None)
        else:
            manual[crit] = prev_manual
        r.undo_manual = (None, None, None)
        return crit

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid():
            return None
        r = self.rows[index.row()]
        key = COLUMNS[index.column()][0]
        cp, ev = r.cp, r.ev
        if role == PARTNER_ROLE:
            return cp.partner
        if role == Qt.CheckStateRole and key == 'check':
            return Qt.Checked if r.checked else Qt.Unchecked
        if role == Qt.EditRole and (ALIASES.get(key, key) in MANUAL_COLS or ALIASES.get(key, key) in EDIT_NEW):
            return self._edit_value(r, ALIASES.get(key, key)) if self.editable_row(r) else None
        if role == CHIP_ROLE and key == 'a_step':
            return step_chip(r, self.sap_company)[1]
        if key.startswith('a_') and role in (Qt.DisplayRole, SORT_ROLE):
            return self._simple_value(r, key, role == SORT_ROLE)
        if key.startswith('a_') and role == Qt.TextAlignmentRole and key in ('a_now', 'a_prop'):
            return Qt.AlignRight | Qt.AlignVCenter
        if key.startswith('a_') and role == Qt.ForegroundRole and key == 'a_prop' and self.editable_row(r):
            return QBrush(QColor('#1F5C99'))           # se poate modifica (dublu-click)
        if role in (Qt.DisplayRole, SORT_ROLE):
            sort = role == SORT_ROLE
            if key == 'state':
                if ev:
                    return ev.display_state
                if cp.inactive:
                    return 'Inactiv (NWCE)'
                st = stage(r, self.sap_company)
                if st == 'valid':
                    return 'Valabil'
                if st == 'na':
                    return str(r.nwce.get('status') or '') if r.nwce else ''
                if r.nwce is not None and str(r.nwce.get('status') or '').upper() == 'UNDER REVIEW':
                    return 'De reinnoit'
                return 'De evaluat'
            if key in NWCE_FIELDS:
                if r.nwce is None:
                    return '' if not sort else ''
                v = r.nwce.get(NWCE_FIELDS[key])
                if sort:
                    if isinstance(v, (int, float)):
                        return float(v)
                    return str(v or '')
                if key == 'open_kloc' and v not in (None, '') and cp.currency != 'EUR':
                    return f'{limits_book.display("open_kloc", v)} {cp.currency}'
                return limits_book.display(NWCE_FIELDS[key], v)
            if key in ('r_exp', 'r_active', 'r_cs', 'r_open', 'r_total', 'r_auth', 'r_eq', 'r_ar') or key in MANUAL_COLS:
                return self._review_value(r, key, sort)
            if key in PAIR_KEYS:
                return self._pair_value(r, key, sort)
            if key == 'next':
                st = stage(r, self.sap_company)
                if st in ('new', 'error') and r.nwce is not None and not limits_book._code(r.nwce.get('customer_code')) \
                        and not cp.inactive:
                    return '⚠ Fara Customer Code in NWCE - completeaza-l'
                if st in ('decide', 'manual') and ev is not None and not ev.review:
                    return '⚠ Evaluat fara revizuire - click-dreapta → Revizuieste'
                if st == 'valid' and not sort:
                    return f'✔ Valabil pana la {fmt_date(limits_book.from_serial(r.nwce.get("valid_till")))}'
                return NEXT_TEXT.get(st, '')
            if key == 'tbd':
                return str(r.nwce.get('tbd_by') or '').strip() if r.nwce is not None else ''
            if key == 'partner':
                return cp.customer_code or '-'
            if key == 'company':
                return r.nwce.company_code if r.nwce else (cp.company_code or '')
            if key == 'name':
                return cp.name if r.lead or sort else f'      ↳ {cp.name}'
            if key == 'grp':
                raw = str(r.nwce.get('group') or '').strip() if r.nwce is not None else ''
                return raw if raw and raw not in ('0', '0.0') else r.group_name
            if key == 'kusd':
                return r.kusd if sort else fmt_money(r.kusd)
            if key == 'group_kusd':
                return r.group_kusd if sort else (fmt_money(r.group_kusd) if r.lead else '')
            if key == 'countries':
                n = len(r.group_companies)
                return n if sort else (n if r.lead and n > 1 else '')
            if key == 'bu':
                return cp.business_unit
            if key == 'ps':
                return cp.purchase_sale
            if key == 'limit':
                return cp.limit if sort else fmt_money(cp.limit)
            if key == 'peak':
                return (cp.peak_exposure or 0) if sort else fmt_money(cp.peak_exposure)
            if key == 'ratio':
                v = cp.peak_vs_limit
                return (v or 0) if sort else (f'{v:.2f}x' if v else '')
            if key == 'months':
                return cp.months_over if sort else (cp.months_over or '')
            if key == 'weeks':
                return cp.weeks_over if sort else (cp.weeks_over or '')
            if key == 'breach':
                return cp.first_breach_week or cp.first_breach_month
            if key == 'pay_beh':
                v = cp.payment.risk_score if cp.payment else None
                return (v if v is not None else -1) if sort else (payment_summary(cp.payment) or ('fara date de plata' if cp.source == 'portfolio' else ''))
            if key == 'pay':
                v = cp.payment.risk_score if cp.payment else None
                return (v or -1) if sort else (f'{v:.0f} {cp.payment.trend}' if v is not None else '')
            if key == 'valid':
                d = limits_book.from_serial(r.nwce.get('valid_till')) if r.nwce else None
                return (d.isoformat() if d else '') if sort else fmt_date(d)
            if key == 'grade':
                g = ev.grade if ev else None
                if g is None and ev and (ev.review or {}).get('grade_source') == 'nwce':     # fara bilant: gradul NWCE pastrat
                    g = ev.review.get('grade_used')
                    why = 'sub 350k USD, fara scorecard' if (ev.inputs or {}).get('scorecard_skipped') else 'fara bilant'
                    return (g or 99) if sort else f'{g} (NWCE, {why})'
                return (g or 99) if sort else (g or '')
            if key == 'proposed':
                p = (ev.proposal or {}).get('proposed') if ev else None
                return (p or 0) if sort else fmt_money(p)
            if key == 'nwce':
                s = (ev.nwce or {}).get('status') if ev else None
                return {'ok': '✔ scris', 'error': '✖ eroare'}.get(s, 'de scris' if ev and ev.state == 'approved' else '')
            if key == 'sap':
                s = (ev.sap or {}).get('status') if ev else None
                if ev and s != 'ok' and (ev.decision or {}).get('sap_skip'):
                    return '— netranscris (aprobat pe alt canal)'
                if s == 'error' and sap_sent(ev):
                    return '⚠ trimis? verifica'
                return {'ok': '✔ salvat', 'error': '✖ eroare', 'dry_ok': 'proba ✔', 'dry_error': 'proba ✖'}.get(
                    s, 'de actualizat' if ev and ev.state == 'approved' else '')
            if key == 'block':
                return cp.block_reason or ('blocat CM' if cp.blocked_cm else '') or ('prepayment' if cp.prepayment else '')
            return '' if not sort else 0
        if role == Qt.BackgroundRole:
            if key == 'state' and ev:
                if ev.state == 'error':
                    return QBrush(RED)
                if ev.state == 'done':
                    return QBrush(GREEN)
                if ev.state == 'approved':
                    return QBrush(BLUE)
                if ev.state in ('evaluated', 'evaluated_manual'):
                    return QBrush(YELLOW if ev.warnings or ev.state == 'evaluated_manual' else GREEN)
            if key == 'ratio' and cp.peak_vs_limit:
                return QBrush(RED if cp.peak_vs_limit > 1.0 else (YELLOW if cp.peak_vs_limit > 0.8 else GREEN))
            if key == 'grade' and ev and ev.grade:
                return QBrush(GREEN if ev.grade <= 4 else (YELLOW if ev.grade <= 7 else RED))
            if key in ('n_open', 'n_mtm', 'n_grade', 'n_valid') and self.new_values(r):
                return QBrush(NEW_GREEN)
            if key == 'eq30':
                v = self._pair_value(r, 'eq30', True)
                t = self._pair_value(r, 'eq30', False)
                if t:
                    return QBrush(RED if v else GREEN)
            if key in ('pay', 'pay_beh') and cp.payment and cp.payment.risk_score is not None:
                v = cp.payment.risk_score
                return QBrush(RED if v >= 70 else (YELLOW if v >= 40 else GREEN))
            if key == 'nwce' and ev and ev.nwce:
                return QBrush(GREEN if ev.nwce.get('status') == 'ok' else RED)
            if key == 'sap' and ev and ev.sap:
                st = ev.sap.get('status')
                if st == 'error' and sap_sent(ev):
                    return QBrush(YELLOW)
                return QBrush(GREEN if st == 'ok' else (BLUE if st == 'dry_ok' else RED))
            if key == 'block' and (cp.block_reason or cp.blocked_cm):
                return QBrush(GREY)
        if role == Qt.ForegroundRole and cp.inactive and not (ev and ev.state in ('approved', 'done')):
            return QBrush(QColor(150, 150, 150))
        if role == Qt.ForegroundRole and (cp.block_reason or cp.blocked_cm) and key in ('name', 'partner'):
            return QBrush(QColor(120, 120, 120))
        if role == Qt.FontRole and (key == 'grade' or (key in ('name', 'a_client') and r.lead and len(r.group_rows) > 1)):
            return self._bold
        if role == Qt.BackgroundRole and not r.lead and key not in ('state', 'next', 'a_step'):
            return QBrush(QColor(247, 249, 252))
        if role == Qt.BackgroundRole and key in MANUAL_COLS and ev is not None and ev.inputs:
            crit = MANUAL_COLS[key]
            if crit in review_mod.manual_needed(ev):
                return QBrush(QColor('#FFF59D'))       # de completat de analist
            if (ev.review or {}).get('manual', {}).get(crit):
                return QBrush(QColor('#E3F2FD'))       # completat manual
        if role == Qt.BackgroundRole and key == 'r_auth' and ev is not None and ev.review:
            route = ev.review.get('route')
            if 'would_escalate' in ev.review and route in ('auto', 'manual'):
                return QBrush(QColor('#FFE0B2' if ev.review['would_escalate'] else '#C6EFCE'))
            return QBrush(QColor('#C6EFCE' if route == 'auto' else ('#FFE0B2' if route == 'escalate' else '#FFF59D')))
        if role == Qt.BackgroundRole and key == 'r_active' and ev is not None and ev.review and ev.review.get('active') is False:
            return QBrush(QColor('#ECEFF1'))
        if role == Qt.BackgroundRole and key == 'countries' and r.lead and len(r.group_companies) > 1:
            return QBrush(BLUE)
        if role == Qt.ForegroundRole and not r.lead and key in ('name', 'partner', 'company', 'a_client'):
            return QBrush(QColor(70, 90, 140))
        if role == Qt.TextAlignmentRole and key in NUMERIC:
            return Qt.AlignRight | Qt.AlignVCenter
        if role == Qt.ToolTipRole:
            if key == 'state' and ev and ev.error:
                return f'{ev.error["title"]}\nCe ai de facut: {ev.error["action"]}'
        return None


class ClientsFilter(QSortFilterProxyModel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.text = ''
        self.only_over = False
        self.only_list = False
        self.hide_blocked = True
        self.only_sales = False
        self.bu = ''
        self.state = ''
        self.tbd = ''
        self.view = 'all'          # work / over / new / decide / write / sap / done / error / all
        self._scope = []
        self.setSortRole(SORT_ROLE)

    def refresh(self):
        """Un client e vizibil daca oricare rand "ancora" al lui trece filtrele; atunci apar TOATE tarile lui.
        Ancore: cu filtru TBD - randurile analistului; fara - clientii din Open Contracts (Italia)."""
        m = self.sourceModel()
        visible, scope = set(), set()
        for r in m.rows:
            if r.group in visible:
                continue
            in_scope = self._anchor_ok(r, with_view=False)
            if in_scope:
                scope.add(r.group)
            if (in_scope or self.view == 'everyone') and self._anchor_ok(r):
                visible.add(r.group)
        if self.text:
            t = self.text.lower()
            visible = {g for g in visible if any(t in x.cp.name.lower() or t in (x.cp.customer_code or '') or t in (x.cp.vat or '').lower()
                                                 or t in x.group_name.lower() for x in m.groups.get(g, []))}
            scope = {g for g in scope if any(t in x.cp.name.lower() or t in (x.cp.customer_code or '') or t in (x.cp.vat or '').lower()
                                             or t in x.group_name.lower() for x in m.groups.get(g, []))}
        self._visible = visible
        self._scope = [r for g in scope for r in m.groups.get(g, [])]       # lista curenta, fara filtrul "Arata"
        self.invalidateFilter()

    def stage_counts(self):
        from collections import Counter
        m = self.sourceModel()
        c = Counter()
        for r in self._scope:
            st = stage(r, m.sap_company)
            c[st] += 1
            if st in ('new', 'error') and review_mod.expiring(r.nwce):
                c['month'] += 1
            if st in PROCESS_STAGES:
                c['process'] += 1
            if st in REVIEWED_STAGES:
                c['reviewed'] += 1
        return c

    def _anchor_ok(self, r, with_view=True):
        cp = r.cp
        if with_view and self.view not in ('all', 'everyone'):
            m = self.sourceModel()
            st = stage(r, m.sap_company)
            if self.view == 'work':
                if st in REVIEWED_STAGES + ('inactive', 'valid', 'na'):
                    return False
                if not self.tbd and st == 'new' and not cp.over_limit:
                    return False
            elif self.view == 'over':
                if not cp.over_limit:
                    return False
            elif self.view == 'done':
                if st not in REVIEWED_STAGES + ('valid',):
                    return False
            elif self.view == 'month':
                if st not in ('new', 'error') or not review_mod.expiring(r.nwce):
                    return False
            elif self.view == 'process':          # in lucru: de completat + scriere NWCE / SAP in fundal + inactivari
                if st not in PROCESS_STAGES:
                    return False
            elif self.view == 'reviewed':
                if st not in REVIEWED_STAGES:
                    return False
            elif st != self.view:
                return False
        if self.view == 'everyone' and with_view:
            pass                       # "Toti clientii": toate listele (si ale colegilor) + Open Contracts
        elif self.tbd:
            if cp.tbd != self.tbd:
                return False
        elif cp.source != 'portfolio':
            return False
        if self.only_over and not cp.over_limit:
            return False
        if self.only_list and not cp.selected_for_evaluation:
            return False
        if self.hide_blocked and (cp.block_reason or cp.blocked_cm or cp.inactive) and not r.checked:
            return False
        if self.only_sales and cp.purchase_sale != 'S':
            return False
        if self.bu and cp.business_unit != self.bu:
            return False
        if self.state:
            ev = r.ev
            st = ev.state if ev else 'new'
            want = {'evaluated': ('evaluated', 'evaluated_manual'), 'approved': ('approved',), 'error': ('error',), 'done': ('done',)}
            if self.state == 'new':
                return ev is None
            if st not in want.get(self.state, (st,)):
                return False
        return True

    def filterAcceptsRow(self, source_row, source_parent):
        return self.sourceModel().rows[source_row].group in getattr(self, '_visible', set())

    def lessThan(self, left, right):
        """Sortare pe client: valoarea randului principal al clientului; tarile aceluiasi client raman impreuna."""
        m = self.sourceModel()
        ra, rb = m.rows[left.row()], m.rows[right.row()]
        if ra.group == rb.group:
            ia, ib = ra.group_rows.index(ra), ra.group_rows.index(rb)
            return (ia < ib) if self.sortOrder() == Qt.AscendingOrder else (ia > ib)
        la, lb = ra.group_rows[0], rb.group_rows[0]
        a = m.data(m.index(la.idx, left.column()), SORT_ROLE)
        b = m.data(m.index(lb.idx, right.column()), SORT_ROLE)
        if a == b:
            return (ra.group < rb.group) if self.sortOrder() == Qt.AscendingOrder else (ra.group > rb.group)
        try:
            return a < b
        except TypeError:
            return str(a) < str(b)
