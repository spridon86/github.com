"""Folderul clientului in "BUC - TRADING COUNTREPARTIES".

Folderele existente au nume variate: "CEREAL DORICA SRL - BRC", "Cereal Dorica S.R.L",
"CEREAL DOCKS Group\\CEREAL DOCKS SPA - BRC". Comparam o cheie normalizata a numelui.
"""
import datetime as dt
import os
import re
import time
import unicodedata
from dataclasses import dataclass, field
from pathlib import Path

from .fsutil import safe_name

# Forme juridice ignorate la comparare (dupa eliminarea punctuatiei si lipirea literelor singure: S.R.L -> SRL).
LEGAL_FORMS = {
    'SRL', 'SPA', 'SA', 'SL', 'SAS', 'SNC', 'SAT', 'SCA', 'SARL', 'SCS', 'SC', 'CA', 'LTD', 'LIMITED', 'PLC', 'LLC', 'INC',
    'GMBH', 'AG', 'KG', 'CO', 'KFT', 'ZRT', 'NYRT', 'BT', 'LDA', 'BV', 'NV', 'AS', 'AB', 'OY', 'APS', 'SP', 'ZOO', 'SRO',
    'DOO', 'AD', 'EAD', 'OOD', 'EOOD', 'SOCIETA', 'RESPONSABILITA', 'LIMITATA', 'SOCIETATE', 'COOPERATIVA', 'COOP', 'SOC',
    'SRLS', 'SS', 'SEMPLIFICATA', 'AGRICOLA', 'ARL',
}
# "AGRICOLA" / "SS" apar si la inceputul numelui ("SOCIETA AGRICOLA X") - se scot doar de la final.


def name_key(name):
    if not name:
        return ''
    n = str(name).upper()
    n = re.sub(r'\s+-\s*(BRC|NO TRADE|CBT|CUSTOMER|VENDOR|SUPPLIER)\b.*$', '', n)   # sufixe interne
    n = re.sub(r'\(.*?\)', ' ', n)                                                  # "(ex ...)"
    n = ''.join(ch for ch in unicodedata.normalize('NFD', n) if unicodedata.category(ch) != 'Mn')
    n = re.sub(r'[^A-Z0-9]+', ' ', n).strip()
    tokens, buf = [], ''
    for t in n.split(' '):            # lipeste literele singure consecutive: "S R L" -> "SRL"
        if len(t) == 1:
            buf += t
        else:
            if buf:
                tokens.append(buf)
                buf = ''
            if t:
                tokens.append(t)
    if buf:
        tokens.append(buf)
    while len(tokens) > 1 and (tokens[-1] in LEGAL_FORMS or tokens[-1] in ('A', 'E', 'DI')):
        tokens.pop()
    return ' '.join(tokens)


def _quick(name):
    n = name.upper()
    if not n.isascii():
        n = ''.join(ch for ch in unicodedata.normalize('NFD', n) if unicodedata.category(ch) != 'Mn')
    return re.sub(r'[^A-Z0-9]', '', n)


# folder de grup cu firmele lui inauntru: "CEREAL DOCKS Group", "GRUPPO Marseglia - BRC", "Grupo X", "Groupe Y".
# Nu "GRUP" singur: in romana e parte din numele firmei ("CARCO GRUP SRL"), nu un folder de grup.
_GROUP_RE = re.compile(r'group|\b(gruppo|grupo)\b', re.I)


def is_group_folder(name):
    return bool(_GROUP_RE.search(str(name or '')))


def find_client_folders(root, names):
    """Cautare dupa primul cuvant din nume, in radacina si in folderele de grup ("... Group\\<client>")."""
    root = Path(root)
    keys = list(dict.fromkeys(k for k in (name_key(n) for n in names if n) if k))
    if not keys:
        return []
    top = _subdirs(root, cache_seconds=120)
    parents = [None] + [p for p in top if is_group_folder(p.name)]
    firsts = list(dict.fromkeys(k.split(' ')[0] for k in keys))
    found = []
    for parent in parents:
        for d in (top if parent is None else _subdirs(parent, cache_seconds=120)):
            q = _quick(d.name)
            if not any(q.startswith(f[:3]) for f in firsts):
                continue      # filtru rapid inainte de normalizarea completa
            key = name_key(d.name)
            if key.split(' ')[0] in firsts and key in keys:
                found.append(d)
    return list(dict.fromkeys(found))


_listing_cache = {}     # radacina are ~25.000 foldere: listarea se refoloseste 2 minute


def _subdirs(path, cache_seconds=0):
    key = str(path).lower()
    if cache_seconds:
        hit = _listing_cache.get(key)
        if hit and time.time() - hit[0] < cache_seconds:
            return hit[1]
    try:
        with os.scandir(path) as it:
            res = [Path(e.path) for e in it if e.is_dir(follow_symlinks=False)]
    except OSError:
        res = []
    if cache_seconds:
        _listing_cache[key] = (time.time(), res)
    return res


def forget_listing():
    _listing_cache.clear()


def _walk_files(path, max_files=5000):
    n = 0
    for dirpath, _, files in os.walk(path):
        for f in files:
            if f.lower() == 'desktop.ini':
                continue
            yield Path(dirpath) / f
            n += 1
            if n >= max_files:
                return


def last_activity(path):
    """Cea mai recenta modificare de fisier (folderele OneDrive au data de creare = data sincronizarii)."""
    latest = 0.0
    for f in _walk_files(path):
        try:
            latest = max(latest, f.stat().st_mtime)
        except OSError:
            pass
    return latest


def year_subfolders(path):
    return sorted(int(p.name) for p in _subdirs(path) if re.fullmatch(r'(19|20)\d{2}', p.name))


def earliest_trace(path):
    """Cea mai veche urma a relatiei in folder: (data, explicatie) - an de subfolder sau fisier vechi."""
    path = Path(path)
    best, why = None, ''
    # subfolderul anului curent poate fi creat chiar de aplicatie - nu dovedeste o relatie veche
    years = [y for y in year_subfolders(path) if y < dt.date.today().year]
    if years:
        best, why = dt.date(years[0], 1, 1), f'subfolderul "{years[0]}"'
    oldest = None
    for f in _walk_files(path):
        try:
            m = f.stat().st_mtime
        except OSError:
            continue
        if oldest is None or m < oldest[0]:
            oldest = (m, f)
    if oldest:
        d = dt.date.fromtimestamp(oldest[0])
        if best is None or d < best:
            best, why = d, f'fisierul "{oldest[1].name}" ({d:%d.%m.%Y})'
    return best, why


@dataclass
class ClientFolder:
    path: Path
    exists: bool
    alternatives: list = field(default_factory=list)


def resolve_client_folder(root, names, new_folder_name):
    """Folderul existent (potrivire dupa nume) sau calea unui folder nou (necreat inca).
    Mai multe potriviri ("X SRL" si "X SRL - BRC"): cel cu activitatea cea mai recenta."""
    cands = find_client_folders(root, names)
    if cands:
        cands.sort(key=lambda p: (last_activity(p), (year_subfolders(p) or [0])[-1], str(p)), reverse=True)
        return ClientFolder(cands[0], True, cands[1:])
    return ClientFolder(Path(root) / safe_name(new_folder_name), False, [])
