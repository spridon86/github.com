import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'tests' / 'fixtures'))

# testele nu scriu in jurnalul real al aplicatiei (data\logs\app.log): intrarile lor ar parea operatii reale
from creditapp import log as _applog  # noqa: E402
_applog._configured = True


@pytest.fixture
def cfg():
    from creditapp.config import DEFAULTS, Config, _merge
    return Config(_merge(DEFAULTS, {}))
