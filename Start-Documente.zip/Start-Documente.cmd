@echo off
rem Porneste Documente client (PDF Creditsafe + scorecard) cu Python din Anaconda. Fereastra consolei se inchide singura.
setlocal
set "PY=%LOCALAPPDATA%\anaconda3\pythonw.exe"
if not exist "%PY%" set "PY=%USERPROFILE%\anaconda3\pythonw.exe"
if not exist "%PY%" set "PY=C:\ProgramData\anaconda3\pythonw.exe"
if not exist "%PY%" goto nopython
cd /d "%~dp0"
start "" "%PY%" -m creditapp.docs_tool
exit /b 0

:nopython
echo Nu am gasit Anaconda - pythonw.exe lipseste. Verifica instalarea Anaconda.
pause
exit /b 1
