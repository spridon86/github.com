"""Sablonul SAP: importul .vbs si executia pe o sesiune SAP simulata (fara SAP real)."""
import datetime as dt

import pytest

from creditapp import sap_gui
from creditapp.errors import AppError

VBS = r'''
If Not IsObject(application) Then
   Set SapGuiAuto  = GetObject("SAPGUI")
   Set application = SapGuiAuto.GetScriptingEngine
End If
session.findById("wnd[0]").maximize
session.findById("wnd[0]/tbar[0]/okcd").text = "/nukm_bp"
session.findById("wnd[0]").sendVKey 0
session.findById("wnd[0]/usr/subSCREEN_3000:SAPLBUS_LOCATOR:3000/ctxtBUS_JOEL_MAIN-CHANGE_NUMBER").text = "76014759"
session.findById("wnd[0]/usr/subSCREEN_3000:SAPLBUS_LOCATOR:3000/ctxtBUS_JOEL_MAIN-CHANGE_NUMBER").caretPosition = 8
session.findById("wnd[0]").sendVKey 0
session.findById("wnd[0]/usr/tabsGS_SCREEN_1100_TABSTRIP/tabpSCREEN_1100_TAB_02").select
session.findById("wnd[0]/usr/ctxtUKM_S_SGM-CREDIT_SGMNT").text = "IT01"
session.findById("wnd[0]/usr/txtUKMBP_CMS_SGM-CREDIT_LIMIT").text = "850.000,00"
session.findById("wnd[0]/usr/ctxtUKMBP_CMS_SGM-LIMIT_VALID_DATE").text = "31.10.2027"
session.findById("wnd[0]/tbar[0]/btn[11]").press
'''


def test_parse_vbs():
    steps = sap_gui.parse_vbs(VBS)
    assert len(steps) == 11
    assert steps[1] == {'id': 'wnd[0]/tbar[0]/okcd', 'op': 'set', 'name': 'text', 'value': '/nukm_bp', 'line': 7}
    assert steps[2]['op'] == 'call' and steps[2]['args'] == [0]
    assert steps[4]['name'] == 'caretPosition' and steps[4]['value'] == 8


def test_parse_args_with_commas_and_quotes():
    s = sap_gui.parse_vbs('session.findById("wnd[0]/usr/cntlGRID/shellcont/shell").setCurrentCell 3,"A, ""B"""')
    assert s[0]['args'] == [3, 'A, "B"']


def test_build_template_placeholders():
    tpl, rep = sap_gui.build_template(VBS, {'bp': '76014759', 'customer_code': '76021671', 'limit': 850000,
                                            'valid_to': dt.date(2027, 10, 31)}, 'rec.vbs')
    vals = [s.get('value') for s in tpl['steps']]
    assert '{bp}' in vals and '{limit}' in vals and '{valid_to}' in vals
    assert 'IT01' in vals                     # segmentul de credit ramane constant
    assert tpl['save_step'] == 10
    assert tpl['formats']['limit'] == {'thousands': '.', 'decsep': ',', 'decimals': 2}
    assert tpl['formats']['valid_to'] == {'date': '%d.%m.%Y'}
    assert 'Customer Code' in rep and 'nu apare' in rep    # customer code nu a fost tastat in SAP


@pytest.mark.parametrize('sample,value,expected', [
    ('850.000', 1_234_000, '1.234.000'), ('850,000', 1_234_000, '1,234,000'), ('850000', 1_234_000, '1234000'),
    ('850.000,00', 1_234_000, '1.234.000,00'), ('850000.00', 75_000, '75000.00'), ('850000,00', 75_000, '75000,00'),
])
def test_amount_formats(sample, value, expected):
    assert sap_gui.format_amount(value, sap_gui.amount_style(sample)) == expected


# ---------------------------------------------------------------- sesiune SAP simulata
class FakeOle:
    """Imita un obiect COM pentru sap_gui._invoke (GetIDsOfNames + Invoke)."""

    def __init__(self, obj):
        self.obj = obj

    def GetIDsOfNames(self, name):
        return name

    def Invoke(self, name, lcid, flags, want_result, *args):
        import pythoncom
        if flags == pythoncom.DISPATCH_PROPERTYPUT:
            self.obj.props[name] = args[0]
            self.obj.session.trace.append(('put', self.obj.id, name, args[0]))
            return None
        if flags == pythoncom.DISPATCH_PROPERTYGET:
            return self.obj.props.get(name)
        return self.obj.call(name, *args)


class FakeElem:
    def __init__(self, session, sid):
        self.session, self.id = session, sid
        self.props = {'text': session.screen_values.get(sid, ''), 'Text': session.screen_values.get(sid, '')}
        self._oleobj_ = FakeOle(self)

    def call(self, name, *args):
        self.session.trace.append(('call', self.id, name, args))
        if name == 'press' and self.id == 'wnd[0]/tbar[0]/btn[11]':
            self.session.saved = True
            self.session.sbar = ('S', 'Changes saved')
        if name == 'HardCopy':
            return args[0]
        return None


class FakeSession:
    def __init__(self, missing=(), error_after_enter=False):
        self.trace, self.saved, self.missing = [], False, set(missing)
        self.sbar = ('', '')
        self.error_after_enter = error_after_enter
        self.screen_values = {'wnd[0]/usr/txtUKMBP_CMS_SGM-CREDIT_LIMIT': '800.000,00'}
        self.elems = {}
        self._oleobj_ = FakeOle(self)
        self.props = {'Busy': False}

    def call(self, name, *args):
        if name == 'findById':
            sid = args[0]
            if sid in self.missing or sid.startswith('wnd[1]'):
                return None
            if sid == 'wnd[0]/sbar':
                e = FakeElem(self, sid)
                e.props.update({'MessageType': self.sbar[0], 'Text': self.sbar[1]})
                return e
            if self.error_after_enter and sid == 'wnd[0]' and any(t[2] == 'sendVKey' for t in self.trace if t[0] == 'call'):
                self.sbar = ('E', 'Business partner does not exist')
            return self.elems.setdefault(sid, FakeElem(self, sid))
        raise AssertionError(name)


@pytest.fixture
def tpl():
    t, _ = sap_gui.build_template(VBS, {'bp': '76014759', 'limit': 850000, 'valid_to': dt.date(2027, 10, 31)}, 'rec.vbs')
    return t


def run(monkeypatch, cfg, tpl, session, dry):
    monkeypatch.setattr(sap_gui, 'connect', lambda c: (session, sap_gui.SapSessionInfo('P01', '100', 'UISPRID', '')))
    values = {'bp': '76099999', 'customer_code': '76021671', 'limit': 1_200_000, 'valid_to': dt.date(2027, 12, 31)}
    return sap_gui.run(tpl, values, cfg, dry_run=dry)


def test_dry_run_never_saves(monkeypatch, cfg, tpl):
    s = FakeSession()
    res = run(monkeypatch, cfg, tpl, s, True)
    assert res.ok and not s.saved and not res.saved
    puts = {t[1]: t[3] for t in s.trace if t[0] == 'put' and t[2] == 'text'}
    assert puts['wnd[0]/usr/txtUKMBP_CMS_SGM-CREDIT_LIMIT'] == '1.200.000,00'
    assert puts['wnd[0]/usr/ctxtUKMBP_CMS_SGM-LIMIT_VALID_DATE'] == '31.12.2027'
    assert puts['wnd[0]/usr/subSCREEN_3000:SAPLBUS_LOCATOR:3000/ctxtBUS_JOEL_MAIN-CHANGE_NUMBER'] == '76099999'
    assert res.before['limit'] == '800.000,00'
    assert ('put', 'wnd[0]/tbar[0]/okcd', 'Text', '/n') in s.trace       # iesire fara salvare


def test_real_run_saves_and_verifies(monkeypatch, cfg, tpl):
    s = FakeSession()
    res = run(monkeypatch, cfg, tpl, s, False)
    assert res.ok and s.saved and res.saved
    assert res.after['limit'] == '1.200.000,00' and 'Changes saved' in res.message


def test_missing_field_stops_before_save(monkeypatch, cfg, tpl):
    s = FakeSession(missing={'wnd[0]/usr/txtUKMBP_CMS_SGM-CREDIT_LIMIT'})
    with pytest.raises(AppError) as e:
        run(monkeypatch, cfg, tpl, s, False)
    assert e.value.code == 'SAP_SCREEN' and not s.saved


def test_optional_step_missing_is_ignored(monkeypatch, cfg, tpl):
    s = FakeSession(missing={'wnd[0]/usr/subSCREEN_3000:SAPLBUS_LOCATOR:3000/ctxtBUS_JOEL_MAIN-CHANGE_NUMBER_X'})
    assert run(monkeypatch, cfg, tpl, s, True).ok


def test_sap_error_message_stops(monkeypatch, cfg, tpl):
    s = FakeSession(error_after_enter=True)
    with pytest.raises(AppError) as e:
        run(monkeypatch, cfg, tpl, s, False)
    assert e.value.code == 'SAP_ERROR' and not s.saved


def test_missing_value_for_placeholder(monkeypatch, cfg, tpl):
    s = FakeSession()
    monkeypatch.setattr(sap_gui, 'connect', lambda c: (s, sap_gui.SapSessionInfo('P01', '100', 'U', '')))
    with pytest.raises(AppError) as e:
        sap_gui.run(tpl, {'bp': None, 'limit': 1, 'valid_to': dt.date(2027, 1, 31)}, cfg, dry_run=True)
    assert e.value.code == 'SAP_TEMPLATE' and not s.saved
