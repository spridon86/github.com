"""Configurarea aplicatiei: config.json (din folderul aplicatiei) peste valorile implicite de mai jos.

Cheile environment / username / baseUrls sunt folosite doar in modul Creditsafe API.
Parolele NU se tin aici: Creditsafe -> Windows Credential Manager (keyring).
"""
import copy
import json
import threading

from . import paths

DEFAULTS = {
    'environment': 'sandbox',
    'username': '',
    'password': '',
    'baseUrls': {
        'sandbox': 'https://connect.sandbox.creditsafe.com/v1',
        'production': 'https://connect.creditsafe.com/v1',
    },
    'reportLanguage': 'en',
    'outputFolder': 'output',
    'counterpartiesRoot': '%OneDriveCommercial%\\BUC - TRADING COUNTREPARTIES',

    'analyst': {'initials': 'IS', 'name': 'Ionut Spridon'},

    # Lista clientilor de evaluat + expunerea (fisierul "Open Contracts ITA")
    'portfolio': {
        'path': '%OneDriveCommercial%\\Documents - WSE Credit Control Counterparty database\\Max Exposure Italy\\Open Contracts ITA.xlsx',
        'country': 'IT',
        # Foaie optionala cu lista clientilor de evaluat (coloana "Partner"). Daca lipseste: toti clientii din "Monthly Exposure Italy".
        'evaluationSheet': 'To Evaluate',
        # facturile (un client fara expunere e activ daca a avut facturi in ultimii 2 ani)
        'invoicesPath': '%OneDriveCommercial%\\Documents - WSE Credit Control Counterparty database\\Max Exposure Italy\\All Invoices.XLSX',
    },
    'review': {'invoiceMonths': 24,
               'scorecardMinUsd': 350000,    # sub acest prag (Open + MTM nou, USD) nu se face scorecard
               'mtmPctIfZero': 0.4},         # MTM actual 0 -> MTM nou = 40% din Open limit nou (USD)

    # Excelul cu limite (SharePoint)
    'limitsBook': {
        'url': 'https://bungeltd.sharepoint.com/sites/beu.creditcontrol.buc/Shared Documents/Credit Limits/NWCE Europe Credit limits.xlsx',
        'sheet': 'LIMITS',
        'table': 'Table1',
        'companyCode': '6675 - Italy',
        'validityMonths': 12,          # Valid till = ultima zi a lunii, peste N luni de la aprobare
        'kusdRounding': 10,            # Open limit KUSD rotunjit la multiplu de 10
        'setTbdByDone': False,         # coloana "TBD by" -> "Done" dupa actualizare
        # moneda coloanei "Open limit K loc. curr." pe company code (verificat din raportul KUSD / K loc din NWCE)
        'companyCurrencies': {'6575': 'HUF', '7179': 'RON', '7182': 'RON'},
        # de facut = STATUS "UNDER REVIEW" (formula NWCE: Valid till <= azi + 30 zile) sau limita expirata;
        # APPROVED si valabil mai mult de N zile = nimic de facut, indiferent ce scrie la "TBD by"
        'renewWithinDays': 30,
    },

    'fx': {'eurUsdFallback': 1.12},    # folosit doar daca ECB nu raspunde

    'creditsafe': {
        'mode': 'web',                 # web = user + parola de pe app.creditsafe.com ; api = cont Connect API
        'cacheDays': 30,               # un raport mai nou de N zile se refoloseste (nu consuma credite)
        'downloadPdf': True,
        'parallelDownloads': 4,
        'lowCreditsWarning': 10,
        'alwaysConfirm': False,        # False: fereastra de confirmare doar cand o firma e negasita / ambigua
    },

    # Creditsafe prin website (parola in Windows Credential Manager, nu aici)
    'creditsafeWeb': {
        'username': '',
        'headless': True,              # Edge invizibil; devine vizibil doar daca login-ul cere ceva neasteptat
        'loginTimeout': 180,
        'pdfButtonSelector': '',       # optional: selector CSS al butonului de PDF, daca site-ul se schimba
        'pdfMenuSelector': '',
    },

    'scorecard': {
        'template': 'Scorecard 2026 Protected Large-Med-Small-Commoddity.xlsx',
        'fileName': 'Scorecard {name} {year}.xlsx',
        'financialReporting': 'Average',
        'autoFx': True,                # completeaza cursul USD->EUR lipsa in foaia "Blank 2" (ECB)
        # 14. Country Rating: categoria tarii, cum o cere scorecardul (criteriul din sablon)
        'countryRatings': {
            'DE': 'AAA', 'NL': 'AAA', 'DK': 'AAA', 'SE': 'AAA', 'CH': 'AAA', 'NO': 'AAA', 'LU': 'AAA',
            'AT': 'AA-A', 'FI': 'AA-A', 'BE': 'AA-A', 'FR': 'AA-A', 'GB': 'AA-A', 'IE': 'AA-A', 'CZ': 'AA-A',
            'EE': 'AA-A', 'SI': 'AA-A', 'SK': 'AA-A', 'LT': 'AA-A', 'LV': 'AA-A', 'PL': 'AA-A', 'ES': 'AA-A',
            'PT': 'AA-A', 'MT': 'AA-A', 'HR': 'AA-A', 'CY': 'AA-A',
            'IT': 'BBB', 'GR': 'BBB', 'BG': 'BBB', 'HU': 'BBB', 'RO': 'BBB', 'RS': 'BBB',
            'UA': 'B-CCC',
        },
    },

    # 11. Payments Behavior din foaia "Payment behaviour report" (zile intarziere medii)
    'paymentBehaviour': {
        'maxDaysA': 5,                 # <= 5 zile  -> A "Highly consistent on time"
        'maxDaysB': 15,                # <= 15 zile -> B "Generally consistent on time"
        'maxDaysD': 45,                # <= 45 zile -> D "Delays consistent"; peste -> E
        'minInvoices': 3,              # sub atatea facturi platite -> C "no data"
        'oldestOverdueForD': 90,       # factura restanta mai veche de N zile -> cel putin D
    },

    # 10. Experience with Counterparty (ani de relatie)
    'experience': {'A': 10, 'B': 5, 'C': 2, 'D': 0.5},

    # Propunerea de limita noua (EUR). Analistul o vede detaliat si o poate modifica.
    'limitPolicy': {
        'exposureBuffer': 0.10,        # limita necesara = varful de expunere + 10%
        'useEquityCap': True,          # plafon = X% din capitalurile proprii (Summary: "30% Equity")
        'equityCapPct': 0.30,
        'roundingSteps': [[100000, 5000], [1000000, 10000], [None, 50000]],   # [pana la, pas]
        'gradeWarningFrom': 9,         # grad >= 9: avertisment "risc ridicat - escaladare / garantii"
        'keepCurrentIfHigher': False,  # True: nu propune scaderea limitei existente
    },

    # Matricea de aprobare "Limits by grade" (USD, limita totala: Open + MTM/PFE, pe tot grupul / clientul).
    # Gradul 11 = No Trade. Lantul de aprobare porneste de la randul analistului ('analystRow').
    'approval': {
        'currency': 'USD',
        'analystRow': 'Ionut Spridon',
        'chainAbove': ['Valentina / Bea', 'BEMEA - Aylin', 'GLOBAL - Alex'],
        'matrix': [
            {'name': 'Valentina / Bea', 'nwceLevel': 'LOCAL', 'limits': [10000000, 10000000, 10000000, 10000000, 10000000, 10000000, 7500000, 5000000, 3500000, 3000000, 0]},
            {'name': 'Ionut Spridon', 'nwceLevel': 'LOCAL', 'limits': [5500000, 5500000, 5500000, 5500000, 5500000, 4500000, 3500000, 2500000, 1500000, 1000000, 0]},
            {'name': 'Camelia Pintilii', 'nwceLevel': 'LOCAL', 'limits': [5500000, 5500000, 5500000, 5500000, 5500000, 4500000, 3500000, 2500000, 1500000, 1000000, 0]},
            {'name': 'Ana Gavrila', 'nwceLevel': 'LOCAL', 'limits': [5500000, 5500000, 5500000, 5500000, 5500000, 4500000, 3500000, 2500000, 1500000, 1000000, 0]},
            {'name': 'BEMEA - Aylin', 'nwceLevel': 'BEMEA', 'limits': [75000000, 75000000, 75000000, 50000000, 30000000, 20000000, 15000000, 10000000, 7000000, 5000000, 0]},
            {'name': 'GLOBAL - Alex', 'nwceLevel': 'GLOBAL', 'limits': [100000000, 100000000, 100000000, 90000000, 75000000, 60000000, 45000000, 30000000, 20000000, 15000000, 0]},
        ],
    },

    # Grupuri de firme (coloana "Group of companies" din NWCE): valori care NU sunt grupuri
    'groups': {'notGroups': ['', 'N/A', 'NA', '0', '-', 'CBT', 'WAREHOUSE', 'NO TRADE', 'NONE']},

    'sap': {
        'template': 'sap_templates/limit_update.json',
        'systemName': '',              # ex. "P01" - gol = prima sesiune SAP deschisa
        'dateFormat': '%d.%m.%Y',
        'transaction': 'ZBEU_UKM_BP_CREDIT_L',
        'autoSubmit': True,            # SAP in fundal dupa NWCE ...
        'verified': False,             # ... dar doar dupa prima trimitere reala reusita (setat automat)
        'segment': 'ZIT1_LIMIT',       # segmentul de credit din ZBEU_UKM_BP_CREDIT_L pentru compania configurata
        'amountFormat': 'plain',       # plain = 800000 ; dot = 800.000 ; comma = 800,000
        # decizii peste autoritatea analistului, aprobate pe alt canal (manager / EMEA / global): bifa "Transcrie in SAP"
        # pornita implicit? In SAP modificarea porneste din nou workflow-ul de aprobare - implicit NU.
        'afterExternalApproval': False,
    },
}


# aprobatori redenumiti in matricea "Limits by grade" (config.json-urile vechi se actualizeaza la incarcare)
_APPROVER_RENAMES = {'GLOBAL': 'GLOBAL - Alex'}


def _migrate(user):
    a = user.get('approval') if isinstance(user, dict) else None
    if not isinstance(a, dict):
        return
    for k in ('externalRatingToGrade', 'subsidiaryNotches'):       # ratingurile externe ale agentiilor nu se mai folosesc
        a.pop(k, None)
    if isinstance(a.get('chainAbove'), list):
        a['chainAbove'] = [_APPROVER_RENAMES.get(n, n) for n in a['chainAbove']]
    for row in a.get('matrix') or []:
        if isinstance(row, dict) and row.get('name') in _APPROVER_RENAMES:
            row['name'] = _APPROVER_RENAMES[row['name']]


def _merge(base, override):
    out = copy.deepcopy(base)
    for k, v in (override or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _merge(out[k], v)
        else:
            out[k] = v
    return out


class Config:
    """Acces la configurare: cfg['limitsBook']['url'] sau cfg.get('limitsBook', 'url')."""

    _lock = threading.Lock()

    def __init__(self, data):
        self.data = data

    @classmethod
    def load(cls, path=None):
        path = path or paths.CONFIG_FILE
        user = {}
        if path.exists():
            with open(path, encoding='utf-8-sig') as f:
                user = json.load(f)
        _migrate(user)
        return cls(_merge(DEFAULTS, user))

    def __getitem__(self, key):
        return self.data[key]

    def get(self, *keys, default=None):
        d = self.data
        for k in keys:
            if not isinstance(d, dict) or k not in d:
                return default
            d = d[k]
        return d

    def set(self, value, *keys):
        d = self.data
        for k in keys[:-1]:
            d = d.setdefault(k, {})
        d[keys[-1]] = value

    def save(self, path=None):
        """Scrie configurarea completa (valorile implicite devin vizibile si editabile in config.json)."""
        path = path or paths.CONFIG_FILE
        with self._lock:
            tmp = path.with_suffix('.json.tmp')
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump(self.data, f, indent=2, ensure_ascii=False)
            tmp.replace(path)

    # --- scurtaturi
    @property
    def cs_base_url(self):
        return self.data['baseUrls'][self.data['environment']]

    @property
    def counterparties_root(self):
        return paths.expand(self.data['counterpartiesRoot'])

    @property
    def portfolio_path(self):
        return paths.expand(self.get('portfolio', 'path'))

    @property
    def template_path(self):
        p = paths.expand(self.get('scorecard', 'template'))
        from pathlib import Path
        p = Path(p)
        return p if p.is_absolute() else paths.APP_ROOT / p
