# Credit Limits Tool (v2)

Evaluarea clienților dintr-un singur loc: **scorecard**, **raport Creditsafe (PDF)** și **actualizarea limitelor în NWCE și SAP**.
Rulează doar pe acest calculator (Python din Anaconda). Nimic nu pleacă în afară, în afară de cererile către Creditsafe, BCE și SharePoint/SAP-ul Bunge.

Pornire: dublu-click pe **`Start-CreditTool.cmd`**.

## Ecranul principal (varianta A)

- **Sus:** „Credit Limits”, **căutarea** (caută în toți clienții, inclusiv listele colegilor; click pe o filă revine la filă) și indicatorii **Creditsafe** / **NWCE** (verde = OK; click = parolă / recitire NWCE). EUR/USD e jos, în bara de stare.
- **Meniul de sus:** Date · **Listă** (lista ta „TBD by”, a colegilor sau toți clienții din Italia) · **Filtre** (peste limită, blocați / inactivi, vânzări, BU, *Arată toate coloanele* ca în excelul NWCE) · SAP · Setări · Ajutor (F1).
- **Patru file**, fiecare cu numărul de clienți: **De revizuit** → **În lucru** → **La aprobare** → **Gata**.
- **Tabelul** are 6 coloane: ☐ · Client · Limită acum · Propus (sau Valabil până) · Grade · **Pasul următor** (etichetă colorată: verde = „Aprobi tu” / „Gata”, galben = „Aprobă BEMEA - Aylin” / „Expiră …”, roșu = „Alege criteriul Plăți” / eroare, albastru = „Se scrie în NWCE…”). Grupurile / aceeași firmă pe mai multe țări apar împreună (`↳ … · companie`). Click pe antetul ☐ = bifează tot ce se vede.
- **În dreapta:** clientul selectat, în propoziții — limită acum, vârf expunere, propunere, 30% din equity, plăți, valabil până, grade, cine aprobă și o frază despre ce urmează. În **În lucru** tot aici modifici: Open nou, MTM nou, Valabil până, Grade (doar fără scorecard) și criteriile 9 / 10 / 11 (cu scorecard, Excel recalculează gradul pe loc). „Propus” și „Grade” se pot modifica și cu dublu-click în tabel. Se salvează doar ce schimbi. **Toate detaliile…** deschide pagina completă, graficul de expunere și istoricul.
- **Jos:** câți sunt bifați și **un singur buton verde** pentru fila curentă:
  - **De revizuit** (și căutarea): *Revizuiește bifații* — expunere → activ? → Creditsafe + scorecard → limita nouă → cine aprobă.
  - **În lucru**: *Trimite bifații în NWCE + SAP* — în autoritatea ta se scriu în NWCE și SAP; peste, merg la „La aprobare” (Annual Review). Lângă el: **Evaluează din nou** — clienții bifați ies din „În lucru” și revin bifați în „De revizuit”; la următoarea revizuire: raport Creditsafe nou și scorecard refăcut (îl înlocuiește pe cel vechi; dacă cel vechi e deschis în Excel, cel nou se salvează alături, cu „(2)”). Nu merge după ce decizia a fost scrisă în NWCE / trimisă în SAP.
  - **La aprobare**: *Am primit aprobarea* — cine a aprobat, data, comentariu NWCE opțional și bifa **Transcrie și în SAP**:
    - nebifat (implicit): decizia se scrie doar în NWCE (nivelul de aprobare al celui care a aprobat), clientul trece în **Gata** cu „doar NWCE” — aprobarea e deja dată, iar în SAP modificarea ar porni din nou workflow-ul de aprobare;
    - bifat: după NWCE se trimite și în SAP, ca la deciziile din autoritatea ta.
    - Alegerea se poate schimba din click-dreapta cât timp decizia nu a plecat în SAP („SAP: nu transcrie” / „SAP: transcrie totuși”). Bifa implicită: Setări → SAP. Aceeași întrebare apare la „Evaluare grup / Annual Review” când decizia e peste autoritatea ta.
  - **Gata**: scrise în NWCE (și SAP); fără buton.
- Inactivările se scriu automat în NWCE.
- **Mesajele** sunt scurte: ce s-a întâmplat și, dacă e cazul, ce ai de făcut. Detaliile tehnice sunt la „Show Details” în fereastra de eroare.
- **Click-dreapta pe client:** evaluare grup / Annual Review, deschide decizia, folder, scorecard, PDF, anulare, inactivare.
- Ce e de făcut decid **STATUS** și **Valid till** din NWCE (UNDER REVIEW / expirat = de făcut), nu „TBD by”.

## Documente client (tool separat)

Pornire: dublu-click pe **`Start-Documente.cmd`**. Face un singur lucru: pentru clienții aleși din NWCE generează **raportul Creditsafe (PDF)** și **scorecardul** și le pune în folderul fiecărui client (`BUC - TRADING COUNTREPARTIES\<Client>\<an>`, inclusiv în folderele de grup „GRUPPO …”); la cerere, și **Annual Review-ul de reînnoire** (Word). Nu scrie în NWCE / SAP, nu propune limite, nu cere aprobări.

- **Sus:** căutare, **lista** (lista ta „TBD by”, toți clienții din NWCE sau lista unui coleg) și indicatorul NWCE (click = recitește de pe SharePoint).
- **Tabelul:** o linie pe firmă (toate companiile / țările ei adunate după VAT): Client · VAT · Companii · Grade (NWCE / Nou) · **Subiective** (9. Fin. reporting · 10. Experience · 11. Payments) · Valabil până · TBD by · **Rezultat**. Cei bifați rămân vizibili când schimbi lista sau cauți. Inactivii / CBT sunt ascunși (bifa „Arată și inactivii / CBT”).
- **Jos:** bifezi clienții → **Generează PDF + scorecard**. Creditsafe: doar firmele Registered (ca în Credit Limits); fereastra de alegere apare doar dacă o firmă nu e găsită sau nu are VAT. **Raport Creditsafe nou**: bifat = raport nou chiar dacă există unul din ultimele 30 de zile; nebifat = se refolosește.
- **Subiectivele, ca în Credit Limits:** dublu-click pe celulă → alegi din listă → valoarea se scrie în scorecardul clientului, Excel recalculează și „Grade Nou” se schimbă pe loc (fișierul se salvează). Galben + „?” = propus de tool, de confirmat; albastru = ales de tine. Se pot schimba doar unde există scorecard și nu în timpul generării. Dacă scorecardul e deschis în Excel sau Excel nu răspunde, alegerea nu se salvează și criteriul rămâne cel de dinainte. Alegerile tale rămân și la o nouă generare (scorecardul nou le primește). Dacă exista deja Annual Review-ul, „Rezultat” arată „Annual Review de refăcut” → click-dreapta → **Refă Annual Review** (din scorecardul actual, fără raport / scorecard nou).
- La pornire se văd documentele făcute deja (din `data\documente.db`, cu data lor dacă nu sunt de azi), ca să poți schimba subiectivele și a doua zi.
- **Scorecardul** se face mereu (și sub pragul de 350.000 USD) și **îl înlocuiește** pe cel vechi cu același nume (fără „(2)”; dacă cel vechi e deschis în Excel, cel nou se salvează alături). Criteriile 10 / 11 vin din folderul clientului și din Open Contracts ITA, ca în Credit Limits.
- **Annual Review (Word)** (bifa de jos): după PDF + scorecard se face și Annual Review-ul de reînnoire, ca modelul aprobat: limitele noi = **limitele actuale din NWCE** pe toate companiile firmei (fără inactive / CBT / NO TRADE), „maintaining the existing credit limit for the next 12 months”; gradul din scorecardul nou (sau din NWCE, dacă nu s-a putut face scorecard); cine aprobă, din matricea „Limits by grade”; relația cu Bunge, cifra de afaceri (All Invoices) și printscreen-ul din „Summary”. Se salvează în același folder și înlocuiește documentul cu același nume (dacă e deschis în Word, cel nou se salvează alături). Clienții cu eroare la Creditsafe sunt săriți; o eroare la un Annual Review nu le oprește pe celelalte. Credit Limits folosește același cod pentru Annual Review.
- **Rezultat:** „Gata · PDF + scorecard + Annual Review (grade 8)”, „Doar PDF · Creditsafe fără bilanț” sau eroarea. Dublu-click / click-dreapta: folderul, scorecardul, PDF-ul, Annual Review-ul.
- Jurnalul e separat (`data\documente.db`): clienții de aici nu apar „în lucru” în Credit Limits. Cele două aplicații pot fi deschise în același timp.

## Revizuirea lunară (fila „De revizuit” → „Revizuiește bifații”)

Revizuirea pornește **doar pe clienții bifați**: cei aprobați de alte echipe din Europa (ex. CARGILL) rămân nebifați. Fără bife butonul e inactiv. Pe celelalte file, butonul lucrează pe clienții bifați, iar dacă nu e bifat niciunul, pe toată fila.

Fiecare pas are coloana lui cu rezultatul (după coloanele din excelul NWCE):

1. **Expiră luna aceasta**: Valid till ≤ sfârșitul lunii curente (fără INACTIVE / CBT / NO TRADE / TSF).
2. **Vârf de expunere**: cea mai mare expunere săptămânală din Open Contracts ITA (doar Italia), **de săptămâna viitoare până la ultima săptămână din fișier**. Săptămâna curentă și cele trecute nu contează. Fără date săptămânale se folosesc lunile de după luna curentă. Aceeași regulă se aplică și vârfului din graficul „Expunere”.
3. **Activ?** Are expunere → activ. Dacă nu are, se verifică facturile din ultimii 2 ani în `All Invoices.XLSX` (după Customer Code, apoi VAT). Fără niciuna → fila **De inactivat**. Dacă fișierul de facturi nu se poate citi, e gol sau nu are nicio factură din ultimele 90 de zile (neactualizat), **nu se inactivează nimic automat**: activitatea nu se poate verifica.
4. **Creditsafe + scorecard** → coloana **Grade nou**. Scorecardul se face **doar dacă limita nouă Open + MTM este de cel puțin 350.000 USD** (`review.scorecardMinUsd` în `config.json`). Sub prag, raportul Creditsafe (PDF) se salvează, se păstrează gradul din NWCE (afișat „6 (NWCE, sub 350k USD, fara scorecard)”) și clientul merge direct la pasul 5. Dacă Creditsafe **nu are bilanț** (persoane fizice, ferme, firme noi), scorecardul se sare: se păstrează gradul din NWCE (afișat „6 (NWCE, fara bilant)”) și clientul merge direct la pasul 5. Criteriile pe care nu le pot decide (plăți fără istoric, experiență fără urmă) apar în coloanele **De completat** (fin. / exp. / plăți); le alegi din listă și **Recalculează** refolosește raportul din cache, fără credite.
5. **Limita nouă** = Open (expunerea rotunjită dacă e peste limita actuală, altfel limita actuală) + MTM, în USD, pe tot clientul / grupul → comparată cu matricea „Limits by grade”.
   - **În autoritatea ta** → decizie aprobată automat → fila **De scris în NWCE**, apoi **În SAP**; scorecardul e salvat în folderul clientului.
   - **Peste** → **Annual Review** (Word; la Financials, printscreen din foaia „Summary” a scorecardului: antetul și Income Statement USD până la Tangible Net Worth) generat automat în folderul clientului, lângă scorecard și PDF-ul Creditsafe → fila **Nivel superior** (altă cale de aprobare).
**Anulează** (click-dreapta pe client sau pe clienții bifați): ce a plecat mai departe fără voia ta (decizie aprobată automat, Annual Review, „De inactivat”, „De completat”) revine în „Luna aceasta”. Fișierele generate rămân în folderul clientului. Ce s-a scris deja în NWCE sau s-a trimis în SAP nu se anulează automat: tool-ul îți spune ce e de refăcut manual (valorile vechi sunt în Date → Istoric modificări).

6. **Equity Scenario** = DA dacă limita totală USD depășește equity-ul clientului din scorecard (se bifează și în SAP).

## Fluxul de lucru

| Pas | Buton | Ce face |
|---|---|---|
| 0 | (automat la pornire) | Citește **Open Contracts ITA.xlsx** (expunere lunară/săptămânală, plăți, VAT, limite), **NWCE** (din cache 12 h sau SharePoint), cursul **BCE**, creditele Creditsafe rămase. |
| 1 | **Evaluează** | Pentru clienții bifați: VAT → căutare Creditsafe (**gratuită**) → fereastră de confirmare (firma găsită, ce vine din cache, câte credite se consumă) → raport JSON + PDF → folderul clientului `BUC - TRADING COUNTREPARTIES\<Client>\<an>` → PDF cu numele din portal → **scorecard** completat și calculat de Excel → **propunere de limită**. |
| 2 | **Decizie limită** (sau dublu-click) | Tot ce știm despre client + propunerea explicată pas cu pas. Editezi limita (EUR), KUSD / K EUR (calculate automat), MTM, payment term, grading, approval level, valid till, ce câmpuri se scriu în NWCE. Poți schimba criteriile subiective și **regenera scorecardul din cache (fără credite)**. |
| 3 | **Scrie în NWCE** | Listă de confirmare (acum → nou) → un singur salvat pe SharePoint → fișierul se redeschide și valorile se **verifică**. Dacă altcineva a modificat rândul între timp, clientul respectiv **nu** se scrie. |
| 4a | **SAP – probă** | Rulează pașii înregistrați până la Save, citește câmpurile și iese cu `/n` **fără salvare**. |
| 4b | **SAP – salvează** | Salvează limita și data de valabilitate; valoarea veche e citită înainte, cea nouă verificată după; capturi de ecran în folderul clientului. Orice ecran / popup / mesaj de eroare neașteptat oprește rularea **înainte** de Save. |

Tabelul principal: filtre (peste limită, lista „To Evaluate”, BU, stare, blocați), sortare pe orice coloană, culori (vârf/limită, risc de plată, grad), grafic expunere vs. limită curentă / propusă, jurnal pe client. **Space** bifează rândurile selectate, **Ctrl+F** caută.

## Lista „TBD by” și clienții pe mai multe țări

- Dropdown-ul **TBD by** (bara de filtre) arată lista fiecărui analist din coloana „TBD by” a excelului NWCE — implicit inițialele tale (Setări → General). Se recunosc și formele scurte („MD”, „AR”). „Toți (Open Contracts ITA)” = vizualizarea pe expunerea din Italia.
- Un client prezent pe **mai multe companii / țări** (aceeași firmă = același VAT, altfel același Customer Code) apare cu **toate rândurile** din NWCE, grupate: primul rând e clientul, dedesubt `↳` celelalte țări. Coloana **Total client KUSD** adună limitele de pe toate companiile; **Țări** = câte companii. Rândurile CBT / NO TRADE nu se adaugă (nu sunt limite).
- Expunerea din **Open Contracts ITA se aplică doar rândului de Italia**. Pentru celelalte țări propunerea păstrează limita curentă; plățile și istoricul din Italia se folosesc pentru aceeași firmă (scorecardul e unul singur per client, raportul Creditsafe se deschide o singură dată).
- Moneda limitei: Ungaria (6575) HUF, România (7179 / 7182) RON, restul EUR — `Open limit KUSD` se calculează cu cursul BCE al monedei respective. Se scrie în NWCE pe rândul exact al companiei.
- SAP: înregistrarea e pentru compania din Setări (6675 - Italy); deciziile pe alte companii se actualizează manual în SAP (tool-ul le listează).

## Grupuri de firme — o singură evaluare pe tot grupul

- Firmele cu același **„Group of companies”** în NWCE (ENI, Mondelez, Schwarz…; scrierile diferite „Nestle”/„NESTLE”, „REWE - bill to” sunt unificate) apar împreună în tabel; coloana **Grup** și **Total grup KUSD** adună limitele tuturor membrilor, pe toate țările.
- Butonul **Evaluare grup / Annual Review**: toți membrii pe rânduri de limită, **un singur grade** pe grup (din scorecardul unui membru sau manual), limite noi (Open + MTM, USD) editabile, totalul grupului și **cine aprobă** conform matricei „Limits by grade” (grade vs limita totală). „Aprobă decizia de grup” creează deciziile pentru toți membrii (grading, KUSD, K moneda locală, approval level, valid till) → **3. Scrie în NWCE** le scrie dintr-o singură salvare.
- **Annual Review (Word)**: draft în formatul folosit (tabel limite actuale / noi, overview, relația cu Bunge, financiare = printscreen din scorecard, concluzie), salvat în folderul grupului / clientului `<an>`; textele de completat sunt marcate `[de completat]`.
- Fereastra are trei aranjări (Setări → General → „Fereastra evaluare grup”): **Clasic** (totul pe un ecran), **Pe pași** (1 grade, 2 limite, 3 cine aprobă, 4 decizie), **Simplu** (rezumat sus, restul la „Mai multe opțiuni”).
- Matricea de aprobare e în `config.json` (`approval`). Pentru un singur client, fereastra de decizie arată tot „Cine aprobă”, calculat pe totalul grupului / clientului.

## Inactivarea clienților

- Rândurile cu **STATUS = INACTIVE** în NWCE apar „Inactiv (NWCE)”, gri, și sunt ascunse implicit („Ascunde blocați / inactivi”); nu intră în numărul din dropdown-ul TBD.
- **Inactivează...** (rândurile bifate / selectate), bifa „Inactivează clientul” din fereastra de decizie sau limită nouă 0 în evaluarea de grup → la **3. Scrie în NWCE**: 0 în Payment Term și în toate coloanele de limită (Open KUSD, K loc., MTM, tone oilseeds / grains, Max months, storage, transfer bond), **Approved on / Valid till goale** (cu 0 în Valid till formula STATUS ar da „UNDER REVIEW”; verificat pe cele 55 de rânduri INACTIVE existente). „Total limit KUSD” e formulă și devine singur 0. După salvare se verifică STATUS = INACTIVE. SAP nu se modifică — managerul trimite lunar inactivările.

## Criteriile scorecardului completate automat

| Criteriu | Sursa |
|---|---|
| Date financiare (Blank 1), 4 ani | Creditsafe Global Financials |
| Curs USD→EUR lipsă în „Blank 2” | BCE, adăugat automat pentru datele bilanțurilor |
| 9. Financial Reporting | implicit *Average* (Setări) |
| 10. Experience | cea mai veche urmă a relației: folderul clientului (ani / fișiere), primul contract deschis, prima plată |
| 11. Payments Behavior | „Payment behaviour report”: întârziere medie (A ≤5 z, B ≤15, D ≤45, E peste; C fără date), restanțe > 90 z / plăți returnate → cel puțin D |
| 12. Age of Company, 13. Credit Bureau | Creditsafe |
| 14. Country Rating | tabel pe țări în `config.json` (criteriul din scorecard) |
| SAP Number | Customer Code |

Toate propunerile se văd cu explicația lor și se pot schimba în fereastra de decizie.

## Propunerea de limită (configurabilă în Setări → Reguli)

`necesar = vârf de expunere (Weekly Exposure) + 10%`, rotunjit în sus (5k sub 100k, 10k sub 1M, 50k peste),
plafonat la **30% din capitalurile proprii** (rândul „30% Equity” din scorecard), rotunjit în jos sub plafon.
Avertismente: grad ≥ 9, equity negativ, propunere peste limita Creditsafe, diferența neacoperită de plafon.
**Este o propunere** — decizia e a analistului.

NWCE: `Open limit K loc. curr.` = limită / 1000; `Open limit KUSD` = K EUR × curs BCE rotunjit la 10; `Valid till` = ultima zi a lunii peste 12 luni (regula din fișier).

## SAP — configurare o singură dată

1. SAP → *Customize Local Layout* (Alt+F12) → *Script Recording and Playback* → Record.
2. Fă o actualizare reală pentru un client în **ZBEU_UKM_BP_CREDIT_L** (Modify BP Credit Limit): F4 pe BP → caută după **Customer** → Score, Validity Score, (Equity Scenario dacă e cazul) → în grilă **Open Limit** și **MTM & PFE limit** + data pe segmentul ZIT1_LIMIT → **rotița dințată** (sus-stânga) → Approve → comentariu ✓ → atașamente ✓ → „SCase Created” ✓.
3. În aplicație: **SAP → Import înregistrare** → fișierul `.vbs`, Customer Code-ul, limita, MTM-ul, data, scorul, bifa Equity și comentariul **exact cum le-ai tastat** → Analizează → Salvează.
4. Rulează întâi **SAP – probă** pe un client: completează tot și se oprește **înainte de rotiță**, apoi iese cu `/n`.

Ce face aplicația la fiecare client:
- Rândurile **Open Limit** / **MTM & PFE limit** din grilă se caută după Segment (`sap.segment`, implicit ZIT1_LIMIT) + Info Type Text, nu după poziția din înregistrare; dacă nu le găsește, se oprește înainte de rotiță.
- Valorile vechi din grilă sunt citite înainte de modificare (în istoric).
- Numărul cazului din popup-ul „SCase Created” apare în coloana SAP și în jurnal.
- După rotiță, modificarea devine un caz de aprobare, așa că ecranul poate arăta încă valorile vechi. Dacă ceva eșuează după rotiță, mesajul spune explicit că cererea poate fi deja trimisă, coloana SAP arată „⚠ trimis? verifica” și clientul **nu se mai retrimite** (nici manual, nici automat), ca să nu apară un caz dublu. Verifici în SAP, apoi click-dreapta pe client: **SAP: confirmă trimiterea** (cazul există) sau **SAP: permite retrimiterea** (cazul nu există).
- Confirmările de după rotiță (comentariu / atașamente / SCase) care nu mai apar nu sunt o eroare: SAP nu le arată mereu pe toate.

Dacă apare „SAP GUI Scripting este dezactivat”: Alt+F12 → Options → Accessibility & Scripting → Scripting → *Enable scripting* (și debifează notificările). Dacă e blocat pe server, cere activarea `sapgui/user_scripting` la SAP Basis.

> În NWCE, **BP code ≠ Customer Code** (ex. MIRA SUD: BP 76014759, Customer 76021671). UKM_BP lucrează cu BP-ul — aplicația îl ia din NWCE.

## Creditsafe

- Conectarea se face prin **app.creditsafe.com cu userul și parola ta de pe site** (Setări → „Conectare Creditsafe”; contul Connect API rămâne opțional).
  Tool-ul pornește un Edge separat, invizibil (sesiune curată la fiecare pornire), se loghează singur
  (~20 s la prima operație), caută după VAT și deschide raportul **exact ca manual** (pagina firmei → date pentru scorecard → buton PDF).
  Dacă login-ul cere ceva neprevăzut, fereastra Edge devine vizibilă și îl termini tu. La erori, captura paginii e în `data\logs\creditsafe_web`.
- Parola e în Windows Credential Manager. Schimbare: **Parola Creditsafe**.
- Rapoartele descărcate se păstrează în `%LOCALAPPDATA%\CreditLimitsApp\reports` și se refolosesc 30 de zile — **regenerarea unui scorecard nu consumă credite**.
- Creditele rămase se văd sus, în bara de instrumente.

## Unde sunt datele

| | |
|---|---|
| `config.json` | toate setările (editabile și din **Setări**) |
| `data\creditlimits.db` | audit: fiecare evaluare, fiecare pas, fiecare modificare NWCE/SAP (vechi → nou). Buton **Istoric modificări**. |
| `data\logs\app.log` | jurnal tehnic |
| `output\Rezumat_evaluari_*.xlsx` | **Export rezumat Excel** |
| `sap_templates\limit_update.json` | șablonul SAP (versiunile vechi se păstrează cu dată) |

## Pentru dezvoltare

```
cd C:\Projects\CreditLimitsApp
%LOCALAPPDATA%\anaconda3\python.exe -m pytest tests      # 178 teste, fără rețea / Excel / SAP
%LOCALAPPDATA%\anaconda3\python.exe -m creditapp         # pornire cu consolă (erorile se văd)
```

Module (`creditapp\`): `portfolio` (Open Contracts), `creditsafe`, `mapping`, `scorecard` (Excel COM), `rules` (propuneri), `limits_book` (NWCE), `sap_gui`, `client_folders`, `pipeline` (fluxul), `audit`, `ui\`.

