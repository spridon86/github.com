"""Componente vizuale: carduri de pas, indicatori de stare, etichete colorate in tabel, ghidul rapid."""
from PyQt5.QtCore import QRectF, QSize, Qt, pyqtSignal
from PyQt5.QtGui import QBrush, QColor, QFont, QPainter, QPen
from PyQt5.QtWidgets import (QDialog, QDialogButtonBox, QFrame, QHBoxLayout, QHeaderView, QLabel, QPushButton, QStyle,
                             QStyledItemDelegate, QTextBrowser, QVBoxLayout)

# paleta variantei A (aceeasi ca in macheta aprobata): fundal, suprafata, text, gri, linii, accent + stari
P = {'bg': '#F3F5F8', 'surface': '#FFFFFF', 'ink': '#17212C', 'muted': '#5A6776', 'line': '#D9E1EA', 'chrome': '#E9EDF2',
     'accent': '#1F5C99', 'accent_soft': '#E6EFF8', 'ok': '#2E7D32', 'ok_soft': '#E5F3E6', 'warn': '#A35F00',
     'warn_soft': '#FBF0DC', 'bad': '#B3261E', 'bad_soft': '#FBE6E4'}
FONT = 'Segoe UI'           # macheta: IBM Plex Sans / Archivo (neinstalate pe calculator) -> fontul de rezerva din macheta
# eticheta colorata (nivel -> fundal, text): "Aprobi tu" verde, "Aproba BEMEA" galben, "Alege criteriul" rosu, in curs albastru
CHIP_COLORS = {'ok': (P['ok_soft'], P['ok']), 'warn': (P['warn_soft'], P['warn']), 'bad': (P['bad_soft'], P['bad']),
               'info': (P['accent_soft'], P['accent']), 'grey': ('#EEF1F5', P['muted'])}
ACCENT = P['accent']
APP_STYLE = """
* { font-family: "%(font)s"; }
QMainWindow, QWidget#central { background: %(bg)s; color: %(ink)s; }
QMenuBar { background: %(surface)s; border-bottom: 1px solid %(line)s; }
QFrame#card { background: %(surface)s; border: 1px solid %(line)s; border-radius: 8px; }
QFrame#appbar, QFrame#footbar { background: %(surface)s; border: 1px solid %(line)s; }
QFrame#appbar { border-top-left-radius: 10px; border-top-right-radius: 10px; border-bottom: none; }
QFrame#footbar { border-bottom-left-radius: 10px; border-bottom-right-radius: 10px; border-top: 1px solid %(line)s; }
QFrame#side { background: %(bg)s; border: none; border-left: 1px solid %(line)s; border-right: 1px solid %(line)s; }
QFrame#tabwrap { background: %(surface)s; border: 1px solid %(line)s; border-top: none; }
QSplitter::handle { background: %(line)s; }
QLabel#title { font-size: 12pt; font-weight: bold; color: %(ink)s; }
QLabel#sideTitle { font-size: 11pt; font-weight: bold; color: %(ink)s; }
QLabel#hint { font-size: 9pt; color: %(accent)s; background: %(accent_soft)s; border-radius: 6px; padding: 6px 10px; }
QLabel#clientName { font-size: 13pt; font-weight: bold; color: %(ink)s; }
QLabel#muted { color: %(muted)s; }
QTableView { background: %(surface)s; border: 1px solid %(line)s; border-top: none; border-bottom: none;
             gridline-color: %(line)s; selection-background-color: %(accent_soft)s; selection-color: %(ink)s; outline: none; }
QTableView::item { border-bottom: 1px solid %(line)s; padding: 0 6px; }
QHeaderView::section { background: %(bg)s; border: none; border-bottom: 1px solid %(line)s;
                       padding: 4px 8px; font-weight: 600; color: %(muted)s; }
QPushButton { padding: 4px 11px; border: 1px solid %(line)s; border-radius: 6px; background: %(surface)s; color: %(ink)s; }
QPushButton:hover { background: %(accent_soft)s; }
QPushButton:disabled { color: #A0A8B0; background: #F5F6F8; }
QPushButton#primary { background: %(ok)s; color: white; border: 1px solid %(ok)s; font-weight: 600; padding: 6px 14px; font-size: 9.5pt; }
QPushButton#primary:hover { background: #276B2B; }
QPushButton#primary:disabled { background: #A9CDAB; border-color: #A9CDAB; }
QPushButton#danger { color: %(bad)s; }
QComboBox, QLineEdit, QSpinBox, QDoubleSpinBox, QDateEdit { padding: 3px 6px; border: 1px solid %(line)s; border-radius: 6px; background: %(surface)s; }
QLineEdit#search { padding: 5px 10px; color: %(ink)s; }
QComboBox QAbstractItemView { background: %(surface)s; color: %(ink)s; selection-background-color: %(accent_soft)s;
                              selection-color: %(ink)s; outline: none; padding: 2px; }
QComboBox QAbstractItemView::item { min-height: 18px; padding: 2px 6px; }
QCheckBox { spacing: 6px; }
QTabWidget::pane { border: 1px solid %(line)s; border-radius: 6px; background: %(surface)s; }
QTabBar#steps { background: %(surface)s; }
QTabBar#steps::tab { padding: 8px 16px; color: %(muted)s; background: %(surface)s; border: none; border-bottom: 2px solid transparent; }
QTabBar#steps::tab:selected { color: %(accent)s; border-bottom: 2px solid %(accent)s; }
QTabBar#steps::tab:hover:!selected { color: %(ink)s; }
QStatusBar { background: %(surface)s; border-top: 1px solid %(line)s; }
""" % dict(P, font=FONT)

STATE_COLORS = {      # textul starii -> (fundal, text)
    'De evaluat': ('#E3ECF7', '#0B3C5D'), 'Evaluat': ('#C6EFCE', '#1B5E20'), 'Evaluat - fara bilant': ('#FFEB9C', '#7A5200'),
    'Eroare': ('#FFC7CE', '#9C0006'), 'Finalizat (NWCE + SAP)': ('#2E7D32', '#FFFFFF'), 'Inactiv (NWCE)': ('#ECEFF1', '#78909C'),
    'Inactivat in NWCE': ('#CFD8DC', '#37474F'), 'Valabil': ('#E8F5E9', '#1B5E20'), 'De reinnoit': ('#FFE0B2', '#8A4B00'),
}


class GroupHeader(QHeaderView):
    """Antet pe doua randuri: coloanele cu eticheta "Grup|Sub" (ex. "Open limit|Veche", "Open limit|Noua") au sus
    numele grupului, intins peste coloanele vecine din acelasi grup, si dedesubt sub-eticheta. Restul: eticheta pe toata inaltimea."""

    def __init__(self, labels, parent=None):
        super().__init__(Qt.Horizontal, parent)
        self.labels = list(labels)
        self.two_rows = True            # False cand nicio coloana vizibila nu are "Grup|Sub" (antet pe un rand)
        self.setSectionsClickable(True)
        self.setHighlightSections(False)

    def _split(self, logical):
        txt = self.labels[logical] if 0 <= logical < len(self.labels) else ''
        return txt.split('|', 1) if '|' in txt else (None, txt)

    def sizeHint(self):
        s = super().sizeHint()
        s.setHeight(self.fontMetrics().height() * (2 if self.two_rows else 1) + (8 if self.two_rows else 14))
        return s

    def _group_rect(self, logical, rect):
        """Dreptunghiul intregului grup (coloanele vizibile vecine cu acelasi nume de grup)."""
        grp = self._split(logical)[0]
        vis = self.visualIndex(logical)
        left = right = vis
        while left > 0:
            lg = self.logicalIndex(left - 1)
            if self.isSectionHidden(lg) or self._split(lg)[0] != grp:
                break
            left -= 1
        while right < self.count() - 1:
            lg = self.logicalIndex(right + 1)
            if self.isSectionHidden(lg) or self._split(lg)[0] != grp:
                break
            right += 1
        x0 = self.sectionViewportPosition(self.logicalIndex(left))
        x1 = self.sectionViewportPosition(self.logicalIndex(right)) + self.sectionSize(self.logicalIndex(right))
        return rect.adjusted(x0 - rect.left(), 0, x1 - rect.right() - 1, 0)

    def paintSection(self, painter, rect, logical):
        if not rect.isValid():
            return
        painter.save()
        grp, sub = self._split(logical)
        painter.fillRect(rect, QColor(P['bg']))
        pen = QPen(QColor(P['line']))
        painter.setPen(pen)
        if grp:
            painter.drawLine(rect.topRight(), rect.topRight())
        painter.drawLine(rect.bottomLeft(), rect.bottomRight())
        f = QFont(self.font())
        f.setBold(True)
        painter.setFont(f)
        painter.setPen(QColor(P['muted']))
        if grp:
            half = rect.height() // 2
            top = rect.adjusted(0, 0, 0, -(rect.height() - half))
            bottom = rect.adjusted(0, half, 0, 0)
            g = self._group_rect(logical, top)
            painter.setClipRect(top)
            painter.fillRect(top, QColor('#E8EEF5'))
            painter.drawText(g.adjusted(4, 0, -4, 0), Qt.AlignCenter, grp)
            painter.setPen(pen)
            painter.drawLine(top.bottomLeft(), top.bottomRight())
            if g.right() <= rect.right() + 1:          # marginea grupului
                painter.drawLine(rect.topRight(), rect.bottomRight())
            painter.setClipping(False)
            painter.setPen(QColor('#33404D') if not sub.startswith('No') else QColor('#1B5E20'))
            painter.drawText(bottom.adjusted(4, 0, -4, 0), Qt.AlignCenter, sub)
            painter.setPen(pen)
            painter.drawLine(bottom.topRight(), bottom.bottomRight())
        else:
            align = Qt.AlignRight if sub in RIGHT_HEADERS else Qt.AlignLeft
            painter.drawText(rect.adjusted(8, 2, -8, -2), align | Qt.AlignVCenter | Qt.TextWordWrap, sub)
        painter.restore()


RIGHT_HEADERS = {'Limită acum', 'Propus'}         # sumele: antetul aliniat la dreapta, ca valorile


def state_colors(text):
    if not text:
        return None
    if text in STATE_COLORS:
        return STATE_COLORS[text]
    if text.startswith('Aprobat') or text.startswith('Inactivare'):
        return ('#DDEBF7', '#0B3C5D') if '✖' not in text else ('#FFC7CE', '#9C0006')
    return ('#EEF1F5', '#33404D')


class PillDelegate(QStyledItemDelegate):
    """Starea / pasul urmator desenate ca eticheta colorata (mai usor de citit decat textul simplu)."""

    def __init__(self, parent=None, colors=state_colors):
        super().__init__(parent)
        self.colors = colors

    def paint(self, painter, option, index):
        text = index.data(Qt.DisplayRole)
        col = self.colors(text)
        if not col:
            return super().paint(painter, option, index)
        painter.save()
        if option.state & QStyle.State_Selected:
            painter.fillRect(option.rect, QColor('#CFE3F7'))
        f = QFont(option.font)
        f.setBold(True)
        f.setPointSizeF(max(7.5, f.pointSizeF() - 0.5))
        painter.setFont(f)
        fm = painter.fontMetrics()
        w = min(option.rect.width() - 8, fm.horizontalAdvance(text) + 16)
        r = QRectF(option.rect.x() + 4, option.rect.y() + 3, w, option.rect.height() - 6)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setPen(Qt.NoPen)
        painter.setBrush(QBrush(QColor(col[0])))
        painter.drawRoundedRect(r, 8, 8)
        painter.setPen(QPen(QColor(col[1])))
        painter.drawText(r.adjusted(8, 0, -6, 0), Qt.AlignVCenter | Qt.AlignLeft, fm.elidedText(text, Qt.ElideRight, int(w - 14)))
        painter.restore()

    def sizeHint(self, option, index):
        s = super().sizeHint(option, index)
        return QSize(s.width() + 20, max(s.height(), 26))


def nwce_status_colors(text):
    t = str(text or '').upper()
    return {'APPROVED': ('#C6EFCE', '#1B5E20'), 'UNDER REVIEW': ('#BBDEFB', '#0D47A1'), 'INACTIVE': ('#ECEFF1', '#78909C'),
            'CBT': ('#ECEFF1', '#546E7A'), 'NO TRADE': ('#FFC7CE', '#9C0006'), 'TSF': ('#EDE7F6', '#4527A0')}.get(t)


def next_colors(text):
    if not text:
        return None
    if text.startswith('✔'):
        return ('#E8F5E9', '#1B5E20')
    if text.startswith('⚠'):
        return ('#FFC7CE', '#9C0006')
    if text.startswith('Inactiv'):
        return ('#ECEFF1', '#78909C')
    return ('#FFF4E0', '#8A4B00')


class ComboDelegate(QStyledItemDelegate):
    """Editare in tabel cu lista de optiuni (criteriile Scale&Subjective completate de analist)."""

    def __init__(self, options, parent=None):
        super().__init__(parent)
        self.options = options          # [(valoare, eticheta)]

    def paint(self, painter, option, index):
        # culoarea din model (galben = de ales, albastru = ales de analist): stylesheet-ul "QTableView::item" o ignora
        bg = index.data(Qt.BackgroundRole)
        if bg is not None:
            painter.fillRect(option.rect.adjusted(0, 0, 0, -1), bg)
        super().paint(painter, option, index)

    def createEditor(self, parent, option, index):
        from PyQt5.QtWidgets import QComboBox
        cb = QComboBox(parent)
        for val, label in self.options:
            cb.addItem(label, val)
        cb.activated.connect(lambda _i: self.commitData.emit(cb))
        return cb

    def setEditorData(self, editor, index):
        i = editor.findData(index.data(Qt.EditRole))
        if i < 0:
            i = editor.findData(str(index.data(Qt.DisplayRole) or '').rstrip(' ?'))
        editor.setCurrentIndex(i)           # -1 = nimic ales (nu se presupune prima optiune)
        editor._initial = editor.currentData() if i >= 0 else None
        editor.showPopup()

    def setModelData(self, editor, model, index):
        # se scrie doar o alegere facuta de analist (iesirea din celula fara alegere nu schimba nimic)
        if editor.currentIndex() < 0 or editor.currentData() == getattr(editor, '_initial', None):
            return
        model.setData(index, editor.currentData(), Qt.EditRole)


class MoneyDelegate(QStyledItemDelegate):
    """Suma intreaga cu separator de mii (limita Open / MTM noua, direct in tabel)."""

    def createEditor(self, parent, option, index):
        from PyQt5.QtWidgets import QDoubleSpinBox
        s = QDoubleSpinBox(parent)
        s.setDecimals(0)
        s.setRange(0, 10_000_000_000)
        s.setSingleStep(10_000)
        s.setGroupSeparatorShown(True)
        s.setButtonSymbols(QDoubleSpinBox.NoButtons)
        return s

    def setEditorData(self, editor, index):
        editor.setValue(float(index.data(Qt.EditRole) or 0))
        editor._initial = editor.value()
        editor.selectAll()

    def setModelData(self, editor, model, index):
        editor.interpretText()
        if editor.value() == getattr(editor, '_initial', None):
            return          # neschimbat: nu se marcheaza ca editat (si nu se scrie 0 cand nu exista valoare)
        model.setData(index, editor.value(), Qt.EditRole)


class DateDelegate(QStyledItemDelegate):
    def createEditor(self, parent, option, index):
        from PyQt5.QtCore import QDate
        from PyQt5.QtWidgets import QDateEdit
        d = QDateEdit(parent)
        d.setCalendarPopup(True)
        d.setDisplayFormat('dd.MM.yyyy')
        # Valid till: nu in trecut si nu absurd de departe (greseala de tastare -> scris in NWCE / SAP)
        d.setDateRange(QDate.currentDate().addDays(1), QDate.currentDate().addMonths(36))
        return d

    def setEditorData(self, editor, index):
        from PyQt5.QtCore import QDate
        v = index.data(Qt.EditRole)
        editor.setDate(v if v is not None else QDate.currentDate())
        editor._initial = editor.date()

    def setModelData(self, editor, model, index):
        if editor.date() == getattr(editor, '_initial', None):
            return
        model.setData(index, editor.date(), Qt.EditRole)


class GradeDelegate(QStyledItemDelegate):
    def createEditor(self, parent, option, index):
        from PyQt5.QtWidgets import QSpinBox
        s = QSpinBox(parent)
        s.setRange(0, 11)
        s.setSpecialValueText('—')          # 0 = fara grade (nu se presupune un grade implicit)
        return s

    def setEditorData(self, editor, index):
        editor.setValue(int(index.data(Qt.EditRole) or 0))
        editor._initial = editor.value()

    def setModelData(self, editor, model, index):
        if editor.value() == 0 or editor.value() == getattr(editor, '_initial', None):
            return
        model.setData(index, editor.value(), Qt.EditRole)


class StepCard(QPushButton):
    """Un pas din flux: numar mare + titlu + explicatie scurta. Click = actiunea pasului."""

    def __init__(self, number, title, subtitle, parent=None):
        super().__init__(parent)
        self.setCursor(Qt.PointingHandCursor)
        self.setMinimumHeight(74)
        self.setCheckable(False)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(10, 6, 10, 6)
        self.num = QLabel(number)
        self.num.setFixedWidth(34)
        self.num.setAlignment(Qt.AlignCenter)
        self.num.setStyleSheet('font-size:18pt;font-weight:bold;color:#9AA7B4;background:transparent;border:none')
        lay.addWidget(self.num)
        box = QVBoxLayout()
        box.setSpacing(0)
        self.title = QLabel(title)
        self.title.setStyleSheet('font-size:11pt;font-weight:bold;color:#0B3C5D;background:transparent;border:none')
        self.sub = QLabel(subtitle)
        self.sub.setStyleSheet('color:#6B7785;background:transparent;border:none')
        self.sub.setWordWrap(True)
        box.addWidget(self.title)
        box.addWidget(self.sub)
        lay.addLayout(box, 1)
        self.count = QLabel('')
        self.count.setAlignment(Qt.AlignCenter)
        self.count.setMinimumWidth(34)
        lay.addWidget(self.count)
        for w in (self.num, self.title, self.sub, self.count):
            w.setAttribute(Qt.WA_TransparentForMouseEvents)
        self.set_count(0)

    def set_count(self, n, active=False):
        self.count.setText(str(n) if n else '')
        bg = '#F57C00' if active and n else ('#005EB8' if n else 'transparent')
        self.count.setStyleSheet(f'font-size:12pt;font-weight:bold;color:white;background:{bg};border-radius:13px;padding:2px 8px;border:none')
        border = '#F57C00' if active else '#DDE3EA'
        width = 2 if active else 1
        self.setStyleSheet(f'QPushButton{{background:#FFFFFF;border:{width}px solid {border};border-radius:8px;text-align:left}}'
                           'QPushButton:hover{background:#EEF4FB}QPushButton:disabled{background:#F5F6F8}')
        self.num.setStyleSheet(f'font-size:18pt;font-weight:bold;color:{"#F57C00" if active else "#9AA7B4"};background:transparent;border:none')


class Chip(QLabel):
    """Indicator de stare in antet, ca eticheta colorata (ex. "Creditsafe OK" verde, "NWCE necitit" rosu)."""
    clicked = pyqtSignal()

    def set(self, ok, text, tip=''):
        level = ok if isinstance(ok, str) else {True: 'ok', False: 'bad', None: 'grey'}[ok]
        bg, fg = CHIP_COLORS[level]
        self.setText(text)
        self.setToolTip(tip)
        self.setCursor(Qt.PointingHandCursor)
        self.setStyleSheet(f'QLabel{{background:{bg};color:{fg};border-radius:10px;padding:2px 10px;font-weight:600}}')

    def mousePressEvent(self, e):
        self.clicked.emit()


class ChipDelegate(QStyledItemDelegate):
    """Coloana "Pasul urmator": textul ca eticheta colorata; nivelul (ok / warn / bad / info / grey) vine din `level_role`."""

    def __init__(self, parent=None, level_role=None):
        super().__init__(parent)
        self.level_role = level_role

    def paint(self, painter, option, index):
        text = index.data(Qt.DisplayRole)
        level = index.data(self.level_role) if self.level_role is not None else None
        if not text or level not in CHIP_COLORS:
            return super().paint(painter, option, index)
        bg, fg = CHIP_COLORS[level]
        painter.save()
        if option.state & QStyle.State_Selected:
            painter.fillRect(option.rect, QColor(P['accent_soft']))
        painter.setPen(QPen(QColor(P['line'])))
        painter.drawLine(option.rect.bottomLeft(), option.rect.bottomRight())
        f = QFont(option.font)
        f.setBold(True)
        f.setPointSizeF(max(7.5, f.pointSizeF() - 0.5))
        painter.setFont(f)
        fm = painter.fontMetrics()
        w = min(option.rect.width() - 12, fm.horizontalAdvance(text) + 20)
        h = min(option.rect.height() - 8, fm.height() + 6)
        r = QRectF(option.rect.x() + 8, option.rect.y() + (option.rect.height() - h) / 2, w, h)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setPen(Qt.NoPen)
        painter.setBrush(QBrush(QColor(bg)))
        painter.drawRoundedRect(r, h / 2, h / 2)
        painter.setPen(QPen(QColor(fg)))
        painter.drawText(r.adjusted(10, 0, -8, 0), Qt.AlignVCenter | Qt.AlignLeft, fm.elidedText(text, Qt.ElideRight, int(w - 18)))
        painter.restore()

    def sizeHint(self, option, index):
        s = super().sizeHint(option, index)
        return QSize(s.width() + 24, max(s.height(), 30))


def card():
    f = QFrame()
    f.setObjectName('card')
    return f


GUIDE_HTML = """
<h2 style="color:#1F5C99">Ghid rapid - Credit Limits</h2>
<p>Patru file, de la stânga la dreapta. Pe fiecare filă bifezi clienții și apeși <b>butonul verde de jos</b>.
În dreapta vezi clientul selectat: cifrele, ce urmează și (în „În lucru”) ce poți modifica.</p>
<table cellpadding=6 border=0>
<tr><td><b>De revizuit</b></td><td>Limitele care expiră luna asta. Bifezi clienții tăi → <b>Revizuiește bifații</b>:
expunere, activ, Creditsafe + scorecard, limita nouă, cine aprobă.</td></tr>
<tr><td><b>În lucru</b></td><td>Propunerile. Modifici în dreapta (Open, MTM, Valabil până, criteriile 9/10/11) sau cu dublu-click pe
„Propus”. Bifezi → <b>Trimite bifații în NWCE + SAP</b>. Ce e peste autoritatea ta merge la „La aprobare”.
<b>Evaluează din nou</b>: raport Creditsafe nou + scorecard refăcut.</td></tr>
<tr><td><b>La aprobare</b></td><td>Peste autoritatea ta (Annual Review în folderul clientului). Când vine aprobarea:
<b>Am primit aprobarea</b> → NWCE; SAP doar dacă bifezi.</td></tr>
<tr><td><b>Gata</b></td><td>Scrise în NWCE (și SAP).</td></tr>
</table>
<p><b>Căutarea</b> de sus caută în toți clienții (și listele colegilor). <b>Listă</b> și <b>Filtre</b> sunt în meniul de sus.
Click-dreapta pe client: grup / Annual Review, folder, scorecard, PDF, anulare, inactivare. <b>Toate detaliile…</b> (în dreapta):
pagina completă, graficul de expunere și istoricul.</p>
"""


class GuideDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle('Ghid rapid')
        self.resize(820, 720)
        lay = QVBoxLayout(self)
        t = QTextBrowser()
        t.setHtml(GUIDE_HTML)
        lay.addWidget(t)
        bb = QDialogButtonBox(QDialogButtonBox.Ok)
        bb.button(QDialogButtonBox.Ok).setText('Am inteles')
        bb.accepted.connect(self.accept)
        lay.addWidget(bb)
