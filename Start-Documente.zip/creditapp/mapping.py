"""Maparea raport Creditsafe (Global Financials GGS) -> scorecard Excel."""
import datetime as dt

# Camp Creditsafe -> eticheta cautata de formulele din foile IS / BS (coloana B din "Blank 1").
FINANCIAL_LABELS = {
    # Profit and loss
    'revenue': 'Revenue',
    'operatingCosts': 'Operating costs',
    'operatingProfit': 'Operating profit',
    'wagesAndSalaries': 'Wages & Salaries',
    'pensionCosts': 'Pension costs',
    'depreciation': 'Depreciation',
    'amortisation': 'Amortisation',
    'financialIncome': 'Financial income',
    'financialExpenses': 'Financial expenses',
    'extraordinaryCosts': 'Extraordinary costs',
    'profitBeforeTax': 'Profit before tax',
    'tax': 'Tax',
    'profitAfterTax': 'Profit after tax',
    'dividends': 'Dividends',
    'minorityInterests': 'Minority interests',
    'otherAppropriations': 'Other appropriations',
    'retainedProfit': 'Retained profit',
    # Balance sheet - assets
    'landAndBuildings': 'Land & buildings',
    'plantAndMachinery': 'Plant & machinery',
    'otherTangibleAssets': 'Other tangible assets',
    'totalTangibleAssets': 'Total tangible assets',
    'goodwill': 'Goodwill',
    'otherIntangibleAssets': 'Other intangible assets',
    'totalIntangibleAssets': 'Total intangible assets',
    'investments': 'Investments',
    'loansToGroup': 'Loans to group',
    'otherLoans': 'Other Loans',
    'miscellaneousFixedAssets': 'Miscellaneous fixed assets',
    'totalOtherFixedAssets': 'Total other fixed assets',
    'totalFixedAssets': 'Total fixed assets',
    'rawMaterials': 'Raw materials',
    'workInProgress': 'Work in progress',
    'finishedGoods': 'Finished goods',
    'otherInventories': 'Other inventories',
    'totalInventories': 'Total inventories',
    'tradeReceivables': 'Trade receivables',
    'groupReceivables': 'Group receivables',
    'receivablesDueAfter1Year': 'Receivables due after 1 year',
    'miscellaneousReceivables': 'Miscellaneous receivables',
    'totalReceivables': 'Total receivables',
    'cash': 'Cash',
    'otherCurrentAssets': 'Other current assets',
    'totalCurrentAssets': 'Total current assets',
    'totalAssets': 'Total assets',
    # Balance sheet - liabilities
    'tradePayables': 'Trade payables within one year',
    'bankLiabilities': 'Bank liabilities within one year',
    'otherLoansOrFinance': 'Other loans/finance',
    'groupPayables': 'Group payables',
    'miscellaneousLiabilities': 'Miscellaneous liabilities within one year',
    'totalCurrentLiabilities': 'Total Current Liabilities',
    'tradePayablesDueAfter1Year': 'Trade payables due after 1 year',
    'bankLiabilitiesDueAfter1Year': 'Bank liabilities due after 1 year',
    'otherLoansOrFinanceDueAfter1Year': 'Other loans/finance due after 1 year',
    'groupPayablesDueAfter1Year': 'Group payables due after 1 year',
    'miscellaneousLiabilitiesDueAfter1Year': 'Miscellaneous liabilities due after 1 year',
    'totalLongTermLiabilities': 'Total long term liabilities',
    'totalLiabilities': 'Total liabilities',
    # Equity
    'calledUpShareCapital': 'Called Up Share Capital',
    'sharePremium': 'Share premium',
    'revenueReserves': 'Revenue reserves',
    'otherReserves': 'Other Reserves',
    'totalShareholdersEquity': 'Total shareholders equity',
}

# 10. Experience with Counterparty - optiunile din scorecard
EXPERIENCE_OPTIONS = {
    'A': 'A - 10+ ani', 'B': 'B - 5-10 ani', 'C': 'C - 2-5 ani', 'D': 'D - 6 luni - 2 ani', 'E': 'E - Nou',
}
# 11. Payments Behavior
PAYMENT_OPTIONS = {
    'A': 'A - Highly consistent on time (+15)', 'B': 'B - Generally consistent on time (+10)',
    'C': 'C - Prepaid / New no data (0)', 'D': 'D - Delays consistent (-10)', 'E': 'E - Delays highly consistent (-15)',
}
FINANCIAL_REPORTING_OPTIONS = ['Best', 'Above Average', 'Average', 'Below Average', 'Uncertain']
COUNTRY_RATING_OPTIONS = ['AAA', 'AA-A', 'BBB', 'BB', 'B-CCC', 'CC-C-D']


def parse_date(value):
    """Data dintr-un camp Creditsafe ("2025-12-31T00:00:00Z") -> date, sau None."""
    if not value:
        return None
    if isinstance(value, dt.datetime):
        return value.date()
    if isinstance(value, dt.date):
        return value
    s = str(value).strip()
    try:
        return dt.date.fromisoformat(s[:10])
    except ValueError:
        return None


def dig(obj, *keys):
    for k in keys:
        if not isinstance(obj, dict):
            return None
        obj = obj.get(k)
    return obj


def company_status(report):
    return str(dig(report, 'companySummary', 'companyStatus', 'status') or '')


def bureau_grade(report):
    """13. Credit Bureau Score: scor Creditsafe -> litera din scorecard.

    Scorecard: A Excellent(10) B Good(5) C Fair(0) D Score not available(0) E Poor(-5) F Unsatisfactory(-10)
    Creditsafe: 71-100 A Very Low Risk | 51-70 B Low | 30-50 C Moderate | 21-29 D High | 1-20 D Very High | E not scored
    """
    status = company_status(report)
    if status and status.lower() != 'active':
        return 'F'
    rating = dig(report, 'creditScore', 'currentCreditRating') or {}
    common = str(rating.get('commonValue') or '')
    if common in ('A', 'B', 'C'):
        return common
    if common == 'D':
        try:
            score = int(str(dig(rating, 'providerValue', 'value')))
        except (TypeError, ValueError):
            return 'E'
        return 'F' if score <= 20 else 'E'
    return 'D'


def incorporation_date(report):
    for v in (dig(report, 'companyIdentification', 'basicInformation', 'companyRegistrationDate'),
              dig(report, 'alternateSummary', 'incorporationDate'),
              dig(report, 'companySummaryExtra', 'incorporationDate'),
              dig(report, 'alternateSummary', 'reaInscriptionDate')):   # Italia: inscrierea in registrul REA
        d = parse_date(v)
        if d:
            return d
    return None


def years_between(start, end):
    return (end - start).days / 365.25


def age_grade(inc_date, as_of=None):
    """12. Age of Company: A 20+ ani, B 12-20, C 8-12, D 5-8, E 2-5, F sub 2."""
    if not inc_date:
        return None
    y = years_between(inc_date, as_of or dt.date.today())
    if y >= 20:
        return 'A'
    if y >= 12:
        return 'B'
    if y >= 8:
        return 'C'
    if y >= 5:
        return 'D'
    if y >= 2:
        return 'E'
    return 'F'


def statements(report, count=4):
    """Ultimele N situatii financiare globale, cele mai recente primele."""
    fs = [s for s in (report.get('financialStatements') or []) if str(s.get('type', '')).startswith('GlobalFinancials') and parse_date(s.get('yearEndDate'))]
    fs.sort(key=lambda s: parse_date(s['yearEndDate']), reverse=True)
    return fs[:count]


def latest_financial_year(report):
    s = statements(report, 1)
    return parse_date(s[0]['yearEndDate']).year if s else None


def statement_value(stmt, field):
    for part in ('profitAndLoss', 'balanceSheet'):
        v = dig(stmt, part, field)
        if v is not None:
            try:
                return float(v)
            except (TypeError, ValueError):
                return None
    return None


def report_vat_numbers(report):
    """Toate numerele VAT/fiscale din raport (campurile difera de la tara la tara)."""
    found = []
    skip = {'financialStatements', 'localFinancialStatements', 'directorsExtra', 'negativeInformationExtra'}
    names = {'vat', 'vatno', 'vatnumber', 'vatregistrationnumber', 'taxcode', 'taxnumber', 'fiscalcode'}

    def walk(o, depth):
        if depth > 3 or not isinstance(o, dict):
            return
        for k, v in o.items():
            if isinstance(v, (str, int)) and k.lower() in names and str(v).strip():
                found.append(str(v).strip())
            elif isinstance(v, dict) and k not in skip:
                walk(v, depth + 1)
            elif isinstance(v, list) and k not in skip:
                for x in v[:5]:
                    walk(x, depth + 1)
    walk(report, 0)
    return list(dict.fromkeys(found))


def summary(report):
    """Datele cheie din raport pentru afisare (fara Excel)."""
    rating = dig(report, 'creditScore', 'currentCreditRating') or {}
    limit = rating.get('creditLimit') or {}
    st = statements(report, 1)
    latest = st[0] if st else None
    return {
        'name': dig(report, 'companySummary', 'businessName') or '',
        'country': dig(report, 'companySummary', 'country') or '',
        'status': company_status(report),
        'connect_id': report.get('companyId') or '',
        'rating_common': rating.get('commonValue') or '',
        'rating_desc': rating.get('commonDescription') or '',
        'rating_score': dig(rating, 'providerValue', 'value'),
        'cs_limit': limit.get('value'),
        'cs_limit_currency': limit.get('currency') or '',
        'incorporated': incorporation_date(report),
        'bureau_grade': bureau_grade(report),
        'latest_year_end': parse_date(latest['yearEndDate']) if latest else None,
        'currency': latest.get('currency') if latest else '',
        'revenue': statement_value(latest, 'revenue') if latest else None,
        'equity': statement_value(latest, 'totalShareholdersEquity') if latest else None,
        'profit_after_tax': statement_value(latest, 'profitAfterTax') if latest else None,
        'total_assets': statement_value(latest, 'totalAssets') if latest else None,
        'intangibles': statement_value(latest, 'totalIntangibleAssets') if latest else None,
        'years': len(statements(report, 4)),
    }
