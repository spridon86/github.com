"""Instanta Excel separata (DispatchEx) pentru scorecard si excelul NWCE.

Nu se ataseaza la Excelul deschis de utilizator: porneste un proces nou, invizibil, care se inchide
(si la nevoie se opreste fortat) la final - fara procese Excel "fantoma".
"""
import time

from . import log
from .errors import AppError, hresult_of

_log = log.get('excel')

BUSY = {'800AC472', '80010001', '8001010A'}            # Excel ocupat / apel respins temporar
DEAD = {'800706BA', '800706BE', '80010108', '80010105'}  # Excel s-a inchis / nu mai raspunde

XL_CALC_MANUAL = -4135
XL_CALC_AUTO = -4105


def is_dead(exc):
    return hresult_of(exc) in DEAD


def retry(fn, attempts=25, delay=0.4):
    """Excel respinge temporar comenzile cand e ocupat - reincercam."""
    for i in range(1, attempts + 1):
        try:
            return fn()
        except Exception as e:
            if hresult_of(e) in BUSY and i < attempts:
                time.sleep(delay)
                continue
            raise


class ExcelApp:
    def __init__(self, visible=False):
        import pythoncom
        import win32com.client
        pythoncom.CoInitialize()
        try:
            self.xl = win32com.client.DispatchEx('Excel.Application')
        except Exception as e:
            raise AppError('EXCEL', f'Excel could not be started: {e}')
        self.pid = None
        try:
            import win32process
            self.pid = win32process.GetWindowThreadProcessId(self.xl.Hwnd)[1]
        except Exception:
            pass
        for prop, val in (('Visible', visible), ('DisplayAlerts', False), ('ScreenUpdating', False),
                          ('AskToUpdateLinks', False), ('EnableEvents', False)):
            try:
                setattr(self.xl, prop, val)
            except Exception:
                pass
        try:
            self.xl.AutomationSecurity = 3     # msoAutomationSecurityForceDisable: fara macro-uri la deschidere
        except Exception:
            pass
        _log.info('Excel started (pid %s)', self.pid)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.quit()

    def wait_ready(self, timeout=15.0):
        """Dupa Open, Excel mai lucreaza cateva clipe (recalcul, sincronizare OneDrive) si respinge comenzile
        ("Call was rejected by callee"): asteptam pana spune ca e gata (Application.Ready)."""
        t0 = time.time()
        while time.time() - t0 < timeout:
            try:
                if self.xl.Ready:
                    return True
            except Exception as e:
                if hresult_of(e) not in BUSY:
                    raise
            time.sleep(0.25)
        _log.warning('Excel not ready after %.0f s', timeout)
        return False

    def open(self, path, read_only=False, attempts=4):
        last = None
        for i in range(1, attempts + 1):
            try:
                wb = retry(lambda: self.xl.Workbooks.Open(str(path), 0, read_only))
                self.wait_ready()
                return wb
            except Exception as e:
                last = e
                if is_dead(e):
                    raise
                if i < attempts:
                    time.sleep(3 * i)   # SharePoint / OneDrive: deseori merge din a doua incercare
        raise last

    def quit(self, wait=6.0):
        """Inchide Excel; daca procesul nu se inchide in `wait` secunde, il opreste fortat.
        Pentru fisiere SharePoint se da un timp mai lung (incarcarea pe server se termina la inchidere)."""
        xl, self.xl = getattr(self, 'xl', None), None
        if xl is None:
            return
        try:
            for wb in list(xl.Workbooks):
                try:
                    wb.Close(False)
                except Exception:
                    pass
        except Exception:
            pass
        try:
            xl.Quit()
        except Exception:
            pass
        del xl
        import gc
        gc.collect()
        if self.pid:
            self._ensure_dead(self.pid, wait)

    @staticmethod
    def _ensure_dead(pid, wait=6.0):
        try:
            import win32api
            import win32con
            import win32event
            h = win32api.OpenProcess(win32con.SYNCHRONIZE | win32con.PROCESS_TERMINATE, False, pid)
        except Exception:
            return   # procesul s-a inchis deja
        try:
            if win32event.WaitForSingleObject(h, int(wait * 1000)) != win32event.WAIT_OBJECT_0:
                win32api.TerminateProcess(h, 1)
                _log.warning('Excel pid %s did not quit - terminated', pid)
        finally:
            win32api.CloseHandle(h)
