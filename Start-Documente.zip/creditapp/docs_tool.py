"""Documente client: alegi clienti din NWCE -> raport Creditsafe (PDF) + scorecard, salvate in folderul fiecarui client
(BUC - TRADING COUNTREPARTIES\\<Client>\\<an>). Atat: nu scrie in NWCE / SAP, nu propune limite, nu cere aprobari.

Pornire: dublu-click pe Start-Documente.cmd (sau python -m creditapp.docs_tool).
Foloseste acelasi cod ca Credit Limits Tool: cautarea Creditsafe (doar firme Registered), raportul + PDF, scorecardul
completat si calculat de Excel, folderul clientului (si in folderele de grup "GRUPPO ..."). Jurnalul e separat
(data\\documente.db), ca acesti clienti sa nu apara "in lucru" in Credit Limits.
Criteriile subiective (9. Fin. reporting, 10. Experience, 11. Payments) se schimba direct in tabel, ca in Credit Limits:
se scriu in scorecardul clientului si Excel recalculeaza grade-ul."""
import concurrent.futures as cf
import datetime as dt
import re
import sys
import traceback
from dataclasses import dataclass, field
from pathlib import Path

from . import errors, limits_book, log, paths, pipeline, rules

_log = log.get('docs')
SKIP_STATUSES = ('INACTIVE', 'CBT', 'NO TRADE', 'TSF')
DONE_STATES = ('evaluated', 'evaluated_manual')
# coloanele criteriilor subiective (foaia Scale&Subjective) -> cheia din ev.inputs; 14. Country Rating: neatins de tool
MANUAL_COLS = {'m_fin': 'financial_reporting', 'm_exp': 'experience', 'm_pay': 'payment'}


# ---------------------------------------------------------------- logica (fara Qt)
@dataclass
class Firm:
    """O firma din NWCE (toate randurile ei - companii / tari - adunate dupa VAT, altfel Customer Code)."""
    key: str
    name: str
    vat: str
    customer_code: str
    rep: object                       # randul NWCE folosit (compania din Setari, daca firma o are)
    rows: list = field(default_factory=list)
    checked: bool = False
    ev: object = None                 # evaluarea facuta (PDF, scorecard, folder)

    @property
    def companies(self):
        return sorted({str(r.company_code or '').split(' ')[0] for r in self.rows if r.company_code})

    @property
    def owners(self):
        return {limits_book.tbd_owner(r.get('tbd_by')) for r in self.rows} - {''}

    @property
    def grade(self):
        return rules.grade_number(self.rep.get('grading'))

    @property
    def valid_till(self):
        return limits_book.from_serial(self.rep.get('valid_till'))

    @property
    def inactive(self):
        return all(str(r.get('status') or '').strip().upper() in SKIP_STATUSES for r in self.rows)


def firms_from_nwce(snap, cfg):
    """Firmele din NWCE, cate una pe firma (VAT, altfel Customer Code, altfel nume)."""
    from .ui.models import group_key
    country = cfg.get('portfolio', 'country', default='IT')
    company = cfg.get('limitsBook', 'companyCode')
    groups = {}
    for r in snap.rows:
        if not str(r.name or '').strip():
            continue
        groups.setdefault(group_key(r.get('vat'), r.customer_code, r.name, country), []).append(r)
    out = []
    for key, rows in groups.items():
        rows = sorted(rows, key=lambda x: (x.company_code != company, not x.customer_code, x.sheet_row))
        rep = rows[0]
        out.append(Firm(key=key, name=str(rep.name).strip(), vat=str(rep.get('vat') or '').strip(),
                        customer_code=limits_book._code(rep.get('customer_code')), rep=rep, rows=rows))
    return sorted(out, key=lambda f: f.name.upper())


def counterparty_for(firm, portfolio, cfg):
    """Clientul pentru evaluare: din Open Contracts ITA daca exista (plati, contracte -> criteriile 10 / 11), altfel din NWCE."""
    from .portfolio import counterparty_from_nwce
    rep = firm.rep
    if portfolio is not None and firm.customer_code and rep.company_code == cfg.get('limitsBook', 'companyCode'):
        cp = portfolio.counterparties.get(firm.customer_code)
        if cp is not None:
            return cp
    prefix = str(rep.company_code or '').split(' ')[0]
    key = f'{firm.customer_code or "NWCE"}@{prefix}#{rep.sheet_row}'
    cur = limits_book.company_currency(cfg, rep.company_code)
    return counterparty_from_nwce(rep, key, cur, next(iter(firm.owners), ''))


def result_chip(ev):
    """(text, nivel) pentru coloana "Rezultat"."""
    if ev is None:
        return '', ''
    if ev.state == 'error':
        return f'Eroare: {(ev.error or {}).get("title", "")}', 'bad'
    files = ev.files or {}
    if files.get('annual_review_error'):
        return f'Annual Review: {files["annual_review_error"]}', 'warn'
    when = _day(ev.created)
    when = f' · {when:%d.%m.%Y}' if when and when != dt.date.today() else ''
    if files.get('annual_review_stale'):
        return f'Grade {ev.grade} · Annual Review de refăcut (click-dreapta){when}', 'warn'
    ar = ' + Annual Review' if files.get('annual_review') else ''
    if ev.state == 'evaluated' and files.get('scorecard'):
        return f'Gata · PDF + scorecard{ar} (grade {ev.grade}){when}', 'ok'
    if ev.state == 'evaluated_manual':
        return f'PDF{ar} · Creditsafe fără bilanț (fără scorecard){when}', 'warn'
    if ev.state == 'evaluated':
        return f'Gata · PDF{ar}{when}', 'ok'
    return 'În curs…', 'info'


def _day(text):
    try:
        return dt.date.fromisoformat(str(text or '')[:10])
    except ValueError:
        return None


# ---------------------------------------------------------------- criteriile subiective (ca in Credit Limits)
def criterion(ev, crit):
    """Valoarea aleasa (A..E / Average...) pentru criteriul subiectiv; '' daca nu exista evaluare."""
    v = ((ev.inputs or {}) if ev is not None else {}).get(crit)
    return v if isinstance(v, str) else (v or {}).get('grade', '') or ''


def can_edit(ev):
    """Criteriile se schimba doar unde exista scorecard (Excel recalculeaza grade-ul in fisierul clientului)."""
    return ev is not None and ev.state == 'evaluated' and ev.grade is not None and bool((ev.files or {}).get('scorecard'))


def set_criterion(ev, crit, value, excel=None):
    """Scrie criteriul in scorecardul clientului; Excel recalculeaza grade-ul si fisierul se salveaza. Evaluarea se
    actualizeaza DOAR daca scorecardul s-a salvat (la eroare ramane cum era). Intoarce (grade vechi, rezultatul Excel)."""
    from .scorecard_live import LiveScorecard
    lv = LiveScorecard(ev.files['scorecard'], excel=excel)
    try:
        res = lv.set(**{crit: value})
        lv.save()
    finally:
        lv.close()
    inp = dict(ev.inputs or {})
    inp[crit] = value if crit == 'financial_reporting' else dict(inp.get(crit) or {}, grade=value, manual=True)
    ev.inputs = inp
    ev.review = dict(ev.review or {})
    ev.review['manual'] = dict(ev.review.get('manual') or {}, **{crit: value})
    sc = dict(ev.scorecard or {})
    old = sc.get('grade')
    sc.update(grade=res.get('grade'), scale=res.get('scale'), points=res.get('points'), criteria=res.get('criteria'))
    if res.get('equity_usd') is not None:
        sc['equity_usd'] = f'{res["equity_usd"]:,.0f}'
    ev.scorecard = sc
    if (ev.files or {}).get('annual_review'):
        ev.files = dict(ev.files, annual_review_stale=True)     # documentul Word are inca grade-ul / printscreen-ul vechi
    return old, res


def choices(ev):
    """Criteriile alese de analist - pastrate la o noua generare (scorecardul nou le primeste in loc de cele propuse)."""
    return {k: v for k, v in ((ev.review or {}).get('manual') or {}).items() if k in MANUAL_COLS.values() and v} if ev else {}


def attach_previous(firms, latest, portfolio, cfg):
    """Documentele facute deja (jurnalul data\\documente.db): ultima evaluare reusita a fiecarei firme, ca sa se vada
    rezultatul si sa se poata schimba subiectivele si dupa repornire. Scorecardul sters / mutat -> fara editare."""
    from .pipeline import Evaluation
    by_code = {}
    for partner, (eid, _created, state, data) in latest.items():
        if state not in DONE_STATES:
            continue
        code = partner.split('@')[0].split('#')[0]
        if code and code != 'NWCE' and eid > by_code.get(code, (0,))[0]:
            by_code[code] = (eid, data)
    for f in firms:
        hit = latest.get(counterparty_for(f, portfolio, cfg).partner)
        data = hit[3] if hit and hit[2] in DONE_STATES else (by_code.get(f.customer_code) or (0, None))[1]
        if not data:
            continue
        ev = Evaluation.from_dict(data)
        sc = (ev.files or {}).get('scorecard')
        if sc and not Path(sc).exists():
            ev.files = {k: v for k, v in ev.files.items() if k != 'scorecard'}      # doar in memorie
        f.ev = ev
    return firms


def active_rows(firm):
    """Randurile de limita ale firmei pentru Annual Review (fara INACTIVE / CBT / NO TRADE)."""
    rows = [r for r in firm.rows if str(r.get('status') or '').strip().upper() not in SKIP_STATUSES
            and not re.search(r'CBT|NO TRADE', str(r.company_code or ''), re.I)]
    return rows or [firm.rep]


def annual_reviews(cfg, results, firm_of, cps, db=None, inv=None, report=None, on_done=None):
    """Annual Review de reinnoire pentru fiecare client cu documentele facute (limitele noi = cele actuale), in acelasi
    folder cu PDF-ul si scorecardul. O eroare la un client nu le opreste pe celelalte (apare la "Rezultat")."""
    from . import annual_review
    todo = [ev for ev in results if ev.state in ('evaluated', 'evaluated_manual') and ev.partner in firm_of]
    for i, ev in enumerate(todo, 1):
        firm = firm_of[ev.partner]
        if report:
            report(f'Annual Review {i}/{len(todo)}: {firm.name}...', i - 1, len(todo))
        ev.files = dict(ev.files or {})
        ev.files.pop('annual_review_error', None)
        ev.files.pop('annual_review_stale', None)
        try:
            path = annual_review.renewal(cfg, active_rows(firm), cps[ev.partner], ev, firm.name, inv)
            ev.files['annual_review'] = str(path)
        except Exception as e:
            _log.exception('Annual review failed for %s', firm.name)
            ev.files['annual_review_error'] = errors.friendly(e)['title']
        if db is not None:
            db.save_evaluation(ev)
        if on_done:
            on_done(ev)
    return results


def prepare_all(ctx, cps, report=None):
    """Cautarea gratuita in Creditsafe (VAT -> firma), in paralel. Intoarce evaluarile pregatite, in ordinea clientilor."""
    preps = [None] * len(cps)
    with cf.ThreadPoolExecutor(max_workers=6, thread_name_prefix='search') as pool:
        futs = {pool.submit(pipeline.prepare, ctx, cp, None): i for i, cp in enumerate(cps)}
        for n, f in enumerate(cf.as_completed(futs), 1):
            preps[futs[f]] = f.result()
            if report:
                report(f'Caut în Creditsafe: {n}/{len(cps)}', n, len(cps))
    return preps


def needs_confirmation(preps):
    """Fereastra de alegere doar cand e ceva de decis: firma negasita, fara VAT sau mai multe firme si niciuna Registered."""
    return not all(ev.state == 'prepared' and not any(w.startswith('Creditsafe a gasit') for w in ev.warnings) for ev in preps)


def generate(ctx, preps, cps, force_refresh=False, on_done=None, chosen=None):
    """Raport Creditsafe + PDF + scorecard pentru fiecare client, in folderul lui. Scorecardul vechi cu acelasi nume
    se inlocuieste (fara dubluri "(2)"); scorecardul se face mereu (si sub pragul de 350.000 USD).
    chosen: partner -> criteriile subiective alese de analist (raman la fel in scorecardul nou)."""
    overrides = {cp.partner: dict((chosen or {}).get(cp.partner) or {}, force_refresh=bool(force_refresh), replace_scorecard=True)
                 for cp in cps.values()}
    return pipeline.evaluate_all(ctx, preps, cps, overrides, on_done=on_done)


# ---------------------------------------------------------------- interfata
def _ui():
    from PyQt5.QtCore import QAbstractTableModel, QModelIndex, QSortFilterProxyModel, Qt, QTimer, pyqtSignal
    from PyQt5.QtGui import QBrush, QColor, QCursor
    from PyQt5.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QComboBox, QDialog, QFrame, QHBoxLayout,
                                 QHeaderView, QLabel, QLineEdit, QMainWindow, QMenu, QMessageBox, QProgressBar, QPushButton,
                                 QTableView, QVBoxLayout, QWidget)

    from . import mapping, review
    from .audit import AuditDB
    from .creditsafe_web import has_credentials, make_client
    from .ui import dialogs
    from .ui.models import fmt_date
    from .ui.widgets import APP_STYLE, Chip, ChipDelegate, ComboDelegate, GroupHeader
    from .ui.worker import Worker

    LEVEL_ROLE = Qt.UserRole + 3
    COLUMNS = [('check', ''), ('name', 'Client'), ('vat', 'VAT'), ('companies', 'Companii'), ('grade', 'Grade|NWCE'),
               ('new_grade', 'Grade|Nou'), ('m_fin', 'Subiective|9. Fin. reporting'), ('m_exp', 'Subiective|10. Experience'),
               ('m_pay', 'Subiective|11. Payments'), ('valid', 'Valabil până'), ('tbd', 'TBD by'), ('result', 'Rezultat')]
    COL = {k: i for i, (k, _l) in enumerate(COLUMNS)}
    TIPS = {'new_grade': 'Grade-ul din scorecardul nou (se recalculează când schimbi subiectivele)',
            'm_fin': '9. Financial Reporting - alegi din listă (dublu-click); se scrie în scorecard și grade-ul se recalculează',
            'm_exp': '10. Experience with Counterparty - propus din folderul clientului / primul contract; îl poți schimba',
            'm_pay': '11. Payments Behavior - propus din raportul de plăți; îl poți schimba',
            'result': 'Galben = criteriu de ales (tool-ul nu l-a putut decide) · albastru = ales de tine'}

    class FirmsModel(QAbstractTableModel):
        edited = pyqtSignal(object, str, object)        # firma, criteriul, valoarea aleasa in tabel

        def __init__(self, parent=None):
            super().__init__(parent)
            self.firms = []
            self.locked = False                         # in timpul generarii nu se schimba scorecardurile

        def load(self, firms):
            self.beginResetModel()
            self.firms = firms
            self.endResetModel()

        def rowCount(self, parent=QModelIndex()):
            return 0 if parent.isValid() else len(self.firms)

        def columnCount(self, parent=QModelIndex()):
            return len(COLUMNS)

        def headerData(self, s, o, role=Qt.DisplayRole):
            if o != Qt.Horizontal:
                return None
            if role == Qt.DisplayRole:
                return COLUMNS[s][1]
            if role == Qt.ToolTipRole:
                return TIPS.get(COLUMNS[s][0])
            return None

        def flags(self, index):
            f = Qt.ItemIsEnabled | Qt.ItemIsSelectable
            key = COLUMNS[index.column()][0]
            if key == 'check':
                return f | Qt.ItemIsUserCheckable
            if key in MANUAL_COLS and not self.locked and can_edit(self.firms[index.row()].ev):
                return f | Qt.ItemIsEditable
            return f

        def _value(self, f, key, sort=False):
            ev = f.ev
            if key == 'check':
                return f.checked
            if key == 'name':
                return f.name.upper() if sort else f.name
            if key == 'vat':
                return f.vat
            if key == 'companies':
                return ', '.join(f.companies)
            if key == 'grade':
                return (f.grade or 99) if sort else (f.grade or '')
            if key == 'new_grade':
                g = ev.grade if ev is not None else None
                return (g or 99) if sort else (g or '')
            if key in MANUAL_COLS:
                v = criterion(ev, MANUAL_COLS[key]) if ev is not None and ev.state in DONE_STATES else ''
                return f'{v} ?' if v and MANUAL_COLS[key] in review.manual_needed(ev) else v     # "?" = propus, de confirmat
            if key == 'valid':
                return (f.valid_till.isoformat() if f.valid_till else '') if sort else fmt_date(f.valid_till)
            if key == 'tbd':
                return ', '.join(sorted(f.owners))
            return result_chip(ev)[0]

        def data(self, index, role=Qt.DisplayRole):
            f = self.firms[index.row()]
            key = COLUMNS[index.column()][0]
            ev = f.ev
            if role == Qt.CheckStateRole and key == 'check':
                return Qt.Checked if f.checked else Qt.Unchecked
            if role == LEVEL_ROLE and key == 'result':
                return result_chip(ev)[1]
            if role == Qt.DisplayRole:
                return '' if key == 'check' else self._value(f, key)
            if role == Qt.EditRole and key in MANUAL_COLS:
                return criterion(ev, MANUAL_COLS[key])
            if role == Qt.UserRole:            # sortare
                return self._value(f, key, sort=True)
            if role == Qt.ToolTipRole and key in MANUAL_COLS and ev is not None:
                inp = (ev.inputs or {}).get(MANUAL_COLS[key])
                why = inp.get('why', '') if isinstance(inp, dict) else ''
                return (why + ('\n' if why else '') + ('Dublu-click: alegi altă valoare (se scrie în scorecard).' if can_edit(ev)
                                                        else 'Fără scorecard: nu se poate schimba.')).strip()
            if role == Qt.BackgroundRole and key in MANUAL_COLS and ev is not None and ev.inputs:
                crit = MANUAL_COLS[key]
                if crit in review.manual_needed(ev):
                    return QBrush(QColor('#FFF59D'))       # de ales de analist
                if (ev.review or {}).get('manual', {}).get(crit):
                    return QBrush(QColor('#E3F2FD'))       # ales de analist
            if role == Qt.FontRole and key == 'new_grade' and ev is not None and ev.grade is not None:
                fnt = QApplication.font()
                fnt.setBold(True)
                return fnt
            if role == Qt.ForegroundRole and f.inactive:
                return QBrush(QColor(150, 150, 150))
            return None

        def setData(self, index, value, role=Qt.EditRole):
            key = COLUMNS[index.column()][0]
            f = self.firms[index.row()]
            if key == 'check' and role == Qt.CheckStateRole:
                f.checked = value == Qt.Checked
                self.dataChanged.emit(index, index)
                return True
            if key in MANUAL_COLS and role == Qt.EditRole and value not in (None, '') and not self.locked and can_edit(f.ev):
                self.edited.emit(f, MANUAL_COLS[key], value)     # fereastra: scorecardul in Excel, apoi refresh_firm
                return True
            return False

        def refresh_firm(self, firm):
            i = self.firms.index(firm)
            self.dataChanged.emit(self.index(i, 0), self.index(i, len(COLUMNS) - 1))

    class FirmsFilter(QSortFilterProxyModel):
        def __init__(self, parent=None):
            super().__init__(parent)
            self.text, self.owner, self.show_inactive = '', None, False
            self.setSortRole(Qt.UserRole)

        def filterAcceptsRow(self, row, parent):
            f = self.sourceModel().firms[row]
            if f.checked:
                return True                     # cei bifati raman vizibili (si cand schimbi lista / cauti altceva)
            if f.inactive and not self.show_inactive:
                return False
            if self.owner is not None and self.owner not in f.owners:
                return False
            t = self.text.lower()
            return not t or t in f.name.lower() or t in f.vat.lower() or t in (f.customer_code or '')

    class DocsWindow(QMainWindow):
        def __init__(self, cfg, autoload=True):
            super().__init__()
            self.cfg = cfg
            self.db = AuditDB(paths.DATA_DIR / 'documente.db')
            self.cs = make_client(cfg)
            self.snap = self.portfolio = None
            self.worker = None
            self.setWindowTitle(f'Documente client - {cfg.get("analyst", "name")}')
            self.resize(1460, 820)
            self.setStyleSheet(APP_STYLE)
            self._build()
            if autoload:
                QTimer.singleShot(150, lambda: self.load(refresh=False))

        # --- ecranul
        def _build(self):
            central = QWidget()
            central.setObjectName('central')
            self.setCentralWidget(central)
            v = QVBoxLayout(central)
            v.setContentsMargins(14, 12, 14, 8)
            v.setSpacing(0)
            bar = QFrame()
            bar.setObjectName('appbar')
            h = QHBoxLayout(bar)
            h.setContentsMargins(14, 10, 14, 10)
            h.setSpacing(12)
            t = QLabel('Documente client')
            t.setObjectName('title')
            h.addWidget(t)
            self.f_text = QLineEdit()
            self.f_text.setObjectName('search')
            self.f_text.setPlaceholderText('Caută client, VAT sau cod…')
            self.f_text.setClearButtonEnabled(True)
            self.f_text.textChanged.connect(self._filter)
            h.addWidget(self.f_text, 1)
            self.f_list = QComboBox()
            self.f_list.setMinimumWidth(200)
            self.f_list.currentIndexChanged.connect(self._filter)
            h.addWidget(self.f_list)
            self.chip_nwce = Chip()
            self.chip_nwce.set(None, 'NWCE …')
            self.chip_nwce.clicked.connect(lambda: self.load(refresh=True))
            h.addWidget(self.chip_nwce)
            v.addWidget(bar)

            self.model = FirmsModel(self)
            self.proxy = FirmsFilter(self)
            self.proxy.setSourceModel(self.model)
            self.table = QTableView()
            self.table.setHorizontalHeader(GroupHeader([lbl for _k, lbl in COLUMNS], self.table))
            self.table.setModel(self.proxy)
            self.table.setSortingEnabled(True)
            self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
            self.table.setShowGrid(False)
            self.table.setWordWrap(False)
            self.table.verticalHeader().setVisible(False)
            self.table.verticalHeader().setDefaultSectionSize(30)
            hh = self.table.horizontalHeader()
            hh.setSectionResizeMode(QHeaderView.Interactive)
            hh.setStretchLastSection(True)
            hh.setDefaultAlignment(Qt.AlignLeft | Qt.AlignVCenter)
            widths = {'check': 32, 'name': 280, 'vat': 115, 'companies': 95, 'grade': 55, 'new_grade': 55, 'm_fin': 120,
                      'm_exp': 105, 'm_pay': 100, 'valid': 95, 'tbd': 60}
            for k, w in widths.items():
                self.table.setColumnWidth(COL[k], w)
            self.table.setItemDelegateForColumn(COL['result'], ChipDelegate(self.table, LEVEL_ROLE))
            self.table.setItemDelegateForColumn(COL['m_fin'], ComboDelegate([(x, x) for x in mapping.FINANCIAL_REPORTING_OPTIONS], self.table))
            self.table.setItemDelegateForColumn(COL['m_exp'], ComboDelegate(list(mapping.EXPERIENCE_OPTIONS.items()), self.table))
            self.table.setItemDelegateForColumn(COL['m_pay'], ComboDelegate(list(mapping.PAYMENT_OPTIONS.items()), self.table))
            self.table.setEditTriggers(QAbstractItemView.DoubleClicked | QAbstractItemView.SelectedClicked | QAbstractItemView.EditKeyPressed)
            self.model.edited.connect(self._criterion_edited)
            self.table.setContextMenuPolicy(Qt.CustomContextMenu)
            self.table.customContextMenuRequested.connect(self._menu)
            self.table.doubleClicked.connect(self._double_clicked)
            hh.sectionClicked.connect(self._header_clicked)
            self.model.dataChanged.connect(lambda *_: self._update_count())
            v.addWidget(self.table, 1)

            foot = QFrame()
            foot.setObjectName('footbar')
            fb = QHBoxLayout(foot)
            fb.setContentsMargins(14, 9, 14, 9)
            fb.setSpacing(12)
            self.lbl_count = QLabel('')
            self.lbl_count.setObjectName('muted')
            fb.addWidget(self.lbl_count)
            self.chk_inactive = QCheckBox('Arată și inactivii / CBT')
            self.chk_inactive.toggled.connect(self._filter)
            fb.addWidget(self.chk_inactive)
            fb.addStretch(1)
            self.chk_ar = QCheckBox('Annual Review (Word)')
            self.chk_ar.setToolTip('Bifat: după PDF și scorecard se face și Annual Review-ul de reînnoire (limitele noi = cele\n'
                                   'actuale din NWCE, pe toate companiile firmei), în același folder. Textele de completat sunt\n'
                                   'marcate [de completat].')
            self.chk_ar.toggled.connect(lambda _on: self._update_count())
            fb.addWidget(self.chk_ar)
            self.chk_new = QCheckBox('Raport Creditsafe nou')
            self.chk_new.setToolTip('Bifat: se descarcă un raport nou chiar dacă există unul din ultimele 30 de zile (consumă un raport).\n'
                                    'Nebifat: se refolosește raportul din ultimele 30 de zile, dacă există.')
            fb.addWidget(self.chk_new)
            self.act = QPushButton('')
            self.act.setObjectName('primary')
            self.act.clicked.connect(self.start)
            fb.addWidget(self.act)
            v.addWidget(foot)

            sb = self.statusBar()
            self.status = QLabel('Pornire...')
            sb.addWidget(self.status, 1)
            self.progress = QProgressBar()
            self.progress.setFixedWidth(220)
            self.progress.setMaximumHeight(14)
            self.progress.setTextVisible(False)
            sb.addPermanentWidget(self.progress)
            self.b_stop = QPushButton('Stop')
            self.b_stop.setEnabled(False)
            self.b_stop.clicked.connect(lambda: self.worker and self.worker.cancel())
            sb.addPermanentWidget(self.b_stop)
            self._update_count()

        def set_status(self, text, level='info'):
            color = {'ok': '#2E7D32', 'warn': '#A35F00', 'error': '#B3261E'}.get(level, '#17212C')
            self.status.setStyleSheet(f'padding:2px 6px;font-weight:600;color:{color}')
            self.status.setText(errors.short_text(text, 300))

        def _firm(self, proxy_index):
            return self.model.firms[self.proxy.mapToSource(proxy_index).row()] if proxy_index.isValid() else None

        def _visible(self):
            return [self.model.firms[self.proxy.mapToSource(self.proxy.index(i, 0)).row()] for i in range(self.proxy.rowCount())]

        def _checked(self):
            return [f for f in self.model.firms if f.checked]

        def _update_count(self):
            n = len(self._checked())
            self.lbl_count.setText(f'{n} bifați · {self.proxy.rowCount()} clienți în listă')
            what = 'PDF + scorecard + Annual Review' if self.chk_ar.isChecked() else 'PDF + scorecard'
            self.act.setText(f'Generează {what} ({n})' if n else 'Bifează clienții')
            self.act.setEnabled(n > 0 and not self._busy())

        def _header_clicked(self, col):
            if col == 0:                       # click pe antetul bifelor = bifeaza / debifeaza tot ce se vede
                vis = self._visible()
                val = not all(f.checked for f in vis) if vis else True
                for f in vis:
                    f.checked = val
                self.model.layoutChanged.emit()
                self._update_count()

        def _filter(self):
            self.proxy.text = self.f_text.text().strip()
            self.proxy.owner = self.f_list.currentData()
            self.proxy.show_inactive = self.chk_inactive.isChecked()
            self.proxy.invalidateFilter()
            self._update_count()

        def _fill_lists(self):
            owners = sorted({o for f in self.model.firms for o in f.owners})
            me = (self.cfg.get('analyst', 'initials') or '').upper()
            self.f_list.blockSignals(True)
            self.f_list.clear()
            if me in owners:
                self.f_list.addItem(f'Lista mea ({me})', me)
            self.f_list.addItem('Toți clienții din NWCE', None)
            for o in owners:
                if o != me:
                    self.f_list.addItem(f'TBD by {o}', o)
            self.f_list.setCurrentIndex(0)
            self.f_list.blockSignals(False)
            self._filter()

        # --- incarcare
        def _busy(self):
            return self.worker is not None

        def _run(self, fn, done, item=None):
            w = Worker(fn)
            w.progress.connect(self._progress)
            w.done.connect(lambda res: (self._end(), done(res)))
            w.failed.connect(self._failed)
            if item:
                w.item.connect(item)
            # firul se tine in viata pana la "finished" (altfel Qt opreste aplicatia: "QThread destroyed while running")
            self._threads = getattr(self, '_threads', set())
            self._threads.add(w)
            w.finished.connect(lambda w=w: self._threads.discard(w))
            self.worker = w
            self.model.locked = True
            self.act.setEnabled(False)
            self.b_stop.setEnabled(True)
            self.progress.setRange(0, 0)
            w.start()

        def _progress(self, text, n, total):
            self.set_status(text)
            if total and total > 0:
                self.progress.setRange(0, total)
                self.progress.setValue(max(0, n))

        def _end(self):
            self.b_stop.setEnabled(False)
            self.progress.setRange(0, 1)
            self.progress.setValue(0)
            self.worker = None
            self.model.locked = False
            self._update_count()

        def _failed(self, f):
            self._end()
            if f.get('code') == 'CANCELLED':
                self.set_status('Oprit.', 'warn')
                return
            self.set_status(f['title'], 'error')
            box = QMessageBox(QMessageBox.Warning, f['title'], f'<b>{f["title"]}</b><br><br>{f["action"]}', parent=self)
            box.setDetailedText(f.get('details') or '')
            box.exec_()

        def load(self, refresh=False):
            if self._busy():
                return

            def job(w):
                from . import portfolio
                w.report('Citesc NWCE' + (' de pe SharePoint (~20 s)...' if refresh else '...'))
                snap = limits_book.load(self.cfg, use_cache=not refresh)
                w.report('Citesc Open Contracts ITA (plăți și contracte, pentru criteriile 10 / 11)...')
                try:
                    pf = portfolio.load(self.cfg.portfolio_path, self.cfg, progress=w.report)
                except Exception as e:
                    _log.warning('Portfolio not loaded: %s', e)
                    pf = None
                firms = firms_from_nwce(snap, self.cfg)
                try:
                    attach_previous(firms, self.db.latest_evaluations(), pf, self.cfg)
                except Exception as e:          # fara rezultatele vechi: tabelul se vede oricum
                    _log.warning('Previous documents not attached: %s', e)
                return snap, pf, firms

            def done(res):
                checked = {f.key for f in self._checked()}
                current = {f.key: f.ev for f in self.model.firms if f.ev is not None}     # cele facute in sesiunea asta
                self.snap, self.portfolio, firms = res
                for f in firms:
                    f.checked = f.key in checked
                    f.ev = current.get(f.key, f.ev)
                self.model.load(firms)
                self._fill_lists()
                src = 'copie locală' if self.snap.from_cache else 'SharePoint'
                fresh = not self.snap.from_cache and self.snap.loaded_at.date() == dt.date.today()
                self.chip_nwce.set('ok' if fresh else 'info', 'NWCE la zi' if fresh else f'NWCE: copie {self.snap.loaded_at:%d.%m %H:%M}',
                                   f'{len(self.snap.rows)} rânduri din {src}. Click = recitește de pe SharePoint.')
                self.set_status(f'{len(firms)} clienți din NWCE. Bifează clienții și apasă „Generează PDF + scorecard”.', 'ok')

            self._run(job, done)

        # --- generare
        def start(self):
            firms = self._checked()
            if not firms or self._busy() or self.snap is None:
                return
            if not has_credentials(self.cfg):
                QMessageBox.information(self, 'Creditsafe', 'Lipsește parola Creditsafe. Deschide Credit Limits Tool → '
                                        'Setări → Parola Creditsafe, apoi încearcă din nou.')
                return
            names = '\n'.join(f'- {f.name}' for f in firms[:12]) + (f'\n... (+{len(firms) - 12})' if len(firms) > 12 else '')
            what = 'raportul Creditsafe (PDF), scorecardul și Annual Review-ul' if self.chk_ar.isChecked() else \
                'raportul Creditsafe (PDF) și scorecardul'
            if QMessageBox.question(self, 'Documente', f'Generez {what} pentru {len(firms)} clienți?\n\n'
                                    f'{names}\n\nSe salvează în folderul fiecărui client.') != QMessageBox.Yes:
                return
            cps = {}
            self._firm_of = {}
            self._chosen = {}
            for f in firms:
                cp = counterparty_for(f, self.portfolio, self.cfg)
                cps[cp.partner] = cp
                self._firm_of[cp.partner] = f
                if choices(f.ev):
                    self._chosen[cp.partner] = choices(f.ev)    # subiectivele alese de tine raman in scorecardul nou
                f.ev = None
                self.model.refresh_firm(f)

            def job(w):
                ctx = pipeline.Context(self.cfg, self.db, self.cs, self.snap, self.portfolio, progress=w.report, cancel=w.cancelled)
                w.report(f'Caut {len(cps)} clienți în Creditsafe...', 0, len(cps))
                return prepare_all(ctx, list(cps.values()), w.report)

            self._run(job, lambda preps: self._prepared(preps, cps))

        def _prepared(self, preps, cps):
            force = self.chk_new.isChecked()
            if needs_confirmation(preps):
                dlg = dialogs.PrepareDialog(self, preps, self.cs, None, self.cfg)
                if dlg.exec_() != QDialog.Accepted:
                    self.set_status('Anulat - nu s-a descărcat niciun raport.', 'warn')
                    return
                preps = dlg.selected()
                force = force or dlg.force_refresh()
            if not preps:
                return

            annual = self.chk_ar.isChecked()
            firm_of = dict(self._firm_of)
            chosen = dict(self._chosen)

            def job(w):
                ctx = pipeline.Context(self.cfg, self.db, self.cs, self.snap, self.portfolio, progress=w.report, cancel=w.cancelled)
                try:
                    results = generate(ctx, preps, cps, force, on_done=lambda ev: w.item.emit(ev), chosen=chosen)
                finally:
                    ctx.close()
                if annual:
                    from . import annual_review
                    w.report('Annual Review: citesc facturile (cifra de afaceri)...')
                    inv = annual_review.load_invoices(self.cfg)
                    annual_reviews(self.cfg, results, firm_of, cps, self.db, inv, w.report, on_done=lambda ev: w.item.emit(ev))
                return results

            def item(ev):
                f = self._firm_of.get(ev.partner)
                if f is not None:
                    f.ev = ev
                    self.model.refresh_firm(f)

            def done(results):
                for ev in results:
                    item(ev)
                ok = [ev for ev in results if ev.state in ('evaluated', 'evaluated_manual')]
                bad = [ev for ev in results if ev not in ok]
                self.set_status(f'Gata: {len(ok)} clienți cu documente în folderele lor' + (f', {len(bad)} cu eroare.' if bad else '.'),
                                'warn' if bad else 'ok')
                if bad:
                    QMessageBox.warning(self, 'Documente', 'Nu s-au putut face documentele pentru:\n\n' + '\n'.join(
                        f'- {ev.name}: {(ev.error or {}).get("title", "")}' for ev in bad[:15]))

            self._run(job, done, item)

        # --- folder / fisiere
        def _menu(self, pos):
            f = self._firm(self.table.indexAt(pos))
            if f is None:
                return
            files = (f.ev.files or {}) if f.ev else {}
            m = QMenu(self)
            m.addAction('Deschide folderul clientului', lambda: self.open_folder(f))
            a = m.addAction('Deschide scorecardul', lambda: dialogs.open_path(files.get('scorecard')))
            a.setEnabled(bool(files.get('scorecard')))
            a = m.addAction('Deschide PDF-ul Creditsafe', lambda: dialogs.open_path(files.get('pdf')))
            a.setEnabled(bool(files.get('pdf')))
            a = m.addAction('Deschide Annual Review', lambda: dialogs.open_path(files.get('annual_review')))
            a.setEnabled(bool(files.get('annual_review')))
            m.addSeparator()
            a = m.addAction('Refă Annual Review' if files.get('annual_review') else 'Fă Annual Review (cu scorecardul actual)',
                            lambda: self.redo_annual_review(f))
            a.setEnabled(bool(f.ev and f.ev.state in DONE_STATES) and not self._busy())
            m.exec_(self.table.viewport().mapToGlobal(pos))

        def _double_clicked(self, idx):
            if COLUMNS[self.proxy.mapToSource(idx).column()][0] in MANUAL_COLS:
                f = self._firm(idx)
                if f is not None and not can_edit(f.ev):
                    self.set_status(f'{f.name}: subiectivele se schimbă după ce are scorecard (generează PDF + scorecard).', 'warn')
                elif self._busy():
                    self.set_status('Se generează documente - subiectivele se pot schimba după ce se termină.', 'warn')
                return          # editarea criteriului (lista din celula)
            self.open_folder(self._firm(idx))

        def _criterion_edited(self, f, crit, value):
            """Criteriul ales in tabel: scris in scorecardul clientului, Excel recalculeaza grade-ul, fisierul se salveaza."""
            ev = f.ev
            QApplication.setOverrideCursor(QCursor(Qt.WaitCursor))
            self.set_status(f'{f.name}: recalculez scorecardul ({crit} = {value})...')
            QApplication.processEvents()
            try:
                old, res = set_criterion(ev, crit, value, excel=self._shared_excel())
                self.db.save_evaluation(ev)
                msg = f'{crit} = {value}: grade {old} → {res.get("grade")} ({res.get("points")} puncte) - salvat in scorecard'
                self.db.event(ev.id, ev.partner, 'INFO', 'Scorecard', msg)
                _log.info('[%s] %s', ev.partner, msg)
                stale = ' Annual Review-ul e de refăcut (click-dreapta).' if (ev.files or {}).get('annual_review_stale') else ''
                self.set_status(f'{f.name}: grade {old} → {res.get("grade")} ({res.get("points")} puncte), salvat în scorecard.{stale}', 'ok')
            except Exception as e:
                _log.exception('Live scorecard failed')
                self._close_shared_excel()
                self.set_status(f'{f.name}: criteriul nu s-a schimbat - scorecardul nu s-a putut recalcula.', 'warn')
                fr = errors.friendly(e)
                QMessageBox.warning(self, fr['title'], f'<b>{fr["title"]}</b><br><br>Alegerea nu s-a salvat (criteriul a rămas '
                                    f'cel de dinainte). {fr["action"]}')
            finally:
                QApplication.restoreOverrideCursor()
            self.model.refresh_firm(f)

        def _shared_excel(self):
            """O singura instanta Excel pentru modificarile din tabel (se inchide singura dupa 2 minute fara folosire)."""
            from .excel_com import ExcelApp
            xl = getattr(self, '_xl', None)
            if xl is not None:
                try:
                    _ = xl.xl.Version
                except Exception:
                    self._close_shared_excel()
                    xl = None
            if xl is None:
                self._xl = xl = ExcelApp(visible=False)
            if not hasattr(self, '_xl_timer'):
                self._xl_timer = QTimer(self)
                self._xl_timer.setSingleShot(True)
                self._xl_timer.timeout.connect(self._close_shared_excel)
            self._xl_timer.start(120_000)
            return xl

        def _close_shared_excel(self):
            xl, self._xl = getattr(self, '_xl', None), None
            if xl is not None:
                try:
                    xl.quit()
                except Exception as e:
                    _log.warning('Shared Excel quit: %s', e)

        def redo_annual_review(self, f):
            """Annual Review-ul refacut din scorecardul actual (dupa schimbarea subiectivelor), fara raport / scorecard nou."""
            if self._busy() or f.ev is None or self.snap is None:
                return
            self._close_shared_excel()          # scorecardul nu ramane deschis in Excel-ul comun
            ev = f.ev
            cp = counterparty_for(f, self.portfolio, self.cfg)

            def job(w):
                from . import annual_review
                w.report(f'Annual Review: {f.name} (citesc facturile)...')
                inv = annual_review.load_invoices(self.cfg)
                return annual_reviews(self.cfg, [ev], {ev.partner: f}, {ev.partner: cp}, self.db, inv, w.report)

            def done(_res):
                self.model.refresh_firm(f)
                err = (ev.files or {}).get('annual_review_error')
                self.set_status(f'{f.name}: Annual Review: {err}' if err else f'{f.name}: Annual Review refăcut (grade {ev.grade}).',
                                'warn' if err else 'ok')

            self._run(job, done)

        def open_folder(self, f):
            if f is None:
                return
            p = f.ev.dest_dir if f.ev and f.ev.dest_dir else None
            if not p:
                from . import client_folders
                res = client_folders.resolve_client_folder(self.cfg.counterparties_root, [f.name], f.name)
                p = str(res.path) if res.exists else self.cfg.counterparties_root
                if not res.exists:
                    self.set_status(f'{f.name}: nu are încă folder - se creează la prima generare.', 'warn')
            dialogs.open_path(p)

        def closeEvent(self, e):
            if self._busy():
                if QMessageBox.question(self, 'Închidere', 'Se generează documente. Opresc și închid?') != QMessageBox.Yes:
                    e.ignore()
                    return
                self.worker.cancel()
                if not self.worker.wait(30000):
                    QMessageBox.warning(self, 'Închidere', 'Pasul curent (Excel / Creditsafe) nu s-a oprit încă. Așteaptă și închide din nou.')
                    e.ignore()
                    return
            self._close_shared_excel()
            try:
                if hasattr(self.cs, 'close'):
                    self.cs.close()
            finally:
                self.db.close()
            e.accept()

    return DocsWindow


def main():
    from PyQt5.QtCore import QLocale, QLockFile, Qt
    from PyQt5.QtGui import QIcon
    from PyQt5.QtWidgets import QApplication, QMessageBox

    from .config import Config
    try:
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('Bunge.CreditLimitsTool.Documente')
    except Exception:
        pass
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)
    app = QApplication(sys.argv)
    app.setApplicationName('Documente client')
    icon = paths.APP_ROOT / 'assets' / 'bunge.ico'
    if icon.exists():
        app.setWindowIcon(QIcon(str(icon)))
    app.setStyle('Fusion')
    QLocale.setDefault(QLocale(QLocale.Romanian, QLocale.Romania))
    font = app.font()
    font.setFamily('Segoe UI')
    font.setPointSizeF(9)
    app.setFont(font)
    logger = log.setup()
    paths.ensure_dirs()
    lock = QLockFile(str(paths.LOCAL_DIR / 'documente.lock'))
    lock.setStaleLockTime(0)
    if not lock.tryLock(200):
        QMessageBox.information(None, 'Documente client', 'Aplicația este deja deschisă.')
        return 0

    def excepthook(etype, value, tb):
        logger.error('Unhandled exception:\n%s', ''.join(traceback.format_exception(etype, value, tb)))
        try:
            f = errors.friendly(value)
            QMessageBox.warning(None, f['title'], f'{f["title"]}\n\n{f["action"]}')
        except Exception:
            pass
    sys.excepthook = excepthook
    try:
        cfg = Config.load()
    except Exception as e:
        QMessageBox.critical(None, 'Documente client', f'config.json nu poate fi citit:\n{e}')
        return 1
    w = _ui()(cfg)
    w.show()
    logger.info('Documente client started')
    rc = app.exec_()
    lock.unlock()
    return rc


if __name__ == '__main__':
    sys.exit(main())
