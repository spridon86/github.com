"""Client HTTP cu doua motoare: `requests` si WinHTTP (stack-ul Windows).

Reteaua Bunge inspecteaza o parte din traficul HTTPS cu un certificat intern pe care Python (certifi)
nu il cunoaste. WinHTTP foloseste depozitul de certificate Windows, ca Edge si PowerShell.
La o eroare SSL cu `requests`, hostul respectiv trece automat pe WinHTTP.
"""
import json as _json
import threading
from urllib.parse import urlencode

import requests

from . import log

_log = log.get('http')


class Response:
    def __init__(self, status, content, content_type=''):
        self.status = status
        self.content = content or b''
        self.content_type = content_type or ''

    @property
    def ok(self):
        return 200 <= self.status < 300

    @property
    def text(self):
        return self.content.decode('utf-8', errors='replace')

    def json(self):
        return _json.loads(self.content.decode('utf-8-sig'))


class Http:
    def __init__(self, timeout=90):
        self.timeout = timeout
        self._local = threading.local()
        self._winhttp_hosts = set()

    def _session(self):
        s = getattr(self._local, 'session', None)
        if s is None:
            s = requests.Session()
            self._local.session = s
        return s

    def request(self, method, url, params=None, headers=None, json_body=None, timeout=None):
        if params:
            q = urlencode({k: v for k, v in params.items() if v not in (None, '')})
            if q:
                url = f'{url}{"&" if "?" in url else "?"}{q}'
        host = url.split('/')[2]
        timeout = timeout or self.timeout
        if host not in self._winhttp_hosts:
            try:
                r = self._session().request(method, url, headers=headers, json=json_body, timeout=timeout)
                return Response(r.status_code, r.content, r.headers.get('Content-Type', ''))
            except requests.exceptions.SSLError as e:
                _log.warning('SSL error with requests for %s (%s) - switching to WinHTTP', host, e)
                self._winhttp_hosts.add(host)
        return self._winhttp(method, url, headers, json_body, timeout)

    @staticmethod
    def _winhttp(method, url, headers, json_body, timeout):
        import pythoncom
        import win32com.client
        pythoncom.CoInitialize()
        h = win32com.client.Dispatch('WinHttp.WinHttpRequest.5.1')
        ms = int(timeout * 1000)
        h.SetTimeouts(ms, ms, ms, ms)
        h.Open(method, url, False)
        for k, v in (headers or {}).items():
            h.SetRequestHeader(k, v)
        try:
            if json_body is not None:
                h.SetRequestHeader('Content-Type', 'application/json; charset=utf-8')
                h.Send(_json.dumps(json_body))
            else:
                h.Send()
        except Exception as e:   # com_error: 0x80072EE2 timeout, 0x80072EE7 nume negasit...
            raise ConnectionError(f'WinHttp {method} {url.split("?")[0]} failed: {e}') from e
        body = h.ResponseBody
        content = bytes(body) if body is not None else b''
        try:
            ctype = h.GetResponseHeader('Content-Type')
        except Exception:
            ctype = ''
        return Response(int(h.Status), content, ctype)


_default = None


def default():
    global _default
    if _default is None:
        _default = Http()
    return _default
