"""Ferestrele de dialog: pregatire evaluare, decizie, confirmare modificari, setari, import SAP, parola."""
import datetime as dt
import html
import os
from pathlib import Path

from PyQt5.QtCore import QDate, Qt
from PyQt5.QtWidgets import (QAbstractItemView, QCheckBox, QComboBox, QDateEdit, QDialog, QDialogButtonBox,
                             QDoubleSpinBox, QFileDialog, QFormLayout, QGridLayout, QGroupBox, QHBoxLayout,
                             QLabel, QLineEdit, QMessageBox, QPlainTextEdit, QPushButton, QSpinBox,
                             QTableWidget, QTableWidgetItem, QTabWidget, QTextBrowser, QVBoxLayout, QWidget)

from .. import limits_book, mapping, rules
from .models import fmt_date, fmt_money

PAYMENT_TERMS = ['After Delivery', 'Before Delivery', 'Prepayment', 'Due Immediately', '1 Day', '2 Days', '3 Days', '4 Days',
                 '5 Days', '7 Days', 'Max. 10 Days', 'Max. 15 Days', 'Max. 30 Days', 'Max. 40 Days', 'Max. 45 Days',
                 'Max. 50 Days', 'Max. 60 Days', 'Max. 70 Days', 'Max. 80 Days', 'Max. 90 Days', 'Max. 100 Days',
                 'Max. 110 Days', 'Max. 120 Days', 'Max. 140 Days', 'Max. 160 Days', 'CAD', 'CAD 2 Days', 'CAD 3 Days',
                 'CAD 5 Days', 'CAD 7 Days', 'CAD 10 Days', 'CAD 15 Days', 'CAD 30 Days', 'CAD 60 days', 'CAFD']
APPROVAL_LEVELS = ['LOCAL', 'BEMEA', 'BBS', 'GLOBAL', 'PL Office', 'BLC Office', 'GVA Office', 'UA Office', 'TR Office',
                   'BEATA', 'USA Office', 'BNA Office', 'BMA Office']
GRADINGS = [str(i) for i in range(1, 12)] + ['Intuitive 8', 'Intuitive 9', 'Intuitive 10']
NWCE_FIELDS = [('open_kloc', 'Open limit K EUR'), ('open_kusd', 'Open limit KUSD'), ('mtm_kusd', 'MTM limit KUSD'),
               ('grading', 'Grading'), ('payment_term', 'Payment Term'), ('approval_level', 'Approval level'),
               ('approved_on', 'Approved on'), ('valid_till', 'Valid till'), ('analyst', 'Analyst'),
               ('comments', 'Comments'), ('tbd_by', 'TBD by = Done')]


def _qdate(d):
    if isinstance(d, str):
        d = dt.date.fromisoformat(d[:10])
    return QDate(d.year, d.month, d.day)


def _pydate(q):
    return dt.date(q.year(), q.month(), q.day())


def _esc(v):
    return html.escape('' if v is None else str(v))


def open_path(p):
    if p and os.path.exists(p):
        os.startfile(p)
        return True
    return False


class TableDialog(QDialog):
    """Lista de confirmare (ex. modificarile NWCE): text + tabel + OK/Anuleaza."""

    def __init__(self, parent, title, intro, headers, rows, ok_text='Continua', danger=False):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(1100, 560)
        lay = QVBoxLayout(self)
        lbl = QLabel(intro)
        lbl.setWordWrap(True)
        lay.addWidget(lbl)
        t = QTableWidget(len(rows), len(headers))
        t.setHorizontalHeaderLabels(headers)
        t.setEditTriggers(QAbstractItemView.NoEditTriggers)
        t.verticalHeader().setVisible(False)
        for i, row in enumerate(rows):
            for j, v in enumerate(row):
                it = QTableWidgetItem('' if v is None else str(v))
                t.setItem(i, j, it)
        t.resizeColumnsToContents()
        t.horizontalHeader().setStretchLastSection(True)
        lay.addWidget(t)
        bb = QDialogButtonBox()
        ok = bb.addButton(ok_text, QDialogButtonBox.AcceptRole)
        if danger:
            ok.setStyleSheet('background:#C62828;color:white;font-weight:bold;padding:6px 14px;')
        else:
            ok.setStyleSheet('background:#2E7D32;color:white;font-weight:bold;padding:6px 14px;')
        bb.addButton('Anuleaza', QDialogButtonBox.RejectRole)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)


# ---------------------------------------------------------------- aprobare pe alt canal
class ExternalApprovalDialog(QDialog):
    """Necesita aprobare -> aprobarea a venit pe alt canal (manager / EMEA / global): cine a aprobat, cand si daca decizia
    se transcrie si in SAP (in SAP modificarea porneste din nou workflow-ul de aprobare)."""

    def __init__(self, parent, rows, approver, write_sap_default):
        super().__init__(parent)
        self.setWindowTitle('Inregistreaza aprobarea')
        self.resize(1000, 520)
        lay = QVBoxLayout(self)
        lbl = QLabel('Decizia a fost aprobata pe alt canal. Limitele de mai jos (cele din „La aprobare”) se scriu in NWCE '
                     'cu nivelul de aprobare corespunzator; alegi daca se transcriu si in SAP.')
        lbl.setWordWrap(True)
        lay.addWidget(lbl)
        headers = ['Client', 'Companie', 'Open nou', 'MTM nou USD', 'Grade', 'Total USD', 'Aproba']
        t = QTableWidget(len(rows), len(headers))
        t.setHorizontalHeaderLabels(headers)
        t.setEditTriggers(QAbstractItemView.NoEditTriggers)
        t.verticalHeader().setVisible(False)
        for i, row in enumerate(rows):
            for j, v in enumerate(row):
                t.setItem(i, j, QTableWidgetItem('' if v is None else str(v)))
        t.resizeColumnsToContents()
        t.horizontalHeader().setStretchLastSection(True)
        lay.addWidget(t)
        f = QFormLayout()
        self.by = QLineEdit(approver)
        f.addRow('Aprobat de:', self.by)
        self.on = QDateEdit(QDate.currentDate())
        self.on.setCalendarPopup(True)
        self.on.setDisplayFormat('dd.MM.yyyy')
        self.on.setMaximumDate(QDate.currentDate())
        f.addRow('Data aprobarii (Approved on):', self.on)
        self.comment = QLineEdit()
        self.comment.setPlaceholderText(f'optional - se scrie in NWCE la "Comments" (ex. "Approved by {approver or "..."}, '
                                        f'email {dt.date.today():%d.%m.%Y}")')
        f.addRow('Comentariu NWCE:', self.comment)
        self.sap = QCheckBox('Transcrie si in SAP')
        self.sap.setChecked(bool(write_sap_default))
        f.addRow('', self.sap)
        hint = QLabel('Nebifat: decizia se scrie doar in NWCE, iar clientul trece în „Gata” cu SAP netranscris - '
                      'aprobarea e deja data, iar in SAP modificarea ar porni din nou workflow-ul de aprobare.\n'
                      'Bifat: dupa NWCE se trimite si in SAP (ca la deciziile din autoritatea ta).')
        hint.setWordWrap(True)
        hint.setStyleSheet('color:#555')
        f.addRow('', hint)
        lay.addLayout(f)
        bb = QDialogButtonBox()
        ok = bb.addButton(f'Aprobat - scrie {len(rows)} in NWCE', QDialogButtonBox.AcceptRole)
        ok.setStyleSheet('background:#2E7D32;color:white;font-weight:bold;padding:6px 14px;')
        bb.addButton('Anuleaza', QDialogButtonBox.RejectRole)
        bb.accepted.connect(self._ok)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)
        self.sap.toggled.connect(lambda on: ok.setText(f'Aprobat - scrie {len(rows)} in NWCE' + (' + SAP' if on else '')))

    def _ok(self):
        if not self.by.text().strip():
            QMessageBox.information(self, 'Aprobare', 'Completeaza cine a aprobat.')
            return
        self.accept()

    def values(self):
        return {'by': self.by.text().strip(), 'on': _pydate(self.on.date()), 'comment': self.comment.text().strip(),
                'write_sap': self.sap.isChecked()}


# ---------------------------------------------------------------- pregatire evaluare
class PrepareDialog(QDialog):
    """Dupa cautarea gratuita in Creditsafe: ce firma s-a gasit, ce vine din cache, cate credite se consuma."""

    def __init__(self, parent, preps, cs_client, credits, cfg):
        super().__init__(parent)
        self.preps, self.cs, self.cfg = preps, cs_client, cfg
        self.setWindowTitle('Pregatire evaluare - confirma firmele si creditele Creditsafe')
        self.resize(1250, 600)
        lay = QVBoxLayout(self)
        self.info = QLabel()
        self.info.setWordWrap(True)
        lay.addWidget(self.info)
        self.t = QTableWidget(len(preps), 6)
        self.t.setHorizontalHeaderLabels(['Include', 'Client (portofoliu)', 'VAT', 'Firma Creditsafe', 'Raport', 'Observatii'])
        self.t.verticalHeader().setVisible(False)
        self.combos, self.checks = [], []
        for i, ev in enumerate(preps):
            chk = QCheckBox()
            chk.setChecked(ev.state == 'prepared')
            chk.stateChanged.connect(self._update)
            w = QWidget()
            hl = QHBoxLayout(w)
            hl.addWidget(chk)
            hl.setAlignment(Qt.AlignCenter)
            hl.setContentsMargins(0, 0, 0, 0)
            self.t.setCellWidget(i, 0, w)
            self.checks.append(chk)
            self.t.setItem(i, 1, QTableWidgetItem(f'{ev.name} [{ev.partner}]'))
            self.t.setItem(i, 2, QTableWidgetItem(ev.vat or '-'))
            cb = QComboBox()
            for c in ev.cs_candidates:
                from ..pipeline import is_registered
                mark = '✔ ' if is_registered(c) else '✖ radiata - '
                cb.addItem(f'{mark}{c.get("name")} | {c.get("id")} | {c.get("city") or ""} | {c.get("status") or ""} | bilant {c.get("latestAccounts") or "-"}', c.get('id'))
            if ev.connect_id:
                idx = cb.findData(ev.connect_id)
                if idx >= 0:
                    cb.setCurrentIndex(idx)
            if ev.cs_candidates and not ev.connect_id:
                cb.insertItem(0, '-- alege firma --', None)
                cb.setCurrentIndex(0)
            cb.currentIndexChanged.connect(lambda _i, row=i: self._choose(row))
            if not ev.cs_candidates:
                cb.addItem('(nicio firma gasita)', None)
                cb.setEnabled(False)
            self.t.setCellWidget(i, 3, cb)
            self.combos.append(cb)
            self.t.setItem(i, 4, QTableWidgetItem(''))
            obs = ev.error['title'] + ' - ' + ev.error['details'] if ev.error else '; '.join(ev.warnings)
            it = QTableWidgetItem(obs)
            it.setToolTip(obs)
            self.t.setItem(i, 5, it)
        self.t.resizeColumnsToContents()
        self.t.setColumnWidth(3, 520)
        self.t.horizontalHeader().setStretchLastSection(True)
        lay.addWidget(self.t)
        self.chk_refresh = QCheckBox('Descarca rapoarte noi chiar daca exista in cache (consuma credite)')
        self.chk_refresh.stateChanged.connect(self._update)
        lay.addWidget(self.chk_refresh)
        self.credits = credits
        bb = QDialogButtonBox()
        self.ok = bb.addButton('Porneste evaluarea', QDialogButtonBox.AcceptRole)
        self.ok.setStyleSheet('background:#2E7D32;color:white;font-weight:bold;padding:6px 14px;')
        bb.addButton('Anuleaza', QDialogButtonBox.RejectRole)
        bb.accepted.connect(self._accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)
        self._update()

    def _choose(self, row):
        ev = self.preps[row]
        cid = self.combos[row].currentData()
        if cid:
            ev.connect_id = cid
            ev.state = 'prepared'
            ev.error = None
            self.checks[row].setChecked(True)
        self._update()

    def _update(self):
        force = self.chk_refresh.isChecked()
        need = 0
        for i, ev in enumerate(self.preps):
            ok = ev.state == 'prepared' and ev.connect_id
            self.checks[i].setEnabled(bool(ok))
            if not ok:
                self.checks[i].setChecked(False)
            cached = ok and not force and self.cs.cached(ev.connect_id)
            if not ok:
                txt = ''
            elif cached:
                txt = 'din cache (gratuit) ' + cached['fetched'].strftime('%d.%m.%Y')
            elif ev.charge is False:
                txt = 'deja cumparat pe site (gratuit)'
            else:
                txt = 'consuma 1 raport (daca nu e deschis recent pe site)'
            self.t.item(i, 4).setText(txt)
            if ok and self.checks[i].isChecked() and not cached and ev.charge is not False:
                need += 1
        sel = sum(1 for c in self.checks if c.isChecked())
        cr = self.credits
        if cr and cr.get('expires'):
            cred = f'{cr["left"]:,} rapoarte ramase din {cr["paid"]:,} (expira {cr["expires"]:%d.%m.%Y})'.replace(',', '.')
        else:
            cred = f'{cr["left"]} rapoarte ramase' if cr else 'rapoarte ramase necunoscute'
        msg = (f'<b>{sel}</b> clienti selectati. Rapoarte noi de descarcat: <b>{need}</b>. Creditsafe: {cred}.<br>'
               'Cautarea in Creditsafe nu a consumat credite. Verifica firma gasita pentru fiecare client (lista derulanta).')
        if cr and need > cr['left']:
            msg += f'<br><span style="color:#C62828"><b>ATENTIE: nu sunt destule credite ({need} necesare, {cr["left"]} ramase).</b></span>'
        self.info.setText(msg)
        self.ok.setEnabled(sel > 0)

    def _accept(self):
        for i, ev in enumerate(self.preps):
            if not self.checks[i].isChecked():
                ev.state = 'skipped'
        self.accept()

    def selected(self):
        return [ev for ev in self.preps if ev.state == 'prepared']

    def force_refresh(self):
        return self.chk_refresh.isChecked()


# ---------------------------------------------------------------- decizie
class DecisionDialog(QDialog):
    REGENERATE = 2

    def __init__(self, parent, ev, cp, cfg, eur_usd, nwce_snapshot, dropdowns=None, group=None):
        super().__init__(parent)
        from ..pipeline import default_decision
        self.ev, self.cp, self.cfg, self.eur_usd = ev, cp, cfg, eur_usd
        self.group = group or []
        ccy = ev.currency or 'EUR'
        self.nwce = nwce_snapshot
        self.overrides = None
        dd = dropdowns or {}
        self.setWindowTitle(f'Decizie limita - {ev.customer_name or ev.name} [{ev.customer_code or "-"}] - {ev.company_code} ({ccy})')
        self.resize(1400, 860)
        d = dict(ev.decision) if ev.decision else default_decision(_Ctx(cfg), ev, eur_usd)
        self._kusd_manual = False

        main = QHBoxLayout(self)
        # --- stanga: tot ce stim despre client
        self.info = QTextBrowser()
        self.info.setOpenLinks(False)
        self.info.anchorClicked.connect(lambda url: open_path(url.toLocalFile() or url.toString()))
        self.info.setHtml(self._info_html())
        main.addWidget(self.info, 3)

        # --- dreapta: decizia
        right = QVBoxLayout()
        main.addLayout(right, 2)
        g = QGroupBox('Limita noua')
        f = QFormLayout(g)
        self.limit = QSpinBox()
        self.limit.setRange(0, 2_000_000_000)
        self.limit.setSingleStep(5000)
        self.limit.setGroupSeparatorShown(True)
        self.limit.setSuffix(f' {ccy}')
        self.limit.setValue(int(d.get('limit_eur') or 0))
        prop = (ev.proposal or {}).get('proposed')
        hl = QHBoxLayout()
        hl.addWidget(self.limit, 1)
        b = QPushButton(f'Propunerea ({fmt_money(prop)})')
        b.clicked.connect(lambda: self.limit.setValue(int(prop or 0)))
        hl.addWidget(b)
        b2 = QPushButton(f'Curenta ({fmt_money(cp.limit)})')
        b2.clicked.connect(lambda: self.limit.setValue(int(cp.limit or 0)))
        hl.addWidget(b2)
        f.addRow(f'Limita ({ccy}):', hl)
        self.rate = QDoubleSpinBox()
        self.rate.setDecimals(6 if ccy != 'EUR' else 4)
        self.rate.setRange(0.0, 10.0)
        self.rate.setSingleStep(0.01 if ccy == 'EUR' else 0.0001)
        self.rate.setValue(float(d.get('eur_usd') or eur_usd or 0))
        f.addRow(f'USD pentru 1 {ccy} (BCE):', self.rate)
        self.kloc = QDoubleSpinBox()
        self.kloc.setRange(0, 10_000_000)
        self.kloc.setDecimals(1)
        self.kloc.setGroupSeparatorShown(True)
        self.kloc.setEnabled(False)
        f.addRow(f'Open limit K {ccy} (NWCE):', self.kloc)
        self.kusd = QSpinBox()
        self.kusd.setRange(0, 10_000_000)
        self.kusd.setGroupSeparatorShown(True)
        self.kusd.setValue(int(d.get('open_kusd') or 0))
        self.kusd.valueChanged.connect(self._kusd_edited)
        f.addRow('Open limit KUSD (NWCE):', self.kusd)
        self.mtm = QSpinBox()
        self.mtm.setRange(0, 10_000_000)
        self.mtm.setGroupSeparatorShown(True)
        try:
            self.mtm.setValue(int(float(d.get('mtm_kusd') or 0)))
        except (TypeError, ValueError):
            pass
        f.addRow('MTM limit KUSD:', self.mtm)
        self.term = QComboBox()
        self.term.setEditable(True)
        self.term.addItems(dd.get('payment_term') or PAYMENT_TERMS)
        self.term.setCurrentText(str(d.get('payment_term') or ''))
        f.addRow('Payment Term:', self.term)
        self.grading = QComboBox()
        self.grading.setEditable(True)
        self.grading.addItems(dd.get('grading') or GRADINGS)
        gval = d.get('grading')
        self.grading.setCurrentText('' if gval is None else (str(int(gval)) if isinstance(gval, float) and gval.is_integer() else str(gval)))
        f.addRow('Grading:', self.grading)
        self.level = QComboBox()
        self.level.setEditable(True)
        self.level.addItems(dd.get('approval_level') or APPROVAL_LEVELS)
        self.level.setCurrentText(str(d.get('approval_level') or ''))
        f.addRow('Approval level:', self.level)
        self.auth_lbl = QLabel()
        self.auth_lbl.setWordWrap(True)
        f.addRow('Cine aproba:', self.auth_lbl)
        self.approved = QDateEdit(_qdate(d['approved_on']))
        self.approved.setCalendarPopup(True)
        self.approved.setDisplayFormat('dd.MM.yyyy')
        self.approved.dateChanged.connect(self._approved_changed)
        f.addRow('Approved on:', self.approved)
        self.valid = QDateEdit(_qdate(d['valid_till']))
        self.valid.setCalendarPopup(True)
        self.valid.setDisplayFormat('dd.MM.yyyy')
        f.addRow('Valid till (NWCE + SAP):', self.valid)
        self.comments = QLineEdit(str(d.get('comments') or ''))
        f.addRow('Comments:', self.comments)
        right.addWidget(g)

        # --- randul NWCE
        g2 = QGroupBox('Randul din excelul NWCE')
        v2 = QVBoxLayout(g2)
        self.row_combo = QComboBox()
        cands, _how = nwce_snapshot.candidates(ev.partner, ev.vat, cfg.get('limitsBook', 'companyCode'), cfg.get('portfolio', 'country')) if nwce_snapshot else ([], '')
        for r in cands:
            self.row_combo.addItem(r.label(), r.sheet_row)
        self.row_combo.addItem('Rand NOU in tabel (client nou in NWCE)', -1)
        cur_row = int(d.get('sheet_row') or 0)
        if d.get('new_row'):
            self.row_combo.setCurrentIndex(self.row_combo.count() - 1)
        elif cur_row:
            i = self.row_combo.findData(cur_row)
            if i >= 0:
                self.row_combo.setCurrentIndex(i)
        v2.addWidget(self.row_combo)
        grid = QGridLayout()
        self.field_checks = {}
        for i, (k, label) in enumerate(NWCE_FIELDS):
            c = QCheckBox(label)
            c.setChecked(k in d.get('fields', []))
            self.field_checks[k] = c
            grid.addWidget(c, i // 3, i % 3)
        v2.addLayout(grid)
        self.chk_inact = QCheckBox('Inactiveaza clientul pe acest rand: 0 in Payment Term si limite, Approved on / Valid till goale '
                                   '(STATUS INACTIVE; managerul il trimite la inactivare)')
        self.chk_inact.setStyleSheet('color:#C62828')
        self.chk_inact.setChecked(bool((ev.decision or {}).get('inactivate')))
        v2.addWidget(self.chk_inact)
        right.addWidget(g2)

        # --- criterii scorecard
        g3 = QGroupBox('Criterii subiective scorecard (schimba si regenereaza)')
        f3 = QFormLayout(g3)
        inp = ev.inputs or {}
        self.c_exp = QComboBox()
        for k, lbl in mapping.EXPERIENCE_OPTIONS.items():
            self.c_exp.addItem(lbl, k)
        self._set_combo(self.c_exp, (inp.get('experience') or {}).get('grade'))
        f3.addRow('10. Experience:', self.c_exp)
        self.c_pay = QComboBox()
        for k, lbl in mapping.PAYMENT_OPTIONS.items():
            self.c_pay.addItem(lbl, k)
        self._set_combo(self.c_pay, (inp.get('payment') or {}).get('grade'))
        f3.addRow('11. Payments Behavior:', self.c_pay)
        self.c_fin = QComboBox()
        for k in mapping.FINANCIAL_REPORTING_OPTIONS:
            self.c_fin.addItem(k, k)
        self._set_combo(self.c_fin, inp.get('financial_reporting') or cfg.get('scorecard', 'financialReporting'))
        f3.addRow('9. Financial Reporting:', self.c_fin)
        regen = QPushButton('Regenereaza scorecardul cu aceste criterii (din cache, fara credite)')
        regen.clicked.connect(self._regenerate)
        f3.addRow(regen)
        right.addWidget(g3)

        right.addStretch(1)
        bb = QDialogButtonBox()
        self.ok = bb.addButton('Aproba decizia', QDialogButtonBox.AcceptRole)
        self.ok.setStyleSheet('background:#2E7D32;color:white;font-weight:bold;padding:8px 18px;')
        if ev.state == 'approved':
            un = bb.addButton('Retrage aprobarea', QDialogButtonBox.DestructiveRole)
            un.clicked.connect(self._unapprove)
        bb.addButton('Inchide', QDialogButtonBox.RejectRole)
        bb.accepted.connect(self._approve)
        bb.rejected.connect(self.reject)
        right.addWidget(bb)

        self.limit.valueChanged.connect(self._recalc)
        self.rate.valueChanged.connect(self._recalc)
        self._recalc(initial=True)
        for w in (self.kusd, self.mtm):
            w.valueChanged.connect(self._update_auth)
        self.grading.currentTextChanged.connect(self._update_auth)
        self._update_auth(initial=not ev.decision)
        self.unapproved = False
        if ev.state not in ('evaluated', 'evaluated_manual', 'approved', 'done'):
            self.ok.setEnabled(False)

    @staticmethod
    def _set_combo(cb, data):
        i = cb.findData(data)
        if i >= 0:
            cb.setCurrentIndex(i)

    def _kusd_edited(self):
        if not getattr(self, '_recalculating', False):
            self._kusd_manual = True

    def _recalc(self, *_a, initial=False):
        lim = self.limit.value()
        self.kloc.setValue(rules.k_local(lim))
        if not (initial and self.ev.decision) and not self._kusd_manual:
            self._recalculating = True
            self.kusd.setValue(int(rules.k_usd(lim, self.rate.value(), self.cfg.get('limitsBook', 'kusdRounding'))))
            self._recalculating = False

    def _update_auth(self, *_a, initial=False):
        """Grade vs limita totala necesara (USD) pe tot grupul / clientul -> nivelul de aprobare."""
        others = sum(g.kusd for g in self.group if g.cp is not self.cp) * 1000
        n = self.cp_row_nwce()
        cur_open = float(n.get('open_kusd') or 0) if n else 0.0
        cur_mtm = float(n.get('mtm_kusd') or 0) if n else 0.0
        cur_total = float(n.get('total_kusd') or 0) if n else 0.0
        other_here = max(0.0, cur_total - cur_open - cur_mtm) * 1000
        total = others + (self.kusd.value() + self.mtm.value()) * 1000 + other_here
        a = rules.approval_authority(self.grading.currentText(), total, self.cfg)
        if a is None:
            self.auth_lbl.setText('<span style="color:#777">alege grading-ul</span>')
            return
        color = '#C62828' if (a.no_trade or a.exceeds_all) else ('#2E7D32' if a.name == self.cfg.get('approval', 'analystRow') else '#9C5700')
        scope = 'grup' if len(self.group) > 1 else 'client'
        self.auth_lbl.setText(f'<span style="color:{color}"><b>{a.text()}</b></span><br><small>total {scope} (toate tarile / firmele)</small>')
        if initial and a.nwce_level:
            self.level.setCurrentText(a.nwce_level)

    def cp_row_nwce(self):
        for g in self.group:
            if g.cp is self.cp:
                return g.nwce
        return None

    def _approved_changed(self, q):
        self.valid.setDate(_qdate(rules.valid_till(_pydate(q), int(self.cfg.get('limitsBook', 'validityMonths')))))

    def _regenerate(self):
        self.overrides = {'experience': self.c_exp.currentData(), 'payment': self.c_pay.currentData(),
                          'financial_reporting': self.c_fin.currentData()}     # 14. Country Rating nu se schimba din tool
        self.done(self.REGENERATE)

    def _unapprove(self):
        self.unapproved = True
        self.done(QDialog.Accepted)

    def _approve(self):
        if self.chk_inact.isChecked():
            if self.row_combo.currentData() in (None, -1):
                QMessageBox.warning(self, 'Inactivare', 'Alege randul NWCE care se inactiveaza.')
                return
            if QMessageBox.question(self, 'Inactivare', 'Clientul va fi INACTIVAT in NWCE pe randul ales (se scrie automat, imediat dupa aprobare). Continui?') != QMessageBox.Yes:
                return
            self.accept()
            return
        lim = self.limit.value()
        msgs = []
        if lim > 0 and self.kusd.value() == 0 and self.field_checks.get('open_kusd') is not None and self.field_checks['open_kusd'].isChecked():
            QMessageBox.warning(self, 'Decizie', 'Open limit KUSD este 0 (lipseste cursul de schimb?). Completeaza cursul sau KUSD-ul '
                                'inainte de aprobare - altfel in NWCE s-ar scrie 0 KUSD langa limita noua.')
            return
        if lim == 0:
            msgs.append('Limita este 0.')
        if self.valid.date() <= self.approved.date():
            QMessageBox.warning(self, 'Decizie', 'Valid till trebuie sa fie dupa Approved on.')
            return
        cap = (self.ev.proposal or {}).get('cap')
        if cap is not None and lim > cap:
            msgs.append(f'Limita depaseste plafonul din equity ({fmt_money(cap)} EUR).')
        if self.ev.grade and self.ev.grade >= int(self.cfg.get('limitPolicy', 'gradeWarningFrom')):
            msgs.append(f'Gradul scorecardului este {self.ev.grade} (risc ridicat).')
        if self.row_combo.currentData() is None:
            msgs.append('Nu exista rand NWCE - nu se va putea scrie in NWCE.')
        if msgs and QMessageBox.question(self, 'Confirma decizia', 'Atentie:\n- ' + '\n- '.join(msgs) + '\n\nAprobi totusi?') != QMessageBox.Yes:
            return
        self.accept()

    def decision(self):
        row = self.row_combo.currentData()
        if self.chk_inact.isChecked():
            from ..pipeline import inactivation_decision
            d = inactivation_decision(_Ctx(self.cfg), self.ev, self.comments.text().strip())
            d['sheet_row'] = 0 if row in (None, -1) else int(row)
            return d
        g = self.grading.currentText().strip()
        return {
            'limit_eur': self.limit.value(),
            'eur_usd': round(self.rate.value(), 4),
            'open_kloc': self.kloc.value() if not float(self.kloc.value()).is_integer() else int(self.kloc.value()),
            'open_kusd': self.kusd.value(),
            'mtm_kusd': self.mtm.value(),
            'payment_term': self.term.currentText().strip(),
            'approval_level': self.level.currentText().strip(),
            'grading': int(g) if g.isdigit() else g,
            'approved_on': _pydate(self.approved.date()).isoformat(),
            'valid_till': _pydate(self.valid.date()).isoformat(),
            'comments': self.comments.text().strip(),
            'fields': [k for k, c in self.field_checks.items() if c.isChecked()],
            'sheet_row': 0 if row in (None, -1) else int(row),
            'new_row': row == -1,
            'approved_at': dt.datetime.now().isoformat(timespec='seconds'),
        }

    def _info_html(self):
        return client_info_html(self.ev, self.cp, group=self.group)


def _status_style(status):
    from .widgets import nwce_status_colors
    c = nwce_status_colors(status)
    return f' style="background:{c[0]};color:{c[1]}"' if c else ''


def _group_html(group, current=None):
    """Limitele clientului pe toate companiile / tarile din NWCE - se aduna. Daca randurile sunt din mai multe firme
    (acelasi "Group of companies"), tabelul arata firma pe fiecare rand si doua totaluri: clientul si grupul."""
    if not group:
        return ''
    cur_row = next((g for g in group if current is not None and g.cp is current), None)
    cur_client = cur_row.client if cur_row is not None else None
    firms = {g.client for g in group}
    multi = len(firms) > 1
    gname = next((g.group_name for g in group if g.group_name), '')
    title = (f'Limite in grupul {_esc(gname or "de firme")} - {len(firms)} firme (se aduna)' if multi
             else 'Limite pe toate companiile (se aduna)')
    h = [f'<h3>{title}</h3><table cellpadding=3 border=1 style="border-collapse:collapse">',
         '<tr style="background:#DDEBF7"><th width=110 nowrap>Companie</th><th nowrap>Status</th><th>TBD</th><th nowrap>K loc.</th>'
         '<th nowrap>Open KUSD</th><th nowrap>MTM KUSD</th><th nowrap>Total KUSD</th><th width=95 nowrap>Valid till</th><th>Grading</th></tr>']
    total = client_total = 0.0
    # cu mai multe firme: numele firmei e un rand-titlu pe toata latimea, deasupra randurilor ei (o coloana separata
    # ar fi strinsa de panoul ingust la o litera pe rand - Qt nu respecta nowrap in tabele)
    order = list(dict.fromkeys(g.client for g in group))
    rows = sorted(group, key=lambda g: order.index(g.client)) if multi else group
    last_client = object()
    for g in rows:
        n = g.nwce
        if multi and g.client != last_client:
            last_client = g.client
            mine = g.client == cur_client
            h.append(f'<tr style="background:{"#FFE699" if mine else "#EEF1F5"}"><td colspan=9><b>{_esc((n.name if n else "") or g.cp.name)}</b>'
                     f'{" &nbsp;(clientul selectat)" if mine else ""}</td></tr>')
        v = (lambda k: limits_book.display(k, n.get(k)) if n else '')
        total += g.kusd
        if g.client == cur_client:
            client_total += g.kusd
        if current is not None and g.cp is current:
            style = ' style="font-weight:bold;background:#FFF2CC"'
        elif multi and g.client == cur_client:
            style = ' style="background:#FFF9E6"'          # aceeasi firma, alta companie / tara
        else:
            style = ''
        ccy = f' {g.cp.currency}' if n and g.cp.currency != 'EUR' else ''
        h.append(f'<tr{style}><td nowrap>{_esc(n.company_code if n else "(fara rand NWCE)")}</td><td nowrap{_status_style(v("status"))}>{_esc(v("status"))}</td>'
                 f'<td>{_esc(g.cp.tbd)}</td><td align=right nowrap>{_esc(v("open_kloc"))}{_esc(ccy)}</td><td align=right nowrap>{_esc(v("open_kusd"))}</td>'
                 f'<td align=right nowrap>{_esc(v("mtm_kusd"))}</td><td align=right nowrap><b>{_esc(v("total_kusd"))}</b></td>'
                 f'<td nowrap>{_esc(v("valid_till"))}</td><td>{_esc(v("grading"))}</td></tr>')
    span = 6
    if multi and cur_client is not None:
        h.append(f'<tr style="background:#FFF2CC"><td colspan={span} nowrap><b>Total client</b> (doar firma selectata)</td>'
                 f'<td align=right nowrap><b>{fmt_money(client_total)}</b></td><td colspan=2></td></tr>')
    h.append(f'<tr style="background:#DDEBF7"><td colspan={span} nowrap><b>{"TOTAL grup" if multi else "TOTAL client"}</b></td>'
             f'<td align=right nowrap><b>{fmt_money(total)}</b></td><td colspan=2></td></tr></table>')
    if multi:
        h.append('<p><small>Firmele din acelasi "Group of companies" se evalueaza impreuna: autoritatea de aprobare se calculeaza '
                 'pe TOTAL grup. Expunerea din Open Contracts ITA se refera doar la randul de Italia al fiecarei firme.</small></p>')
    elif len(group) > 1:
        h.append('<p><small>Expunerea din Open Contracts ITA se refera doar la randul de Italia.</small></p>')
    return ''.join(h)


def client_info_html(ev, cp, nwce_row=None, group=None):
    """Tot ce stim despre client, ca HTML (panoul de detalii si fereastra de decizie)."""
    if ev is None:
        return _portfolio_html(cp, nwce_row) + _group_html(group, cp)
    cs = ev.cs or {}
    sc = ev.scorecard or {}
    p = ev.proposal or {}
    h = [f'<h2 style="margin:0">{_esc(ev.customer_name or ev.name)}</h2>',
         f'<p>Customer Code <b>{_esc(ev.customer_code or "-")}</b> | VAT <b>{_esc(ev.vat)}</b> | Creditsafe <b>{_esc(ev.connect_id)}</b>'
         + (f' | BU {_esc(cp.business_unit)} | {_esc(cp.purchase_sale)}' if cp.source == 'portfolio' else '') + '</p>']
    if ev.error:
        h.append(f'<p style="background:#FFC7CE;padding:6px"><b>{_esc(ev.error["title"])}</b><br>{_esc(ev.error["action"])}<br><small>{_esc(ev.error["details"])}</small></p>')
    if ev.decision and ev.state in ('approved', 'done'):
        # scrierea in NWCE / SAP: bifa verde daca s-a scris, X rosu daca nu (detaliile mai jos)
        def mark(label, st, extra=''):
            s = (st or {}).get('status')
            if s == 'ok':
                return f'<span style="background:#C6EFCE;color:#1B5E20;padding:3px 8px"><b>✔ {label}</b>{extra}</span>'
            if s in ('error', 'dry_error'):
                return f'<span style="background:#FFC7CE;color:#9C0006;padding:3px 8px"><b>✖ {label} - nescris</b></span>'
            return f'<span style="background:#EEF1F5;color:#33404D;padding:3px 8px">… {label} in curs</span>'
        case = (ev.sap or {}).get('case_number')
        sap_txt = mark('SAP', ev.sap, f' (caz {_esc(case)})' if case else '') if not (ev.decision or {}).get('inactivate') else ''
        ext = (ev.decision or {}).get('external_approval')
        if (ev.decision or {}).get('sap_skip') and (ev.sap or {}).get('status') != 'ok':
            sap_txt = ('<span style="background:#ECEFF1;color:#455A64;padding:3px 8px"><b>— SAP netranscris</b> '
                       '(aprobat pe alt canal)</span>')
        if ext:
            sap_txt += f' &nbsp; <small>aprobat de <b>{_esc(ext.get("by"))}</b> la {fmt_date(ext.get("on"))}</small>'
        h.append(f'<p style="font-size:10pt">{mark("NWCE", ev.nwce)} &nbsp; {sap_txt}</p>')
    h.append('<h3>Propunere</h3>')
    ccy = _esc(ev.currency or 'EUR')
    h.append(f'<p>Companie <b>{_esc(ev.company_code)}</b> | moneda limitei <b>{ccy}</b></p>')
    h.append(f'<p style="font-size:11pt">Limita curenta <b>{fmt_money(cp.limit)}</b> {ccy} &rarr; propus <b style="color:#2E7D32">{fmt_money(p.get("proposed"))}</b> {ccy}</p><ul>')
    h += [f'<li>{_esc(x)}</li>' for x in p.get('lines', [])]
    h.append('</ul>')
    for w in p.get('warnings', []):
        h.append(f'<p style="background:#FFEB9C;padding:4px">&#9888; {_esc(w)}</p>')
    h.append('<h3>Scorecard</h3>')
    if sc:
        h.append(f'<p style="font-size:10.5pt">Grad <b>{_esc(sc.get("grade"))}</b> | {_esc(sc.get("scale"))} | {_esc(sc.get("points"))} puncte</p>')
        h.append('<table cellpadding=3 border=0>')
        inp = ev.inputs or {}
        why = {'10. Experience': (inp.get('experience') or {}).get('why'), '11. Payments Behavior': (inp.get('payment') or {}).get('why')}
        for k, v in (sc.get('criteria') or {}).items():
            h.append(f'<tr><td>{_esc(k)}</td><td align=right><b>{_esc(v)}</b></td><td><small>{_esc(why.get(k, ""))}</small></td></tr>')
        h.append('</table>')
        h.append(f'<p>Ani bilant: {_esc(sc.get("years"))} | Venit USD: {_esc(sc.get("revenue_usd"))} | Equity USD: {_esc(sc.get("equity_usd"))} | Current ratio: {_esc(sc.get("current_ratio"))} | Curs: {_esc(sc.get("fx_rate"))}</p>')
    else:
        h.append('<p>Fara scorecard calculat (fara bilant / eroare).</p>')
    h.append('<h3>Creditsafe</h3>')
    h.append(f'<p>{_esc(cs.get("name"))} | status <b>{_esc(cs.get("status"))}</b> | rating <b>{_esc(cs.get("rating_common"))}</b> ({_esc(cs.get("rating_score"))}/100) {_esc(cs.get("rating_desc"))}<br>'
             f'Limita Creditsafe: <b>{fmt_money(cs.get("cs_limit"))} {_esc(cs.get("cs_limit_currency"))}</b> | infiintata {fmt_date(cs.get("incorporated"))} | '
             f'ultimul bilant {fmt_date(cs.get("latest_year_end"))} ({_esc(cs.get("currency"))})<br>'
             f'Venit {fmt_money(cs.get("revenue"))} | Profit net {fmt_money(cs.get("profit_after_tax"))} | Capitaluri proprii <b>{fmt_money(cs.get("equity"))}</b> | Active {fmt_money(cs.get("total_assets"))}<br>'
             f'Raport {"din cache" if ev.report_from_cache else "descarcat"} la {fmt_date(ev.report_fetched)}</p>')
    h.append('<h3>Expunere (Open Contracts)</h3>')
    h.append(f'<p>Varf <b>{fmt_money(cp.peak_exposure)}</b> ({_esc(cp.peak_week)}) = {cp.peak_vs_limit or 0:.2f}x limita | '
             f'{cp.weeks_over} saptamani / {cp.months_over} luni peste limita | prima depasire {_esc(cp.first_breach_week or cp.first_breach_month)}<br>'
             f'Total commitment {fmt_money(cp.total_commitment)} | ultimul contract {fmt_date(cp.last_contract)} | MTM limit SAP {fmt_money(cp.mtm_limit)} | '
             f'restante {fmt_money(cp.overdue_amount)} | creante {fmt_money(cp.receivables)}</p>')
    pb = cp.payment
    if pb:
        h.append('<h3>Comportament de plata</h3>')
        h.append(f'<p>Risk score <b>{pb.risk_score or 0:.0f}</b> {_esc(pb.trend)} {_esc(pb.trend_text)} | prioritate {_esc(pb.priority)} | '
                 f'intarziere {_esc(pb.days_late_text)} | restanta cea mai veche {pb.oldest_overdue_days or 0:.0f} zile | '
                 f'sold net {fmt_money(pb.net_open_balance)}<br><small>{_esc(pb.key_drivers)}</small></p>')
    vals = (ev.nwce_row or {}).get('values') or {}
    h.append('<h3>NWCE acum</h3>')
    if vals:
        keys = ['status', 'grading', 'payment_term', 'open_kloc', 'open_kusd', 'mtm_kusd', 'total_kusd', 'approved_on', 'valid_till', 'approval_level', 'analyst', 'bp_code']
        h.append('<table cellpadding=2>' + ''.join(f'<tr><td>{_esc(limits_book.LABELS.get(k, k))}</td><td><b>{_esc(limits_book.display(k, vals.get(k)))}</b></td></tr>' for k in keys) + '</table>')
    else:
        h.append(f'<p>{_esc((ev.nwce_row or {}).get("how") or "Nu exista in NWCE")}</p>')
    if ev.warnings:
        h.append('<h3>De verificat</h3><ul>' + ''.join(f'<li>{_esc(w)}</li>' for w in ev.warnings) + '</ul>')
    d = ev.decision or {}
    if d:
        h.append('<h3>Decizie</h3>')
        h.append(f'<p>Limita aprobata <b>{fmt_money(d.get("limit_eur"))} EUR</b> ({_esc(d.get("open_kloc"))} K EUR / {_esc(d.get("open_kusd"))} KUSD, '
                 f'curs {_esc(d.get("eur_usd"))}) | grading {_esc(d.get("grading"))} | valid till {fmt_date(d.get("valid_till"))} | '
                 f'{_esc(d.get("payment_term"))} | aprobat {fmt_date(d.get("approved_at"))}</p>')
    for label, st in (('NWCE', ev.nwce), ('SAP', ev.sap)):
        if st:
            color = '#C6EFCE' if st.get('status') in ('ok', 'dry_ok') else '#FFC7CE'
            extra = ''
            if st.get('before') or st.get('after'):
                extra = '<br><small>inainte: ' + _esc(', '.join(f'{k}={v}' for k, v in (st.get('before') or {}).items())) + \
                        ' | dupa: ' + _esc(', '.join(f'{k}={v}' for k, v in (st.get('after') or {}).items())) + '</small>'
            shots = ''.join(f' <a href="file:///{_esc(s)}">[captura]</a>' for s in st.get('screenshots') or [])
            h.append(f'<p style="background:{color};padding:4px"><b>{label}</b> ({fmt_date(st.get("at"))} {_esc(str(st.get("at", ""))[11:16])}): {_esc(st.get("message"))}{shots}{extra}</p>')
    files = ev.files or {}
    if files or ev.dest_dir:
        links = [f'<a href="file:///{_esc(v)}">{_esc(Path(v).name)}</a>' for v in files.values() if v]
        if ev.dest_dir:
            links.append(f'<a href="file:///{_esc(ev.dest_dir)}">Folder: {_esc(ev.dest_dir)}</a>')
        h.append('<h3>Fisiere</h3><p>' + '<br>'.join(links) + '</p>')
    h.append(_group_html(group, cp))
    return ''.join(h)


def _portfolio_html(cp, nwce_row):
    h = [f'<h2 style="margin:0">{_esc(cp.name)}</h2>',
         f'<p>Customer Code <b>{_esc(cp.customer_code or "-")}</b> | VAT <b>{_esc(cp.vat or "-")}</b>'
         + (f' | BU {_esc(cp.business_unit)} | {_esc(cp.purchase_sale)}' if cp.source == 'portfolio' else '')
         + f'{" | grup " + _esc(cp.group) if cp.group else ""}</p>']
    if cp.block_reason or cp.blocked_cm:
        h.append(f'<p style="background:#EEEEEE;padding:4px">Blocaj: {_esc(cp.block_reason or cp.block_reason_cm or "blocat in Credit Management")}</p>')
    v = limits_book.validity(nwce_row)
    if v == 'valid':
        h.append(f'<p style="color:#1B5E20"><b>✔ Limita e APPROVED si valabila pana la {_esc(limits_book.display("valid_till", nwce_row.get("valid_till")))} '
                 '- nimic de facut.</b> (Se poate reevalua oricum, daca e nevoie.)</p>')
    elif v == 'inactive':
        h.append('<p style="color:#78909C"><b>Client INACTIV in NWCE - nimic de facut.</b></p>')
    else:
        st = (nwce_row.get('status') if nwce_row is not None else '') or 'fara rand NWCE'
        h.append(f'<p style="color:#8A4B00"><b>De evaluat</b> (STATUS {_esc(st)}) - butonul albastru "Evalueaza acest client".</p>')
    if cp.source != 'portfolio':
        h.append(f'<h3>Expunere</h3><p>Companie <b>{_esc(cp.company_code)}</b> ({_esc(cp.currency)}) - expunerea din Open Contracts ITA '
                 'exista doar pentru Italia; pentru acest rand nu se calculeaza.</p>')
    else:
        h.append('<h3>Expunere (Open Contracts)</h3>')
    if cp.source == 'portfolio':
        h.append(f'<p>Companie <b>{_esc(cp.company_code or "")}</b> | limita curenta <b>{fmt_money(cp.limit)}</b> {_esc(cp.currency)} | varf <b>{fmt_money(cp.peak_exposure)}</b> ({_esc(cp.peak_week)}) = {cp.peak_vs_limit or 0:.2f}x | '
             f'{cp.weeks_over} saptamani / {cp.months_over} luni peste limita | prima depasire {_esc(cp.first_breach_week or cp.first_breach_month)}<br>'
             f'Total commitment {fmt_money(cp.total_commitment)} | ultimul contract {fmt_date(cp.last_contract)} | primul contract deschis {fmt_date(cp.first_contract)}<br>'
             f'MTM limit {fmt_money(cp.mtm_limit)} | restante {fmt_money(cp.overdue_amount)} | creante {fmt_money(cp.receivables)} | validitate scor SAP {fmt_date(cp.score_validity)}</p>')
    if cp.data_quality:
        h.append(f'<p><small>Calitatea datelor: {_esc(cp.data_quality)}</small></p>')
    pb = cp.payment
    if pb:
        h.append('<h3>Comportament de plata</h3>')
        h.append(f'<p>Risk score <b>{pb.risk_score or 0:.0f}</b> {_esc(pb.trend)} {_esc(pb.trend_text)} | prioritate {_esc(pb.priority)} | '
                 f'intarziere {_esc(pb.days_late_text)} | restanta cea mai veche {pb.oldest_overdue_days or 0:.0f} zile | sold net {fmt_money(pb.net_open_balance)}'
                 f'<br><small>{_esc(pb.key_drivers)}</small></p>')
    h.append('<h3>NWCE acum</h3>')
    if nwce_row is not None:
        keys = ['status', 'grading', 'payment_term', 'open_kloc', 'open_kusd', 'mtm_kusd', 'total_kusd', 'approved_on', 'valid_till', 'approval_level', 'analyst', 'bp_code']
        h.append(f'<p><small>{_esc(nwce_row.label())}</small></p><table cellpadding=2>' + ''.join(
            f'<tr><td>{_esc(limits_book.LABELS.get(k, k))}</td><td><b>{_esc(limits_book.display(k, nwce_row.get(k)))}</b></td></tr>' for k in keys) + '</table>')
    else:
        h.append('<p>Nu a fost gasit in NWCE pentru compania configurata (sau NWCE necitit).</p>')
    return ''.join(h)


class _Ctx:
    def __init__(self, cfg):
        self.cfg = cfg


# ---------------------------------------------------------------- setari
class SettingsDialog(QDialog):
    def __init__(self, parent, cfg):
        super().__init__(parent)
        self.cfg = cfg
        self.setWindowTitle('Setari')
        self.resize(900, 640)
        lay = QVBoxLayout(self)
        tabs = QTabWidget()
        lay.addWidget(tabs)
        self.w = {}

        def line(key_path, width=None):
            e = QLineEdit(str(cfg.get(*key_path) or ''))
            self.w[key_path] = e
            return e

        def browse(edit, folder=False, filt='Excel (*.xlsx *.xlsm)'):
            b = QPushButton('...')
            b.setFixedWidth(30)

            def go():
                if folder:
                    p = QFileDialog.getExistingDirectory(self, 'Alege folderul', edit.text())
                else:
                    p, _ = QFileDialog.getOpenFileName(self, 'Alege fisierul', edit.text(), filt)
                if p:
                    edit.setText(os.path.normpath(p))
            b.clicked.connect(go)
            hl = QHBoxLayout()
            hl.addWidget(edit, 1)
            hl.addWidget(b)
            return hl

        # general
        t = QWidget()
        f = QFormLayout(t)
        f.addRow('Initiale analist (NWCE "Analyst", scorecard):', line(('analyst', 'initials')))
        f.addRow('Nume analist:', line(('analyst', 'name')))
        self.mode = QComboBox()
        self.mode.addItem('Website app.creditsafe.com (user + parola de pe site)', 'web')
        self.mode.addItem('Creditsafe Connect API (cont API separat)', 'api')
        self.mode.setCurrentIndex(max(0, self.mode.findData(cfg.get('creditsafe', 'mode') or 'web')))
        f.addRow('Conectare Creditsafe:', self.mode)
        f.addRow('Utilizator website Creditsafe:', line(('creditsafeWeb', 'username')))
        self.w[('creditsafeWeb', 'headless')] = QCheckBox('Edge invizibil (devine vizibil doar daca login-ul cere ceva neasteptat)')
        self.w[('creditsafeWeb', 'headless')].setChecked(bool(cfg.get('creditsafeWeb', 'headless')))
        f.addRow('', self.w[('creditsafeWeb', 'headless')])
        self.env = QComboBox()
        self.env.addItems(['production', 'sandbox'])
        self.env.setCurrentText(cfg['environment'])
        f.addRow('Doar pentru API - mediu:', self.env)
        f.addRow('Doar pentru API - utilizator:', line(('username',)))
        f.addRow('Rapoarte refolosite din cache (zile):', self._spin(('creditsafe', 'cacheDays'), 0, 365))
        self.w[('creditsafe', 'downloadPdf')] = QCheckBox('Descarca si PDF-ul Creditsafe (ca din portal)')
        self.w[('creditsafe', 'downloadPdf')].setChecked(bool(cfg.get('creditsafe', 'downloadPdf')))
        f.addRow('', self.w[('creditsafe', 'downloadPdf')])
        from .group_dialog import VARIANTS
        self.gvar = QComboBox()
        for k, label in VARIANTS.items():
            self.gvar.addItem(label, k)
        self.gvar.setCurrentIndex(max(0, self.gvar.findData(cfg.get('ui', 'groupDialogVariant', default='clasic'))))
        f.addRow('Fereastra evaluare grup:', self.gvar)
        tabs.addTab(t, 'General')

        # fisiere
        t = QWidget()
        f = QFormLayout(t)
        f.addRow('Fisierul cu clienti (Open Contracts):', browse(line(('portfolio', 'path'))))
        f.addRow('Foaie optionala cu lista de evaluat:', line(('portfolio', 'evaluationSheet')))
        f.addRow('Folderele clientilor:', browse(line(('counterpartiesRoot',)), folder=True))
        f.addRow('Excel limite NWCE (URL SharePoint):', line(('limitsBook', 'url')))
        f.addRow('Company code in NWCE:', line(('limitsBook', 'companyCode')))
        f.addRow('Sablon scorecard:', browse(line(('scorecard', 'template'))))
        f.addRow('Nume fisier scorecard:', line(('scorecard', 'fileName')))
        tabs.addTab(t, 'Fisiere')

        # reguli
        t = QWidget()
        f = QFormLayout(t)
        f.addRow('Buffer peste varful de expunere (%):', self._dspin(('limitPolicy', 'exposureBuffer'), 0, 2, pct=True))
        self.w[('limitPolicy', 'useEquityCap')] = QCheckBox('Plafoneaza limita la un procent din capitalurile proprii')
        self.w[('limitPolicy', 'useEquityCap')].setChecked(bool(cfg.get('limitPolicy', 'useEquityCap')))
        f.addRow('', self.w[('limitPolicy', 'useEquityCap')])
        f.addRow('Plafon din equity (%):', self._dspin(('limitPolicy', 'equityCapPct'), 0, 5, pct=True))
        f.addRow('Avertisment de la gradul:', self._spin(('limitPolicy', 'gradeWarningFrom'), 1, 11))
        self.w[('limitPolicy', 'keepCurrentIfHigher')] = QCheckBox('Nu propune scaderea limitei existente')
        self.w[('limitPolicy', 'keepCurrentIfHigher')].setChecked(bool(cfg.get('limitPolicy', 'keepCurrentIfHigher')))
        f.addRow('', self.w[('limitPolicy', 'keepCurrentIfHigher')])
        f.addRow('Valabilitate limita (luni):', self._spin(('limitsBook', 'validityMonths'), 1, 36))
        f.addRow('Rotunjire KUSD:', self._spin(('limitsBook', 'kusdRounding'), 1, 1000))
        f.addRow('Plati: A pana la (zile intarziere):', self._spin(('paymentBehaviour', 'maxDaysA'), 0, 365))
        f.addRow('Plati: B pana la:', self._spin(('paymentBehaviour', 'maxDaysB'), 0, 365))
        f.addRow('Plati: D pana la (peste = E):', self._spin(('paymentBehaviour', 'maxDaysD'), 0, 365))
        f.addRow('Experienta: A de la (ani):', self._dspin(('experience', 'A'), 0, 100))
        f.addRow('Experienta: B de la:', self._dspin(('experience', 'B'), 0, 100))
        f.addRow('Experienta: C de la:', self._dspin(('experience', 'C'), 0, 100))
        f.addRow('Experienta: D de la:', self._dspin(('experience', 'D'), 0, 100))
        tabs.addTab(t, 'Reguli')

        # SAP
        t = QWidget()
        f = QFormLayout(t)
        f.addRow('Sistem SAP (gol = prima sesiune):', line(('sap', 'systemName')))
        f.addRow('Sablon SAP:', browse(line(('sap', 'template')), filt='JSON (*.json)'))
        self.w[('sap', 'afterExternalApproval')] = QCheckBox('Decizii aprobate pe alt canal (manager / EMEA / global): "Transcrie in SAP" '
                                                             'bifat implicit\n(in SAP modificarea porneste din nou workflow-ul de aprobare)')
        self.w[('sap', 'afterExternalApproval')].setChecked(bool(cfg.get('sap', 'afterExternalApproval')))
        f.addRow('', self.w[('sap', 'afterExternalApproval')])
        tabs.addTab(t, 'SAP')

        bb = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        bb.accepted.connect(self._save)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)

    def _spin(self, key, lo, hi):
        s = QSpinBox()
        s.setRange(lo, hi)
        s.setValue(int(self.cfg.get(*key) or 0))
        self.w[key] = s
        return s

    def _dspin(self, key, lo, hi, pct=False):
        s = QDoubleSpinBox()
        s.setDecimals(2)
        if pct:
            s.setRange(lo * 100, hi * 100)
            s.setValue(float(self.cfg.get(*key) or 0) * 100)
            s.setSuffix(' %')
            s.setProperty('pct', True)
        else:
            s.setRange(lo, hi)
            s.setValue(float(self.cfg.get(*key) or 0))
        self.w[key] = s
        return s

    def _save(self):
        for key, wdg in self.w.items():
            if isinstance(wdg, QLineEdit):
                val = wdg.text().strip()
            elif isinstance(wdg, QCheckBox):
                val = wdg.isChecked()
            elif isinstance(wdg, QDoubleSpinBox):
                val = wdg.value() / 100 if wdg.property('pct') else wdg.value()
            else:
                val = wdg.value()
            self.cfg.set(val, *key)
        self.cfg.set(self.env.currentText(), 'environment')
        self.cfg.set(self.mode.currentData(), 'creditsafe', 'mode')
        self.cfg.set(self.gvar.currentData(), 'ui', 'groupDialogVariant')
        self.cfg.save()
        self.accept()


# ---------------------------------------------------------------- parola
class PasswordDialog(QDialog):
    def __init__(self, parent, cfg):
        super().__init__(parent)
        web = (cfg.get('creditsafe', 'mode') or 'web') == 'web'
        self.setWindowTitle('Creditsafe - login app.creditsafe.com' if web else f'Creditsafe API - parola ({cfg["environment"]})')
        f = QFormLayout(self)
        self.user = QLineEdit((cfg.get('creditsafeWeb', 'username') or 'ionut.spridon@bunge.com') if web else cfg['username'])
        self.pwd = QLineEdit()
        self.pwd.setEchoMode(QLineEdit.Password)
        f.addRow('Utilizator:', self.user)
        f.addRow('Parola:', self.pwd)
        note = ('Userul si parola cu care intri pe app.creditsafe.com.\n' if web else '') + \
            'Parola se salveaza criptat in Windows Credential Manager, doar pentru utilizatorul tau Windows.'
        f.addRow(QLabel(note))
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        f.addRow(bb)


# ---------------------------------------------------------------- import SAP
class SapImportDialog(QDialog):
    def __init__(self, parent, cfg, nwce_snapshot):
        super().__init__(parent)
        from .. import sap_gui
        self.sap_gui, self.cfg, self.nwce = sap_gui, cfg, nwce_snapshot
        self.tpl = None
        self.setWindowTitle('Import inregistrare SAP (.vbs)')
        self.resize(950, 720)
        lay = QVBoxLayout(self)
        intro = QLabel(
            '<b>Cum inregistrezi (o singura data):</b><ol>'
            '<li>In SAP: <i>Customize Local Layout</i> (Alt+F12) &rarr; <i>Script Recording and Playback...</i> &rarr; alege fisierul de salvare &rarr; butonul rosu (Record).</li>'
            '<li>Fa o actualizare reala pentru UN client in <b>ZBEU_UKM_BP_CREDIT_L</b>: F4 la BP &rarr; cauta dupa Customer &rarr; Score, Validity Score, '
            '(Equity Scenario daca e cazul) &rarr; Open Limit + MTM &amp; PFE limit + data in grila &rarr; <b>rotita dintata</b> &rarr; '
            'Approve &rarr; comentariu &#10003; &rarr; atasamente &#10003; &rarr; SCase Created &#10003;.</li>'
            '<li>Opreste inregistrarea si importa fisierul .vbs aici. Completeaza mai jos exact valorile pe care le-ai tastat.</li></ol>'
            'Aplicatia inlocuieste aceste valori cu datele fiecarui client. Inainte de prima rulare reala foloseste <b>Proba</b>.')
        intro.setWordWrap(True)
        lay.addWidget(intro)
        f = QFormLayout()
        self.file = QLineEdit()
        b = QPushButton('Alege .vbs...')
        b.clicked.connect(self._browse)
        hl = QHBoxLayout()
        hl.addWidget(self.file, 1)
        hl.addWidget(b)
        f.addRow('Fisier inregistrat:', hl)
        self.cust = QLineEdit()
        self.cust.setPlaceholderText('ex. 76021671')
        self.cust.editingFinished.connect(self._lookup_bp)
        f.addRow('Customer Code al clientului folosit:', self.cust)
        self.bp = QLineEdit()
        self.bp.setPlaceholderText('completat automat din NWCE (BP code)')
        f.addRow('BP tastat in SAP:', self.bp)
        self.limit = QLineEdit()
        self.limit.setPlaceholderText('ex. 850000 (suma tastata, fara separatori)')
        f.addRow('Limita tastata:', self.limit)
        self.valid = QDateEdit(QDate.currentDate())
        self.valid.setCalendarPopup(True)
        self.valid.setDisplayFormat('dd.MM.yyyy')
        self.chk_valid = QCheckBox('am tastat si o data de valabilitate:')
        hl2 = QHBoxLayout()
        hl2.addWidget(self.chk_valid)
        hl2.addWidget(self.valid, 1)
        f.addRow('Valid to:', hl2)
        self.grade = QLineEdit()
        self.grade.setPlaceholderText('optional - daca ai tastat si scorul / gradul')
        f.addRow('Scor tastat:', self.grade)
        self.mtm = QLineEdit()
        self.mtm.setPlaceholderText('ex. 200000 (MTM & PFE limit tastata, USD)')
        f.addRow('MTM tastat:', self.mtm)
        self.equity = QCheckBox('am bifat Equity Scenario')
        f.addRow('Equity:', self.equity)
        self.comment = QLineEdit()
        self.comment.setPlaceholderText('textul exact scris la "Add comments" (optional)')
        f.addRow('Comentariu tastat:', self.comment)
        lay.addLayout(f)
        bt = QPushButton('Analizeaza inregistrarea')
        bt.clicked.connect(self._analyze)
        lay.addWidget(bt)
        self.report = QPlainTextEdit()
        self.report.setReadOnly(True)
        lay.addWidget(self.report, 1)
        bb = QDialogButtonBox()
        self.save = bb.addButton('Salveaza sablonul', QDialogButtonBox.AcceptRole)
        self.save.setEnabled(False)
        bb.addButton('Anuleaza', QDialogButtonBox.RejectRole)
        bb.accepted.connect(self._save)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)

    def _browse(self):
        p, _ = QFileDialog.getOpenFileName(self, 'Inregistrarea SAP', os.path.expanduser('~\\Documents'), 'SAP GUI script (*.vbs);;Toate (*.*)')
        if p:
            self.file.setText(os.path.normpath(p))

    def _lookup_bp(self):
        if not self.nwce or self.bp.text().strip():
            return
        rows = self.nwce.by_code.get(self.cust.text().strip(), [])
        for r in rows:
            bp = limits_book._code(r.get('bp_code'))
            if bp:
                self.bp.setText(bp)
                return

    def _analyze(self):
        try:
            text = self.sap_gui.read_vbs(self.file.text())
        except OSError as e:
            QMessageBox.warning(self, 'Import SAP', f'Fisierul nu poate fi citit: {e}')
            return
        samples = {'bp': self.bp.text().strip() or None, 'customer_code': self.cust.text().strip() or None}
        lim = self.limit.text().replace('.', '').replace(',', '').replace(' ', '').strip()
        if lim.isdigit():
            samples['limit'] = int(lim)
        if self.chk_valid.isChecked():
            samples['valid_to'] = _pydate(self.valid.date())
        if self.grade.text().strip():
            samples['grade'] = self.grade.text().strip()
        mtm = self.mtm.text().replace('.', '').replace(',', '').replace(' ', '').strip()
        if mtm.isdigit():
            samples['mtm'] = int(mtm)
        if self.equity.isChecked():
            samples['equity'] = True
        if self.comment.text().strip():
            samples['comment'] = self.comment.text().strip()
        try:
            self.tpl, rep = self.sap_gui.build_template(text, samples, Path(self.file.text()).name)
        except Exception as e:
            self.tpl = None
            self.report.setPlainText(f'Eroare: {e}')
            self.save.setEnabled(False)
            return
        steps = '\n'.join(f'{i + 1:3}. {s["op"]:4} {s["name"]:<14} {s.get("value", s.get("args", ""))!s:<20} {s["id"]}'
                          for i, s in enumerate(self.tpl['steps']))
        self.report.setPlainText(rep + '\n\nPasi:\n' + steps)
        self.save.setEnabled('limit' in self.tpl.get('formats', {}) or any('{limit}' == s.get('value') for s in self.tpl['steps']))

    def _save(self):
        p = self.sap_gui.save_template(self.cfg, self.tpl)
        QMessageBox.information(self, 'Import SAP', f'Sablon salvat: {p}\n\nFoloseste intai "SAP - proba" pe un client.')
        self.accept()
