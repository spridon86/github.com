import datetime as dt

from creditapp import rules
from creditapp.portfolio import PaymentBehaviour


def pb(**kw):
    base = dict(recent_invoices=10, baseline_invoices=30, recent_days_late=2, baseline_days_late=3, oldest_overdue_days=0, payment_returns=0)
    base.update(kw)
    return PaymentBehaviour(**base)


def test_payment_grade_thresholds(cfg):
    assert rules.payment_grade(None, cfg)[0] == 'C'
    assert rules.payment_grade(pb(recent_invoices=1, baseline_invoices=1), cfg)[0] == 'C'
    assert rules.payment_grade(pb(recent_days_late=5), cfg)[0] == 'A'
    assert rules.payment_grade(pb(recent_days_late=5.1), cfg)[0] == 'B'
    assert rules.payment_grade(pb(recent_days_late=15), cfg)[0] == 'B'
    assert rules.payment_grade(pb(recent_days_late=30), cfg)[0] == 'D'
    assert rules.payment_grade(pb(recent_days_late=60), cfg)[0] == 'E'


def test_payment_grade_uses_baseline_when_few_recent(cfg):
    g, why = rules.payment_grade(pb(recent_invoices=1, recent_days_late=90, baseline_days_late=4), cfg)
    assert g == 'A' and '12 luni' in why


def test_payment_grade_downgrades_on_old_overdue_or_returns(cfg):
    assert rules.payment_grade(pb(oldest_overdue_days=120), cfg)[0] == 'D'
    assert rules.payment_grade(pb(payment_returns=2), cfg)[0] == 'D'


def test_experience(cfg):
    today = dt.date(2026, 10, 16)
    assert rules.experience_grade(None, cfg, today)[0] == 'E'
    assert rules.experience_grade(dt.date(2016, 4, 22), cfg, today)[0] == 'A'
    assert rules.experience_grade(dt.date(2020, 1, 1), cfg, today)[0] == 'B'
    assert rules.experience_grade(dt.date(2023, 1, 1), cfg, today)[0] == 'C'
    assert rules.experience_grade(dt.date(2025, 9, 24), cfg, today)[0] == 'D'
    assert rules.experience_grade(dt.date(2026, 8, 1), cfg, today)[0] == 'E'


def test_valid_till_end_of_month():
    # regula observata in NWCE: aprobat 04.03.2026 -> 31.03.2027; 14.08.2026 -> 31.08.2027
    assert rules.valid_till(dt.date(2026, 3, 4), 12) == dt.date(2027, 3, 31)
    assert rules.valid_till(dt.date(2026, 8, 14), 12) == dt.date(2027, 8, 31)
    assert rules.valid_till(dt.date(2027, 1, 31), 1) == dt.date(2027, 2, 28)
    assert rules.valid_till(dt.date(2027, 12, 15), 12) == dt.date(2028, 12, 31)


def test_kusd_like_nwce():
    assert rules.k_usd(800_000, 1.12) == 900       # MONDELEZ / MIRA SUD: 800 K EUR -> 900 KUSD
    assert rules.k_usd(60_000, 1.12) == 70         # ZANE REMO: 60 -> 70
    assert rules.k_usd(0, 1.12) == 0
    assert rules.k_local(850_000) == 850
    assert rules.k_local(125_500) == 125.5


def test_round_up_steps(cfg):
    assert rules.round_up(98_000, cfg) == 100_000
    assert rules.round_up(100_001, cfg) == 110_000
    assert rules.round_up(1_000_001, cfg) == 1_050_000
    assert rules.round_up(100_000, cfg) == 100_000
    assert rules.round_up(0, cfg) == 0


def test_propose_need_without_cap(cfg):
    p = rules.propose_limit(800_000, 1_021_670, None, 5, None, cfg)    # 1.123.837 > 1M -> pas 50k
    assert p.need == 1_150_000 and p.proposed == 1_150_000 and p.cap is None
    p = rules.propose_limit(400_000, 489_000, None, 5, None, cfg)      # 537.900 -> pas 10k
    assert p.need == 540_000


def test_propose_capped_by_equity(cfg):
    p = rules.propose_limit(800_000, 1_126_125, 2_000_000, 6, None, cfg)
    assert p.cap == 600_000
    assert p.proposed == 600_000
    assert any('garantii' in w for w in p.warnings)


def test_propose_cap_rounds_down(cfg):
    p = rules.propose_limit(100_000, 500_000, 1_234_567, 5, None, cfg)   # cap 370.370 -> 370.000
    assert p.proposed == 370_000 and p.proposed <= p.cap


def test_propose_negative_equity(cfg):
    p = rules.propose_limit(100_000, 200_000, -50_000, 8, None, cfg)
    assert p.proposed == 0 and any('negative' in w for w in p.warnings)


def test_propose_no_exposure_keeps_current(cfg):
    p = rules.propose_limit(250_000, 0, 5_000_000, 3, None, cfg)
    assert p.proposed == 250_000


def test_propose_warnings_grade_and_creditsafe(cfg):
    p = rules.propose_limit(100_000, 200_000, None, 10, 50_000, cfg)
    assert any('Grad scorecard 10' in w for w in p.warnings)
    assert any('Creditsafe' in w for w in p.warnings)


def test_keep_current_if_higher(cfg):
    cfg.set(True, 'limitPolicy', 'keepCurrentIfHigher')
    p = rules.propose_limit(900_000, 100_000, None, 3, None, cfg)
    assert p.proposed == 900_000


def test_country_rating(cfg):
    assert rules.country_rating('it', cfg) == 'BBB'
    assert rules.country_rating('DE', cfg) == 'AAA'
    assert rules.country_rating('XX', cfg) is None
