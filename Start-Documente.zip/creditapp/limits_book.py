"""Excelul de limite "NWCE Europe Credit limits.xlsx" (SharePoint), foaia LIMITS, tabelul Table1.

Citire: tot tabelul intr-un singur apel (snapshot), cu cache local pentru pornire rapida.
Scriere (doar la cererea explicita a analistului):
  1. deschide fisierul editabil (co-authoring SharePoint); daca s-a deschis doar in citire -> stop;
  2. pentru fiecare client: gaseste randul (Customer Code + Company code), verifica ca valorile
     n-au fost schimbate de altcineva fata de ce a vazut analistul (altfel -> stop pentru acel client);
  3. scrie doar campurile alese, salveaza, inchide;
  4. redeschide fisierul doar in citire si verifica valorile scrise.
Coloanele se gasesc dupa antet (nu dupa pozitie) - mutarea coloanelor nu strica nimic.
"""
import datetime as dt
import json
import re
import time
from dataclasses import dataclass, field

from . import log, paths
from .errors import AppError
from .excel_com import ExcelApp, retry

_log = log.get('nwce')

# cheie interna -> antetul din excel (comparat fara spatii multiple / majuscule)
COLUMNS = {
    'status': 'STATUS', 'company_code': 'Company code', 'bp_code': 'BP code', 'customer_code': 'Customer Code',
    'supplier_code': 'Supplier code', 'name': 'Counterparty name', 'vat': 'VAT code', 'group': 'Group of companies',
    'grading': 'Grading', 'tbd_by': 'TBD by', 'analyst': 'Analyst', 'compliance': 'Last compliance check',
    'payment_term': 'Payment Term', 'open_kusd': 'Open limit KUSD', 'open_kloc': 'Open limit K loc. curr.',
    'mtm_kusd': 'MTM limit KUSD', 'max_months': 'Max months fwd', 'total_kusd': 'Total limit KUSD',
    'tons_oilseeds': 'Limits in tons /oilseeds', 'tons_grains': 'Limits in tons/grains', 'storage_tons': 'Storage in tons',
    'storage_kusd': 'Storage limit KUSD', 'bond_tons': 'Limit in Tones for transfer bond Hungary',
    'bond_kusd': 'Transfer bond limit KUSD Hungary',
    'approved_on': 'Approved on mm/dd/yyyy', 'valid_till': 'Valid till mm/dd/yyyy', 'insurance': 'Insurance KUSD /KEUR',
    'collateral': 'Collateral: PN/BG', 'approval_level': 'Approval level', 'trader': 'Trader', 'comments': 'Comments',
}
REQUIRED = ('company_code', 'customer_code', 'name', 'vat', 'open_kusd', 'open_kloc', 'approved_on', 'valid_till')
# campuri pe care aplicatia le poate scrie (formulele STATUS si Total limit KUSD se calculeaza singure)
WRITABLE = ('grading', 'tbd_by', 'analyst', 'payment_term', 'open_kusd', 'open_kloc', 'mtm_kusd', 'max_months',
            'approved_on', 'valid_till', 'approval_level', 'comments', 'company_code', 'customer_code', 'bp_code',
            'name', 'vat', 'group', 'trader', 'compliance',
            'tons_oilseeds', 'tons_grains', 'storage_tons', 'storage_kusd', 'bond_tons', 'bond_kusd')

# Inactivare (regula Credit Control): 0 in Payment Term si in toate limitele, datele goale ->
# formula din STATUS da "INACTIVE" (cu 0 in "Valid till" ar da "UNDER REVIEW"). "Total limit KUSD" e formula - nu se scrie.
INACTIVATE_ZERO = ('payment_term', 'open_kusd', 'open_kloc', 'mtm_kusd', 'tons_oilseeds', 'tons_grains', 'max_months',
                   'storage_tons', 'storage_kusd', 'bond_tons', 'bond_kusd')
INACTIVATE_EMPTY = ('approved_on', 'valid_till')
# coloane care pot lipsi din foaie fara risc cand se scrie 0 in ele (tone / storage / transfer bond)
OPTIONAL_ZERO = ('tons_oilseeds', 'tons_grains', 'max_months', 'storage_tons', 'storage_kusd', 'bond_tons', 'bond_kusd')


def inactivation_changes(columns=None):
    ch = {k: 0 for k in INACTIVATE_ZERO if columns is None or k in columns}
    ch.update({k: None for k in INACTIVATE_EMPTY})
    return ch


def validity(row, renew_days=30, today=None):
    """Starea limitei dupa STATUS si Valid till: 'valid' (APPROVED, valabil > N zile), 'review' (de reinnoit),
    'inactive', 'na' (CBT / NO TRADE / TSF - nu sunt limite de evaluat)."""
    import datetime as _dt
    if row is None:
        return 'review'
    st = str(row.get('status') or '').strip().upper()
    if st == 'INACTIVE':
        return 'inactive'
    if st in ('CBT', 'NO TRADE', 'TSF'):
        return 'na'
    vt = from_serial(row.get('valid_till'))
    today = today or _dt.date.today()
    if st == 'APPROVED' and vt and vt > today + _dt.timedelta(days=renew_days):
        return 'valid'
    return 'review'


def is_inactive(row):
    return row is not None and str(row.get('status') or '').strip().upper() == 'INACTIVE'
DATE_FIELDS = ('approved_on', 'valid_till', 'compliance')
LABELS = {
    'grading': 'Grading', 'tbd_by': 'TBD by', 'analyst': 'Analyst', 'payment_term': 'Payment Term',
    'open_kusd': 'Open limit KUSD', 'open_kloc': 'Open limit K loc. curr.', 'mtm_kusd': 'MTM limit KUSD',
    'max_months': 'Max months fwd', 'approved_on': 'Approved on', 'valid_till': 'Valid till',
    'approval_level': 'Approval level', 'comments': 'Comments', 'total_kusd': 'Total limit KUSD', 'status': 'STATUS',
    'bp_code': 'BP code', 'customer_code': 'Customer Code', 'company_code': 'Company code', 'name': 'Counterparty name', 'vat': 'VAT code',
    'tons_oilseeds': 'Limits in tons /oilseeds', 'tons_grains': 'Limits in tons/grains', 'storage_tons': 'Storage in tons',
    'storage_kusd': 'Storage limit KUSD', 'bond_tons': 'Transfer bond tons', 'bond_kusd': 'Transfer bond KUSD',
}
CODE_FIELDS = ('bp_code', 'customer_code', 'supplier_code')
_CACHE = paths.LOCAL_DIR / 'nwce_snapshot.json'
_EXCEL_EPOCH = dt.date(1899, 12, 30)


def _norm(h):
    return re.sub(r'\s+', ' ', str(h or '')).strip().lower()


_TBD_RE = re.compile(r'^\s*(?:tbd\s+by\s+)?([A-Za-z]{2,4})\s*$', re.I)


def tbd_owner(value):
    """Analistul din coloana "TBD by": "TBD by IS" / "IS" -> "IS"; "Done", "Sent to BBS ..." -> ""."""
    m = _TBD_RE.match(str(value or ''))
    if not m:
        return ''
    owner = m.group(1).upper()
    return '' if owner in ('DONE', 'BBS', 'NA', 'N') else owner


def company_currency(cfg, company_code):
    prefix = str(company_code or '').split(' ')[0]
    return (cfg.get('limitsBook', 'companyCurrencies', default={}) or {}).get(prefix, 'EUR')


def _code(v):
    if v is None:
        return ''
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    s = str(v).strip()
    return '' if s in ('0', '-', 'n/a') else s


def vat_key(vat, country='IT'):
    v = re.sub(r'[^A-Za-z0-9]', '', str(vat or '')).upper()
    if not v or not re.search(r'\d', v):
        return ''
    if re.match(r'^[A-Z]{2}', v):
        return v
    return ('EL' if country.upper() == 'GR' else country.upper()) + v


def to_serial(d):
    return float((d - _EXCEL_EPOCH).days) if d else None


def from_serial(v):
    if isinstance(v, (int, float)) and 1 < v < 100000:
        return _EXCEL_EPOCH + dt.timedelta(days=int(v))
    if isinstance(v, dt.datetime):
        return v.date()
    return None


def display(key, v):
    """Valoare pentru afisare (date ca dd.mm.yyyy, numere fara .0)."""
    if v is None or v == '':
        return ''
    if key in CODE_FIELDS:
        return _code(v)
    if key in DATE_FIELDS:
        d = from_serial(v)
        return d.strftime('%d.%m.%Y') if d else str(v)
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        s = f'{v:,.0f}' if float(v).is_integer() else f'{v:,.2f}'
        return s.replace(',', ' ').replace('.', ',').replace(' ', '.')     # format romanesc: 1.250 / 12,5
    return str(v).strip()


def same(key, a, b):
    """Comparatie toleranta (numere 900 vs 900.0, texte cu spatii, date)."""
    if key in DATE_FIELDS:
        return from_serial(a) == from_serial(b) if (from_serial(a) or from_serial(b)) else _blank(a) == _blank(b)
    fa, fb = _f(a), _f(b)
    if fa is not None and fb is not None:
        return abs(fa - fb) < 0.0001
    return _blank(a) == _blank(b)


def _f(v):
    if isinstance(v, (int, float)):
        return float(v)
    try:
        return float(str(v).replace(',', '').strip())
    except (TypeError, ValueError):
        return None


def _blank(v):
    s = re.sub(r'\s+', ' ', str(v if v is not None else '')).strip()
    return '' if s in ('-', '0') else s


@dataclass
class NwceRow:
    sheet_row: int                  # numarul randului in foaie (1 = antet)
    values: dict                    # cheie interna -> valoare bruta (Value2)

    def get(self, key):
        return self.values.get(key)

    @property
    def customer_code(self):
        return _code(self.values.get('customer_code'))

    @property
    def company_code(self):
        return str(self.values.get('company_code') or '').strip()

    @property
    def name(self):
        return str(self.values.get('name') or '').strip()

    def label(self):
        return (f'rand {self.sheet_row}: {self.company_code} | {self.name} | {display("open_kloc", self.get("open_kloc"))} K loc. | '
                f'{display("open_kusd", self.get("open_kusd"))} KUSD | {self.get("status") or ""} | valid till {display("valid_till", self.get("valid_till"))}')


@dataclass
class Snapshot:
    rows: list
    columns: dict                   # cheie -> index coloana (1-based, in foaie)
    loaded_at: dt.datetime
    source: str
    from_cache: bool = False
    dropdowns: dict = field(default_factory=dict)     # listele din foaia DROPDOWNS
    by_code: dict = field(default_factory=dict)
    by_vat: dict = field(default_factory=dict)

    def index(self, country='IT'):
        self.by_code, self.by_vat = {}, {}
        for r in self.rows:
            if r.customer_code:
                self.by_code.setdefault(r.customer_code, []).append(r)
            k = vat_key(r.get('vat'), country)
            if k:
                self.by_vat.setdefault(k, []).append(r)
        return self

    def row_by_sheet(self, sheet_row):
        if not hasattr(self, '_by_sheet') or self._by_sheet is None:
            self._by_sheet = {r.sheet_row: r for r in self.rows}
        return self._by_sheet.get(int(sheet_row or 0))

    def tbd_owners(self):
        owners = {tbd_owner(r.get('tbd_by')) for r in self.rows}
        owners |= {tbd_owner(v) for v in self.dropdowns.get('tbd_by', [])}
        return sorted(o for o in owners if o)

    def candidates(self, customer_code, vat, company_code, country='IT'):
        """Randurile posibile pentru client: (lista, explicatie). Lista ordonata - primul = cel mai probabil."""
        prefix = company_code.split(' ')[0] if company_code else ''

        def rank(r):
            cc = r.company_code
            return (cc == company_code, cc.startswith(prefix) and not re.search(r'CBT|NO TRADE', cc, re.I), -r.sheet_row)
        rows = list(self.by_code.get(str(customer_code), []))
        how = 'Customer Code'
        if not rows and vat:
            rows = list(self.by_vat.get(vat_key(vat, country), []))
            how = 'VAT'
        rows.sort(key=rank, reverse=True)
        return rows, how

    def pick(self, customer_code, vat, company_code, country='IT'):
        """Randul sigur pentru client sau None + motiv (niciunul / ambiguu)."""
        rows, how = self.candidates(customer_code, vat, company_code, country)
        exact = [r for r in rows if r.company_code == company_code]
        if len(exact) == 1:
            return exact[0], f'gasit dupa {how}'
        if len(exact) > 1:
            return None, f'{len(exact)} randuri cu {company_code} ({how})'
        if not rows:
            return None, 'nu exista in NWCE'
        return None, f'exista doar pentru alte companii: {", ".join(sorted({r.company_code for r in rows}))}'

    def save_cache(self):
        try:
            _CACHE.parent.mkdir(parents=True, exist_ok=True)
            data = {'loaded_at': self.loaded_at.isoformat(), 'source': self.source, 'columns': self.columns,
                    'dropdowns': self.dropdowns, 'rows': [[r.sheet_row, r.values] for r in self.rows]}
            tmp = _CACHE.with_suffix('.tmp')
            tmp.write_text(json.dumps(data, ensure_ascii=False, default=str), encoding='utf-8')
            tmp.replace(_CACHE)
        except OSError as e:
            _log.warning('NWCE cache not saved: %s', e)

    @staticmethod
    def load_cache(country='IT'):
        try:
            data = json.loads(_CACHE.read_text(encoding='utf-8'))
        except (OSError, ValueError):
            return None
        rows = [NwceRow(r, v) for r, v in data['rows']]
        snap = Snapshot(rows, data['columns'], dt.datetime.fromisoformat(data['loaded_at']), data['source'], True)
        snap.dropdowns = data.get('dropdowns') or {}
        return snap.index(country)


def _map_columns(header):
    idx = {}
    norm = {_norm(h): i + 1 for i, h in enumerate(header) if h not in (None, '')}
    for key, text in COLUMNS.items():
        if _norm(text) in norm:
            idx[key] = norm[_norm(text)]
    missing = [COLUMNS[k] for k in REQUIRED if k not in idx]
    if missing:
        raise AppError('BOOK_OPEN', f'NWCE: columns not found: {", ".join(missing)}')
    return idx


def _table(wb, cfg):
    ws = wb.Worksheets(cfg.get('limitsBook', 'sheet'))
    try:
        lo = ws.ListObjects(cfg.get('limitsBook', 'table'))
    except Exception:
        lo = ws.ListObjects(1) if ws.ListObjects.Count else None
    return ws, lo


def _read(wb, cfg, source):
    ws, lo = _table(wb, cfg)
    if lo is not None:
        rng = lo.Range
        first_row = rng.Row
        values = rng.Value2
    else:
        ur = ws.UsedRange
        first_row = ur.Row
        values = ur.Value2
    header = values[0]
    cols = _map_columns(header)
    rows = []
    for i, line in enumerate(values[1:], start=1):
        vals = {k: line[c - 1] for k, c in cols.items() if c - 1 < len(line)}
        if not any(v not in (None, '') for v in vals.values()):
            continue
        rows.append(NwceRow(first_row + i, vals))
    snap = Snapshot(rows, cols, dt.datetime.now(), source)
    snap.dropdowns = _dropdowns(wb)
    return snap


def _dropdowns(wb):
    """Listele de validare din foaia DROPDOWNS (Grading, Payment term, Approval level, TBD by)."""
    want = {'grading': 'grading', 'payment_term': 'payment_term', 'approval_level': 'approval_level', 'tbd_by': 'to be done by'}
    try:
        vals = wb.Worksheets('DROPDOWNS').Range('A1:L80').Value2
    except Exception:
        return {}
    out = {}
    header = vals[0]
    for key, text in want.items():
        for c, h in enumerate(header):
            if _norm(h) == text:
                items = []
                for row in vals[1:]:
                    v = row[c]
                    if v in (None, ''):
                        continue
                    if isinstance(v, float) and v.is_integer():
                        v = int(v)
                    items.append(str(v).strip())
                out[key] = list(dict.fromkeys(items))
                break
    return out


def load(cfg, excel=None, use_cache=False, max_cache_hours=12, url=None):
    """Citeste tabelul NWCE (doar citire). Cu use_cache: refoloseste copia locala mai noua de N ore."""
    country = cfg.get('portfolio', 'country', default='IT')
    if use_cache:
        s = Snapshot.load_cache(country)
        if s and (dt.datetime.now() - s.loaded_at).total_seconds() < max_cache_hours * 3600:
            return s
    url = url or cfg.get('limitsBook', 'url')
    own = excel is None
    xl = excel or ExcelApp()
    wb = None
    try:
        try:
            wb = xl.open(url, read_only=True)
        except Exception as e:
            raise AppError('BOOK_OPEN', f'Could not open {url}', str(e))
        snap = _read(wb, cfg, url).index(country)
    finally:
        if wb is not None:
            try:
                wb.Close(False)
            except Exception:
                pass
        if own:
            xl.quit()
    if url == cfg.get('limitsBook', 'url') and str(url).lower().startswith('http'):
        snap.save_cache()      # doar fisierul oficial de pe SharePoint (nu copii locale / teste)
    _log.info('NWCE loaded: %d rows', len(snap.rows))
    return snap


# ---------------------------------------------------------------- scriere
@dataclass
class RowUpdate:
    """O modificare ceruta de analist pentru un client."""
    partner: str
    sheet_row: int                  # randul vazut de analist (0 = rand nou)
    expected: dict                  # valorile vazute de analist (pentru verificarea de concurenta)
    changes: dict                   # cheie -> valoare noua (datele ca datetime.date)
    customer_code: str = ''
    company_code: str = ''
    name: str = ''                  # numele vazut (pentru randurile fara Customer Code)
    new_row: bool = False
    inactivate: bool = False        # dupa salvare STATUS trebuie sa fie INACTIVE
    # rezultat
    ok: bool = False
    message: str = ''
    before: dict = field(default_factory=dict)
    after: dict = field(default_factory=dict)


def _excel_value(key, v):
    if key in DATE_FIELDS and isinstance(v, dt.datetime):
        v = v.date()
    if key in DATE_FIELDS and isinstance(v, dt.date):
        return to_serial(v)
    return v


def apply(updates, cfg, progress=None, verify=True, url=None):
    """Scrie modificarile in NWCE. Intoarce lista de RowUpdate cu ok/message/before/after."""
    say = progress or (lambda t: None)
    url = url or cfg.get('limitsBook', 'url')
    xl = ExcelApp()
    wb = None
    try:
        say('Deschid excelul NWCE pentru editare (SharePoint)...')
        try:
            wb = xl.open(url, read_only=False)
        except Exception as e:
            raise AppError('BOOK_OPEN', f'Could not open {url} for editing', str(e))
        if wb.ReadOnly:
            raise AppError('BOOK_READONLY', 'NWCE opened read-only - nothing was written.')
        ws, lo = _table(wb, cfg)
        header = (lo.HeaderRowRange if lo is not None else ws.Rows(1)).Value2[0]
        offset = (lo.Range.Column - 1) if lo is not None else 0      # coloanele tabelului -> coloanele foii
        cols = {k: c + offset for k, c in _map_columns(header).items()}
        header_row = lo.HeaderRowRange.Row if lo is not None else 1
        written = 0
        broken = []         # randuri ramase scrise partial (refacerea a esuat) -> fisierul NU se salveaza
        for u in updates:
            row, added, done = None, None, []        # done: [(coloana, valoarea de dinainte)] - pentru refacere
            try:
                say(f'NWCE: {u.partner} ...')
                # o coloana ceruta care lipseste din foaie (antet redenumit) = eroare, nu "scris si verificat"
                missing = [k for k, v in u.changes.items()
                           if k in WRITABLE and k not in cols and not (k in OPTIONAL_ZERO and v == 0)]
                if missing:
                    raise AppError('BOOK_COLUMNS', 'NWCE: columns not found: ' + ', '.join(COLUMNS.get(k, k) for k in missing))
                if u.new_row:
                    added = _add_row(lo)
                    row = added.Range.Row
                else:
                    row = _locate(ws, lo, cols, u, header_row)
                u.before = {k: ws.Cells(row, cols[k]).Value2 for k in set(u.changes) | set(u.expected) if k in cols}
                changed_by_other = [k for k, v in u.expected.items() if k in cols and not same(k, u.before.get(k), v)]
                if changed_by_other:
                    raise AppError('BOOK_CHANGED', 'NWCE: rândul a fost modificat de altcineva. Nu am scris nimic. '
                                   'Reîncarcă NWCE și încearcă din nou. (' + ', '.join(
                                       f'{LABELS.get(k, k)}: "{display(k, u.expected[k])}" -> "{display(k, u.before.get(k))}"'
                                       for k in changed_by_other) + ')')
                for k, v in u.changes.items():
                    if k not in cols or k not in WRITABLE:
                        continue
                    retry(lambda r=row, c=cols[k], val=_excel_value(k, v): setattr(ws.Cells(r, c), 'Value2', val))
                    done.append((cols[k], u.before.get(k)))
                u.sheet_row = row
                u.ok = True
                written += 1
            except Exception as e:
                u.ok = False
                u.message = e.message if isinstance(e, AppError) else str(e)
                _log.exception('NWCE update failed for %s', u.partner)
                # tot randul sau nimic: celulele deja scrise revin la valorile de dinainte, randul nou se sterge
                try:
                    for c, old in reversed(done):
                        retry(lambda r=row, c=c, val=old: setattr(ws.Cells(r, c), 'Value2', val))
                    if added is not None:
                        retry(lambda: added.Delete())
                except Exception:
                    _log.exception('NWCE rollback failed for %s', u.partner)
                    broken.append(u)
                    u.message += ' | Randul a ramas scris partial - fisierul NU s-a salvat.'
        if broken:
            for u in updates:
                if u.ok:
                    u.ok, u.message = False, 'Nesalvat: alt rand nu a putut fi refacut dupa o eroare - nimic nu s-a scris.'
            written = 0
        if written:
            say('Salvez excelul NWCE...')
            retry(lambda: wb.Save())
        try:
            retry(lambda: wb.Close(False))
        except Exception as e:
            _log.warning('NWCE close failed (after save): %s', e)     # salvarea a reusit - verificarea de mai jos confirma
        wb = None
    finally:
        if wb is not None:
            try:
                wb.Close(False)
            except Exception:
                pass
        xl.quit(wait=180)       # asteapta sa se termine incarcarea pe SharePoint
    if verify and any(u.ok for u in updates):
        say('Verific valorile salvate in NWCE (redeschid fisierul)...')
        time.sleep(2)
        try:
            snap = load(cfg, url=url)
            by_row = {r.sheet_row: r for r in snap.rows}
            for u in updates:
                if not u.ok:
                    continue
                r = by_row.get(u.sheet_row)
                if r is None or (u.customer_code and r.customer_code != str(u.customer_code)):
                    u.ok, u.message = False, 'Verificare: randul nu mai corespunde dupa salvare - verifica manual.'
                    continue
                u.after = {k: r.get(k) for k in u.changes}
                u.after['status'] = r.get('status')
                bad = [k for k, v in u.changes.items() if k in cols and k in WRITABLE and not same(k, r.get(k), _excel_value(k, v))]
                status = str(r.get('status') or '').strip().upper()
                if bad:
                    u.ok = False
                    u.message = 'Verificare esuata pentru: ' + ', '.join(LABELS.get(k, k) for k in bad)
                elif u.inactivate and status != 'INACTIVE':
                    u.ok = False
                    u.message = f'Scris, dar STATUS = "{r.get("status") or ""}" (asteptat INACTIVE) - verifica randul manual.'
                else:
                    u.message = 'Scris si verificat.' + (f' STATUS: {r.get("status")}.' if r.get('status') else '')
        except Exception as e:
            for u in updates:
                if u.ok:
                    u.message = f'Scris, dar verificarea nu a putut rula: {e}'
    return updates


def _add_row(lo):
    if lo is None:
        raise AppError('BOOK_OPEN', 'NWCE: no table to add a row to.')
    return retry(lambda: lo.ListRows.Add())


def _locate(ws, lo, cols, u, header_row):
    """Randul de scris: cel vazut de analist (daca e tot clientul respectiv) sau cautat din nou."""
    code_col = cols['customer_code']
    comp_col = cols['company_code']
    if u.new_row:
        return _add_row(lo).Range.Row
    if u.sheet_row and u.sheet_row > header_row:
        code = _code(ws.Cells(u.sheet_row, code_col).Value2)
        comp = str(ws.Cells(u.sheet_row, comp_col).Value2 or '').strip()
        same_client = (code == str(u.customer_code)) if u.customer_code else \
            (_norm(ws.Cells(u.sheet_row, cols['name']).Value2) == _norm(u.name) and bool(u.name))
        if same_client and (not u.company_code or comp == u.company_code):
            return u.sheet_row
    if not u.customer_code:
        raise AppError('BOOK_ROW_NOT_FOUND', f'Row {u.sheet_row} no longer holds "{u.name}" and the client has no Customer Code - reload NWCE.')
    # randul s-a mutat (sortare / randuri inserate): cautare in coloana Customer Code
    last = (lo.Range.Row + lo.Range.Rows.Count - 1) if lo is not None else ws.UsedRange.Rows.Count
    codes = ws.Range(ws.Cells(header_row + 1, code_col), ws.Cells(last, code_col)).Value2
    comps = ws.Range(ws.Cells(header_row + 1, comp_col), ws.Cells(last, comp_col)).Value2
    hits = [header_row + 1 + i for i, (c, k) in enumerate(zip(codes, comps))
            if _code(c[0]) == str(u.customer_code) and (not u.company_code or str(k[0] or '').strip() == u.company_code)]
    if len(hits) == 1:
        return hits[0]
    if not hits:
        raise AppError('BOOK_ROW_NOT_FOUND', f'Customer Code {u.customer_code} / {u.company_code} not found in NWCE.')
    raise AppError('BOOK_AMBIGUOUS', f'{len(hits)} rows for Customer Code {u.customer_code} / {u.company_code}: {hits}')
