"""Erori explicite pentru utilizator: fiecare eroare tehnica -> "ce s-a intamplat" + "ce ai de facut".

Codul aplicatiei arunca AppError(cod, mesaj). Erorile tehnice (HTTP, Excel, SAP, fisiere) sunt
recunoscute dupa mesaj / HRESULT.
"""
import re
import traceback


class AppError(Exception):
    def __init__(self, code, message='', details=''):
        super().__init__(message or code)
        self.code = code
        self.message = message or code
        self.details = details


FRIENDLY = {
    # --- Creditsafe
    'NO_FINANCIALS': ('Creditsafe nu are bilanturi pentru aceasta firma',
                      'Tipic pentru persoane fizice, ferme si firme noi. PDF-ul Creditsafe a fost salvat - completeaza scorecardul manual din situatiile oficiale.'),
    'NOT_FOUND': ('Firma nu a fost gasita in Creditsafe',
                  'Verifica VAT-ul / nr. de inregistrare si tara. Cauta dupa nume din fereastra clientului sau verifica direct in portalul Creditsafe.'),
    'CS_AMBIGUOUS': ('Creditsafe a gasit mai multe firme',
                     'Alege firma corecta in fereastra "Alege firma Creditsafe" si porneste din nou.'),
    'AUTH': ('Autentificarea Creditsafe a esuat',
             'Parola Creditsafe e gresita sau a expirat. Meniul Setari -> "Parola Creditsafe" si introdu-o din nou.'),
    'AUTH_MISSING': ('Lipseste parola Creditsafe',
                     'Meniul Setari -> "Parola Creditsafe". Parola se salveaza criptat in Windows Credential Manager.'),
    'CREDITS': ('Creditele Creditsafe s-au terminat',
                'Contractul nu mai are rapoarte disponibile pentru aceasta tara. Contacteaza account managerul Creditsafe; rapoartele deja descarcate raman in cache.'),
    'REPORT_UNAVAILABLE': ('Creditsafe nu are raport pentru aceasta firma',
                           'Id-ul Creditsafe poate fi vechi sau firma nu e acoperita. Cauta din nou dupa VAT sau verifica in portal.'),
    'FORBIDDEN': ('Nu e inclus in contractul Creditsafe',
                  'Accesul nu acopera aceasta tara / acest tip de raport. Intreaba account managerul Creditsafe.'),
    'RATE_LIMIT': ('Creditsafe limiteaza cererile',
                   'Prea multe cereri intr-un timp scurt. Asteapta un minut si reia.'),
    'NETWORK': ('Serverul nu poate fi contactat',
                'Verifica internetul / VPN-ul si reia. Status Creditsafe: https://status.creditsafe.com'),
    'CS_SERVER': ('Eroare pe serverul Creditsafe', 'Problema temporara la Creditsafe. Reia peste cateva minute.'),
    # --- fisiere / foldere
    'FILE_LOCKED': ('Fisier deschis / blocat',
                    'Fisierul e deschis in Excel / Acrobat (poate de un coleg) sau OneDrive inca il sincronizeaza. Inchide-l si reia.'),
    'NO_ACCESS': ('Nu ai drept de scriere in folder', 'Cere acces la folderul OneDrive / SharePoint.'),
    'CLIENT_ROOT': ('Folderele clientilor nu sunt disponibile',
                    'Folderul "BUC - TRADING COUNTREPARTIES" nu a fost gasit. Verifica daca OneDrive ruleaza si e sincronizat.'),
    'TEMPLATE': ('Lipseste sablonul de scorecard', 'Fisierul "Scorecard 2026 ... .xlsx" trebuie sa fie in folderul aplicatiei (vezi Setari).'),
    # --- Excel / scorecard
    'EXCEL': ('Excel n-a răspuns la timp', 'Încearcă din nou. Dacă se repetă, închide ferestrele Excel deschise.'),
    'INVALID_RESULT': ('Scorecardul nu a putut fi calculat',
                       'Datele financiare din Creditsafe sunt incomplete si scorecardul nu da un grad valid. Deschide scorecardul (foaia "Blank 1") si completeaza manual.'),
    # --- portofoliu
    'PORTFOLIO': ('Fisierul cu clienti nu poate fi citit',
                  'Verifica calea catre "Open Contracts ITA.xlsx" in Setari si ca OneDrive l-a sincronizat.'),
    'NO_VAT': ('Clientul nu are VAT in liste',
               'VAT-ul nu e nici in foaia "VAT Italy", nici in excelul NWCE. Introdu VAT-ul manual in fereastra clientului.'),
    # --- excelul de limite NWCE
    'BOOK_OPEN': ('Excelul de limite NWCE nu poate fi deschis',
                  'Verifica conexiunea la SharePoint (VPN) si ca esti logat in Office cu contul Bunge. Reia peste cateva secunde.'),
    'BOOK_READONLY': ('Excelul de limite NWCE s-a deschis doar in citire',
                      'Fisierul e blocat (check-out / editat exclusiv de altcineva) sau nu ai drept de editare. Nu s-a scris nimic. Reia mai tarziu.'),
    'BOOK_ROW_NOT_FOUND': ('Clientul nu exista in excelul NWCE',
                           'Nu exista rand cu acest Customer Code / VAT pentru compania configurata. Bifeaza "Adauga rand nou" in decizie daca e client nou.'),
    'BOOK_AMBIGUOUS': ('Mai multe randuri NWCE pentru client',
                       'Alege randul corect in fereastra de decizie (coloana "Rand NWCE").'),
    'SAP_NO_BP': ('Lipseste BP code in NWCE - SAP nu a fost atins',
                  'In ZBEU_UKM_BP_CREDIT_L clientul se cauta dupa BP. Completeaza coloana "BP code" in NWCE pentru acest client '
                  '(Customer Code-ul nu ajunge), reincarca NWCE (click pe indicatorul NWCE, sus) si apoi click-dreapta → Trimite in SAP.'),
    'BOOK_CHANGED': ('NWCE: rândul a fost modificat de altcineva',
                     'Nu am scris nimic. Reîncarcă NWCE și încearcă din nou.'),
    'BOOK_VERIFY': ('Valorile scrise in NWCE nu se confirma',
                    'Dupa salvare, valorile citite inapoi difera. Verifica manual randul in excel.'),
    # --- SAP
    'SAP_NOT_RUNNING': ('SAP nu este deschis', 'Deschide SAP Logon, logheaza-te in sistemul corect si reia.'),
    'SAP_SCRIPTING': ('SAP GUI Scripting este dezactivat',
                      'In SAP: Customize Local Layout (Alt+F12) -> Options -> Accessibility & Scripting -> Scripting -> bifeaza "Enable scripting" si debifeaza notificarile. Daca e blocat pe server (sapgui/user_scripting), cere activarea la echipa SAP Basis.'),
    'SAP_TEMPLATE': ('Lipseste inregistrarea SAP',
                     'Meniul SAP -> "Importa inregistrare SAP (.vbs)". Inregistreaza o data actualizarea unei limite cu Script Recording si importa fisierul.'),
    'SAP_SCREEN': ('Ecranul SAP difera de cel inregistrat',
                   'Un camp din inregistrare nu exista pe ecran (alt layout / alta tranzactie / popup neasteptat). Nu s-a salvat nimic. Reinregistreaza scriptul daca problema persista.'),
    'SAP_ERROR': ('SAP a refuzat modificarea', 'Citeste mesajul SAP de mai jos; nimic nu a fost salvat daca mesajul este o eroare.'),
    'SAP_SUBMITTED': ('SAP: cererea poate fi deja trimisă',
                      'Verifică în SAP înainte să o trimiți din nou.'),
    'SAP_VERIFY': ('Valoarea din SAP nu se confirma', 'Dupa salvare, campul citit inapoi difera de valoarea dorita. Verifica manual in SAP.'),
    'CANCELLED': ('Anulat', 'Operatia a fost oprita de utilizator.'),
    'UNKNOWN': ('Eroare neasteptata', 'Reia. Daca se repeta, detaliile tehnice sunt in data\\logs\\app.log.'),
}

WARNINGS = {
    'FEW_YEARS': 'Doar {0} an(i) de bilant in Creditsafe - criteriul "Trend" (3 ani) are punctaj mic. Verifica gradul.',
    'FX_MISSING': 'Nu exista curs USD pentru {0} la {1} in foaia "Blank 2" - gradul NU e sigur.',
    'FX_ADDED': 'Curs USD->EUR adaugat in "Blank 2" din ECB: {0}.',
    'FX_EUR_ONLY': 'Bilantul e in {0}, dar tabelul de curs ("Blank 2") are doar USD->EUR - gradul poate fi gresit.',
    'NO_AGE': 'Lipseste data infiintarii in Creditsafe - "Age of Company" a ramas valoarea din sablon.',
    'OLD_ACCOUNTS': 'Ultimul bilant este din {0} - mai vechi de 18 luni.',
    'NOT_ACTIVE': 'Statusul firmei in Creditsafe este "{0}".',
    'NEW_FOLDER': 'Nu exista folder de client - s-a creat unul nou: {0}',
    'MANY_FOLDERS': 'Mai multe foldere se potrivesc - s-a ales cel folosit cel mai recent. Celelalte: {0}',
    'CS_MANY': 'Creditsafe a gasit {0} firme pentru {1}, niciuna inregistrata (Registered) - s-a ales {2}. Verifica.',
    # nu incepe cu "Creditsafe a gasit": nu e nimic de decis, fereastra de confirmare nu se deschide pentru asta
    'CS_REGISTERED': 'Creditsafe: am ales firma activă{0}. Celelalte {1} sunt sedii vechi, radiate.',
}

_HRESULT_EXCEL = {'800AC472', '80010001', '800706BA', '800706BE', '80010108', '80010105'}


def hresult_of(exc):
    """HRESULT-ul unei erori COM (pywintypes.com_error) ca text hex, sau ''."""
    hr = getattr(exc, 'hresult', None)
    if hr is None and getattr(exc, 'args', None):
        a0 = exc.args[0]
        if isinstance(a0, int):
            hr = a0
    if hr is None:
        return ''
    if isinstance(exc.args, tuple) and len(exc.args) >= 3 and isinstance(exc.args[2], tuple):
        # com_error: (hr, text, (wcode, source, text, helpfile, helpctx, scode), argerr)
        scode = exc.args[2][5] if len(exc.args[2]) > 5 else None
        if isinstance(scode, int) and scode:
            return '%08X' % (scode & 0xFFFFFFFF)
    return '%08X' % (hr & 0xFFFFFFFF)


def error_code(exc):
    if isinstance(exc, AppError):
        return exc.code
    msg = str(exc)
    m = re.match(r'^\[(\w+)\]', msg)
    if m and m.group(1) in FRIENDLY:
        return m.group(1)
    rules = [
        (r'CreditsExceeded|credits exceeded', 'CREDITS'),
        (r'ReportUnavailable|Report unavailable', 'REPORT_UNAVAILABLE'),
        (r'HTTP 401|Unauthorized', 'AUTH'),
        (r'HTTP 403|Forbidden', 'FORBIDDEN'),
        (r'HTTP 404|Not Found', 'NOT_FOUND'),
        (r'HTTP 429|Too Many', 'RATE_LIMIT'),
        (r'HTTP 5\d\d', 'CS_SERVER'),
        (r'Max retries|NameResolution|getaddrinfo|ConnectTimeout|ReadTimeout|Connection aborted|timed out|ConnectionError|WinHttp|0x80072', 'NETWORK'),
        (r'being used by another process|is locked|sharing violation|PermissionError: \[WinError 32\]', 'FILE_LOCKED'),
        (r'Access is denied|Permission denied|WinError 5\b', 'NO_ACCESS'),
    ]
    for pat, code in rules:
        if re.search(pat, msg, re.I):
            return code
    if hresult_of(exc) in _HRESULT_EXCEL:
        return 'EXCEL'
    if type(exc).__name__ == 'com_error':
        return 'EXCEL'
    return 'UNKNOWN'


def short_text(text, limit=400):
    t = ' '.join(line.strip() for line in str(text).splitlines() if line.strip())
    m = re.match(r'^(.{40,}?[.:])\s+There are several possible reasons', t)
    if m:
        t = m.group(1)
    return t if len(t) <= limit else t[:limit] + '...'


def friendly(exc):
    """dict(code, title, action, details) pentru afisare."""
    code = error_code(exc)
    title, action = FRIENDLY.get(code, FRIENDLY['UNKNOWN'])
    if isinstance(exc, AppError):
        details = exc.message if exc.message != code else ''
        if exc.details:
            details = f'{details} | {exc.details}' if details else exc.details
    else:
        details = f'{type(exc).__name__}: {exc}'
    details = re.sub(r'^\[\w+\]\s*', '', details)
    return {'code': code, 'title': title, 'action': action, 'details': short_text(details)}


def format_exc(exc):
    return ''.join(traceback.format_exception(type(exc), exc, exc.__traceback__))


def warning(key, *args):
    return WARNINGS[key].format(*args)
