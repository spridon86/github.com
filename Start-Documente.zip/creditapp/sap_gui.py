"""Actualizarea limitei in SAP prin SAP GUI Scripting, pe baza unei inregistrari facute de analist.

De ce inregistrare: ecranele SAP (UKM_BP / FD32, segmentul de credit, layout-ul) difera intre sisteme
si utilizatori. Analistul inregistreaza o singura data o actualizare de limita (Script Recording,
Alt+F12), iar aplicatia transforma fisierul .vbs intr-un sablon: valorile tastate in inregistrare
(BP-ul, limita, data de valabilitate, scorul) devin variabile.

Siguranta:
- "Proba" (dry-run) executa pasii pana la Save, citeste campurile si iese cu /n fara salvare;
- orice camp lipsa / popup neasteptat / mesaj de eroare SAP opreste executia INAINTE de Save;
- valoarea veche se citeste inainte de a fi suprascrisa (audit), cea noua se citeste dupa Save;
- se salveaza capturi de ecran inainte si dupa Save.
"""
import datetime as dt
import json
import re
import time
from dataclasses import dataclass, field
from pathlib import Path

from . import log, paths
from .errors import AppError

_log = log.get('sap')

# pasul care salveaza / trimite: Save (Ctrl+S) sau rotita dintata din ZBEU_UKM_BP_CREDIT_L (tbar[1]/btn[36]).
# tbar[1]/btn[8] (F8) e doar Execute pe ecranul de selectie - nu trimite nimic.
SAVE_IDS = ('wnd[0]/tbar[0]/btn[11]', 'wnd[0]/tbar[1]/btn[36]')
POPUP_WAIT = 3          # secunde: cat se asteapta o confirmare dupa rotita inainte de a o considera absenta
SEGMENT_RE = re.compile(r'^Z[A-Z0-9]+_(LIMIT\d?|OPEN)$', re.I)
GRID_CALLS = {'modifyCell', 'setCurrentCell', 'modifyCheckbox', 'changeCheckbox'}
OPTIONAL_OPS = {'caretPosition', 'setFocus', 'maximize', 'resizeWorkingPane', 'restore', 'iconify', 'firstVisibleRow',
                'verticalScrollbar.position', 'horizontalScrollbar.position'}
PLACEHOLDERS = {
    'bp': 'BP (Business Partner) - din NWCE "BP code"',
    'customer_code': 'Customer Code',
    'limit': 'Limita noua (moneda locala, suma intreaga)',
    'valid_to': 'Data de valabilitate a limitei',
    'grade': 'Gradul din scorecard (1-11)',
    'today': 'Data de azi',
    'mtm': 'Limita MTM & PFE (USD, suma intreaga)',
    'equity': 'Bifa Equity Scenario (limita totala USD > equity)',
    'comment': 'Comentariul cazului',
    'segment': 'Segmentul de credit (ex. ZIT1_LIMIT)',
    'currency': 'Moneda limitei Open (EUR / RON / HUF)',
}


# ---------------------------------------------------------------- import .vbs
_LINE = re.compile(r'^\s*session\.findById\("((?:[^"]|"")+)"\)\.([\w.]+)\s*(?:=\s*(.+?)|\s+(.+?))?\s*$', re.I)


def _vbs_value(tok):
    tok = tok.strip()
    if tok.startswith('"') and tok.endswith('"') and len(tok) >= 2:
        return tok[1:-1].replace('""', '"')
    if tok.lower() in ('true', 'false'):
        return tok.lower() == 'true'
    if re.fullmatch(r'-?\d+', tok):
        return int(tok)
    if re.fullmatch(r'-?\d+\.\d+', tok):
        return float(tok)
    return tok


def _split_args(s):
    out, cur, q = [], '', False
    for ch in s:
        if ch == '"':
            q = not q
            cur += ch
        elif ch == ',' and not q:
            out.append(cur)
            cur = ''
        else:
            cur += ch
    if cur.strip():
        out.append(cur)
    return [_vbs_value(a) for a in out]


def read_vbs(path):
    """Textul inregistrarii. SAP GUI salveaza .vbs in UTF-16 (BOM FF FE); editat manual poate fi UTF-8 / ANSI."""
    raw = Path(path).read_bytes()
    if raw[:2] in (b'\xff\xfe', b'\xfe\xff'):
        return raw.decode('utf-16')
    if raw[:3] == b'\xef\xbb\xbf':
        return raw[3:].decode('utf-8', errors='replace')
    if len(raw) > 3 and raw[1:2] == b'\x00' and raw[3:4] == b'\x00':
        return raw.decode('utf-16-le', errors='replace')
    try:
        return raw.decode('utf-8')
    except UnicodeDecodeError:
        return raw.decode('cp1252', errors='replace')


def parse_vbs(text):
    """Pasii din fisierul inregistrat: dict(id, op='set'|'call', name, value|args)."""
    steps = []
    for n, line in enumerate(text.splitlines(), 1):
        m = _LINE.match(line)
        if not m:
            continue
        sid, name, assigned, args = m.group(1).replace('""', '"'), m.group(2), m.group(3), m.group(4)
        if assigned is not None:
            steps.append({'id': sid, 'op': 'set', 'name': name, 'value': _vbs_value(assigned), 'line': n})
        else:
            steps.append({'id': sid, 'op': 'call', 'name': name, 'args': _split_args(args) if args else [], 'line': n})
    if not steps:
        raise AppError('SAP_TEMPLATE', 'The .vbs file contains no SAP GUI steps (session.findById...).')
    return steps


def _digits(s):
    return re.sub(r'[^\d]', '', str(s))


def amount_style(sample):
    """Formatul sumei tastate in inregistrare: '850.000' / '850,000' / '850000' / '850.000,00' / '850000.00'."""
    s = str(sample).strip()
    dec, decsep = 0, ''
    m = re.search(r'([.,])(\d{1,2})$', s)
    if m:
        dec, decsep = len(m.group(2)), m.group(1)
        s = s[:m.start()]
    thousands = '.' if '.' in s else (',' if ',' in s else '')
    if not decsep:
        decsep = ',' if thousands == '.' else '.'
    return {'thousands': thousands, 'decsep': decsep, 'decimals': dec}


def format_amount(value, fmt):
    v = int(round(float(value)))
    s = f'{v:,}'.replace(',', fmt.get('thousands', ''))
    dec = int(fmt.get('decimals', 0))
    return s + (fmt.get('decsep', '.') + '0' * dec if dec else '')


DATE_FORMATS = ['%d.%m.%Y', '%m/%d/%Y', '%d/%m/%Y', '%Y-%m-%d', '%Y.%m.%d', '%d-%m-%Y']


def _date_format_of(sample, target):
    for f in DATE_FORMATS:
        try:
            if dt.datetime.strptime(str(sample).strip(), f).date() == target:
                return f
        except ValueError:
            pass
    return None


def build_template(vbs_text, samples, source_name=''):
    """Transforma inregistrarea in sablon.

    samples: valorile folosite la inregistrare, ex. {'bp': '76014759', 'customer_code': '76021671',
             'limit': 850000, 'valid_to': date(2027,10,31), 'grade': '6'} (doar cele tastate).
    Intoarce (template_dict, raport_text)."""
    steps = parse_vbs(vbs_text)
    formats, found = {}, {}
    for s in steps:
        if s['op'] != 'set' or not isinstance(s['value'], str) or s['name'].lower() not in ('text', 'key'):
            continue
        val = s['value'].strip()
        for key, sample in samples.items():
            if sample in (None, ''):
                continue
            hit = False
            if key == 'limit':
                if re.fullmatch(r'[\d.,\s]+', val) and _norm_amount(val) == str(int(float(sample))):
                    formats['limit'] = amount_style(val)
                    hit = True
            elif key in ('valid_to', 'today'):
                f = _date_format_of(val, sample)
                if f:
                    formats[key] = {'date': f}
                    hit = True
            elif val == str(sample).strip() or (val.isdigit() and val.lstrip('0') == str(sample).strip().lstrip('0')):
                hit = True
            if hit:
                s['value'] = '{' + key + '}'
                found.setdefault(key, []).append(s['id'])
                break
    # valorile din argumentele apelurilor (grila ALV: modifyCell rand, "COLOANA", "valoare")
    for s in steps:
        if s['op'] != 'call' or not s.get('args'):
            continue
        for ai, arg in enumerate(s['args']):
            if not isinstance(arg, str) or ai == 0:
                continue
            val = arg.strip()
            for key, sample in samples.items():
                if sample in (None, '', True, False):
                    continue
                hit = False
                if key in ('limit', 'mtm'):
                    if re.fullmatch(r'[\d.,\s]+', val) and _norm_amount(val) == str(int(float(sample))):
                        formats[key] = amount_style(val)
                        hit = True
                elif key in ('valid_to', 'today'):
                    f = _date_format_of(val, sample)
                    if f:
                        formats[key] = {'date': f}
                        hit = True
                elif val == str(sample).strip():
                    hit = True
                if hit:
                    s['args'][ai] = '{' + key + '}'
                    found.setdefault(key, []).append(f'{s["id"]} ({s["name"]})')
                    break
    # randurile din grila: rolul se deduce din ce se scrie pe ele (limita -> Open Limit, mtm -> MTM & PFE)
    roles = {}
    for s in steps:
        if s['op'] == 'call' and s['name'] in GRID_CALLS and s.get('args') and isinstance(s['args'][0], int):
            vals = [a for a in s['args'][1:] if isinstance(a, str)]
            if '{limit}' in vals:
                roles[(s['id'], s['args'][0])] = 'open'
            elif '{mtm}' in vals:
                roles[(s['id'], s['args'][0])] = 'mtm'
    for s in steps:
        if s['op'] == 'call' and s['name'] in GRID_CALLS and s.get('args') and isinstance(s['args'][0], int):
            role = roles.get((s['id'], s['args'][0]))
            if role:
                s['grid_role'] = role
        elif s['op'] == 'set' and s['name'].lower() == 'currentcellrow' and isinstance(s['value'], int):
            role = roles.get((s['id'], s['value']))
            if role:
                s['grid_role'] = role
    # bifa Equity Scenario: primul .selected = true de pe ecranul principal
    if samples.get('equity'):
        for s in steps:
            if s['op'] == 'set' and s['name'].lower() == 'selected' and s['id'].startswith('wnd[0]/usr') and s['value'] is True:
                s['value'] = '{equity}'
                found.setdefault('equity', []).append(s['id'])
                break
    notes = _adapt_zbeu(steps, found)
    save_idx = next((i for i, s in enumerate(steps) if s['op'] == 'call' and s['name'].lower() == 'press' and s['id'] in SAVE_IDS), None)
    tpl = {
        'name': f'Actualizare limita SAP ({source_name})' if source_name else 'Actualizare limita SAP',
        'source': source_name,
        'imported_at': dt.datetime.now().isoformat(timespec='seconds'),
        'save_step': save_idx,
        'formats': formats,
        'steps': steps,
    }
    lines = [f'{len(steps)} pasi importati din {source_name or "inregistrare"}.']
    for key in dict.fromkeys(list(samples) + list(found)):
        if key not in found and (samples.get(key) in (None, '', False) or (key == 'customer_code' and any('BUSSEARCH' in x.upper() for x in found.get('bp', [])))):
            continue
        if key in found:
            lines.append(f'  {{{key}}} <- {PLACEHOLDERS.get(key, key)}: {len(found[key])} camp(uri) {found[key][0]}')
        else:
            lines.append(f'  ATENTIE: valoarea pentru {PLACEHOLDERS.get(key, key)} ("{samples[key]}") nu apare in inregistrare.')
    if save_idx is None:
        lines.append('  ATENTIE: nu am gasit apasarea pe Save / rotita (wnd[0]/tbar[0]/btn[11] sau wnd[0]/tbar[1]/btn[8]) - sablonul nu poate trimite.')
    for role, label in (('open', 'Open Limit'), ('mtm', 'MTM & PFE limit')):
        if any(s.get('grid_role') == role for s in steps):
            lines.append(f'  Grila: randul "{label}" se cauta la fiecare client dupa Segment + Info Type Text.')
    else:
        lines.append(f'  Save / Execute = pasul {save_idx + 1}; dupa el urmeaza {len(steps) - save_idx - 1} pas(i) (Approve, comentariu, atasamente, caz).')
    lines += ['  ' + n for n in notes]
    if 'limit' not in found and not any(s.get('synth') for s in steps):
        lines.append('  Sablonul NU modifica limita - verifica valoarea introdusa si reimporta.')
    return tpl, '\n'.join(lines)


def _adapt_zbeu(steps, found):
    """Ajustari pentru ZBEU_UKM_BP_CREDIT_L, deduse din inregistrare. Intoarce notele pentru raportul de import."""
    notes = []
    # cautarea BP (F4) cauta dupa numarul de BP: BP != Customer Code la clienti -> se tasteaza BP-ul din NWCE
    for s in steps:
        if s['op'] == 'set' and 'BUSSEARCH-PARTNER' in s['id'].upper() and s['value'] == '{customer_code}':
            s['value'] = '{bp}'
            found.setdefault('bp', []).append(s['id'])
            if s['id'] in found.get('customer_code', []):
                found['customer_code'].remove(s['id'])
                if not found['customer_code']:
                    del found['customer_code']
            notes.append('Cautarea F4 e dupa numarul de BP: se tasteaza BP code din NWCE (nu Customer Code).')
        if s['op'] == 'set' and s['name'].lower() == 'selectedrows':
            s['expect_one'] = True
    # tranzactia pornita din Favorite (arborele din SAP Easy Access): intai /n, ca sa fim pe meniul principal
    i0 = next((i for i, s in enumerate(steps) if s['name'] not in OPTIONAL_OPS), None)
    if i0 is not None and steps[i0]['name'] == 'doubleClickNode':
        steps[i0]['check_tcode'] = True
        steps[i0:i0] = [{'id': 'wnd[0]/tbar[0]/okcd', 'op': 'set', 'name': 'text', 'value': '/nSESSION_MANAGER', 'line': 0, 'synth': True},
                        {'id': 'wnd[0]', 'op': 'call', 'name': 'sendVKey', 'args': [0], 'line': 0, 'synth': True}]
        notes.append('Tranzactia porneste din Favorite: inainte se revine la meniul principal (/n), apoi se verifica tranzactia.')
    # segmentul de credit tastat -> {segment}; "NEW_SEGMENTS" + popup-ul lui doar daca clientul nu are segmentul
    for s in steps:
        if s['op'] == 'set' and isinstance(s['value'], str) and SEGMENT_RE.match(s['value'].strip()):
            s['value'] = '{segment}'
            found.setdefault('segment', []).append(s['id'])
    for i, s in enumerate(steps):
        if s['op'] == 'call' and s['name'] == 'pressToolbarButton' and s.get('args') == ['NEW_SEGMENTS']:
            s['if_segment_missing'] = True
            j = i + 1
            while j < len(steps) and steps[j]['id'].startswith('wnd[1]'):
                steps[j]['if_segment_missing'] = True
                j += 1
            notes.append('Segmentul nou se adauga doar daca clientul nu il are deja in grila.')
    # limita Open nu e in inregistrare (ex. furnizor cu Open 0): aceiasi pasi ca la MTM, pe randul "Open Limit"
    mtm_steps = [s for s in steps if s.get('grid_role') == 'mtm' and s['name'] == 'modifyCell']
    if 'limit' not in found and mtm_steps:
        amount = next((s for s in mtm_steps if '{mtm}' in s['args']), None)
        cur = next((s for s in mtm_steps if s is not amount and len(s['args']) == 3 and isinstance(s['args'][2], str)
                    and re.fullmatch(r'[A-Za-z]{3}', s['args'][2])), None)
        grid = amount['id']
        new = [{'id': grid, 'op': 'call', 'name': 'modifyCell', 'args': [0, amount['args'][1], '{limit}'], 'grid_role': 'open', 'synth': True}]
        if cur:
            new.append({'id': grid, 'op': 'call', 'name': 'modifyCell', 'args': [0, cur['args'][1], '{currency}'], 'grid_role': 'open', 'synth': True})
        new.append({'id': grid, 'op': 'call', 'name': 'triggerModified', 'args': [], 'grid_role': 'open', 'synth': True})
        at = steps.index(next(s for s in steps if s.get('grid_role') == 'mtm'))
        for k, st in enumerate(new):
            st['line'] = 0
            steps.insert(at + k, st)
        found.setdefault('limit', []).append(f'{grid} (randul "Open Limit", coloana {amount["args"][1]} - dedus din pasii MTM)')
        notes.append(f'Limita Open: completata pe randul "Open Limit", coloana {amount["args"][1]}'
                     f'{" + moneda " + cur["args"][1] if cur else ""} (dedus din pasii MTM - de confirmat la Proba).')
    return notes


def template_file(cfg):
    p = Path(paths.expand(cfg.get('sap', 'template')))
    return p if p.is_absolute() else paths.APP_ROOT / p


def load_template(cfg):
    p = template_file(cfg)
    if not p.exists():
        raise AppError('SAP_TEMPLATE', f'SAP template not found: {p}')
    return json.loads(p.read_text(encoding='utf-8'))


def save_template(cfg, tpl):
    p = template_file(cfg)
    p.parent.mkdir(parents=True, exist_ok=True)
    if p.exists():   # pastreaza versiunea anterioara
        p.replace(p.with_name(f'{p.stem}_{dt.datetime.now():%Y%m%d_%H%M%S}{p.suffix}'))
    p.write_text(json.dumps(tpl, indent=2, ensure_ascii=False), encoding='utf-8')
    return p


# ---------------------------------------------------------------- COM: apeluri explicite
def _invoke(obj, name, kind, *args):
    """Apel COM explicit (metoda / get / put). Evita ambiguitatea din dispatch-ul dinamic al pywin32,
    unde citirea unui atribut poate executa o metoda (ex. .press)."""
    import pythoncom
    ole = obj._oleobj_ if hasattr(obj, '_oleobj_') else obj
    dispid = ole.GetIDsOfNames(name)
    flags = {'method': pythoncom.DISPATCH_METHOD, 'get': pythoncom.DISPATCH_PROPERTYGET,
             'put': pythoncom.DISPATCH_PROPERTYPUT}[kind]
    res = ole.Invoke(dispid, 0, flags, kind != 'put', *args)
    if kind != 'put' and type(res).__name__ == 'PyIDispatch':
        import win32com.client
        return win32com.client.Dispatch(res)
    return res


def _find(session, sid):
    try:
        return _invoke(session, 'findById', 'method', sid, False)
    except Exception:
        return None


def _get(obj, prop):
    try:
        return _invoke(obj, prop, 'get')
    except Exception:
        return None


@dataclass
class SapSessionInfo:
    system: str
    client: str
    user: str
    transaction: str
    language: str = ''

    def __str__(self):
        return f'{self.system}/{self.client} {self.user}'


def connect(cfg):
    """Prima sesiune SAP libera (sau a sistemului configurat). Intoarce (session, info)."""
    import pythoncom
    import win32com.client
    pythoncom.CoInitialize()
    try:
        sapgui = win32com.client.GetObject('SAPGUI')
    except Exception:
        raise AppError('SAP_NOT_RUNNING', 'SAP Logon is not running.')
    try:
        app = _invoke(sapgui, 'GetScriptingEngine', 'get')
    except Exception as e:
        raise AppError('SAP_SCRIPTING', f'SAP GUI scripting engine not available: {e}')
    want = (cfg.get('sap', 'systemName') or '').strip().upper()
    idle_rank = {'SESSION_MANAGER': 0, 'SMEN': 0, 'S000': 1}   # doar sesiuni pe meniul principal
    candidates, in_use = [], []
    conns = _get(app, 'Children')
    n_conn = _get(conns, 'Count') or 0
    if not n_conn:
        raise AppError('SAP_NOT_RUNNING', 'SAP Logon is open, but you are not logged in to any system.')
    for i in range(n_conn):
        conn = _invoke(conns, 'ElementAt', 'method', i)
        if _get(conn, 'DisabledByServer'):
            raise AppError('SAP_SCRIPTING', 'Scripting is disabled on the SAP server (sapgui/user_scripting).')
        sessions = _get(conn, 'Children')
        for j in range(_get(sessions, 'Count') or 0):
            s = _invoke(sessions, 'ElementAt', 'method', j)
            if _get(s, 'Busy'):
                continue
            info = _get(s, 'Info')
            si = SapSessionInfo(str(_get(info, 'SystemName') or ''), str(_get(info, 'Client') or ''),
                                str(_get(info, 'User') or ''), str(_get(info, 'Transaction') or ''), str(_get(info, 'Language') or ''))
            if want and si.system.upper() != want:
                continue
            if not si.user:
                continue   # ecran de login
            # o sesiune intr-o tranzactie poate avea lucru nesalvat al analistului: nu o folosim
            if si.transaction.upper() in idle_rank:
                candidates.append((idle_rank[si.transaction.upper()], -j, s, si))
            else:
                in_use.append(si.transaction)
    if candidates:
        candidates.sort(key=lambda c: c[:2])
        return candidates[0][2], candidates[0][3]
    if in_use:
        raise AppError('SAP_NOT_RUNNING', f'All SAP sessions are busy in a transaction ({", ".join(in_use)}). '
                                          'Open a new session on the main menu (SAP Easy Access) and retry.')
    raise AppError('SAP_NOT_RUNNING', f'No free SAP session{" for " + want if want else ""} (logged in).')


# ---------------------------------------------------------------- executie
@dataclass
class SapRunResult:
    ok: bool = False
    dry_run: bool = True
    saved: bool = False
    submit_attempted: bool = False                  # rotita / Save apasata (chiar daca apelul COM a dat eroare)
    message: str = ''
    status_type: str = ''
    status_text: str = ''
    before: dict = field(default_factory=dict)     # placeholder -> valoarea gasita pe ecran inainte
    after: dict = field(default_factory=dict)      # placeholder -> valoarea citita dupa Save / inainte de iesire
    expected: dict = field(default_factory=dict)
    screenshots: list = field(default_factory=list)
    session: str = ''
    case_number: str = ''
    popups: list = field(default_factory=list)      # textele ferestrelor popup (Approve, comentariu, caz...)
    log: list = field(default_factory=list)


def render_values(tpl, values):
    """Valorile reale in formatul inregistrarii (suma cu separatori, data dd.mm.yyyy...)."""
    fm = tpl.get('formats', {})
    out = {}
    for k, v in values.items():
        if v is None:
            continue
        if k in ('limit', 'mtm'):
            out[k] = format_amount(v, fm.get(k, fm.get('limit', {})))
        elif k == 'equity':
            continue
        elif isinstance(v, (dt.date, dt.datetime)):
            out[k] = v.strftime(fm.get(k, {}).get('date', '%d.%m.%Y'))
        else:
            out[k] = str(v)
    return out


def _subst(value, rendered):
    if not isinstance(value, str):
        return value

    def rep(m):
        k = m.group(1)
        if k not in rendered:
            raise AppError('SAP_TEMPLATE', f'No value for {{{k}}} (missing data for this client).')
        return rendered[k]
    return re.sub(r'\{(' + '|'.join(PLACEHOLDERS) + r')\}', rep, value)


def _status(session):
    sbar = _find(session, 'wnd[0]/sbar')
    if sbar is None:
        return '', ''
    return str(_get(sbar, 'MessageType') or ''), str(_get(sbar, 'Text') or '')


def _popup_text(session):
    """Tot textul vizibil din fereastra popup (titlu + toate controalele, pe 3 niveluri)."""
    w = _find(session, 'wnd[1]')
    if w is None:
        return None
    parts = [str(_get(w, 'Text') or '')]

    def walk(o, depth):
        kids = _get(o, 'Children')
        for i in range(min(_get(kids, 'Count') or 0, 40) if kids is not None else 0):
            try:
                k = _invoke(kids, 'ElementAt', 'method', i)
            except Exception:
                continue
            t = _get(k, 'Text')
            if t and str(t).strip():
                parts.append(str(t).strip())
            if depth < 3 and _get(k, 'ContainerType'):
                walk(k, depth + 1)
    usr = _find(session, 'wnd[1]/usr')
    if usr is not None:
        walk(usr, 0)
    return ' | '.join(p for p in parts if p)


CASE_RE = re.compile(r'(?:Case|Caz|SCase)\D{0,25}?(\d{5,})', re.I)


def _case_from(text):
    m = CASE_RE.search(text or '')
    return (m.group(1).lstrip('0') or m.group(1)) if m else ''


def _grid_cols(grid):
    """(randuri, coloana Segment, coloana Info Type Text) din grila ZBEU. Dupa titlu, iar daca titlurile
    nu se potrivesc, dupa continut (ZIT1_LIMIT... / 'Open Limit', 'MTM ...')."""
    cols = _get(grid, 'ColumnOrder')
    names = []
    try:
        n = _get(cols, 'Count') or 0
        names = [str(_invoke(cols, 'ElementAt', 'method', i)) for i in range(n)]
    except Exception:
        try:
            names = [str(c) for c in cols]
        except Exception:
            names = []
    title = {}
    for c in names:
        try:
            title[c] = str(_invoke(grid, 'GetDisplayedColumnTitle', 'method', c) or '')
        except Exception:
            title[c] = c
    rows = int(_get(grid, 'RowCount') or 0)

    def cell(r, c):
        try:
            return str(_invoke(grid, 'GetCellValue', 'method', r, c) or '').strip()
        except Exception:
            return ''
    seg_col = next((c for c in names if 'segment' in title[c].lower() or 'SGM' in c.upper()), None) or \
        next((c for c in names if any(SEGMENT_RE.match(cell(r, c)) for r in range(min(rows, 30)))), None)
    info_col = next((c for c in names if 'info' in title[c].lower() and 'text' in title[c].lower()), None) or \
        next((c for c in names if 'TEXT' in c.upper() and 'INFO' in c.upper()), None) or \
        next((c for c in names if any(re.search(r'open limit|mtm', cell(r, c), re.I) for r in range(min(rows, 30)))), None)
    return rows, seg_col, info_col, names, cell


def _grid_has_segment(grid, segment):
    rows, seg_col, _, names, cell = _grid_cols(grid)
    if not seg_col:
        raise AppError('SAP_SCREEN', f'Grid: column "Segment" not found (columns: {", ".join(names[:15])})')
    return any(cell(r, seg_col).upper() == segment.upper() for r in range(rows))


def _grid_row(grid, role, segment):
    """Randul din grila ZBEU_UKM_BP_CREDIT_L pentru 'open' (Open Limit) / 'mtm' (MTM & PFE limit) pe segmentul dat.
    Pozitia difera de la client la client (mai multe segmente), deci se cauta dupa Segment + Info Type Text."""
    rows, seg_col, info_col, names, cell = _grid_cols(grid)
    if not info_col:
        raise AppError('SAP_SCREEN', f'Grid: column "Info Type Text" not found (columns: {", ".join(names[:15])})')
    if segment and not seg_col:
        raise AppError('SAP_SCREEN', f'Grid: column "Segment" not found (columns: {", ".join(names[:15])})')
    want = 'open limit' if role == 'open' else 'mtm'
    hits = [r for r in range(rows) if want in cell(r, info_col).lower()
            and (not segment or cell(r, seg_col).upper() == segment.upper())]
    if len(hits) == 1:
        return hits[0]
    raise AppError('SAP_SCREEN', f'Grid: {"no" if not hits else len(hits)} row(s) "{want}" for segment {segment or "?"}.')


def _check_bp_hits(grid, bp):
    """Lista din cautarea BP: un partener apare o data pe adresa (ex. VBGRAINS: Ancona + Roma), deci se accepta
    mai multe randuri doar daca TOATE au Partner = BP-ul cautat."""
    n_rows = int(_get(grid, 'RowCount') or 0)
    if not n_rows:
        raise AppError('SAP_SCREEN', f'BP search returned no results for BP {bp}.')
    cols = _get(grid, 'ColumnOrder')
    try:
        names = [str(_invoke(cols, 'ElementAt', 'method', i)) for i in range(_get(cols, 'Count') or 0)]
    except Exception:
        names = []
    col = next((c for c in names if c.upper() == 'PARTNER'), None)
    if not col:
        if n_rows == 1:
            return
        raise AppError('SAP_SCREEN', f'BP search returned {n_rows} results for BP {bp} and the Partner column is not visible.')
    found = {str(_invoke(grid, 'GetCellValue', 'method', r, col) or '').strip().lstrip('0') for r in range(n_rows)}
    if found != {str(bp or '').strip().lstrip('0')}:
        raise AppError('SAP_SCREEN', f'BP search for {bp} returned other partners: {", ".join(sorted(found))}.')


def _set_equity(session, on):
    """Bifa Equity Scenario de pe ecranul principal, gasita dupa text (nu e in inregistrare cand n-a fost bifata)."""
    found = []

    def walk(o, depth):
        kids = _get(o, 'Children')
        for i in range(min(_get(kids, 'Count') or 0, 200) if kids is not None else 0):
            try:
                k = _invoke(kids, 'ElementAt', 'method', i)
            except Exception:
                continue
            txt = f'{_get(k, "Text") or ""} {_get(k, "Tooltip") or ""} {_get(k, "Name") or ""}'
            if str(_get(k, 'Type') or '') == 'GuiCheckBox' and 'equity' in txt.lower():
                found.append(k)
            elif depth < 3:
                walk(k, depth + 1)
    usr = _find(session, 'wnd[0]/usr')
    if usr is not None:
        walk(usr, 0)
    if len(found) != 1:
        if not on:
            return None          # nu trebuie bifata; daca nu o gasim, nu e nimic de facut
        raise AppError('SAP_SCREEN', f'Equity Scenario checkbox: {len(found)} found on screen - tick it manually or re-record with it ticked.')
    before = bool(_get(found[0], 'Selected'))
    _invoke(found[0], 'Selected', 'put', bool(on))
    return before, bool(on)


def _norm_amount(s):
    s = str(s or '').strip()
    s = re.sub(r'[.,]\d{1,2}$', '', s) if re.search(r'[.,]\d{1,2}$', s) and not re.search(r'[.,]\d{3}$', s) else s
    return _digits(s).lstrip('0') or '0'


def _same_value(key, a, b):
    if key in ('limit', 'mtm'):
        return _norm_amount(a) == _norm_amount(b)
    return str(a or '').strip().lstrip('0') == str(b or '').strip().lstrip('0')


def run(tpl, values, cfg, dry_run=True, shot_dir=None, cancel=None):
    """Executa sablonul pentru un client. values: dict cu bp, customer_code, limit, valid_to, grade, today."""
    res = SapRunResult(dry_run=dry_run)
    grid_rows = {}
    save_idx = tpl.get('save_step')
    if save_idx is None and not dry_run:
        raise AppError('SAP_TEMPLATE', 'The SAP template has no Save step - re-record including the Save click.')
    values = dict(values)
    values.setdefault('today', dt.date.today())
    segment = values.get('segment') or cfg.get('sap', 'segment') or ''
    values['segment'] = segment or None
    values.setdefault('currency', 'EUR')
    # 0 / lipsa = randul respectiv din grila nu se atinge (ex. furnizor: doar MTM)
    skip_roles = {r for r, k in (('open', 'limit'), ('mtm', 'mtm')) if not values.get(k)}
    rendered = render_values(tpl, values)
    res.expected = dict(rendered)
    session, info = connect(cfg)
    res.session = str(info)
    steps = tpl['steps']
    stop_at = save_idx if (dry_run or save_idx is None) else len(steps)
    shot_dir = Path(shot_dir) if shot_dir else None
    stamp = dt.datetime.now().strftime('%Y%m%d_%H%M%S')
    placeholder_fields = {}     # id camp -> placeholder (pentru citirea dupa)

    def shot(tag):
        if not shot_dir:
            return
        try:
            shot_dir.mkdir(parents=True, exist_ok=True)
            p = shot_dir / f'SAP_{values.get("customer_code", "")}_{stamp}_{tag}.png'
            w = _find(session, 'wnd[0]')
            _invoke(w, 'HardCopy', 'method', str(p), 2)
            res.screenshots.append(p)
        except Exception as e:
            _log.warning('SAP screenshot failed: %s', e)

    def leave():
        try:
            okcd = _find(session, 'wnd[0]/tbar[0]/okcd')
            if okcd is not None and _find(session, 'wnd[1]') is None:
                _invoke(okcd, 'Text', 'put', '/n')
                _invoke(_find(session, 'wnd[0]'), 'sendVKey', 'method', 0)
        except Exception:
            pass

    try:
        skip_popup = False
        for i, s in enumerate(steps):
            if i == save_idx and not any(st.get('value') == '{equity}' for st in steps):
                eq = _set_equity(session, bool(values.get('equity')))
                if eq is not None:
                    res.before['equity'] = 'DA' if eq[0] else 'NU'
                    res.log.append(f'Equity Scenario = {"DA" if eq[1] else "NU"} (era {res.before["equity"]})')
            if i >= stop_at:
                break
            if cancel and cancel():
                raise AppError('CANCELLED', 'Cancelled before SAP save.')
            if s.get('grid_role') in skip_roles:
                continue
            if s.get('if_segment_missing'):
                if s['id'].startswith('wnd[0]'):
                    skip_popup = _grid_has_segment(_find(session, s['id']), segment)
                    if skip_popup:
                        res.log.append(f'{i + 1}. segmentul {segment} exista deja - nu se adauga')
                if skip_popup:
                    continue
            # un popup care nu e in inregistrare inainte de un pas pe wnd[0] = ceva neprevazut
            if s['id'].startswith('wnd[0]') and _find(session, 'wnd[1]') is not None:
                raise AppError('SAP_SCREEN', f'Unexpected SAP popup before step {i + 1}: {_popup_text(session)}')
            obj = _find(session, s['id'])
            optional = s['name'] in OPTIONAL_OPS
            if obj is None and save_idx is not None and i > save_idx and s['id'].startswith('wnd[1]'):
                # dupa rotita SAP nu arata mereu toate confirmarile inregistrate (comentariu / atasamente / SCase):
                # daca nu mai e nicio fereastra popup, cererea e deja trimisa - pasul se sare, nu e eroare
                t0 = time.time()
                while _find(session, 'wnd[1]') is None and time.time() - t0 < POPUP_WAIT:
                    time.sleep(0.3)
                if _find(session, 'wnd[1]') is None:
                    res.log.append(f'{i + 1}. fereastra popup nu a mai aparut - pas sarit')
                    continue
                obj = _find(session, s['id'])
            if obj is None:
                if optional:
                    continue
                raise AppError('SAP_SCREEN', f'Step {i + 1} (line {s.get("line")}): field not on screen: {s["id"]}', ' '.join(_status(session)))
            if i == save_idx:
                shot('1_before_save')
                res.submit_attempted = not dry_run
            try:
                if s['id'].startswith('wnd[1]'):
                    txt = _popup_text(session) or ''
                    if txt and (not res.popups or res.popups[-1] != txt):
                        res.popups.append(txt)          # tot ce a aratat SAP in ferestre (pentru jurnal)
                    res.case_number = _case_from(txt) or res.case_number
                if s['op'] == 'set' and s['value'] == '{equity}':
                    _invoke(obj, s['name'], 'put', bool(values.get('equity')))
                elif s.get('expect_one'):
                    _check_bp_hits(obj, values.get('bp'))
                    _invoke(obj, s['name'], 'put', s['value'])
                elif s['op'] == 'set' and s.get('grid_role'):
                    key = (s['id'], s['grid_role'])
                    if key not in grid_rows:
                        grid_rows[key] = _grid_row(obj, s['grid_role'], segment)
                    _invoke(obj, s['name'], 'put', grid_rows[key])
                elif s['op'] == 'set':
                    val = _subst(s['value'], rendered)
                    m = re.fullmatch(r'\{(' + '|'.join(PLACEHOLDERS) + r')\}', str(s['value']))
                    if m:
                        placeholder_fields[s['id']] = m.group(1)
                        res.before.setdefault(m.group(1), str(_get(obj, s['name']) or ''))
                    _invoke(obj, s['name'], 'put', val)
                else:
                    args = [_subst(a, rendered) for a in s.get('args', [])]
                    if s.get('grid_role') and args and isinstance(args[0], int):
                        key = (s['id'], s['grid_role'])
                        if key not in grid_rows:
                            grid_rows[key] = _grid_row(obj, s['grid_role'], segment)
                            for a_ in s.get('args', [])[1:]:
                                m_ph = re.fullmatch(r'\{(limit|mtm|valid_to)\}', str(a_))
                                if m_ph:
                                    try:
                                        res.before.setdefault(m_ph.group(1) + f'@{s["grid_role"]}',
                                                              str(_invoke(obj, 'GetCellValue', 'method', grid_rows[key], args[1])))
                                    except Exception:
                                        pass
                        args[0] = grid_rows[key]
                    _invoke(obj, s['name'], 'method', *args)
            except AppError:
                raise
            except Exception as e:
                if optional:
                    continue
                raise AppError('SAP_SCREEN', f'Step {i + 1} (line {s.get("line")}) {s["name"]} on {s["id"]} failed: {e}')
            res.log.append(f'{i + 1}. {s["name"]} {s["id"].split("/")[-1]}')
            # asteapta SAP si verifica mesajele de eroare dupa fiecare actiune de navigare
            if s['op'] == 'call' and s['name'] in ('sendVKey', 'press', 'select', 'doubleClickNode', 'doubleClick',
                                                   'doubleClickCurrentCell', 'pressToolbarButton'):
                t0 = time.time()
                while _get(session, 'Busy') and time.time() - t0 < 60:
                    time.sleep(0.2)
                mt, txt = _status(session)
                if save_idx is not None and i >= save_idx and txt:
                    res.case_number = _case_from(txt) or res.case_number      # unele sisteme dau cazul in bara de stare
                    if not res.popups or res.popups[-1] != f'[bara de stare] {txt}':
                        res.popups.append(f'[bara de stare] {txt}')
                if mt in ('E', 'A') and i != save_idx:
                    raise AppError('SAP_ERROR', f'SAP error after step {i + 1}: {txt}')
                if i == save_idx:
                    res.status_type, res.status_text = mt, txt
                    if mt in ('E', 'A'):
                        raise AppError('SAP_ERROR', f'SAP refused the save: {txt}')
                    res.saved = True
                if s.get('check_tcode'):
                    want = (cfg.get('sap', 'transaction') or '').upper()
                    got = str(_get(_get(session, 'Info'), 'Transaction') or '').upper()
                    if want and got != want:
                        raise AppError('SAP_SCREEN', f'The favourite opened transaction {got or "?"}, expected {want}.')

        # citire dupa (in proba: valorile tastate, inainte de iesire; real: dupa Save)
        for fid, key in placeholder_fields.items():
            obj = _find(session, fid)
            if obj is not None:
                name = next((s['name'] for s in steps if s['id'] == fid and s['op'] == 'set'), 'Text')
                res.after[key] = str(_get(obj, name) or '')
        if dry_run:
            shot('proba')
            mt, txt = _status(session)
            res.status_type, res.status_text = mt, txt
            res.ok = True
            res.message = 'Proba reusita: toti pasii pana la Save au mers. Nimic nu a fost salvat.'
        else:
            shot('2_after_save')
            bad = [k for k in ('limit', 'valid_to') if res.after.get(k) and k in rendered and not _same_value(k, res.after[k], rendered[k])]
            # ZBEU (rotita): modificarea devine un caz de aprobare, ecranul poate arata inca valorile vechi
            case_flow = steps[save_idx]['id'] != 'wnd[0]/tbar[0]/btn[11]'
            if bad and case_flow:
                _log.info('SAP after case creation shows %s', {k: res.after[k] for k in bad})
                bad = []
            if bad:
                raise AppError('SAP_VERIFY', 'After save SAP shows: ' + ', '.join(f'{k}="{res.after[k]}" (expected "{rendered[k]}")' for k in bad))
            res.ok = True
            verified = [k for k in ('limit', 'valid_to') if res.after.get(k) and k in rendered and _same_value(k, res.after[k], rendered[k])]
            res.message = (f'Trimis in SAP{" - caz " + res.case_number if res.case_number else ""}: {res.status_text or "fara mesaj"}'
                           + (f' | verificat: {", ".join(verified)}' if verified else ''))
    except AppError as e:
        res.ok = False
        if (res.saved or res.submit_attempted) and not dry_run:
            e.message = f'DUPA SAVE / ROTITA (cererea poate fi deja trimisa - verifica in SAP inainte de a repeta): {e.message}'
            e.code = 'SAP_SUBMITTED'
        res.message = e.message
        e.sap_result = res          # pipeline-ul pastreaza "trimis" ca sa nu retrimita cazul
        shot('eroare')
        raise
    except Exception as e:
        # eroare COM neasteptata: daca rotita a fost deja apasata, cererea poate exista in SAP
        res.ok = False
        err = AppError('UNKNOWN', f'{type(e).__name__}: {e}')
        if res.submit_attempted:
            err = AppError('SAP_SUBMITTED', f'DUPA SAVE / ROTITA (cererea poate fi deja trimisa - verifica in SAP inainte de a repeta): {e}')
        res.message = err.message
        err.sap_result = res
        shot('eroare')
        raise err from e
    finally:
        leave()   # proba / eroare inainte de Save: iesire fara salvare; dupa Save: inchide tranzactia
    return res
