"""Fluxul pe client: pregatire (VAT -> Creditsafe, gratuit) -> raport (credite / cache) -> folder client ->
PDF -> scorecard -> propunere de limita -> decizia analistului -> NWCE -> SAP.

Toate functiile ruleaza in firul de lucru (nu in interfata). Fiecare pas e scris in baza de audit.
"""
import concurrent.futures as cf
import datetime as dt
import re
from dataclasses import asdict, dataclass, field
from pathlib import Path

from . import client_folders, errors, fsutil, limits_book, log, mapping, paths, rules, scorecard
from .creditsafe import country_of_vat
from .errors import AppError
from .excel_com import ExcelApp, is_dead

_log = log.get('pipeline')

STATE_LABELS = {
    'new': 'De evaluat', 'prepared': 'Pregatit', 'evaluated': 'Evaluat', 'evaluated_manual': 'Evaluat - fara bilant',
    'error': 'Eroare', 'approved': 'Aprobat', 'done': 'Finalizat', 'cancelled': 'Anulat - de reluat',
}


@dataclass
class Evaluation:
    partner: str
    name: str
    id: int = None
    created: str = ''
    state: str = 'new'
    vat: str = ''
    country: str = 'IT'
    customer_name: str = ''           # numele din NWCE / portofoliu (folosit in scorecard si folder)
    customer_code: str = ''           # Customer Code (gol pentru unele randuri NWCE)
    company_code: str = ''            # company code NWCE (6675 - Italy, 6575 - Hungary...)
    currency: str = 'EUR'             # moneda limitei (K loc. curr.)
    connect_id: str = ''
    cs_candidates: list = field(default_factory=list)
    cs: dict = field(default_factory=dict)
    report_json: str = ''
    report_fetched: str = ''
    report_from_cache: bool = False
    folder: str = ''
    folder_exists: bool = False
    folder_alternatives: list = field(default_factory=list)
    dest_dir: str = ''
    files: dict = field(default_factory=dict)
    inputs: dict = field(default_factory=dict)
    scorecard: dict = None
    proposal: dict = None
    charge: bool = None               # deschiderea raportului consuma credit (verificat pe site); None = necunoscut
    nwce_row: dict = None             # randul NWCE la momentul evaluarii (sheet_row, values, how)
    review: dict = None               # revizuirea lunara: expunere, activ, limita noua, autoritate, ruta
    decision: dict = None
    nwce: dict = None
    sap: dict = None
    warnings: list = field(default_factory=list)
    error: dict = None

    def to_dict(self):
        return asdict(self)

    @classmethod
    def from_dict(cls, d):
        known = {f for f in cls.__dataclass_fields__}
        return cls(**{k: v for k, v in d.items() if k in known})

    @property
    def grade(self):
        try:
            return int(str((self.scorecard or {}).get('grade')))
        except (TypeError, ValueError):
            return None

    @property
    def display_state(self):
        if (self.decision or {}).get('inactivate') and self.state in ('approved', 'done'):
            n = (self.nwce or {}).get('status')
            return 'Inactivat in NWCE' if n == 'ok' else ('Inactivare - NWCE ✖' if n == 'error' else 'Inactivare aprobata - NWCE …')
        if self.state == 'approved' or self.state == 'done':
            parts = ['Aprobat']
            n = (self.nwce or {}).get('status')
            s = (self.sap or {}).get('status')
            parts.append('NWCE ✔' if n == 'ok' else ('NWCE ✖' if n == 'error' else 'NWCE …'))
            parts.append('SAP ✔' if s == 'ok' else ('SAP ✖' if s == 'error' else ('SAP proba ✔' if s == 'dry_ok' else 'SAP …')))
            if n == 'ok' and s == 'ok':
                return 'Finalizat (NWCE + SAP)'
            return ' | '.join(parts)
        return STATE_LABELS.get(self.state, self.state)


class Context:
    """Ce e nevoie pentru o rulare: configurare, audit, Creditsafe, NWCE, anulare, progres."""

    def __init__(self, cfg, db, cs, nwce=None, portfolio=None, progress=None, cancel=None):
        self.cfg = cfg
        self.db = db
        self.cs = cs
        self.nwce = nwce
        self.portfolio = portfolio
        self.progress = progress or (lambda *a: None)
        self.cancel = cancel or (lambda: False)
        self.excel = None

    def say(self, text, done=None, total=None):
        self.progress(text, done, total)

    def check_cancel(self):
        if self.cancel():
            raise AppError('CANCELLED', 'Stopped by the user.')

    def get_excel(self):
        if self.excel is None:
            self.excel = ExcelApp()
        return self.excel

    def restart_excel(self):
        if self.excel is not None:
            self.excel.quit()
        self.excel = ExcelApp()
        return self.excel

    def close(self):
        if self.excel is not None:
            self.excel.quit()
            self.excel = None


def log_event(ctx, ev, level, step, message, details=''):
    _log.info('[%s] %s %s: %s', ev.partner, level, step, message)
    try:
        ctx.db.event(ev.id, ev.partner, level, step, message, details)
    except Exception:
        _log.exception('audit event failed')


def set_error(ctx, ev, exc, step):
    f = errors.friendly(exc)
    ev.error = {**f, 'step': step, 'at': dt.datetime.now().isoformat(timespec='seconds')}
    ev.state = 'error'
    log_event(ctx, ev, 'ERROR', step, f['title'], f['details'])
    if f['code'] == 'UNKNOWN':
        _log.error('Unexpected error for %s:\n%s', ev.partner, errors.format_exc(exc))


# ---------------------------------------------------------------- 1. pregatire (gratuit)
def _nwce_info(ctx, cp):
    if not ctx.nwce:
        return None, 'NWCE neincarcat'
    company = ctx.cfg.get('limitsBook', 'companyCode')
    row, why = ctx.nwce.pick(cp.partner, cp.vat, company, ctx.cfg.get('portfolio', 'country'))
    return row, why


def new_evaluation(ctx, cp, overrides=None):
    o = overrides or {}
    ev = Evaluation(partner=cp.partner, name=cp.name, created=dt.datetime.now().isoformat(timespec='seconds'))
    ev.customer_code = cp.customer_code or ''
    ev.company_code = cp.company_code or ctx.cfg.get('limitsBook', 'companyCode')
    ev.currency = cp.currency or 'EUR'
    row, why = None, ''
    if cp.nwce_sheet_row and ctx.nwce:
        row = ctx.nwce.row_by_sheet(cp.nwce_sheet_row)
        if row is not None and (row.name != cp.name or row.company_code != cp.company_code):
            row = None      # NWCE s-a schimbat de la incarcare
        why = 'randul din lista TBD' if row is not None else 'randul TBD nu mai corespunde - reincarca NWCE'
    else:
        row, why = _nwce_info(ctx, cp)
    ev.customer_name = (row.name if row else '') or cp.name
    ev.vat = (o.get('vat') or cp.vat or (str(row.get('vat') or '').strip() if row else '')).strip()
    ev.country = country_of_vat(ev.vat, ctx.cfg.get('portfolio', 'country'))
    if row:
        ev.nwce_row = {'sheet_row': row.sheet_row, 'how': why, 'values': {k: v for k, v in row.values.items()}}
    else:
        ev.nwce_row = {'sheet_row': 0, 'how': why, 'values': {}}
    return ev


def prepare(ctx, cp, overrides=None):
    """VAT -> cautare Creditsafe (gratuita). Seteaza connect_id si candidatii. Nu consuma credite."""
    o = overrides or {}
    ev = new_evaluation(ctx, cp, o)
    try:
        if o.get('connect_id'):
            ev.connect_id = o['connect_id']
            ev.cs_candidates = o.get('candidates') or []
        else:
            if ev.vat:
                res = ctx.cs.find_by_vat(ev.vat, ev.country)
            else:
                res = []
            if not res and not ev.vat:
                # fara VAT: cautare dupa nume - NU se alege automat, analistul confirma firma
                res = ctx.cs.search(ev.country, name=re.sub(r'\b(S\.?R\.?L\.?|S\.?P\.?A\.?|SNC|SAS)\b\.?', '', cp.name).strip()[:60])
                ev.cs_candidates = [_cand(c) for c in res]
                raise AppError('NO_VAT' if not res else 'CS_AMBIGUOUS',
                               f'No VAT for {cp.name}; {len(res)} Creditsafe results by name - choose the right company.')
            if not res:
                raise AppError('NOT_FOUND', f'VAT {ev.vat} ({ev.country}) not found in Creditsafe.')
            # acelasi VAT apare si cu sediile vechi radiate (Italia: "Cancelled / Previous HQ" in alta provincie): conteaza
            # doar firmele inregistrate; mai multe inregistrate -> oricare (cea cu bilantul cel mai recent)
            registered = [c for c in res if is_registered(c)]
            pool = registered or res
            best = sorted(pool, key=lambda c: str(c.get('dateOfLatestAccounts') or ''), reverse=True)[0]
            ev.connect_id = best['id']
            ev.cs_candidates = [_cand(c) for c in registered + [c for c in res if c not in registered]]
            if not registered and len(res) > 1:
                ev.warnings.append(errors.warning('CS_MANY', len(res), ev.vat, f'{best.get("name")} {best["id"]}'))
            elif len(res) > 1:
                city = str((best.get('address') or {}).get('city') or '').strip().title()
                ev.warnings.append(errors.warning('CS_REGISTERED', f' din {city}' if city else f' ({best["id"]})',
                                                  len(res) - len(registered)))
        if hasattr(ctx.cs, 'will_charge') and not ctx.cs.cached(ev.connect_id):
            ev.charge = ctx.cs.will_charge(ev.connect_id)
        ev.state = 'prepared'
    except Exception as e:
        set_error(ctx, ev, e, 'Creditsafe - cautare')
    return ev


REGISTERED_STATUSES = ('active', 'registered', 'live')


def is_registered(c):
    """Firma inregistrata in Creditsafe (Register Status "Registered" / status "Active"), nu radiata ("Cancelled", "NonActive")."""
    return str(c.get('status') or '').strip().lower() in REGISTERED_STATUSES


def _cand(c):
    return {'id': c.get('id'), 'name': c.get('name'), 'regNo': c.get('regNo'), 'vatNo': ', '.join(map(str, c.get('vatNo') or [])) if isinstance(c.get('vatNo'), list) else c.get('vatNo'),
            'status': c.get('status'), 'city': (c.get('address') or {}).get('city'), 'latestAccounts': str(c.get('dateOfLatestAccounts') or '')[:10]}


def needs_credit(ctx, ev, force_refresh=False):
    if not ev.connect_id:
        return False
    if force_refresh:
        return True
    c = ctx.cs.cached(ev.connect_id)
    return not (c and (c['pdf_path'] or not ctx.cfg.get('creditsafe', 'downloadPdf')))


# ---------------------------------------------------------------- 2. evaluare completa
def evaluate_all(ctx, preps, cps, overrides=None, on_done=None):
    """Descarca rapoartele in paralel, apoi scorecard-urile pe rand (Excel). on_done(ev) dupa fiecare client."""
    overrides = overrides or {}
    with_pdf = bool(ctx.cfg.get('creditsafe', 'downloadPdf'))
    todo = [ev for ev in preps if ev.state == 'prepared']
    results = []
    for ev in preps:
        if ev.state != 'prepared':
            ctx.db.save_evaluation(ev)
            results.append(ev)
            if on_done:
                on_done(ev)
    pool = cf.ThreadPoolExecutor(max_workers=max(1, int(ctx.cfg.get('creditsafe', 'parallelDownloads', default=4))), thread_name_prefix='cs')
    try:
        # un singur raport per firma Creditsafe, chiar daca se evalueaza mai multe randuri (tari) ale ei
        by_id = {}
        for ev in todo:
            if ev.connect_id not in by_id:
                by_id[ev.connect_id] = pool.submit(ctx.cs.fetch_report, ev.connect_id, with_pdf,
                                                   not overrides.get(ev.partner, {}).get('force_refresh'))
        futures = {ev.partner: by_id[ev.connect_id] for ev in todo}
        reuse = {}
        for n, ev in enumerate(todo, 1):
            ctx.check_cancel()
            ctx.say(f'[{n}/{len(todo)}] {ev.name}: raport Creditsafe...', n - 1, len(todo))
            ctx.db.save_evaluation(ev)
            try:
                rep = futures[ev.partner].result()
            except Exception as e:
                set_error(ctx, ev, e, 'Creditsafe - raport')
                ctx.db.save_evaluation(ev)
                results.append(ev)
                if on_done:
                    on_done(ev)
                continue
            log_event(ctx, ev, 'INFO', 'Creditsafe', f'Raport {"din cache" if rep["from_cache"] else "descarcat"} ({rep["fetched"]:%d.%m.%Y %H:%M})')
            evaluate_one(ctx, ev, cps[ev.partner], rep, overrides.get(ev.partner, {}), n, len(todo), reuse)
            ctx.db.save_evaluation(ev)
            results.append(ev)
            if on_done:
                on_done(ev)
    finally:
        pool.shutdown(wait=False, cancel_futures=True)
    return results


def evaluate_one(ctx, ev, cp, rep, o, n=1, total=1, reuse=None):
    cfg = ctx.cfg
    report = rep['report']
    ev.report_json = str(rep['json_path'])
    ev.report_fetched = rep['fetched'].isoformat(timespec='seconds')
    ev.report_from_cache = rep['from_cache']
    ev.cs = {k: (v.isoformat() if isinstance(v, dt.date) else v) for k, v in mapping.summary(report).items()}
    step = 'Folder client'
    try:
        # --- folder client \ an curent
        root = cfg.counterparties_root
        if not Path(root).exists():
            raise AppError('CLIENT_ROOT', f'Not found: {root}')
        cf_ = client_folders.resolve_client_folder(root, [ev.customer_name, cp.name, ev.cs.get('name')], ev.customer_name)
        ev.folder, ev.folder_exists = str(cf_.path), cf_.exists
        ev.folder_alternatives = [str(p) for p in cf_.alternatives]
        if not cf_.exists:
            ev.warnings.append(errors.warning('NEW_FOLDER', cf_.path.name))
        if cf_.alternatives:
            ev.warnings.append(errors.warning('MANY_FOLDERS', '; '.join(p.name for p in cf_.alternatives)))
        dest = cf_.path / str(dt.date.today().year)
        try:
            dest.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            raise AppError('NO_ACCESS', f'Could not create {dest}: {e}')
        ev.dest_dir = str(dest)

        # --- PDF Creditsafe (acelasi nume ca in portal: NUME_FIRMA_<id>_<data_ora>.pdf)
        step = 'PDF Creditsafe'
        if rep.get('pdf_path'):
            cs_name = re.sub(r'\s+', '_', re.sub(r'[\\/:*?"<>|]', '', ev.cs.get('name') or ev.name).strip())
            pdf_name = f'{cs_name}_{ev.connect_id}_{rep["fetched"]:%Y-%m-%d_%H-%M-%S}.pdf'
            target = dest / pdf_name
            if target.exists():
                ev.files['pdf'] = str(target)          # acelasi raport (din cache) e deja in folder
            else:
                ev.files['pdf'] = str(fsutil.copy_to_destination(rep['pdf_path'], target))
            log_event(ctx, ev, 'INFO', step, f'PDF salvat: {ev.files["pdf"]}')

        # --- criterii subiective propuse (analistul le poate schimba si regenera)
        step = 'Criterii scorecard'
        traces = []
        if cf_.exists:
            d, why = client_folders.earliest_trace(cf_.path)
            if d:
                traces.append((d, f'folderul clientului: {why}'))
        if cp.first_contract:
            traces.append((cp.first_contract, f'primul contract deschis ({cp.first_contract:%d.%m.%Y})'))
        if cp.payment and cp.payment.first_activity:
            traces.append((cp.payment.first_activity, f'prima plata in raportul de plati ({cp.payment.first_activity:%d.%m.%Y})'))
        first = min(traces, key=lambda t: t[0]) if traces else (None, '')
        exp_g, years, exp_why = rules.experience_grade(first[0], cfg)
        if first[1]:
            exp_why += f' Sursa: {first[1]}.'
        pay_g, pay_why = rules.payment_grade(cp.payment, cfg)
        country_iso = ev.cs.get('country') or ev.country
        cr = rules.country_rating(country_iso, cfg)
        ev.inputs = {
            'experience': {'grade': o.get('experience') or exp_g, 'proposed': exp_g, 'why': exp_why, 'manual': bool(o.get('experience'))},
            'payment': {'grade': o.get('payment') or pay_g, 'proposed': pay_g, 'why': pay_why, 'manual': bool(o.get('payment'))},
            'financial_reporting': o.get('financial_reporting') or cfg.get('scorecard', 'financialReporting'),
            'country_rating': o.get('country_rating') or cr,
        }

        # --- scorecard
        step = 'Scorecard'
        ctx.say(f'[{n}/{total}] {ev.name}: scorecard...', n - 1, total)
        year = mapping.latest_financial_year(report) or dt.date.today().year
        file_name = cfg.get('scorecard', 'fileName').format(name=fsutil.safe_name(ev.customer_name), year=year, partner=ev.partner)
        inp = scorecard.ScorecardInputs(
            customer_name=ev.customer_name, customer_code=ev.customer_code,
            experience=ev.inputs['experience']['grade'], payment=ev.inputs['payment']['grade'],
            financial_reporting=ev.inputs['financial_reporting'], country_rating=ev.inputs['country_rating'],
            analyst=cfg.get('analyst', 'initials'))
        key = (ev.connect_id, inp.experience, inp.payment, inp.financial_reporting, inp.country_rating, str(dest))
        try:
            if o.get('skip_scorecard'):
                # limita mica (Open + MTM sub prag): nu e nevoie de scorecard - se pastreaza gradul din NWCE
                ev.scorecard = None
                ev.state = 'evaluated'
                ev.inputs['scorecard_skipped'] = o['skip_scorecard']
                log_event(ctx, ev, 'INFO', step, f'Scorecard nenecesar: {o["skip_scorecard"]}')
            elif reuse is not None and key in reuse:          # acelasi client, alta tara: acelasi scorecard
                ev.scorecard = dict(reuse[key])
                ev.files['scorecard'] = ev.scorecard.get('file')
                ev.warnings.extend(ev.scorecard.get('warnings') or [])
                ev.state = 'evaluated'
                log_event(ctx, ev, 'INFO', step, f'Acelasi scorecard ca pentru celelalte randuri ale clientului - grad {ev.scorecard.get("grade")}')
            else:
                res = _fill_with_restart(ctx, report, inp, dest, file_name, replace=bool(o.get('replace_scorecard')))
                ev.scorecard = {k: (str(v) if isinstance(v, Path) else v) for k, v in res.__dict__.items()}
                ev.files['scorecard'] = str(res.file)
                ev.warnings.extend(res.warnings)
                ev.state = 'evaluated'
                if reuse is not None:
                    reuse[key] = dict(ev.scorecard)
                log_event(ctx, ev, 'INFO', step, f'Grad {res.grade} ({res.scale}, {res.points} puncte) - {res.file}')
        except AppError as e:
            if e.code != 'NO_FINANCIALS':
                raise
            ev.scorecard = None
            ev.state = 'evaluated_manual'
            ev.warnings.append('Creditsafe nu are bilanturi - scorecardul trebuie completat manual; propunerea nu are plafon din equity.')
            log_event(ctx, ev, 'WARN', step, 'Fara bilanturi in Creditsafe')

        # --- propunerea de limita
        step = 'Propunere limita'
        build_proposal(ctx, ev, cp)
        ev.error = None
    except Exception as e:
        set_error(ctx, ev, e, step)
    return ev


def _fill_with_restart(ctx, report, inp, dest, file_name, replace=False):
    try:
        return scorecard.fill(report, inp, dest, file_name, ctx.get_excel(), ctx.cfg, replace=replace)
    except Exception as e:
        if not is_dead(e):
            raise
        _log.warning('Excel died - restarting')
        return scorecard.fill(report, inp, dest, file_name, ctx.restart_excel(), ctx.cfg, replace=replace)


def mark_redo(ctx, ev):
    """"Evalueaza din nou" din Proces initiat: evaluarea curenta se inchide (clientul iese din fila), iar urmatoarea
    revizuire descarca un raport Creditsafe nou si reface scorecardul (il inlocuieste pe cel vechi)."""
    ev.state = 'cancelled'
    ev.decision = None
    ev.review = {'redo': True, 'redo_at': dt.datetime.now().isoformat(timespec='seconds')}
    log_event(ctx, ev, 'INFO', 'Reevaluare', 'Evalueaza din nou: la urmatoarea revizuire raport Creditsafe nou + scorecard refacut')
    ctx.db.save_evaluation(ev)
    return ev


def wants_redo(ev):
    return bool(ev is not None and ev.state == 'cancelled' and (ev.review or {}).get('redo'))


def build_proposal(ctx, ev, cp):
    cur = (ev.cs or {}).get('currency') or ''
    lim_cur = ev.currency or 'EUR'
    equity = ev.cs.get('equity') if cur == lim_cur else None
    cs_limit = ev.cs.get('cs_limit') if (ev.cs.get('cs_limit_currency') or '') == lim_cur else None
    if cur and cur != lim_cur:
        ev.warnings.append(f'Bilantul e in {cur}, limita in {lim_cur} - plafonul din equity nu se aplica automat.')
    if cp.source == 'nwce' and not cp.monthly:
        ev.warnings.append('Client din lista TBD fara expunere in Open Contracts ITA - propunerea pastreaza limita curenta.')
    peak = cp.peak_exposure if cp.peak_exposure is not None else cp.max_exposure
    p = rules.propose_limit(cp.limit, peak, equity, ev.grade, cs_limit, ctx.cfg, lim_cur)
    ev.proposal = {'proposed': p.proposed, 'current': p.current, 'need': p.need, 'cap': p.cap,
                   'lines': p.lines, 'warnings': p.warnings, 'peak': peak, 'peak_week': cp.peak_week}


# ---------------------------------------------------------------- 3. decizie -> NWCE
def default_decision(ctx, ev, eur_usd):
    """Valorile implicite din fereastra de decizie: propunerea + campurile actuale din NWCE.
    eur_usd = USD pentru 1 unitate din moneda limitei (EUR, HUF, RON)."""
    eur_usd = eur_usd or (ev.review or {}).get('usd_rate') or 0       # fara curs: KUSD 0 -> fereastra de decizie avertizeaza
    cfg = ctx.cfg
    vals = (ev.nwce_row or {}).get('values') or {}
    rv = ev.review or {}
    edit = rv.get('edit') or {}
    today = dt.date.today()
    months = int(cfg.get('limitsBook', 'validityMonths'))
    if edit.get('open') is not None or rv.get('new_open_local') is not None:
        # revizuirea lunara: aceleasi valori ca in tabelul "Proces initiat" (inclusiv ce a schimbat analistul in celule)
        limit = edit['open'] if edit.get('open') is not None else rv['new_open_local']
        mtm = (edit['mtm_usd'] / 1000) if edit.get('mtm_usd') is not None else (rv.get('mtm_kusd') if rv.get('mtm_kusd') is not None else vals.get('mtm_kusd'))
        grading = edit.get('grade') or ev.grade or rv.get('grade_used') or vals.get('grading')
        level = rv.get('nwce_level') or vals.get('approval_level') or ''
        valid = edit.get('valid') or rules.valid_till(today, months).isoformat()
        fields = ['open_kloc', 'open_kusd', 'mtm_kusd', 'grading', 'approval_level', 'analyst', 'approved_on', 'valid_till']
    else:
        limit = (ev.proposal or {}).get('proposed') or 0
        mtm = vals.get('mtm_kusd')
        grading = ev.grade if ev.grade is not None else vals.get('grading')
        level = vals.get('approval_level') or ''
        valid = rules.valid_till(today, months).isoformat()
        fields = ['open_kloc', 'open_kusd', 'grading', 'analyst', 'approved_on', 'valid_till']
    return {
        'limit_eur': limit,
        'currency': ev.currency or 'EUR',
        'eur_usd': eur_usd,
        'open_kloc': rules.k_local(limit),
        'open_kusd': rules.k_usd(limit, eur_usd, cfg.get('limitsBook', 'kusdRounding')),
        'mtm_kusd': mtm,
        'payment_term': vals.get('payment_term') or '',
        'approval_level': level,
        'grading': grading,
        'approved_on': today.isoformat(),
        'valid_till': valid,
        'comments': '',
        'fields': fields,
        'sheet_row': (ev.nwce_row or {}).get('sheet_row') or 0,
        'new_row': False,
    }


def inactivation_decision(ctx, ev, comment=''):
    """Decizia de inactivare: limite 0, date goale -> STATUS INACTIVE in NWCE (managerul trimite lunar la inactivare)."""
    vals = (ev.nwce_row or {}).get('values') or {}
    return {'inactivate': True, 'limit_eur': 0, 'currency': ev.currency, 'comments': comment,
            'fields': ['inactivate'] + (['comments'] if comment else []), 'sheet_row': (ev.nwce_row or {}).get('sheet_row') or 0,
            'new_row': False, 'approved_at': dt.datetime.now().isoformat(timespec='seconds'),
            'previous': {k: vals.get(k) for k in ('payment_term', 'open_kusd', 'open_kloc', 'mtm_kusd', 'approved_on', 'valid_till')}}


def decision_changes(ctx, ev):
    """dict camp NWCE -> valoare noua, din decizia aprobata."""
    d = ev.decision
    if d.get('inactivate'):
        out = limits_book.inactivation_changes()
        if 'comments' in d.get('fields', []) and d.get('comments'):
            out['comments'] = d['comments']
        return out
    out = {}
    for k in d.get('fields', []):
        if k == 'analyst':
            out['analyst'] = ctx.cfg.get('analyst', 'initials')
        elif k in ('approved_on', 'valid_till'):
            out[k] = dt.date.fromisoformat(d[k])
        elif k == 'tbd_by':
            out[k] = 'Done'
        elif k in d:
            out[k] = d[k]
    if ctx.cfg.get('limitsBook', 'setTbdByDone') and 'tbd_by' not in out:
        out['tbd_by'] = 'Done'
    if d.get('new_row'):
        out.update({'company_code': ev.company_code or ctx.cfg.get('limitsBook', 'companyCode'), 'customer_code': ev.customer_code,
                    'name': ev.customer_name, 'vat': ev.vat})
    return out


def _parse_display(key, s):
    """Inversul lui limits_book.display: '04.09.2025' -> data, '1.250' -> 1250.0, '12,5' -> 12.5, '' -> None, text -> text."""
    s = '' if s is None else str(s).strip()
    if s == '':
        return None
    if key in limits_book.DATE_FIELDS:
        try:
            return dt.datetime.strptime(s, '%d.%m.%Y').date()
        except ValueError:
            return s
    if re.fullmatch(r'-?\d{1,3}(\.\d{3})*(,\d+)?|-?\d+(,\d+)?', s):
        return float(s.replace('.', '').replace(',', '.'))
    return s


def restore_plan(ev):
    """Ce s-ar pune la loc in NWCE: {camp: (valoarea scrisa de tool, valoarea de dinainte)} din ultima scriere."""
    st = ev.nwce or {}
    before, after = st.get('before') or {}, st.get('after') or {}
    return {k: (after.get(k, ''), v) for k, v in before.items() if k in limits_book.WRITABLE and after.get(k, '') != v}


def restore_nwce(ctx, ev):
    """Pune la loc in NWCE valorile de dinainte de ultima scriere a tool-ului (ex. o inactivare gresita).
    Aceleasi verificari ca la scriere: randul trebuie sa contina inca exact ce a scris tool-ul."""
    st = ev.nwce or {}
    plan = restore_plan(ev)
    if st.get('status') != 'ok' or not plan:
        raise AppError('NOTHING_TO_RESTORE', 'Nu exista o scriere in NWCE de refacut pentru acest client.')
    changes = {k: _parse_display(k, old) for k, (_new, old) in plan.items()}
    vals = (ev.nwce_row or {}).get('values') or {}
    expected = {k: vals.get(k) for k in changes if k in vals}
    u = limits_book.RowUpdate(partner=ev.partner, sheet_row=int(st.get('sheet_row') or (ev.decision or {}).get('sheet_row') or 0),
                              expected=expected, changes=changes, customer_code=ev.customer_code or '',
                              company_code=ev.company_code or ctx.cfg.get('limitsBook', 'companyCode'), name=ev.customer_name or ev.name)
    limits_book.apply([u], ctx.cfg, progress=lambda t: ctx.say(t))
    for k, new in u.changes.items():
        ctx.db.change(ev.id, ev.partner, 'NWCE (refacere)', limits_book.LABELS.get(k, k), limits_book.display(k, u.before.get(k)),
                      limits_book.display(k, limits_book._excel_value(k, new)), 'ok' if u.ok else 'error', u.message)
    if u.ok:
        ev.nwce_row = ev.nwce_row or {'values': {}}
        ev.nwce_row.setdefault('values', {}).update(u.after or {k: limits_book._excel_value(k, v) for k, v in u.changes.items()})
        ev.nwce = {'status': 'restored', 'message': 'Valorile de dinainte au fost puse la loc. ' + (u.message or ''),
                   'at': dt.datetime.now().isoformat(timespec='seconds'), 'sheet_row': u.sheet_row,
                   'before': {k: limits_book.display(k, v) for k, v in u.before.items()},
                   'after': {k: limits_book.display(k, v) for k, v in u.after.items()}}
        ev.state, ev.decision, ev.review = 'cancelled', None, None
    log_event(ctx, ev, 'INFO' if u.ok else 'ERROR', 'NWCE refacere', u.message or ('OK' if u.ok else 'Eroare'))
    ctx.db.save_evaluation(ev)
    return u


def apply_nwce(ctx, evs):
    """Scrie in NWCE toate deciziile aprobate. Un singur fisier deschis / salvat pentru tot lotul."""
    updates, by_partner = [], {}
    for ev in evs:
        changes = decision_changes(ctx, ev)
        expected = {}
        if not ev.decision.get('new_row'):
            vals = (ev.nwce_row or {}).get('values') or {}
            expected = {k: vals.get(k) for k in changes if k in vals}
        u = limits_book.RowUpdate(partner=ev.partner, sheet_row=int(ev.decision.get('sheet_row') or 0), expected=expected,
                                  changes=changes, customer_code=ev.customer_code or '',
                                  company_code=ev.company_code or ctx.cfg.get('limitsBook', 'companyCode'),
                                  name=ev.customer_name or ev.name, new_row=bool(ev.decision.get('new_row')),
                                  inactivate=bool(ev.decision.get('inactivate')))
        updates.append(u)
        by_partner[ev.partner] = ev
    limits_book.apply(updates, ctx.cfg, progress=lambda t: ctx.say(t))
    for u in updates:
        ev = by_partner[u.partner]
        if u.ok:   # randul vazut de aplicatie = cel scris (o noua scriere compara cu aceste valori)
            ev.nwce_row = ev.nwce_row or {'values': {}}
            ev.nwce_row.setdefault('values', {}).update(u.after or {k: limits_book._excel_value(k, v) for k, v in u.changes.items()})
            ev.nwce_row['sheet_row'] = u.sheet_row
            ev.decision['sheet_row'] = u.sheet_row
            ev.decision['new_row'] = False
        ev.nwce = {'status': 'ok' if u.ok else 'error', 'message': u.message, 'sheet_row': u.sheet_row,
                   'before': {k: limits_book.display(k, v) for k, v in u.before.items()},
                   'after': {k: limits_book.display(k, v) for k, v in u.after.items()},
                   'at': dt.datetime.now().isoformat(timespec='seconds')}
        for k, new in u.changes.items():
            ctx.db.change(ev.id, ev.partner, 'NWCE', limits_book.LABELS.get(k, k), limits_book.display(k, u.before.get(k)),
                          limits_book.display(k, limits_book._excel_value(k, new)), 'ok' if u.ok else 'error', u.message)
        log_event(ctx, ev, 'INFO' if u.ok else 'ERROR', 'NWCE', u.message or ('OK' if u.ok else 'Eroare'))
        _maybe_done(ev)
        ctx.db.save_evaluation(ev)
    return updates


# ---------------------------------------------------------------- 4. SAP
def find_bp(ctx, ev):
    """BP code pentru SAP: randul NWCE al deciziei -> acelasi rand in copia NWCE curenta (completat intre timp) ->
    alte randuri NWCE ale aceluiasi client (acelasi Customer Code, apoi acelasi VAT)."""
    vals = (ev.nwce_row or {}).get('values') or {}
    bp = limits_book._code(vals.get('bp_code'))
    if bp and bp != '0':
        return bp
    snap = getattr(ctx, 'nwce', None)
    if snap is None:
        return ''
    sheet = (ev.nwce_row or {}).get('sheet_row') or (ev.decision or {}).get('sheet_row')
    r = snap.row_by_sheet(sheet) if sheet else None
    if r is not None:
        bp = limits_book._code(r.get('bp_code'))
        if bp and bp != '0':
            return bp
    code = str(ev.customer_code or '').strip()
    vk = limits_book.vat_key(ev.vat or vals.get('vat'), ctx.cfg.get('portfolio', 'country', default='IT'))
    for match in (lambda x: code and x.customer_code == code,
                  lambda x: vk and limits_book.vat_key(x.get('vat'), ctx.cfg.get('portfolio', 'country', default='IT')) == vk):
        bps = {limits_book._code(x.get('bp_code')) for x in snap.rows if match(x)} - {'', '0'}
        if len(bps) == 1:
            return bps.pop()
    return ''


def sap_values(ctx, ev):
    d = ev.decision
    bp = find_bp(ctx, ev)
    rv = ev.review or {}
    eq = d.get('equity_scenario')
    if eq is None:
        eq = rv.get('equity_scenario', False)
    mtm = d.get('mtm_kusd')
    return {'bp': bp or None, 'customer_code': ev.customer_code, 'limit': d['limit_eur'],
            'mtm': float(mtm) * 1000 if isinstance(mtm, (int, float)) else None,
            # SAP "Score" accepta doar cifra: "Intuitive 9" / 9.0 -> 9
            'valid_to': dt.date.fromisoformat(d['valid_till']), 'grade': rules.grade_number(d.get('grading')), 'today': dt.date.today(),
            'equity': bool(eq), 'currency': ev.currency or 'EUR',
            'comment': (f'Annual review {dt.date.today():%d.%m.%Y}: grade {d.get("grading")}, limita {d["limit_eur"]:,.0f} {ev.currency}'
                        f'{", MTM " + format(float(mtm) * 1000, ",.0f") + " USD" if isinstance(mtm, (int, float)) else ""}'
                        f' - scorecard + Creditsafe in folderul clientului').replace(',', '.')}


def run_sap(ctx, ev, tpl, dry_run):
    from . import sap_gui
    try:
        sap_company = ctx.cfg.get('limitsBook', 'companyCode')
        if (ev.company_code or sap_company) != sap_company:
            raise AppError('SAP_TEMPLATE', f'The SAP recording is for {sap_company}; this limit is on {ev.company_code} - update it in SAP manually.')
        values = sap_values(ctx, ev)
        if not values.get('bp'):
            raise AppError('SAP_NO_BP', f'{ev.customer_name or ev.name}: no BP code in NWCE (Customer Code {ev.customer_code or "-"}).')
        # capturile raman in folderul aplicatiei (data\sap_captures), NU in folderul clientului
        res = sap_gui.run(tpl, values, ctx.cfg, dry_run=dry_run, shot_dir=paths.DATA_DIR / 'sap_captures', cancel=ctx.cancel)
        status = 'dry_ok' if dry_run else 'ok'
        msg = res.message
    except Exception as e:
        f = errors.friendly(e)
        res = getattr(e, 'sap_result', None)        # rezultatul partial (ce s-a citit / daca rotita a fost apasata)
        status = 'dry_error' if dry_run else 'error'
        msg = f'{f["title"]}: {f["details"]}'
    # trimis = rotita / Save apasata: cazul poate exista in SAP chiar daca un pas de dupa a esuat -> nu se retrimite automat
    submitted = not dry_run and (status == 'ok' or bool(res and (res.saved or res.submit_attempted)))
    ev.sap = {'status': status, 'message': msg, 'at': dt.datetime.now().isoformat(timespec='seconds'),
              'submitted': submitted,
              'case_number': getattr(res, 'case_number', '') if res else '',
              'popups': list(getattr(res, 'popups', []) or []) if res else [],
              'before': res.before if res else {}, 'after': res.after if res else {},
              'expected': res.expected if res else {}, 'session': res.session if res else '',
              'screenshots': [str(p) for p in (res.screenshots if res else [])], 'status_text': res.status_text if res else ''}
    if not dry_run:
        for k in ('limit', 'valid_to'):
            if res and k in res.expected:
                ctx.db.change(ev.id, ev.partner, 'SAP', k, res.before.get(k), res.expected.get(k), status, msg)
        if not (res and res.expected):
            ctx.db.change(ev.id, ev.partner, 'SAP', 'limit', None, ev.decision.get('limit_eur'), status, msg)
    log_event(ctx, ev, 'INFO' if status in ('ok', 'dry_ok') else 'ERROR', 'SAP' + (' (proba)' if dry_run else ''), msg)
    if res and res.popups and not dry_run:
        log_event(ctx, ev, 'INFO', 'SAP ferestre', ' || '.join(res.popups)[:1500])
    _maybe_done(ev)
    ctx.db.save_evaluation(ev)
    return ev


def sap_sent(ev):
    """True daca cererea a plecat deja in SAP (ok sau eroare DUPA rotita) - nu se retrimite fara acordul analistului."""
    s = ev.sap or {}
    if s.get('status') == 'ok':
        return True
    if 'submitted' in s:
        return bool(s['submitted'])
    return s.get('status') == 'error' and 'DUPA SAVE' in str(s.get('message') or '')     # inregistrari dinainte de flag


def sap_confirm_manual(ctx, ev, sent):
    """Analistul a verificat in SAP: sent=True -> cazul exista (ok); sent=False -> nu exista, se poate retrimite."""
    old = dict(ev.sap or {})
    prev = str(old.get('message') or '')
    if sent:
        ev.sap = dict(old, status='ok', submitted=True,
                      message=f'Confirmat manual de analist ({dt.date.today():%d.%m.%Y}): cazul exista in SAP. Inainte: {prev}'[:1500])
        log_event(ctx, ev, 'INFO', 'SAP', 'Trimiterea confirmata manual de analist (cazul exista in SAP).')
    else:
        ev.sap = dict(old, status='error', submitted=False,
                      message=f'Retrimitere permisa de analist ({dt.date.today():%d.%m.%Y}): cazul NU exista in SAP. Inainte: {prev}'[:1500])
        log_event(ctx, ev, 'WARN', 'SAP', 'Analistul a confirmat ca cererea NU exista in SAP - retrimiterea e permisa.')
    _maybe_done(ev)
    ctx.db.save_evaluation(ev)
    return ev


def sap_skipped(ev):
    """Decizia nu se transcrie in SAP (aprobata pe alt canal - in SAP ar porni din nou workflow-ul de aprobare)."""
    return bool((ev.decision or {}).get('sap_skip'))


def set_sap_skip(ctx, ev, skip):
    """Analistul schimba "Transcrie in SAP" pe o decizie aprobata, cat timp nu a plecat inca in SAP."""
    if ev.decision is None or sap_sent(ev):
        return ev
    ev.decision['sap_skip'] = bool(skip)
    log_event(ctx, ev, 'INFO', 'SAP', 'Nu se transcrie in SAP (aprobat pe alt canal).' if skip else 'Se transcrie in SAP.')
    if not skip and ev.state == 'done' and (ev.sap or {}).get('status') != 'ok' and not (ev.decision or {}).get('inactivate'):
        ev.state = 'approved'            # inapoi la "SAP de trimis"
    _maybe_done(ev)
    ctx.db.save_evaluation(ev)
    return ev


def _maybe_done(ev):
    d = ev.decision or {}
    if (ev.nwce or {}).get('status') == 'ok' and ((ev.sap or {}).get('status') == 'ok' or d.get('inactivate') or d.get('sap_skip')):
        ev.state = 'done'
