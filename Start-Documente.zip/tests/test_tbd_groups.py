"""Lista "TBD by" si gruparea clientilor pe toate companiile / tarile din NWCE."""
import datetime as dt

import pytest

from creditapp import limits_book as lb
from creditapp.portfolio import Counterparty, PaymentBehaviour, Portfolio


@pytest.mark.parametrize('value,owner', [
    ('TBD by IS', 'IS'), ('tbd by md', 'MD'), ('MD', 'MD'), ('  TCU ', 'TCU'), ('Done', ''), ('EX. BBS', ''),
    ('Sent to BBS OCT26', ''), ('sent to BBS JUL26 - expired', ''), ('0', ''), (None, ''), ('PS Bio Trade', ''),
])
def test_tbd_owner(value, owner):
    assert lb.tbd_owner(value) == owner


def test_company_currency(cfg):
    assert lb.company_currency(cfg, '6575 - Hungary') == 'HUF'
    assert lb.company_currency(cfg, '7179 - Romania') == 'RON'
    assert lb.company_currency(cfg, '6675 - Italy') == 'EUR'


def _snapshot():
    rows = [
        lb.NwceRow(10, {'company_code': '6675 - Italy', 'customer_code': 76000001.0, 'name': 'CARGILL AGRICULTURA SRL', 'vat': 'RO8915840', 'total_kusd': 0.0, 'tbd_by': 'TBD by IS'}),
        lb.NwceRow(11, {'company_code': '7179 - Romania', 'customer_code': 76000001.0, 'name': 'CARGILL AGRICULTURA SRL', 'vat': 'RO8915840', 'total_kusd': 5900.0, 'open_kloc': 26000.0, 'tbd_by': 'TBD by IS'}),
        lb.NwceRow(12, {'company_code': '6575 - Hungary', 'customer_code': 76000001.0, 'name': 'CARGILL AGRICULTURA SRL', 'vat': 'RO8915840', 'total_kusd': 300.0, 'tbd_by': ''}),
        lb.NwceRow(13, {'company_code': '6675 - Italy', 'customer_code': 76021671.0, 'name': 'MIRA SUD S.R.L.', 'vat': 'IT01491571210', 'total_kusd': 1400.0, 'tbd_by': ''}),
        lb.NwceRow(14, {'company_code': '7020 - Netherlands', 'customer_code': 76021671.0, 'name': 'MIRA SUD S.R.L.', 'vat': 'IT01491571210', 'total_kusd': 200.0, 'tbd_by': 'MD'}),
        lb.NwceRow(15, {'company_code': '6675 - CBT', 'customer_code': 76021671.0, 'name': 'MIRA SUD S.R.L. - CBT', 'vat': 'IT01491571210', 'total_kusd': 0.0, 'tbd_by': ''}),
        lb.NwceRow(16, {'company_code': '6503 - Hilter', 'customer_code': 0, 'name': 'LIDL SRBIJA KD', 'vat': 'XS106884585', 'total_kusd': 260.0, 'tbd_by': 'IP'}),
        lb.NwceRow(17, {'company_code': '6501 - Mannheim', 'customer_code': 76099999.0, 'name': 'OTHER GMBH', 'vat': 'DE111', 'total_kusd': 50.0, 'tbd_by': ''}),
    ]
    return lb.Snapshot(rows, {}, dt.datetime.now(), 't').index('IT')


def _portfolio():
    mira = Counterparty(partner='76021671', name='MIRA SUD S.R.L.', vat='IT01491571210', limit=800000, weeks_over=3,
                        payment=PaymentBehaviour(risk_score=10), first_contract=dt.date(2016, 1, 1))
    other = Counterparty(partner='76055555', name='ALTRO SRL', vat='IT0000000001', limit=10000)
    return Portfolio('x', dt.datetime.now(), {'76021671': mira, '76055555': other}, [], [], [], [])


@pytest.fixture
def model(cfg):
    from creditapp.ui.models import ClientsFilter, ClientsModel
    m = ClientsModel()
    m.load(_portfolio(), {}, _snapshot(), '6675 - Italy', 'IT', cfg)
    p = ClientsFilter()
    p.setSourceModel(m)
    p.hide_blocked = False
    return m, p


def test_groups_cover_all_companies(model):
    m, _ = model
    mira = m.by_partner['76021671']
    assert [g.nwce.company_code for g in mira.group_rows] == ['6675 - Italy', '7020 - Netherlands']   # CBT nu e limita
    assert mira.lead and mira.group_kusd == 1600.0
    nl = mira.group_rows[1]
    assert nl.cp.source == 'nwce' and nl.cp.tbd == 'MD' and not nl.lead
    assert nl.cp.payment is mira.cp.payment and nl.cp.first_contract == dt.date(2016, 1, 1)   # aceeasi firma
    assert nl.cp.peak_exposure is None and not nl.cp.monthly                                   # expunerea doar pe Italia
    cargill = [r for r in m.rows if 'CARGILL' in r.cp.name]
    assert len(cargill) == 3 and cargill[0].group_kusd == 6200.0
    assert {r.cp.currency for r in cargill} == {'EUR', 'RON', 'HUF'}
    assert not any(r.cp.name == 'OTHER GMBH' for r in m.rows)        # client fara legatura cu lista


def test_filter_tbd_shows_whole_client(model):
    m, p = model
    p.tbd = 'IS'
    p.refresh()
    shown = {m.rows[p.mapToSource(p.index(i, 0)).row()].nwce.company_code for i in range(p.rowCount())}
    assert shown == {'6675 - Italy', '7179 - Romania', '6575 - Hungary'}     # Ungaria apare desi nu e TBD IS
    p.tbd = 'MD'
    p.refresh()
    names = [m.rows[p.mapToSource(p.index(i, 0)).row()] for i in range(p.rowCount())]
    assert {r.cp.name for r in names} == {'MIRA SUD S.R.L.'} and len(names) == 2   # Italia + Olanda


def test_filter_without_tbd_only_portfolio_anchors(model):
    m, p = model
    p.tbd = ''
    p.only_over = True
    p.refresh()
    rows = [m.rows[p.mapToSource(p.index(i, 0)).row()] for i in range(p.rowCount())]
    assert {r.cp.name for r in rows} == {'MIRA SUD S.R.L.'} and len(rows) == 2      # cu randul din Olanda


def test_rows_without_customer_code_get_unique_keys(model):
    m, _ = model
    lidl = [r for r in m.rows if r.cp.name == 'LIDL SRBIJA KD'][0]
    assert lidl.cp.partner.startswith('NWCE@6503') and lidl.cp.customer_code == ''
