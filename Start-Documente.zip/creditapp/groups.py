"""Grupuri de firme (coloana "Group of companies" din NWCE): un grup se evalueaza o singura data -
limitele tuturor membrilor (toate firmele, toate tarile) se aduna si se da un singur grade."""
import re
import unicodedata
from collections import Counter
from dataclasses import dataclass, field

from . import limits_book, rules


def norm_group(value, cfg=None):
    """'Nestle' / 'NESTLE' / '(GROHAGE)' / 'REWE - bill to' / 'Fenaco (BP group 89542)' -> cheie comuna; '' daca nu e grup."""
    if value is None or isinstance(value, (int, float)):      # celule goale citite ca 0 / 0.0
        return ''
    # fara diacritice: "NESTLÉ" = "NESTLE" (altfel É dispare si ramane "NESTL")
    s = unicodedata.normalize('NFKD', str(value)).encode('ascii', 'ignore').decode('ascii').upper().strip()
    if re.fullmatch(r'[0\s.,\-]*', s):
        return ''
    s = re.sub(r'\bBP GROUP\s*\d+\b', ' ', s)
    s = re.sub(r'[()]', ' ', s)
    s = re.sub(r'\s*-\s*BILL TO.*$', '', s)
    s = re.sub(r'[^A-Z0-9&]+', ' ', s).strip()
    s = re.sub(r'\s+(GROUP|GRUPPO|GRUPO|GROUPE|HOLDING)$', '', s).strip()
    not_groups = {str(x).upper() for x in ((cfg.get('groups', 'notGroups') if cfg else None) or
                                          ['', 'N/A', 'NA', '0', '-', 'CBT', 'WAREHOUSE', 'NO TRADE', 'NONE'])}
    not_groups |= {re.sub(r'[^A-Z0-9&]+', ' ', x).strip() for x in not_groups}
    return '' if s in not_groups else s


def display_group(raw_values):
    """Numele afisat al grupului: varianta cea mai des scrisa."""
    vals = [str(v).strip() for v in raw_values if str(v or '').strip()]
    return Counter(vals).most_common(1)[0][0] if vals else ''


@dataclass
class MemberLine:
    """Un rand de limita (o firma pe o companie Bunge) in evaluarea de grup. Sume in USD."""
    row: object                      # Row din tabel (cp, nwce, ev)
    name: str
    company: str
    region: str
    grade: object
    trader: str
    open_usd: float = 0.0
    mtm_usd: float = 0.0
    other_usd: float = 0.0           # storage / transfer bond (raman neschimbate)
    new_open_usd: float = 0.0
    new_mtm_usd: float = 0.0
    include: bool = True

    @property
    def total_usd(self):
        return self.open_usd + self.mtm_usd + self.other_usd

    @property
    def new_total_usd(self):
        return self.new_open_usd + self.new_mtm_usd + self.other_usd


def _k(v):
    return float(v) * 1000 if isinstance(v, (int, float)) else 0.0


def member_lines(rows):
    out = []
    for r in rows:
        n = r.nwce
        open_usd = _k(n.get('open_kusd')) if n else 0.0
        mtm_usd = _k(n.get('mtm_kusd')) if n else 0.0
        total = _k(n.get('total_kusd')) if n else 0.0
        trader = str(n.get('trader') or '').strip() if n else ''
        out.append(MemberLine(
            row=r, name=(n.name if n else r.cp.name), company=(n.company_code if n else (r.cp.company_code or '')),
            region=rules.region_of(n.company_code if n else r.cp.company_code), grade=(n.get('grading') if n else None),
            trader='' if trader.lower() in ('n/a', '0') else trader,
            open_usd=open_usd, mtm_usd=mtm_usd, other_usd=max(0.0, total - open_usd - mtm_usd),
            new_open_usd=open_usd, new_mtm_usd=mtm_usd))
    return out


def default_group_grade(lines):
    """Gradul cel mai des intalnit in NWCE pentru membrii grupului (punct de plecare)."""
    gs = [rules.grade_number(m.grade) for m in lines]
    gs = [g for g in gs if g]
    return Counter(gs).most_common(1)[0][0] if gs else None


@dataclass
class ReviewCounterparty:
    """Un rand din tabelul Annual Review: o firma (toate companiile Bunge ale ei adunate)."""
    name: str
    grade: object
    open_usd: float = 0.0
    mtm_usd: float = 0.0
    total_usd: float = 0.0
    new_open_usd: float = 0.0
    new_mtm_usd: float = 0.0
    new_total_usd: float = 0.0
    regions: list = field(default_factory=list)
    traders: list = field(default_factory=list)


def review_counterparties(lines, grade):
    by = {}
    for m in lines:
        if not m.include:
            continue
        key = limits_book.vat_key(m.row.cp.vat) or m.name.upper()
        c = by.setdefault(key, ReviewCounterparty(name=m.name, grade=grade))
        c.open_usd += m.open_usd
        c.mtm_usd += m.mtm_usd
        c.total_usd += m.total_usd
        c.new_open_usd += m.new_open_usd
        c.new_mtm_usd += m.new_mtm_usd
        c.new_total_usd += m.new_total_usd
        if m.region and m.region not in c.regions:
            c.regions.append(m.region)
        for t in re.split(r'\s*[;/]\s*', m.trader):
            if t and t not in c.traders:
                c.traders.append(t)
    return list(by.values())
