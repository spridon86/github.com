"""Operatii cu fisiere robuste pentru OneDrive / fisiere deschise in Excel."""
import re
import shutil
import time
from pathlib import Path

from .errors import AppError


def copy_file(src, dst):
    """Copiaza si un fisier deschis in Excel (CopyFileW din Windows, ca Explorer; open() din Python esueaza)."""
    try:
        import win32api
        win32api.CopyFile(str(src), str(dst), 0)
    except ImportError:
        shutil.copyfile(src, dst)


def safe_name(name):
    """Nume valid de fisier/folder Windows (fara caractere interzise, fara punct/spatiu la final)."""
    n = re.sub(r'[\\/:*?"<>|\r\n\t]', ' ', str(name or ''))
    n = re.sub(r'\s+', ' ', n).strip().rstrip('. ')
    return n or 'fara_nume'


def unique_path(path):
    """X.xlsx exista -> X (2).xlsx, X (3).xlsx ..."""
    path = Path(path)
    if not path.exists():
        return path
    i = 2
    while True:
        p = path.with_name(f'{path.stem} ({i}){path.suffix}')
        if not p.exists():
            return p
        i += 1


def copy_to_destination(src, dst, attempts=4, replace=False):
    """Copiaza un fisier terminat in folderul final (OneDrive), cu nume liber si reincercari daca e blocat.
    replace=True: inlocuieste fisierul existent cu acelasi nume (ex. scorecardul refacut); daca e deschis / blocat,
    se salveaza alaturi cu nume liber ("... (2)") - nimic nu se pierde."""
    dst = Path(dst)
    try:
        dst.parent.mkdir(parents=True, exist_ok=True)
    except PermissionError as e:
        raise AppError('NO_ACCESS', f'Could not create folder {dst.parent}: {e}')
    if replace and dst.exists():
        try:
            copy_file(src, dst)
            return dst
        except Exception:
            pass                # deschis in Excel / blocat: alaturi, cu nume liber (mai jos)
    target = unique_path(dst)
    for attempt in range(1, attempts + 1):
        try:
            copy_file(src, target)
            return target
        except Exception as e:
            msg = str(e)
            if re.search(r'denied|WinError 5\b|\(5,', msg, re.I):
                raise AppError('NO_ACCESS', f'No write permission: {dst.parent}', msg)
            if attempt < attempts:
                time.sleep(1)
                continue
            raise AppError('FILE_LOCKED', f'Could not save {target}', msg)
