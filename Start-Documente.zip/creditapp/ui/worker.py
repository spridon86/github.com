"""Rularea operatiilor lungi in fundal (interfata ramane responsiva). Un singur job o data."""
import threading

from PyQt5.QtCore import QThread, pyqtSignal

from .. import errors, log

_log = log.get('worker')


class Worker(QThread):
    progress = pyqtSignal(str, int, int)      # text, facut, total (-1 = necunoscut)
    item = pyqtSignal(object)                 # rezultat partial (ex. o evaluare terminata)
    done = pyqtSignal(object)                 # rezultatul final
    failed = pyqtSignal(object)               # dict friendly error

    def __init__(self, fn, *args, name='job', **kwargs):
        super().__init__()
        self.fn, self.args, self.kwargs, self.name = fn, args, kwargs, name
        self._cancel = threading.Event()

    def cancel(self):
        self._cancel.set()

    def cancelled(self):
        return self._cancel.is_set()

    def report(self, text, done=None, total=None):
        self.progress.emit(str(text), -1 if done is None else int(done), -1 if total is None else int(total))

    def run(self):
        import pythoncom
        pythoncom.CoInitialize()      # Excel / SAP prin COM in acest fir
        try:
            res = self.fn(self, *self.args, **self.kwargs)
            self.done.emit(res)
        except Exception as e:
            _log.exception('Job %s failed', self.name)
            f = errors.friendly(e)
            f['trace'] = errors.format_exc(e)
            self.failed.emit(f)
        finally:
            pythoncom.CoUninitialize()
