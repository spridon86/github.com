"""Completeaza o copie a scorecardului Excel din raportul Creditsafe si intoarce rezultatele calculate de Excel.

In plus fata de completarea simpla:
- cursul USD->EUR lipsa pentru datele bilanturilor se adauga automat in "Blank 2" (BCE);
- criteriile subiective vin din aplicatie (Experience, Payments Behavior, Financial Reporting, Country Rating);
- se citeste punctajul fiecarui criteriu, pentru afisare.
Calculul gradului ramane cel din Excel, neschimbat.
"""
import datetime as dt
import shutil
import uuid
from dataclasses import dataclass, field
from pathlib import Path

from . import fx, log, mapping, paths
from .errors import AppError, warning
from .excel_com import XL_CALC_AUTO, XL_CALC_MANUAL, retry
from .fsutil import copy_to_destination

_log = log.get('scorecard')

COUNTRY_NAMES = {
    'AT': 'Austria', 'BE': 'Belgium', 'BG': 'Bulgaria', 'HR': 'Croatia', 'CY': 'Cyprus', 'CZ': 'Czech Republic',
    'DK': 'Denmark', 'EE': 'Estonia', 'FI': 'Finland', 'FR': 'France', 'DE': 'Germany', 'GR': 'Greece',
    'HU': 'Hungary', 'IE': 'Ireland', 'IT': 'Italy', 'LV': 'Latvia', 'LT': 'Lithuania', 'LU': 'Luxembourg',
    'MT': 'Malta', 'NL': 'Netherlands', 'NO': 'Norway', 'PL': 'Poland', 'PT': 'Portugal', 'RO': 'Romania',
    'RS': 'Serbia', 'SK': 'Slovakia', 'SI': 'Slovenia', 'ES': 'Spain', 'SE': 'Sweden', 'CH': 'Switzerland',
    'GB': 'United Kingdom', 'UA': 'Ukraine', 'SM': 'San Marino', 'US': 'United States',
}
SCALE_NAMES = {'LARGE': 'Large Corporate', 'Medium': 'Middle Market', 'Small Market': 'Small Market', 'Commodity': 'Commodity Trading'}
POINTS_CELL = {'Large Corporate': 'P15', 'Middle Market': 'P25', 'Small Market': 'P32', 'Commodity Trading': 'P44'}
CRITERIA_CELLS = {   # punctaj pe criteriile subiective (Scale&Subjective)
    '9. Financial Reporting': 'D26', '10. Experience': 'H26', '11. Payments Behavior': 'D34',
    '12. Age of Company': 'H35', '13. Credit Bureau': 'D44', '14. Country Rating': 'H44',
}


@dataclass
class ScorecardInputs:
    customer_name: str
    customer_code: str = ''
    experience: str = 'C'
    payment: str = 'C'
    financial_reporting: str = 'Average'
    country_rating: str = None
    analyst: str = ''


@dataclass
class ScorecardResult:
    company: str
    connect_id: str
    country: str
    customer_code: str
    years: str
    currency: str
    fx_rate: str
    revenue_usd: str
    cs_rating: str
    cs_limit: str
    bureau: str
    incorporated: str
    age: str
    experience: str
    payment: str
    scale: str
    points: str
    grade: str
    equity_usd: str
    current_ratio: str
    criteria: dict = field(default_factory=dict)
    warnings: list = field(default_factory=list)
    file: Path = None

    @property
    def grade_int(self):
        try:
            return int(str(self.grade).strip())
        except ValueError:
            return None


def template_path(cfg):
    p = cfg.template_path
    if not p.exists():
        raise AppError('TEMPLATE', f'Scorecard template not found: {p}')
    return p


def _fmt_date(d):
    return f'{d.day:02d}/{d.month:02d}/{d.year:04d}'


def fill(report, inputs, out_dir, file_name, excel, cfg, replace=False):
    """Genereaza scorecardul. excel = ExcelApp. Intoarce ScorecardResult (fisierul copiat in out_dir).
    replace=True (evaluare refacuta): inlocuieste scorecardul existent cu acelasi nume, in loc de "... (2)"."""
    stmts = mapping.statements(report, 4)
    if not stmts:
        raise AppError('NO_FINANCIALS', 'The Creditsafe report contains no financial statements.')
    tpl = template_path(cfg)
    name = inputs.customer_name or mapping.dig(report, 'companySummary', 'businessName') or 'Unknown'
    iso = str(mapping.dig(report, 'companySummary', 'country') or '').upper()
    country_name = COUNTRY_NAMES.get(iso, iso)

    paths.WORK_DIR.mkdir(parents=True, exist_ok=True)
    work = paths.WORK_DIR / f'{uuid.uuid4().hex}.xlsx'
    shutil.copyfile(tpl, work)

    rating = mapping.dig(report, 'creditScore', 'currentCreditRating') or {}
    bureau = mapping.bureau_grade(report)
    inc = mapping.incorporation_date(report)
    age = mapping.age_grade(inc)
    warns = []
    if not age:
        warns.append(warning('NO_AGE'))
    if len(stmts) < 3:
        warns.append(warning('FEW_YEARS', len(stmts)))
    latest_end = mapping.parse_date(stmts[0]['yearEndDate'])
    if latest_end < dt.date.today() - dt.timedelta(days=548):
        warns.append(warning('OLD_ACCOUNTS', latest_end.strftime('%d.%m.%Y')))
    status = mapping.company_status(report)
    if status and status.lower() != 'active':
        warns.append(warning('NOT_ACTIVE', status))
    cur = str(stmts[0].get('currency') or '')

    xl = excel.xl
    wb = None
    try:
        wb = excel.open(work)
        retry(lambda: setattr(xl, 'Calculation', XL_CALC_MANUAL))   # altfel Excel recalculeaza dupa fiecare celula

        # --- Blank 1: etichete in B, valori in C:F (cel mai recent in C), date ca text dd/MM/yyyy
        dates = [_fmt_date(mapping.parse_date(s['yearEndDate'])) for s in stmts]
        rows = [[f'Creditsafe {report.get("companyId", "")} - {name}', None, None, None, None],
                ['Year end date'] + dates + [None] * (4 - len(stmts)),
                ['Currency'] + [str(s.get('currency') or '') for s in stmts] + [None] * (4 - len(stmts))]
        for field_name, label in mapping.FINANCIAL_LABELS.items():
            vals = [label, None, None, None, None]
            has = False
            for i, s in enumerate(stmts):
                v = mapping.statement_value(s, field_name)
                if v is not None:
                    vals[1 + i] = v
                    has = True
            if has:
                rows.append(vals)
        b1 = wb.Worksheets('Blank 1')
        matrix = tuple(tuple(r) for r in rows)
        retry(lambda: setattr(b1.Range('C2:F2'), 'NumberFormat', '@'))
        # adresa explicita: in COM dinamic din Python, Range.Resize(r, c) intoarce o singura celula
        retry(lambda: setattr(b1.Range(f'B1:F{len(rows)}'), 'Value2', matrix))

        # --- Blank 2: curs USD->EUR pentru fiecare data de bilant (doar bilanturi in EUR)
        if cfg.get('scorecard', 'autoFx') and cur == 'EUR':
            added = _ensure_fx_rows(wb, [mapping.parse_date(s['yearEndDate']) for s in stmts])
            if added:
                warns.append(warning('FX_ADDED', ', '.join(added)))

        # --- Scale&Subjective
        ss = wb.Worksheets('Scale&Subjective')
        today = dt.date.today()
        writes = {
            'C2': name,                                                       # Name of Counterparty
            'C4': f'=DATE({today.year},{today.month},{today.day})',           # Date of review
            'C5': country_name,                                               # Country HQ
            'D20': inputs.financial_reporting or cfg.get('scorecard', 'financialReporting'),   # 9.
            'H20': inputs.experience,                                         # 10. Experience
            'D28': inputs.payment,                                            # 11. Payments Behavior
            'D37': bureau,                                                    # 13. Credit Bureau (Creditsafe)
        }
        if inputs.analyst:
            writes['C3'] = inputs.analyst
        if age:
            writes['H28'] = age                                               # 12. Age of Company
        if inputs.customer_code:
            writes['E3'] = inputs.customer_code                               # SAP Number
        if inputs.country_rating:
            writes['H37'] = inputs.country_rating                             # 14. Country Rating
        cur_label = _currency_label(wb, cur)
        if cur_label:
            writes['E4'] = cur_label                                          # Financials currency
        for addr, val in writes.items():
            retry(lambda a=addr, v=val: setattr(ss.Range(a), 'Formula', str(v)))

        # Scorecard folosit (B11) = sugestia din B9, tradusa in denumirile din lista C9:C12
        retry(lambda: xl.CalculateFull())
        suggested = str(ss.Range('B9').Text).strip()
        scale = SCALE_NAMES.get(suggested)
        if scale:
            retry(lambda: setattr(ss.Range('B11'), 'Value2', scale))
        retry(lambda: xl.CalculateFull())

        fx_txt = str(ss.Range('C15').Text).strip()
        if not fx_txt or fx_txt.startswith('#'):
            warns.append(warning('FX_MISSING', cur, dates[0]))
        elif cur != 'EUR':
            warns.append(warning('FX_EUR_ONLY', cur))

        summ = wb.Worksheets('Summary')
        crit = {}
        for k, a in CRITERIA_CELLS.items():
            crit[k] = str(ss.Range(a).Text).strip()
        lim = rating.get('creditLimit') or {}
        res = ScorecardResult(
            company=name, connect_id=str(report.get('companyId', '')), country=country_name,
            customer_code=inputs.customer_code or '',
            years=', '.join(str(mapping.parse_date(s['yearEndDate']).year) for s in stmts),
            currency=cur, fx_rate=fx_txt,
            revenue_usd=str(wb.Worksheets('IS').Range('B34').Text).strip(),
            cs_rating=f'{rating.get("commonValue", "")} ({mapping.dig(rating, "providerValue", "value")}/100) - {rating.get("commonDescription", "")}',
            cs_limit=f'{lim.get("value", "")} {lim.get("currency", "")}'.strip(),
            bureau=bureau, incorporated=inc.isoformat() if inc else 'necunoscut', age=age or '',
            experience=inputs.experience, payment=inputs.payment,
            scale=str(summ.Range('D6').Text).strip(),
            points=str(ss.Range(POINTS_CELL[scale]).Text).strip() if scale else '',
            grade=str(summ.Range('E6').Text).strip(),
            equity_usd=str(summ.Range('D18').Text).strip(),
            current_ratio=str(summ.Range('D26').Text).strip(),
            criteria=crit, warnings=warns,
        )
        # fisierul salvat se deschide cu calcul automat, direct pe rezumat
        retry(lambda: setattr(xl, 'Calculation', XL_CALC_AUTO))
        retry(lambda: summ.Activate())
        retry(lambda: wb.Save())
        retry(lambda: wb.Close(False))
        wb = None
    except Exception:
        if wb is not None:
            try:
                wb.Close(False)
            except Exception:
                pass
        _unlink(work)
        raise

    g = res.grade_int
    if g is None or not 1 <= g <= 11:
        _unlink(work)
        raise AppError('INVALID_RESULT', f'Calculated grade "{res.grade}" (scale "{res.scale}", points "{res.points}").', ' '.join(warns))
    try:
        res.file = copy_to_destination(work, Path(out_dir) / file_name, replace=replace)
        if replace and Path(res.file).name != file_name:
            warns.append(f'Scorecardul vechi ({file_name}) era deschis - cel nou s-a salvat ca {Path(res.file).name}.')
    finally:
        _unlink(work)
    return res


def _unlink(p):
    try:
        Path(p).unlink()
    except OSError:
        pass


def _ensure_fx_rows(wb, dates):
    """Adauga in "Blank 2" (Date | FX USD->EUR) cursul BCE pentru datele lipsa. Intoarce lista adaugata."""
    ws = wb.Worksheets('Blank 2')
    data = ws.Range('A1:B500').Value2
    existing = {str(r[0]).strip() for r in data if r and r[0] not in (None, '')}
    last = max((i + 1 for i, r in enumerate(data) if r and r[0] not in (None, '')), default=1)
    added = []
    for d in dates:
        key = _fmt_date(d)
        if key in existing:
            continue
        usd = fx.usd_per_eur(d)
        if not usd:
            continue    # ramane avertismentul FX_MISSING
        last += 1
        row = last
        retry(lambda r=row: setattr(ws.Range(f'A{r}'), 'NumberFormat', '@'))
        retry(lambda r=row, k=key: setattr(ws.Range(f'A{r}'), 'Value2', k))
        retry(lambda r=row, v=round(1.0 / usd, 4): setattr(ws.Range(f'B{r}'), 'Value2', v))
        existing.add(key)
        added.append(f'{key} = {1.0 / usd:.4f}')
    return added


def _currency_label(wb, cur):
    """'EUR' -> 'EUR, Euro ' (formatul din foaia ascunsa Country, coloana E) sau None."""
    if not cur:
        return None
    try:
        vals = wb.Worksheets('Country').Range('E2:E300').Value2
    except Exception:
        return None
    for r in vals or ():
        v = r[0] if r else None
        if isinstance(v, str) and v.upper().startswith(cur.upper() + ','):
            return v
    return None
