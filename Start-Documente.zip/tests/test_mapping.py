import datetime as dt

import make_report
from creditapp import mapping


def test_bureau_grade():
    assert mapping.bureau_grade(make_report.report(common='A')) == 'A'
    assert mapping.bureau_grade(make_report.report(common='B')) == 'B'
    assert mapping.bureau_grade(make_report.report(common='C')) == 'C'
    assert mapping.bureau_grade(make_report.report(common='D', score='25')) == 'E'
    assert mapping.bureau_grade(make_report.report(common='D', score='15')) == 'F'
    assert mapping.bureau_grade(make_report.report(common='E')) == 'D'
    assert mapping.bureau_grade(make_report.report(common='A', status='NonActive')) == 'F'


def test_age_grade():
    today = dt.date(2026, 10, 16)
    assert mapping.age_grade(dt.date(1998, 3, 15), today) == 'A'
    assert mapping.age_grade(dt.date(2010, 1, 1), today) == 'B'
    assert mapping.age_grade(dt.date(2017, 1, 1), today) == 'C'
    assert mapping.age_grade(dt.date(2020, 1, 1), today) == 'D'
    assert mapping.age_grade(dt.date(2023, 1, 1), today) == 'E'
    assert mapping.age_grade(dt.date(2025, 1, 1), today) == 'F'
    assert mapping.age_grade(None) is None


def test_statements_sorted_and_limited():
    rep = make_report.report(years=(2023, 2025, 2024, 2022, 2021))
    st = mapping.statements(rep, 4)
    assert [mapping.parse_date(s['yearEndDate']).year for s in st] == [2025, 2024, 2023, 2022]
    assert mapping.latest_financial_year(rep) == 2025


def test_statements_ignores_local_and_bad_dates():
    rep = make_report.report(years=(2025,))
    rep['financialStatements'].append({'type': 'LocalFinancialsCSIT', 'yearEndDate': '2026-12-31T00:00:00Z'})
    rep['financialStatements'].append({'type': 'GlobalFinancialsGGS', 'yearEndDate': None})
    assert len(mapping.statements(rep)) == 1


def test_parse_date_variants():
    assert mapping.parse_date('2025-12-31T00:00:00.000000Z') == dt.date(2025, 12, 31)
    assert mapping.parse_date('2025-12-31') == dt.date(2025, 12, 31)
    assert mapping.parse_date('') is None
    assert mapping.parse_date('n/a') is None


def test_summary_and_vat():
    rep = make_report.report()
    s = mapping.summary(rep)
    assert s['name'] == 'MIRA SUD S.R.L.' and s['cs_limit'] == '650000' and s['currency'] == 'EUR'
    assert s['incorporated'] == dt.date(1998, 3, 15)
    assert s['equity'] > 0 and s['years'] == 3
    assert '01491571210' in mapping.report_vat_numbers(rep)
