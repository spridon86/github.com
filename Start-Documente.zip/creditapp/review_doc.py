"""Annual Review (Word) pentru un grup / client - draft dupa modelul folosit in Credit Control
(Annual Review - ENI GROUP): tabelul de limite actuale / noi, overview, relatia cu Bunge,
financiare (printscreen din foaia "Summary" a scorecardului, B5:F pana la Tangible Net Worth; daca poza nu se poate
face: tabelul foii; fara scorecard: USD, 3 ani, din Creditsafe), concluzia analistului. Textele de completat sunt marcate [de completat]."""
import datetime as dt

from . import fx, mapping

NAVY = '0B3C5D'
BLUE_TXT = (0x2E, 0x75, 0xB6)


def _usd(v):
    return f'{v:,.0f}'


def _mil(v):
    return f'{v / 1_000_000:,.1f}'


def financials_usd(report, years=3):
    """[(an, {indicator: valoare USD})] din ultimele bilanturi, convertite la cursul BCE de la data bilantului."""
    out = []
    for st in mapping.statements(report, years):
        d = mapping.parse_date(st['yearEndDate'])
        cur = (st.get('currency') or 'EUR').upper()
        if cur == 'USD':
            rate = 1.0
        else:
            eur_usd = fx.ecb_rate('USD', d)
            if not eur_usd:
                continue
            if cur == 'EUR':
                rate = eur_usd
            else:
                per_eur = fx.ecb_rate(cur, d)
                if not per_eur:
                    continue
                rate = eur_usd / per_eur

        def v(field):
            x = mapping.statement_value(st, field)
            return None if x is None else x * rate
        ca, cl = v('totalCurrentAssets'), v('totalCurrentLiabilities')
        out.append((d.year, {
            'Revenue': v('revenue'), 'Operating Profit': v('operatingProfit'), 'Profit Before Tax': v('profitBeforeTax'),
            'Net Profit': v('profitAfterTax'), 'Total Assets': v('totalAssets'),
            "Shareholders' Equity": v('totalShareholdersEquity'),
            'Net Working Capital': (ca - cl) if ca is not None and cl is not None else None,
        }))
    return out


def _fmt_cell(v, number_format):
    """Valoarea din Excel cum o arata Excel (aprox.): 61,176,471 / 1.52 / 20% / 31/12/2025."""
    if v is None:
        return ''
    if isinstance(v, (dt.datetime, dt.date)):
        return v.strftime('%B %d, %Y') if 'mmm' in (number_format or '').lower() else v.strftime('%d/%m/%Y')
    if isinstance(v, bool):
        return str(v)
    if isinstance(v, (int, float)):
        fmt = number_format or ''
        if '%' in fmt:
            return f'{v:.0%}'
        dec = 2 if ('0.00' in fmt or (isinstance(v, float) and abs(v) < 1000 and v != int(v))) else 0
        return f'{v:,.{dec}f}'
    return str(v).strip()


def scorecard_summary(path):
    """Foaia "Summary" din scorecardul clientului (B5:F52) - exact continutul din printscreen-ul scorecardului:
    antet (nume, regiune, tara, analist, data; scala, grade calculat / final), Income Statement USD si ratiile.
    Intoarce lista de randuri [B, C, D, E, F] (texte), fara randurile goale; None daca fisierul nu se poate citi."""
    from openpyxl import load_workbook
    try:
        wb = load_workbook(str(path), data_only=True, read_only=False)
        ws = wb['Summary']
    except Exception:
        return None
    rows = []
    for r in range(5, 53):
        vals = [_fmt_cell(ws.cell(r, c).value, ws.cell(r, c).number_format) for c in range(2, 7)]
        if any(vals):
            rows.append((r, vals))
    wb.close()
    return rows or None


def summary_picture(path, out_png):
    """Printscreen din foaia "Summary" a scorecardului: antetul (nume, regiune, tara, analist, data, scala, grade) si
    Income Statement in USD pana la "Tangible Net Worth" (B5:F22 in sablonul 2026), exact cum il arata Excel.
    Se lucreaza pe o copie (scorecardul poate fi deschis la analist). Intoarce calea PNG sau None."""
    import time
    import uuid
    from pathlib import Path
    from . import log, paths
    from .excel_com import ExcelApp, retry
    from .fsutil import copy_file
    _log = log.get('review_doc')
    paths.WORK_DIR.mkdir(parents=True, exist_ok=True)
    tmp = paths.WORK_DIR / f'summary_{uuid.uuid4().hex[:8]}.xlsx'
    xl = None
    try:
        copy_file(path, tmp)
        xl = ExcelApp()
        wb = xl.open(tmp, read_only=True)
        ws = wb.Worksheets('Summary')
        last = 22
        for r in range(11, 53):
            if 'tangible net worth' in str(ws.Cells(r, 2).Value or '').strip().lower():
                last = r
                break
        rng = ws.Range(f'B5:F{last}')
        retry(lambda: rng.CopyPicture(1, -4147))          # xlScreen, xlPicture: ca pe ecran, fara linii de grila
        # scorecardul e protejat (foaie + structura): graficul pentru export se face intr-un registru nou, gol
        ws2 = xl.xl.Workbooks.Add().Worksheets(1)
        co = ws2.ChartObjects().Add(0, 0, rng.Width, rng.Height)
        try:
            co.Chart.ChartArea.Format.Line.Visible = False
        except Exception:
            pass
        for _ in range(5):                                 # Paste esueaza uneori daca clipboard-ul nu e gata
            try:
                co.Activate()
                co.Chart.Paste()
                break
            except Exception:
                time.sleep(0.5)
        else:
            return None
        out_png = Path(out_png)
        co.Chart.Export(str(out_png), 'PNG')
        co.Delete()
        for w in (ws2.Parent, wb):                   # registrele inchise explicit: Excel se poate opri singur
            try:
                w.Close(False)
            except Exception:
                pass
        return out_png if out_png.exists() and out_png.stat().st_size > 1000 else None
    except Exception as e:
        _log.warning('Summary screenshot failed for %s: %s', path, e)
        return None
    finally:
        if xl is not None:
            try:
                xl.xl.CutCopyMode = False
                import win32clipboard               # poza din clipboard tine Excel deschis la iesire
                win32clipboard.OpenClipboard()
                win32clipboard.EmptyClipboard()
                win32clipboard.CloseClipboard()
            except Exception:
                pass
            xl.quit()
        try:
            tmp.unlink()
        except OSError:
            pass


# "Commodity Description" din Open Contracts -> familia scrisa in Annual Review (prima regula care se potriveste)
_COMMODITY_RULES = [
    ('crude oil', 'Crude oil'), ('refined oil', 'Refined oil'), ('neutralised oil', 'Refined oil'), ('soybean meal', 'SBM'),
    ('sunflower meal', 'SFM'), ('sunmeal', 'SFM'), ('rapeseed meal', 'RSM'), ('hulls', 'Hulls'), ('wheat', 'Wheat'),
    ('corn', 'Corn'), ('barley', 'Barley'), ('soybean', 'Soybeans'), ('sunflowerseed', 'Sunflower seeds'),
    ('rapeseed', 'Rapeseed'), ('glycerine', 'Glycerine'), ('fatty acid', 'Fatty acids'), ('byproduct', 'By-products'),
]


def commodity_families(counts):
    """{descriere: nr. contracte} -> ['SBM', 'Corn', 'Wheat', ...] ordonate dupa numarul de contracte."""
    fam = {}
    for desc, n in (counts or {}).items():
        d = str(desc).lower()
        name = next((f for k, f in _COMMODITY_RULES if k in d), None)
        if name is None:            # fara regula: descrierea fara prefixul de origine ("Any", "00", "IT"...)
            parts = str(desc).split(' ', 1)
            name = (parts[1] if len(parts) > 1 and (len(parts[0]) <= 3 or parts[0].lower() == 'any') else str(desc)).strip().capitalize()
        fam[name] = fam.get(name, 0) + n
    return [k for k, _ in sorted(fam.items(), key=lambda kv: -kv[1])]


def scorecard_figures(path):
    """Cifrele din foaia "Summary" a scorecardului (USD, ultimul an): year, sales, net_income, equity, equity30.
    Se citeste o copie (scorecardul poate fi deschis la analist). {} daca nu se poate citi."""
    import tempfile
    import uuid
    from pathlib import Path
    from openpyxl import load_workbook
    from .fsutil import copy_file
    tmp = Path(tempfile.gettempdir()) / f'scorecard_{uuid.uuid4().hex[:8]}.xlsx'
    try:
        copy_file(path, tmp)
        wb = load_workbook(str(tmp), data_only=True, read_only=True)
        ws = wb['Summary']
        head6 = next(ws.iter_rows(min_row=6, max_row=6, max_col=6, values_only=True))      # scala | grade calculat | final
        rows = {str(r[1] or '').strip().lower(): r for r in ws.iter_rows(min_row=11, max_row=23, max_col=4, values_only=True)}
        wb.close()
    except Exception:
        return {}
    finally:
        try:
            tmp.unlink()
        except OSError:
            pass
    out = {}
    from .rules import grade_number
    g = grade_number(head6[5]) or grade_number(head6[4])     # "Final Grade" daca e completat (0 = gol), altfel cel calculat
    if g:
        out['grade'] = g
    head = next((r for k, r in rows.items() if k.startswith('income statement')), None)
    y = head[3] if head else None
    if isinstance(y, (dt.date, dt.datetime)):
        out['year'] = y.year
    elif y:
        import re
        m = re.search(r'(19|20)\d{2}', str(y))
        if m:
            out['year'] = int(m.group(0))
    for key, label in (('sales', 'sales'), ('net_income', 'net income'), ('equity', 'equity'), ('equity30', '30% equity')):
        r = rows.get(label)
        if r and isinstance(r[3], (int, float)):
            out[key] = float(r[3])
    return out


_COUNTRIES = {
    'IT': ('Italian', 'Italy'), 'ES': ('Spanish', 'Spain'), 'FR': ('French', 'France'), 'DE': ('German', 'Germany'),
    'AT': ('Austrian', 'Austria'), 'CH': ('Swiss', 'Switzerland'), 'NL': ('Dutch', 'the Netherlands'), 'BE': ('Belgian', 'Belgium'),
    'HU': ('Hungarian', 'Hungary'), 'RO': ('Romanian', 'Romania'), 'GR': ('Greek', 'Greece'), 'PT': ('Portuguese', 'Portugal'),
    'GB': ('British', 'the United Kingdom'), 'PL': ('Polish', 'Poland'), 'BG': ('Bulgarian', 'Bulgaria'), 'HR': ('Croatian', 'Croatia'),
    'SI': ('Slovenian', 'Slovenia'), 'RS': ('Serbian', 'Serbia'), 'SK': ('Slovak', 'Slovakia'), 'CZ': ('Czech', 'the Czech Republic'),
}


def _about_text(report):
    """Textul din "About the company" (fara nume - numele se scrie ingrosat inainte), din raportul Creditsafe."""
    iso = str(mapping.dig(report, 'companySummary', 'country') or '').upper()
    adj, country = _COUNTRIES.get(iso, ('', iso))
    inc = mapping.incorporation_date(report)
    city = str(mapping.dig(report, 'alternateSummary', 'contactAddress', 'city') or '').strip().title()
    act, emp = _activity(report)
    s = f' is {"an" if adj and adj[0] in "AEIOU" else "a"} {adj + " " if adj else ""}company'
    if inc:
        s += f' founded in {inc.year}'
    if city or country:
        s += f'{" and" if inc else ""} headquartered in {", ".join(x for x in (city, country) if x)}'
    s += '.'
    if act:
        s += f' Its main activity is the {act[0].lower() + act[1:]}' + (f', with approximately {emp} employees' if emp else '') + '.'
    parent = mapping.dig(report, 'groupStructure', 'ultimateParent', 'name')
    if parent:
        s += f' The ultimate parent company is {parent}.'
    return s


def _activity(report):
    s = mapping.dig(report, 'companySummary', 'mainActivity', 'description') or mapping.dig(report, 'companySummary', 'mainActivity', 'activityDescription')
    emp = mapping.dig(report, 'otherInformation', 'employeesInformation')
    n_emp = None
    if isinstance(emp, list) and emp:
        n_emp = emp[0].get('numberOfEmployees')
    return s, n_emp


def build(path, data):
    """data: dict cu group, total_new_usd, grade, grade_source, compliance, fiscal_year, counterparties (ReviewCounterparty),
    authority, relationship (lista de texte), report (raportul Creditsafe al mamei sau None),
    analyst, insurance_usd."""
    from docx import Document
    from docx.enum.table import WD_TABLE_ALIGNMENT
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.shared import Cm, Pt, RGBColor

    doc = Document()
    for sec in doc.sections:
        sec.left_margin = sec.right_margin = Cm(1.4)
        sec.top_margin = sec.bottom_margin = Cm(1.5)
    st = doc.styles['Normal']
    st.font.name = 'Cambria'
    st.font.size = Pt(10.5)

    def heading(text, size=13):
        p = doc.add_paragraph()
        r = p.add_run(text)
        r.bold = True
        r.font.size = Pt(size)
        r.font.color.rgb = RGBColor(*BLUE_TXT)
        p.paragraph_format.space_before = Pt(10)
        p.paragraph_format.space_after = Pt(3)
        return p

    def label(lbl, value):
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(0)
        p.add_run(f'{lbl}: ').bold = True
        p.add_run(str(value))

    def shade(cell, color):
        tcpr = cell._tc.get_or_add_tcPr()
        sh = OxmlElement('w:shd')
        sh.set(qn('w:val'), 'clear')
        sh.set(qn('w:color'), 'auto')
        sh.set(qn('w:fill'), color)
        tcpr.append(sh)

    def cell_text(cell, text, bold=False, white=False, align=None, size=7.5):
        cell.text = ''
        p = cell.paragraphs[0]
        r = p.add_run(str(text))
        r.bold = bold
        r.font.size = Pt(size)
        if white:
            r.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        if align:
            p.alignment = align

    g = data['group']
    cps = data['counterparties']
    figs = scorecard_figures(data['scorecard_file']) if data.get('scorecard_file') else {}
    total_new = data['total_new_usd']
    # equity scenario: limita totala peste 30% din capitalurile proprii (randul "30% Equity" din scorecard)
    equity_scenario = bool(figs.get('equity30') and total_new > figs['equity30']) if figs.get('equity30') else bool(data.get('equity_scenario'))
    heading(f'Annual Review – {g}', 15)
    label('Counterparty', g)
    label('Total Limit Requested', f'USD {_mil(total_new)} million' + (' (equity scenario)' if equity_scenario else ''))
    label('Grade', f'{data["grade"]}')
    label('Compliance', data.get('compliance') or '[de completat]')
    label('Latest Fiscal Year', data.get('fiscal_year') or (f'December {figs["year"]}' if figs.get('year') else '[de completat]'))
    doc.add_paragraph()

    # --- tabelul de limite
    hdr = ['Counterparty Name', 'Grade', 'Open Credit', 'MTM/PFE', 'Total', 'Open Credit', 'MTM/PFE', 'Total', 'Region using the limit', 'Commercial responsible']
    t = doc.add_table(rows=2, cols=len(hdr))
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.style = 'Table Grid'
    t.autofit = False
    widths = [Cm(w) for w in (3.3, 1.0, 1.75, 1.75, 1.8, 1.75, 1.75, 1.8, 1.15, 2.05)]
    top = t.rows[0].cells
    top[2].merge(top[4])
    top[5].merge(top[7])
    for c in t.rows[0].cells:
        shade(c, NAVY)
    cell_text(t.rows[0].cells[2], 'Actual Open limits', True, True, WD_ALIGN_PARAGRAPH.CENTER)
    cell_text(t.rows[0].cells[5], 'New Limits', True, True, WD_ALIGN_PARAGRAPH.CENTER)
    for i, h in enumerate(hdr):
        shade(t.rows[1].cells[i], NAVY)
        cell_text(t.rows[1].cells[i], h, True, True, WD_ALIGN_PARAGRAPH.CENTER)
    tot = [0.0] * 6
    for c in cps:
        row = t.add_row().cells
        vals = [c.name, c.grade, _usd(c.open_usd), _usd(c.mtm_usd), _usd(c.total_usd), _usd(c.new_open_usd), _usd(c.new_mtm_usd),
                _usd(c.new_total_usd), ' + '.join(c.regions), '; '.join(c.traders)]
        for i, v in enumerate(vals):
            cell_text(row[i], v, align=WD_ALIGN_PARAGRAPH.RIGHT if 2 <= i <= 7 else (WD_ALIGN_PARAGRAPH.CENTER if i in (1, 8) else None))
            shade(row[i], 'D9D9D9')
        for i, x in enumerate((c.open_usd, c.mtm_usd, c.total_usd, c.new_open_usd, c.new_mtm_usd, c.new_total_usd)):
            tot[i] += x
    row = t.add_row().cells
    for i, v in enumerate(['Grand Total', data['grade']] + [_usd(x) for x in tot] + ['', '']):
        shade(row[i], NAVY)
        cell_text(row[i], v, True, True, WD_ALIGN_PARAGRAPH.RIGHT if 2 <= i <= 7 else WD_ALIGN_PARAGRAPH.CENTER)
    for r_ in t.rows:
        for i, c in enumerate(r_.cells):
            c.width = widths[i]

    # --- texte
    heading('Overview')
    cur_total = sum(c.total_usd for c in cps)
    change = data.get('limit_change')            # same / up / down (limitele in moneda locala), din revizuire
    if change is None:
        change = 'same' if cur_total and abs(total_new - cur_total) / cur_total <= 0.05 else ('up' if total_new > cur_total else 'down')
    if change == 'same':
        rec = 'maintaining the existing credit limit for the next 12 months' + (
            ', with an adjustment to reflect the exchange rate evolution' if abs(total_new - cur_total) >= 1 else '')
    elif change == 'up':
        rec = f'increasing the credit limit to USD {_mil(total_new)} million for the next 12 months, in line with the expected exposure'
    else:
        rec = f'reducing the credit limit to USD {_mil(total_new)} million for the next 12 months'
    doc.add_paragraph(f'I am submitting for approval the annual review of {g} and based on the available information, we recommend {rec}.')

    heading('About the company')
    rep = data.get('report')
    p = doc.add_paragraph()
    if rep:
        p.add_run(g).bold = True
        p.add_run(_about_text(rep) + ' ')
    p.add_run('[de completat: descrierea grupului, piete, produse]')

    heading('Relationship with Bunge')
    for line in data.get('relationship') or ['[de completat]']:
        doc.add_paragraph(line, style='List Bullet')
    p = doc.add_paragraph()
    p.add_run('[de completat: printscreen SAP - Payment history]').italic = True

    heading('Financials')
    fin = financials_usd(rep) if rep else []
    pic = None
    if data.get('scorecard_file'):
        import tempfile
        from pathlib import Path
        pic = summary_picture(data['scorecard_file'], Path(tempfile.mkdtemp()) / 'summary.png')
    summ = scorecard_summary(data['scorecard_file']) if data.get('scorecard_file') and not pic else None
    if pic:
        # printscreen din scorecard (foaia "Summary": antet + Income Statement USD pana la Tangible Net Worth)
        doc.add_picture(str(pic), width=Cm(18))
        try:
            pic.unlink()
            pic.parent.rmdir()
        except OSError:
            pass
    elif summ:
        # continutul foii "Summary" din scorecard (acelasi aspect: antet, Income Statement USD, ratii pe sectiuni)
        st_ = doc.add_table(rows=0, cols=5)
        st_.style = 'Table Grid'
        st_.autofit = False
        sw = [Cm(w) for w in (4.6, 6.2, 2.4, 2.4, 2.4)]
        for r, (b, c, d, e, f) in summ:
            cells = st_.add_row().cells
            section = r in (5, 11, 24, 29, 37, 43)            # randurile albastre din scorecard
            growth = not b and not c and r in (13, 15, 17, 19)  # variatia an la an sub Sales / GP / NI / Equity
            for i, v in enumerate((b, c, d, e, f)):
                if section:
                    shade(cells[i], '1F5C99')
                elif r <= 9:
                    shade(cells[i], 'DDEBF7')
                cell_text(cells[i], v, bold=section or (r <= 9 and i in (0, 2, 3, 4)), white=section,
                          align=WD_ALIGN_PARAGRAPH.RIGHT if i >= 2 and r > 9 else (WD_ALIGN_PARAGRAPH.CENTER if i >= 2 else None),
                          size=6.5 if growth else 7.5)
        for row_ in st_.rows:
            for i, c in enumerate(row_.cells):
                c.width = sw[i]
        doc.add_paragraph(f'Source: Bunge scorecard ({data["scorecard_file"].split(chr(92))[-1]}), sheet "Summary".').runs[0].font.size = Pt(8)
    elif fin:
        biggest = max((abs(v) for _, d in fin for v in d.values() if v is not None), default=0)
        div, unit = (1e9, 'USD bn') if biggest >= 1e9 else (1e6, 'USD m')
        ft = doc.add_table(rows=1, cols=1 + len(fin))
        ft.style = 'Table Grid'
        cell_text(ft.rows[0].cells[0], unit, True, size=9)
        for i, (y, _) in enumerate(fin, 1):
            cell_text(ft.rows[0].cells[i], y, True, align=WD_ALIGN_PARAGRAPH.CENTER, size=9)
        for k in fin[0][1]:
            c = ft.add_row().cells
            cell_text(c[0], k, size=9)
            for i, (_, d) in enumerate(fin, 1):
                v = d.get(k)
                cell_text(c[i], '' if v is None else f'{v / div:,.1f}', align=WD_ALIGN_PARAGRAPH.CENTER, size=9)
        doc.add_paragraph(f'Source: Creditsafe ({mapping.dig(rep, "companySummary", "businessName")}), converted at ECB year-end rates.').runs[0].font.size = Pt(8)
    else:
        doc.add_paragraph('[de completat - nu exista raport Creditsafe pentru firma mama]')

    heading('Credit Analyst Feedback')
    doc.add_paragraph('Considering:')
    fb = list(data.get('feedback') or [])
    # equity / rezultat net: aceleasi cifre ca in printscreen (scorecard, USD); activele totale: Creditsafe la cursul BCE
    last = fin[0][1] if fin else {}
    equity = figs.get('equity', last.get("Shareholders' Equity"))
    net = figs.get('net_income', last.get('Net Profit'))
    year = figs.get('year') or (fin[0][0] if fin else None)
    assets = last.get('Total Assets')
    div = 1e9 if abs(assets or equity or 0) >= 1e9 else 1e6
    unit = 'billion' if div == 1e9 else 'million'
    if equity is not None:
        fb.append(f"Shareholders' equity of approximately USD {equity / div:,.1f} {unit}"
                  + (f' and total assets of USD {assets / div:,.1f} {unit}' if assets else '') + ';')
    if net is not None:
        fb.append(f'Net result of approximately USD {net / div:,.1f} {unit}' + (f' in FY{year}' if year else '') + ';')
    if data.get('insurance_usd'):
        fb.append(f'Existing insurance support of approximately USD {_mil(data["insurance_usd"])} million;')
    for line in fb:
        doc.add_paragraph(line, style='List Bullet')
    detail = ', '.join(x for x in (f'Grade {data["grade"]}', 'equity scenario' if equity_scenario else '') if x)
    doc.add_paragraph(f'I support the requested combined limit of USD {_mil(total_new)} million ({detail}) for {g.rstrip(".")}.')
    doc.save(str(path))
    return path
