"""Citeste fisierul "Open Contracts ITA.xlsx": lista clientilor de evaluat, expunerea si comportamentul de plata.

Fisierul e deschis de obicei in Excel si sincronizat de OneDrive - se citeste o copie temporara
(openpyxl, doar valori), fara sa blocheze originalul.

Foi folosite (dupa numele coloanelor, nu dupa pozitie):
  Monthly Exposure Italy   - Partner, nume, BU, limita, expunere pe luni, luni peste limita
  Weekly Exposure Italy    - total commitment, Peak Exposure, Peak Week, saptamani peste limita
  Payment behaviour report - zile de intarziere, restante, trend (antetul e pe randul 2)
  VAT Italy                - Customer Code -> VAT
  Limits_Italy             - blocaj, validitatea scorului, MTM, restante
  Open Contracts           - prima data de contract a partenerului (pentru "Experience")
  <evaluationSheet>        - optional: lista clientilor de evaluat (coloana "Partner")
"""
import datetime as dt
import re
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path

from . import log, paths
from .errors import AppError
from .fsutil import copy_file

_log = log.get('portfolio')


@dataclass
class PaymentBehaviour:
    risk_score: float = None
    trend: str = ''
    trend_text: str = ''
    days_late_text: str = ''
    priority: str = ''
    alerts: str = ''
    net_overdue_share: float = None
    oldest_overdue_days: float = None
    net_open_balance: float = None
    recent_days_late: float = None
    baseline_days_late: float = None
    recent_invoices: float = None
    baseline_invoices: float = None
    payment_returns: float = None
    first_activity: dt.date = None
    last_cash_payment: dt.date = None
    key_drivers: str = ''


@dataclass
class Counterparty:
    partner: str
    name: str
    business_unit: str = ''
    purchase_sale: str = ''
    prepayment: bool = False
    block_reason: str = ''
    limit: float = 0.0                    # limita curenta (EUR) din fisier = SAP
    monthly: dict = field(default_factory=dict)     # 'OCT 26' -> expunere
    months_over: int = 0
    first_breach_month: str = ''
    # saptamanal
    last_contract: dt.date = None
    total_commitment: float = None
    peak_exposure: float = None
    peak_week: str = ''
    peak_vs_limit: float = None
    weeks_over: int = 0
    first_breach_week: str = ''
    weekly: dict = field(default_factory=dict)
    data_quality: str = ''
    # alte foi
    vat: str = ''
    group: str = ''
    payment: PaymentBehaviour = None
    blocked_cm: bool = False
    block_reason_cm: str = ''
    score_validity: dt.date = None
    mtm_limit: float = None
    overdue_amount: float = None
    receivables: float = None
    first_contract: dt.date = None
    commodities: dict = field(default_factory=dict)     # "Commodity Description" din Open Contracts -> nr. contracte
    selected_for_evaluation: bool = False
    # clienti din lista "TBD by" a excelului NWCE (pot lipsi din Open Contracts / fi pe alta companie)
    source: str = 'portfolio'             # portfolio | nwce
    company_code: str = ''                # gol = compania configurata
    nwce_sheet_row: int = 0
    nwce_customer_code: str = ''
    tbd: str = ''
    currency: str = 'EUR'
    inactive: bool = False                # STATUS = INACTIVE in NWCE

    @property
    def customer_code(self):
        return self.nwce_customer_code if self.source == 'nwce' else self.partner

    @property
    def max_exposure(self):
        vals = [v for v in self.monthly.values() if isinstance(v, (int, float))]
        peak = self.peak_exposure or 0
        return max([peak] + vals) if vals or peak else 0

    @property
    def over_limit(self):
        return (self.months_over or 0) > 0 or (self.weeks_over or 0) > 0


def counterparty_from_nwce(row, key, currency, owner):
    """Client din lista "TBD by" care nu e in Open Contracts (sau e pe alta companie)."""
    from .limits_book import _code
    kloc = _num(row.get('open_kloc')) or 0.0
    return Counterparty(partner=key, name=row.name, vat=str(row.get('vat') or '').strip(), limit=kloc * 1000,
                        group='' if str(row.get('group') or '').strip() in ('0', 'n/a') else str(row.get('group') or '').strip(),
                        source='nwce', company_code=row.company_code, nwce_sheet_row=row.sheet_row,
                        nwce_customer_code=_code(row.get('customer_code')), tbd=owner, currency=currency)


def _norm(h):
    return re.sub(r'\s+', ' ', str(h or '')).strip().lower()


def _num(v):
    if v is None or v == '':
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip().replace(' ', '').replace(' ', '')
    s = s.rstrip('%')
    try:
        return float(s.replace(',', '')) if s.count(',') and s.count('.') else float(s.replace(',', '.'))
    except ValueError:
        return None


def _date(v):
    if isinstance(v, dt.datetime):
        return v.date()
    if isinstance(v, dt.date):
        return v
    return None


def _partner(v):
    """Codul partenerului ca text, fara '.0' si spatii."""
    if v is None:
        return ''
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    s = str(v).strip()
    return s[:-2] if s.endswith('.0') and s[:-2].isdigit() else s


def _header_index(header_row, required, sheet):
    idx = {}
    for i, h in enumerate(header_row):
        k = _norm(h)
        if k and k not in idx:
            idx[k] = i
    missing = [r for r in required if _norm(r) not in idx]
    if missing:
        raise AppError('PORTFOLIO', f'Sheet "{sheet}": columns not found: {", ".join(missing)}')
    return idx


_MONTH_RE = re.compile(r'^[A-Z]{3} \d{2}$')            # 'OCT 26'
_WEEK_RE = re.compile(r'^W\d{2} [A-Z]{3}\d{2}$')         # 'W42 OCT26'
_MONTHS = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC']


def week_key(label):
    """'W45 NOV26' -> (2026, 45) (anul ISO al saptamanii); None daca nu e o saptamana."""
    m = re.match(r'^W(\d{2}) ([A-Z]{3})(\d{2})$', str(label or '').strip())
    if not m:
        return None
    week, mon, year = int(m.group(1)), m.group(2), 2000 + int(m.group(3))
    if week == 1 and mon == 'DEC':
        year += 1                         # W01 incepe uneori in decembrie
    elif week >= 52 and mon == 'JAN':
        year -= 1                         # W52 / W53 se poate termina in ianuarie
    return year, week


def future_peak(cp, today=None):
    """Varful de expunere de SAPTAMANA VIITOARE pana la ultima saptamana din fisier (saptamana curenta si cele
    trecute nu conteaza). Fara date saptamanale: lunile de dupa luna curenta. Intoarce (valoare, eticheta)."""
    today = today or dt.date.today()
    cur = tuple(today.isocalendar()[:2])
    best = (0.0, '')
    for label, v in (cp.weekly or {}).items():
        k = week_key(label)
        if k and k > cur and isinstance(v, (int, float)) and v > best[0]:
            best = (float(v), label)
    if not cp.weekly:
        for label, v in (cp.monthly or {}).items():
            m = re.match(r'^([A-Z]{3}) (\d{2})$', label)
            if not m or m.group(1) not in _MONTHS:
                continue
            ym = (2000 + int(m.group(2)), _MONTHS.index(m.group(1)) + 1)
            if ym > (today.year, today.month) and isinstance(v, (int, float)) and v > best[0]:
                best = (float(v), label)
    return best


def future_weeks_over(cp, today=None):
    """(numarul de saptamani viitoare peste limita, prima saptamana viitoare peste limita)."""
    if not cp.limit:
        return 0, ''
    cur = tuple((today or dt.date.today()).isocalendar()[:2])
    over = sorted((week_key(k), k) for k, v in (cp.weekly or {}).items()
                  if week_key(k) and week_key(k) > cur and isinstance(v, (int, float)) and v > cp.limit)
    return len(over), (over[0][1] if over else '')


class Portfolio:
    def __init__(self, source_path, loaded_at, counterparties, month_cols, week_cols, evaluation_list, notes):
        self.source_path = source_path
        self.loaded_at = loaded_at
        self.counterparties = counterparties          # dict partner -> Counterparty
        self.month_cols = month_cols
        self.week_cols = week_cols
        self.evaluation_list = evaluation_list        # lista de parteneri din foaia optionala (sau [])
        self.notes = notes

    def get(self, partner):
        return self.counterparties.get(_partner(partner))

    def __len__(self):
        return len(self.counterparties)


def _copy_for_reading(path):
    paths.WORK_DIR.mkdir(parents=True, exist_ok=True)
    tmp = paths.WORK_DIR / f'portfolio_{uuid.uuid4().hex[:8]}.xlsx'
    last = None
    for _ in range(3):
        try:
            copy_file(path, tmp)
            return tmp
        except Exception as e:
            last = e
            time.sleep(1)
    raise AppError('PORTFOLIO', f'Could not copy {path}: {last}')


def load(path, cfg, progress=None):
    """Citeste tot portofoliul. progress(text) - optional."""
    import openpyxl
    path = Path(path)
    if not path.exists():
        raise AppError('PORTFOLIO', f'File not found: {path}')
    say = progress or (lambda t: None)
    say('Copiez fisierul cu clienti...')
    tmp = _copy_for_reading(path)
    notes = []
    try:
        wb = openpyxl.load_workbook(tmp, read_only=True, data_only=True)
        names = {ws.title.strip().lower(): ws.title for ws in wb.worksheets}

        def sheet(name, required=True):
            real = names.get(name.lower())
            if not real:
                if required:
                    raise AppError('PORTFOLIO', f'Sheet "{name}" not found in {path.name}')
                notes.append(f'Foaia "{name}" lipseste - informatiile ei nu sunt disponibile.')
                return None
            return wb[real]

        # --- Monthly Exposure (lista principala)
        say('Citesc expunerea lunara...')
        ws = sheet('Monthly Exposure Italy')
        rows = ws.iter_rows(values_only=True)
        hdr = next(rows)
        ix = _header_index(hdr, ['Partner', 'Partner Description', 'Limit'], ws.title)
        month_cols = [(i, str(h).strip()) for i, h in enumerate(hdr) if h and _MONTH_RE.match(str(h).strip())]
        cps = {}

        def g(row, col):
            i = ix.get(_norm(col))
            return row[i] if i is not None and i < len(row) else None

        for row in rows:
            pid = _partner(g(row, 'Partner'))
            if not pid or not pid.isdigit():
                continue
            c = Counterparty(
                partner=pid,
                name=str(g(row, 'Partner Description') or '').strip(),
                business_unit=str(g(row, 'Business Unit') or '').strip(),
                purchase_sale=str(g(row, 'Purchase / Sale') or '').strip(),
                prepayment=bool(str(g(row, 'Prepayment/CAD') or '').strip()),
                block_reason=str(g(row, 'Block reason') or '').strip(),
                limit=_num(g(row, 'Limit')) or 0.0,
                months_over=int(_num(g(row, 'Months Over Limit')) or 0),
                first_breach_month=str(g(row, 'First Breach Month') or '').strip(),
            )
            c.monthly = {name: (_num(row[i]) or 0.0) for i, name in month_cols if i < len(row)}
            cps[pid] = c

        # --- Weekly Exposure
        say('Citesc expunerea saptamanala...')
        week_cols = []
        ws = sheet('Weekly Exposure Italy', required=False)
        if ws is not None:
            rows = ws.iter_rows(values_only=True)
            hdr = next(rows)
            ixw = _header_index(hdr, ['Partner'], ws.title)
            week_cols = [(i, str(h).strip()) for i, h in enumerate(hdr) if h and _WEEK_RE.match(str(h).strip())]

            def gw(row, col):
                i = ixw.get(_norm(col))
                return row[i] if i is not None and i < len(row) else None

            for row in rows:
                c = cps.get(_partner(gw(row, 'Partner')))
                if not c:
                    continue
                c.last_contract = _date(gw(row, 'Last Contract in SAP'))
                c.total_commitment = _num(gw(row, 'Total Commitment'))
                c.peak_exposure = _num(gw(row, 'Peak Exposure'))
                c.peak_week = str(gw(row, 'Peak Week') or '').strip()
                c.peak_vs_limit = _num(gw(row, 'Peak vs Limit'))
                c.weeks_over = int(_num(gw(row, 'Weeks Over Limit')) or 0)
                c.first_breach_week = str(gw(row, 'First Breach Week') or '').strip()
                c.data_quality = str(gw(row, 'Data Quality Detail') or '').strip()
                c.weekly = {name: (_num(row[i]) or 0.0) for i, name in week_cols if i < len(row)}
                # varful: de saptamana viitoare pana la sfarsit (nu "Peak Week" din fisier, care include trecutul)
                if c.weekly:
                    c.peak_exposure, c.peak_week = future_peak(c)
                    c.peak_vs_limit = (c.peak_exposure / c.limit) if c.limit else None
                    c.weeks_over, c.first_breach_week = future_weeks_over(c)

        for c in cps.values():           # fara expunere saptamanala: varful din lunile viitoare
            if not c.weekly and c.monthly:
                c.peak_exposure, c.peak_week = future_peak(c)
                c.peak_vs_limit = (c.peak_exposure / c.limit) if c.limit else None

        # --- Payment behaviour (antet pe randul 2)
        say('Citesc comportamentul de plata...')
        ws = sheet('Payment behaviour report', required=False)
        if ws is not None:
            rows = ws.iter_rows(values_only=True)
            next(rows)
            hdr = next(rows)
            ixp = _header_index(hdr, ['Account'], ws.title)

            def gp(row, col):
                i = ixp.get(_norm(col))
                return row[i] if i is not None and i < len(row) else None

            for row in rows:
                c = cps.get(_partner(gp(row, 'Account')))
                if not c:
                    continue
                c.payment = PaymentBehaviour(
                    risk_score=_num(gp(row, 'Risk Score')),
                    trend=str(gp(row, 'Trend') or ''),
                    trend_text=str(gp(row, 'Payment Trend') or ''),
                    days_late_text=str(gp(row, 'Days Late (Before → Now)') or ''),
                    priority=str(gp(row, 'Risk Priority') or ''),
                    alerts=str(gp(row, 'Alerts') or ''),
                    net_overdue_share=_num(gp(row, 'Net Overdue Share of Open')),
                    oldest_overdue_days=_num(gp(row, 'Oldest Overdue Days')),
                    net_open_balance=_num(gp(row, 'Net Open Balance')),
                    recent_days_late=_num(gp(row, 'Recent Days Late')),
                    baseline_days_late=_num(gp(row, 'Baseline Days Late')),
                    recent_invoices=_num(gp(row, 'Recent Invoices Paid')),
                    baseline_invoices=_num(gp(row, 'Baseline Invoices Paid')),
                    payment_returns=_num(gp(row, 'Payment Returns Count')),
                    first_activity=_date(gp(row, 'First Activity Date')),
                    last_cash_payment=_date(gp(row, 'Last Cash Payment')),
                    key_drivers=str(gp(row, 'Key Drivers') or ''),
                )

        # --- VAT Italy
        ws = sheet('VAT Italy', required=False)
        if ws is not None:
            rows = ws.iter_rows(values_only=True)
            hdr = next(rows)
            ixv = _header_index(hdr, ['Customer Code', 'VAT code'], ws.title)
            for row in rows:
                c = cps.get(_partner(row[ixv['customer code']]))
                vat = str(row[ixv['vat code']] or '').strip()
                if c and re.search(r'\d{5,}', vat) and not c.vat:
                    c.vat = vat
                    grp = row[ixv['group of companies']] if 'group of companies' in ixv else None
                    c.group = '' if str(grp or '').strip() in ('0', 'n/a', 'None') else str(grp or '').strip()

        # --- Limits_Italy
        ws = sheet('Limits_Italy', required=False)
        if ws is not None:
            rows = ws.iter_rows(values_only=True)
            hdr = next(rows)
            ixl = _header_index(hdr, ['Customer'], ws.title)

            def gl(row, col):
                i = ixl.get(_norm(col))
                return row[i] if i is not None and i < len(row) else None

            for row in rows:
                c = cps.get(_partner(gl(row, 'Customer')))
                if not c:
                    continue
                c.blocked_cm = str(gl(row, 'Blocked in Credit Management') or '').strip().upper() == 'X'
                c.block_reason_cm = str(gl(row, 'Reason for Block in Credit Management') or '').strip()
                c.score_validity = _date(gl(row, 'Validity of the score'))
                c.mtm_limit = _num(gl(row, 'MTM Limit'))
                c.overdue_amount = _num(gl(row, 'Overdue Amount'))
                c.receivables = _num(gl(row, 'Receivables'))

        # --- Open Contracts: prima data de contract si marfurile pe partener (foaie mare - doar 3 coloane)
        say('Citesc istoricul contractelor...')
        ws = sheet('Open Contracts', required=False)
        if ws is not None:
            rows = ws.iter_rows(values_only=True)
            hdr = next(rows)
            ixo = _header_index(hdr, ['Partner', 'Document Date'], ws.title)
            ip, idd = ixo['partner'], ixo['document date']
            ic = ixo.get('commodity description')
            for row in rows:
                if ip >= len(row) or idd >= len(row):
                    continue
                c = cps.get(_partner(row[ip]))
                if c is None:
                    continue
                d = _date(row[idd])
                if d and (c.first_contract is None or d < c.first_contract):
                    c.first_contract = d
                com = str(row[ic] or '').strip() if ic is not None and ic < len(row) else ''
                if com:
                    c.commodities[com] = c.commodities.get(com, 0) + 1

        # --- lista optionala de evaluat
        evaluation = []
        ev_name = (cfg.get('portfolio', 'evaluationSheet') or '').strip()
        if ev_name and ev_name.lower() in names:
            ws = wb[names[ev_name.lower()]]
            rows = list(ws.iter_rows(values_only=True))
            if rows:
                ixe = {_norm(h): i for i, h in enumerate(rows[0]) if h}
                col = ixe.get('partner', ixe.get('customer code', ixe.get('customer', 0)))
                for row in rows[1:]:
                    pid = _partner(row[col] if col < len(row) else None)
                    if pid.isdigit():
                        evaluation.append(pid)
                        if pid in cps:
                            cps[pid].selected_for_evaluation = True
                        else:
                            notes.append(f'Partenerul {pid} din foaia "{ev_name}" nu exista in "Monthly Exposure Italy".')
        wb.close()
    except AppError:
        raise
    except Exception as e:
        raise AppError('PORTFOLIO', f'{path.name}: {type(e).__name__}: {e}') from e
    finally:
        try:
            tmp.unlink()
        except OSError:
            pass
    _log.info('Portfolio loaded: %d counterparties, %d to evaluate', len(cps), len(evaluation))
    return Portfolio(path, dt.datetime.now(), cps, [m for _, m in month_cols], [w for _, w in week_cols], evaluation, notes)
