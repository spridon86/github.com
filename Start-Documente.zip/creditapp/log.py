"""Jurnal in data/logs/app.log (rotit, 10 x 2 MB)."""
import logging
import logging.handlers

from . import paths

_configured = False


def setup():
    global _configured
    if _configured:
        return logging.getLogger('creditapp')
    paths.ensure_dirs()
    logger = logging.getLogger('creditapp')
    logger.setLevel(logging.DEBUG)
    fh = logging.handlers.RotatingFileHandler(paths.LOG_DIR / 'app.log', maxBytes=2_000_000, backupCount=10, encoding='utf-8')
    fh.setFormatter(logging.Formatter('%(asctime)s %(levelname)-7s [%(threadName)s] %(name)s: %(message)s'))
    logger.addHandler(fh)
    _configured = True
    return logger


def get(name):
    setup()
    return logging.getLogger(f'creditapp.{name}')
