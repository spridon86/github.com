@echo off
rem Porneste Credit Limits Tool cu Python din Anaconda. Fereastra consolei se inchide singura.
setlocal
set "PY=%LOCALAPPDATA%\anaconda3\pythonw.exe"
if not exist "%PY%" set "PY=%USERPROFILE%\anaconda3\pythonw.exe"
if not exist "%PY%" set "PY=C:\ProgramData\anaconda3\pythonw.exe"
if not exist "%PY%" goto nopython
cd /d "%~dp0"
start "" "%PY%" -m creditapp
exit /b 0

:nopython
echo Nu am gasit Anaconda - pythonw.exe lipseste. Verifica instalarea Anaconda.
pause
exit /b 1
