"""Graficul de expunere: expunerea saptamanala (sau lunara) fata de limita curenta si limita propusa."""
import matplotlib

matplotlib.use('Qt5Agg')
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg  # noqa: E402
from matplotlib.figure import Figure  # noqa: E402
from matplotlib.ticker import FuncFormatter  # noqa: E402

BAR = '#5B8FC7'
BAR_OVER = '#D9534F'
LIMIT = '#222222'
PROPOSED = '#2E7D32'


def _k(v, _pos=None):
    if abs(v) >= 1_000_000:
        return f'{v / 1_000_000:.1f}M'
    if abs(v) >= 1000:
        return f'{v / 1000:.0f}k'
    return f'{v:.0f}'


class ExposureChart(FigureCanvasQTAgg):
    def __init__(self, parent=None):
        self.fig = Figure(figsize=(8, 3), dpi=100, tight_layout=True)
        super().__init__(self.fig)
        self.setParent(parent)
        self.ax = self.fig.add_subplot(111)
        self.clear('Selecteaza un client.')

    def clear(self, text=''):
        self.ax.clear()
        self.ax.set_axis_off()
        if text:
            self.ax.text(0.5, 0.5, text, ha='center', va='center', color='#777777', transform=self.ax.transAxes)
        self.draw_idle()

    def show_counterparty(self, cp, proposed=None):
        self.ax.clear()
        data = cp.weekly if cp.weekly and any(cp.weekly.values()) else cp.monthly
        weekly = data is cp.weekly
        labels = list(data.keys())
        values = [data[k] or 0 for k in labels]
        # fara saptamanile goale de la final
        while labels and not values[-1]:
            labels.pop()
            values.pop()
        while len(labels) > 1 and not values[0]:     # si saptamanile fara expunere de la inceput
            labels.pop(0)
            values.pop(0)
        if not labels:
            self.clear('Fara expunere in "Open Contracts".')
            return
        self.ax.set_axis_on()
        colors = [BAR_OVER if cp.limit and v > cp.limit else BAR for v in values]
        x = range(len(labels))
        self.ax.bar(x, values, color=colors, width=0.8, label='Expunere ' + ('saptamanala' if weekly else 'lunara'))
        if cp.limit:
            self.ax.axhline(cp.limit, color=LIMIT, linewidth=1.4, linestyle='-', label=f'Limita curenta {_k(cp.limit)}')
        if proposed:
            self.ax.axhline(proposed, color=PROPOSED, linewidth=1.6, linestyle='--', label=f'Propus {_k(proposed)}')
        step = max(1, len(labels) // 14)
        self.ax.set_xticks(list(x)[::step])
        self.ax.set_xticklabels(labels[::step], rotation=45, ha='right', fontsize=7)
        self.ax.yaxis.set_major_formatter(FuncFormatter(_k))
        self.ax.tick_params(axis='y', labelsize=8)
        self.ax.grid(axis='y', alpha=0.3)
        for s in ('top', 'right'):
            self.ax.spines[s].set_visible(False)
        # legenda pe fundal alb opac, cu chenar: se citeste si cand trece peste linii / bare
        leg = self.ax.legend(fontsize=7, loc='upper right', frameon=True, fancybox=True, framealpha=0.95,
                             facecolor='#FFFFFF', edgecolor='#9AA7B4', borderpad=0.6)
        leg.set_zorder(10)
        self.ax.set_title(f'{cp.name} - varf {_k(cp.peak_exposure or max(values))} ({cp.peak_week or "-"})', fontsize=9)
        self.draw_idle()
