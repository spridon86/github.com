"""Revizuirea lunara a limitelor (procesul Credit Control):

1. Clientii carora le expira limita luna aceasta (NWCE: Valid till <= sfarsitul lunii curente).
2. Expunerea: cea mai mare expunere din LUNA URMATOARE (Open Contracts ITA - lunar + saptamanal).
3. Activ = are expunere; altfel facturi in ultimii 2 ani (All Invoices). Inactiv -> propus la inactivare.
4. Creditsafe + scorecard -> grade nou. Criteriile fara informatie raman de completat de analist.
5. Limita noua (Open + MTM, USD) vs autoritatea pentru grade-ul nou:
   - in autoritatea analistului -> decizie aprobata automat (NWCE + SAP);
   - peste -> Annual Review generat in folderul clientului, aprobare pe alta cale.
"""
import datetime as dt

from . import limits_book, rules

MONTHS = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC']


def end_of_month(d):
    return rules.end_of_month(d)


def next_month(today=None):
    today = today or dt.date.today()
    return dt.date(today.year + (today.month == 12), today.month % 12 + 1, 1)


def month_label(d):
    return f'{MONTHS[d.month - 1]} {d:%y}'          # 'NOV 26' (antetul din "Monthly Exposure Italy")


def expiring(row, today=None):
    """Randul NWCE are limita care expira pana la sfarsitul lunii curente (sau a expirat deja)."""
    if row is None:
        return False
    st = str(row.get('status') or '').strip().upper()
    if st in ('INACTIVE', 'CBT', 'NO TRADE', 'TSF'):
        return False
    vt = limits_book.from_serial(row.get('valid_till'))
    today = today or dt.date.today()
    if vt is None:
        return st == 'UNDER REVIEW'
    return vt <= end_of_month(today)


def next_month_exposure(cp, today=None):
    """(valoare, eticheta) - expunerea folosita in revizuire: cea mai mare expunere de SAPTAMANA VIITOARE pana la
    ultima saptamana din Open Contracts (saptamana curenta si cele trecute nu conteaza)."""
    from .portfolio import future_peak
    return future_peak(cp, today)


def open_contracts_match(cp, portfolio, country='IT'):
    """Acelasi client in Open Contracts ITA sub alt cod / fara cod in NWCE (dupa VAT sau nume), cu limita sau expunere.
    Intoarce counterparty-ul gasit sau None."""
    if portfolio is None:
        return None
    from .client_folders import name_key
    from .limits_book import vat_key
    from .portfolio import future_peak
    vk, nk = vat_key(cp.vat, country), name_key(cp.name)
    # potrivire larga pe nume (primul cuvant semnificativ): o potrivire in plus doar impiedica inactivarea automata - sigur
    first = next((w for w in nk.split() if len(w) >= 4), '') if nk else ''
    for pc in portfolio.counterparties.values():
        if pc is cp:
            continue
        pk = name_key(pc.name)
        same = (vk and vat_key(pc.vat, country) == vk) or (nk and pk == nk) or \
            (first and next((w for w in pk.split() if len(w) >= 4), '') == first)
        if same and ((pc.limit or 0) > 0 or future_peak(pc)[0] > 0 or any((v or 0) > 0 for v in (pc.monthly or {}).values())):
            return pc
    return None


def activity(cp, exposure, invoices_data, months=24, portfolio=None, country='IT'):
    """(activ True/False/None, explicatie). None = nu se poate decide -> NU se inactiveaza automat.
    Inactiv (False) doar daca: are Customer Code, fara expunere, fara facturi pe 2 ani si nu apare nici in Open Contracts
    dupa VAT / nume (ex. AGRINORD: fara cod in NWCE, dar cu limita si expunere in Open Contracts)."""
    if exposure and exposure > 0:
        return True, 'expunere in saptamanile viitoare'
    from .invoices import recent_activity
    has, why = recent_activity(invoices_data, cp.customer_code, cp.vat, months)
    if has:
        return True, why
    pc = open_contracts_match(cp, portfolio, country)
    if pc is not None:
        code = pc.customer_code or pc.partner
        return True, (f'activ in Open Contracts ca {code} ({pc.name[:30]}, limita {pc.limit or 0:,.0f}) - '
                      f'{"completeaza Customer Code in NWCE" if not cp.customer_code else "verifica codul din NWCE"}').replace(',', '.')
    if not cp.customer_code:
        return None, 'fara Customer Code in NWCE - expunerea / facturile nu se pot verifica: completeaza codul (nu se inactiveaza)'
    if has is None:
        # fisier de facturi lipsa / gol / neactualizat: lipsa facturilor nu dovedeste nimic
        return None, f'fara expunere; {why} - activitatea nu se poate verifica (nu se inactiveaza automat)'
    return False, f'fara expunere; {why}'


def manual_needed(ev):
    """Criteriile din Scale&Subjective care nu s-au putut decide din date - le completeaza analistul."""
    inp = ev.inputs or {}
    done = (ev.review or {}).get('manual', {})
    out = []
    pay = inp.get('payment') or {}
    if ('Fara istoric' in pay.get('why', '') or 'insuficiente' in pay.get('why', '')) and not pay.get('manual') and 'payment' not in done:
        out.append('payment')
    exp = inp.get('experience') or {}
    if 'Nicio urma' in exp.get('why', '') and not exp.get('manual') and 'experience' not in done:
        out.append('experience')
    return out


def new_limits(vals, exposure, cfg, usd_rate):
    """(open nou in moneda locala, open nou KUSD, MTM KUSD) - limita Open creste doar daca expunerea din luna urmatoare o depaseste."""
    cur_open_local = float(vals.get('open_kloc') or 0) * 1000
    need = float(exposure or 0)
    new_open = rules.round_up(need, cfg) if need > cur_open_local else cur_open_local
    rate = usd_rate or 0
    new_open_kusd = rules.k_usd(new_open, rate, cfg.get('limitsBook', 'kusdRounding')) if rate else float(vals.get('open_kusd') or 0)
    return new_open, new_open_kusd, default_mtm_kusd(float(vals.get('mtm_kusd') or 0), new_open_kusd, cfg)


def default_mtm_kusd(cur_mtm_kusd, new_open_kusd, cfg):
    """MTM nou: cel actual; daca MTM actual = 0 -> 40% din Open limit nou (USD), rotunjit la 10 KUSD (review.mtmPctIfZero)."""
    if cur_mtm_kusd or not new_open_kusd:
        return cur_mtm_kusd
    pct = float(cfg.get('review', 'mtmPctIfZero', default=0.4) or 0)
    step = int(cfg.get('limitsBook', 'kusdRounding', default=10) or 10)
    return float(round(new_open_kusd * pct / step) * step)


def needs_scorecard(vals, exposure, cfg, usd_rate):
    """Scorecard doar daca limita noua Open + MTM este de cel putin review.scorecardMinUsd (implicit 350.000 USD).
    Intoarce (da/nu, total USD)."""
    _o, open_kusd, mtm_kusd = new_limits(vals, exposure, cfg, usd_rate)
    total = (open_kusd + mtm_kusd) * 1000
    return total >= float(cfg.get('review', 'scorecardMinUsd', default=350000) or 0), total


def plan(ev, cp, group_rows, cfg, usd_rate, exposure, today=None):
    """Limita noua + verificarea autoritatii. Intoarce dict pentru ev.review."""
    vals = (ev.nwce_row or {}).get('values') or {}
    cur_kloc = float(vals.get('open_kloc') or 0)
    cur_open_local = cur_kloc * 1000
    mtm_kusd = float(vals.get('mtm_kusd') or 0)
    cur_total_kusd = float(vals.get('total_kusd') or 0)
    other_kusd = max(0.0, cur_total_kusd - float(vals.get('open_kusd') or 0) - mtm_kusd)
    need = float(exposure or 0)
    if need > cur_open_local:
        new_open = rules.round_up(need, cfg)
        why = f'varful de expunere de saptamana viitoare ({rules._m(need)}) depaseste limita actuala ({rules._m(cur_open_local)})'
    else:
        new_open = cur_open_local
        why = 'limita actuala acopera varful de expunere de saptamana viitoare - se reinnoieste'
    rate = usd_rate or 0
    new_open_kusd = rules.k_usd(new_open, rate, cfg.get('limitsBook', 'kusdRounding')) if rate else float(vals.get('open_kusd') or 0)
    if not mtm_kusd:
        mtm_kusd = default_mtm_kusd(0.0, new_open_kusd, cfg)
        if mtm_kusd:
            why += f'; MTM actual 0 → MTM nou = 40% din Open ({rules._m(mtm_kusd * 1000)} USD)'
    total_usd = (new_open_kusd + mtm_kusd + other_kusd) * 1000
    others_usd = sum(g.kusd for g in group_rows if g.cp is not cp) * 1000 if group_rows else 0.0
    grade, grade_src = ev.grade, 'scorecard'
    if grade is None:       # fara bilant in Creditsafe -> scorecardul nu se poate face: se merge mai departe cu gradul din NWCE
        grade, grade_src = rules.grade_number(vals.get('grading')), 'nwce'
    auth = rules.approval_authority(grade, total_usd + others_usd, cfg) if grade else None
    equity_usd = _equity_usd(ev, rate)
    analyst = cfg.get('approval', 'analystRow')
    if auth is None:
        route = 'manual'
    elif auth.no_trade:
        route = 'escalate'
    else:
        route = 'auto' if auth.name == analyst else 'escalate'
    return {
        'exposure': need, 'new_open_local': new_open, 'new_open_kusd': new_open_kusd, 'mtm_kusd': mtm_kusd,
        'total_usd': total_usd, 'group_total_usd': total_usd + others_usd, 'limit_why': why,
        'grade_used': grade, 'grade_source': grade_src if grade else '',
        'authority': auth.name if auth else '', 'authority_text': auth.text() if auth else 'fara grade (nici scorecard, nici NWCE)',
        'nwce_level': auth.nwce_level if auth else '', 'equity_usd': equity_usd,
        'equity_scenario': bool(equity_usd is not None and total_usd + others_usd > equity_usd),
        'route': route, 'usd_rate': rate,
    }


def _equity_usd(ev, rate):
    """Capitalurile proprii ale clientului in USD: din scorecard (Summary "Equity", deja in USD) sau din Creditsafe."""
    import re
    txt = str((ev.scorecard or {}).get('equity_usd') or '').strip().replace(',', '')     # text Excel: "13,611,765"
    m = re.fullmatch(r'\((\d+(?:\.\d+)?)\)|(-?\d+(?:\.\d+)?)', txt)
    if m:
        return -float(m.group(1)) if m.group(1) else float(m.group(2))
    cs = ev.cs or {}
    if cs.get('equity') is not None and rate and (cs.get('currency') or 'EUR') == (ev.currency or 'EUR'):
        return float(cs['equity']) * rate
    return None


def finalize(ev, cfg, usd_rate, others_usd=0.0, today=None):
    """Next: limitele finale = cele schimbate de analist (ev.review['edit']: open, mtm_usd, valid, grade) sau propunerea.
    Intoarce (decizia, autoritatea, review actualizat). Decizia se aplica doar daca autoritatea e a analistului."""
    today = today or dt.date.today()
    rv = dict(ev.review or {})
    edit = rv.get('edit') or {}
    vals = (ev.nwce_row or {}).get('values') or {}
    rate = usd_rate or rv.get('usd_rate') or 0
    open_local = edit.get('open') if edit.get('open') is not None else rv.get('new_open_local')
    if open_local is None:
        open_local = float(vals.get('open_kloc') or 0) * 1000
    mtm_kusd = (float(edit['mtm_usd']) / 1000) if edit.get('mtm_usd') is not None else float(rv.get('mtm_kusd') or vals.get('mtm_kusd') or 0)
    grade = rules.grade_number(edit.get('grade')) or ev.grade or rv.get('grade_used') or rules.grade_number(vals.get('grading'))
    open_kusd = rules.k_usd(open_local, rate, cfg.get('limitsBook', 'kusdRounding')) if rate else float(rv.get('new_open_kusd') or vals.get('open_kusd') or 0)
    other_kusd = max(0.0, float(vals.get('total_kusd') or 0) - float(vals.get('open_kusd') or 0) - float(vals.get('mtm_kusd') or 0))
    total_usd = (open_kusd + mtm_kusd + other_kusd) * 1000
    auth = rules.approval_authority(grade, total_usd + (others_usd or 0), cfg) if grade else None
    equity_usd = _equity_usd(ev, rate)
    rv.update({
        'new_open_local': open_local, 'new_open_kusd': open_kusd, 'mtm_kusd': mtm_kusd, 'total_usd': total_usd,
        'group_total_usd': total_usd + (others_usd or 0), 'grade_used': grade, 'usd_rate': rate,
        'authority': auth.name if auth else '', 'authority_text': auth.text() if auth else 'fara grade',
        'nwce_level': auth.nwce_level if auth else '', 'equity_usd': equity_usd,
        'equity_scenario': bool(equity_usd is not None and total_usd + (others_usd or 0) > equity_usd),
    })
    valid = edit.get('valid') or rules.valid_till(today, int(cfg.get('limitsBook', 'validityMonths'))).isoformat()
    # fara scorecard si fara grade schimbat manual: in NWCE ramane textul existent ("Intuitive 9"); in SAP merge doar cifra
    grading = grade
    nwce_txt = vals.get('grading')
    if ev.grade is None and not edit.get('grade') and isinstance(nwce_txt, str) and rules.grade_number(nwce_txt) == grade:
        grading = nwce_txt.strip()
    decision = {
        'limit_eur': open_local, 'currency': ev.currency, 'eur_usd': rate, 'open_kloc': rules.k_local(open_local),
        'open_kusd': open_kusd, 'mtm_kusd': mtm_kusd, 'payment_term': vals.get('payment_term') or '',
        'approval_level': rv['nwce_level'] or vals.get('approval_level') or '',     # nu se goleste celula din NWCE
        'grading': grading, 'approved_on': today.isoformat(), 'valid_till': valid,
        'comments': '', 'fields': ['open_kloc', 'open_kusd', 'mtm_kusd', 'grading', 'approval_level', 'approved_on', 'valid_till', 'analyst'],
        'sheet_row': (ev.nwce_row or {}).get('sheet_row') or 0, 'new_row': False,
        'approved_at': dt.datetime.now().isoformat(timespec='seconds'), 'auto': not edit,
        'equity_scenario': rv['equity_scenario'],
    }
    return decision, auth, rv


def external_decision(ev, cfg, usd_rate, others_usd, approved_by, approved_on, write_sap, comment='', today=None):
    """Decizie peste autoritatea analistului, aprobata pe alt canal (manager / EMEA / global): aceleasi limite ca la Next
    (propunerea + ce a schimbat analistul in celule), cu cine a aprobat si cand. write_sap=False -> decizia se scrie doar in
    NWCE; in SAP nu se transcrie (acolo ar porni din nou workflow-ul de aprobare)."""
    dec, auth, rv = finalize(ev, cfg, usd_rate, others_usd, today)
    dec.update(approved_on=approved_on.isoformat(), auto=False, sap_skip=not write_sap,
               external_approval={'by': approved_by, 'on': approved_on.isoformat()}, authority=auth.name if auth else '')
    if comment:
        dec['comments'] = comment
        dec['fields'] = list(dec['fields']) + ['comments']
    return dec, auth, rv


def auto_decision(ev, rv, cfg, today=None):
    """Decizia aprobata automat (in autoritatea analistului): limita noua, grade nou, valabilitate 12 luni."""
    today = today or dt.date.today()
    vals = (ev.nwce_row or {}).get('values') or {}
    kloc = rules.k_local(rv['new_open_local'])
    return {
        'limit_eur': rv['new_open_local'], 'currency': ev.currency, 'eur_usd': rv['usd_rate'], 'open_kloc': kloc,
        'open_kusd': rv['new_open_kusd'], 'mtm_kusd': rv['mtm_kusd'], 'payment_term': vals.get('payment_term') or '',
        'approval_level': rv['nwce_level'], 'grading': rv.get('grade_used') or ev.grade,
        'approved_on': today.isoformat(),
        'valid_till': rules.valid_till(today, int(cfg.get('limitsBook', 'validityMonths'))).isoformat(),
        'comments': '', 'fields': ['open_kloc', 'open_kusd', 'mtm_kusd', 'grading', 'approval_level', 'approved_on', 'valid_till', 'analyst'],
        'sheet_row': (ev.nwce_row or {}).get('sheet_row') or 0, 'new_row': False,
        'approved_at': dt.datetime.now().isoformat(timespec='seconds'), 'auto': True,
        'equity_scenario': rv.get('equity_scenario'),
    }
