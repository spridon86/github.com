"""Editorii din tabel ("Proces initiat"): intrarea si iesirea din celula fara schimbare nu scrie nimic
(inainte: grade 6 / Open 0 / prima optiune din lista ajungeau in decizie -> NWCE / SAP)."""
import os

import pytest

os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
QtWidgets = pytest.importorskip('PyQt5.QtWidgets')
from PyQt5.QtCore import QDate, Qt  # noqa: E402

from creditapp.ui import widgets  # noqa: E402


@pytest.fixture(scope='module')
def app():
    return QtWidgets.QApplication.instance() or QtWidgets.QApplication([])


class Model:
    def __init__(self, value):
        self.value, self.calls = value, []

    def setData(self, index, value, role):
        self.calls.append(value)
        return True


class Index:
    def __init__(self, value):
        self.v = value

    def data(self, role=Qt.DisplayRole):
        return self.v if role == Qt.EditRole else ''


def _roundtrip(delegate, value, change=None):
    ed = delegate.createEditor(None, None, Index(value))
    delegate.setEditorData(ed, Index(value))
    if change:
        change(ed)
    m = Model(value)
    delegate.setModelData(ed, m, Index(value))
    return m.calls


def test_grade_without_value_is_not_set_to_6(app):
    d = widgets.GradeDelegate()
    assert _roundtrip(d, 0) == []                                   # fara grade: nimic scris
    assert _roundtrip(d, 7) == []                                   # neschimbat
    assert _roundtrip(d, 0, lambda e: e.setValue(6)) == [6]         # ales explicit


def test_money_untouched_is_not_written(app):
    d = widgets.MoneyDelegate()
    assert _roundtrip(d, 0.0) == [] and _roundtrip(d, 190_000.0) == []
    assert _roundtrip(d, 190_000.0, lambda e: e.setValue(200_000)) == [200_000]


def test_combo_without_value_does_not_pick_first_option(app):
    d = widgets.ComboDelegate([('A', 'A - bun'), ('C', 'C - fara date')])
    assert _roundtrip(d, '') == []
    assert _roundtrip(d, 'C') == []
    assert _roundtrip(d, '', lambda e: e.setCurrentIndex(1)) == ['C']


def test_valid_till_cannot_be_in_the_past(app):
    d = widgets.DateDelegate()
    ed = d.createEditor(None, None, Index(None))
    ed.setDate(QDate(2020, 1, 1))
    assert ed.date() > QDate.currentDate()
    assert _roundtrip(d, None) == []                                # fara data: nimic scris
