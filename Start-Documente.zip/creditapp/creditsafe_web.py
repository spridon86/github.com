"""Creditsafe prin website (app.creditsafe.com) cu userul si parola de pe site - fara cont API.

Site-ul e o aplicatie web care, dupa login (mylogin.creditsafe.com), foloseste in spate:
  cautare      GET https://api.app.creditsafe.com/v1/search/companies?country=IT&vatNo=...
  taxare?      GET https://api.app.creditsafe.com/ubo/users/<user>/services/1002/check?amount=1&suppliedRef=<id>
  contoare     GET https://api.app.creditsafe.com/v1/UserServices?userId=<user>&country=US&locale=en
  raport       GET https://upp-connect.creditsafe.com/v1/companies/<id>?includeIndicators=true&template=upp&language=en
                   (acelasi format Global Financials ca API-ul Connect -> scorecardul nu se schimba)
  PDF          generat de browser din pagina firmei (butonul de descarcare)

Tool-ul ruleaza un Edge separat (sesiune curata, invizibila) intr-un fir dedicat:
- login automat cu userul / parola din Windows Credential Manager;
- tokenul site-ului e folosit pentru cautare / contoare (gratuite);
- raportul se deschide EXACT ca manual: pagina firmei in Edge (o singura comanda de raport),
  datele se iau din raspunsul paginii, apoi se apasa descarcarea PDF.
Daca login-ul cere ceva neasteptat (ex. 2FA), fereastra Edge devine vizibila si analistul il termina.
"""
import base64
import datetime as dt
import json
import queue
import re
import threading
import time
from pathlib import Path

from . import log, paths
from .creditsafe import CreditsafeClient
from .errors import AppError

_log = log.get('creditsafe_web')

APP = 'https://app.creditsafe.com'
API = 'https://api.app.creditsafe.com'
UPP = 'https://upp-connect.creditsafe.com'
KEYRING_SERVICE = 'CreditLimitsApp/creditsafe-web'
DEBUG_DIR = paths.LOG_DIR / 'creditsafe_web'
REPORT_SERVICE = 1001          # "Company Credit Report" - contorul de rapoarte din contract
CHECK_SERVICES = (1002,)       # verificarea facuta de site la deschiderea raportului


# ---------------------------------------------------------------- credentiale
def get_credentials(cfg):
    import keyring
    user = (cfg.get('creditsafeWeb', 'username') or '').strip()
    pwd = keyring.get_password(KEYRING_SERVICE, user) if user else None
    if not (user and pwd):
        raise AppError('AUTH_MISSING', f'No Creditsafe website password saved for {user or "(no user)"}.')
    return user, pwd


def save_credentials(cfg, user, password):
    import keyring
    keyring.set_password(KEYRING_SERVICE, user.strip(), password)
    cfg.set(user.strip(), 'creditsafeWeb', 'username')


def _jwt_claims(token):
    try:
        part = token.split('.')[1]
        return json.loads(base64.urlsafe_b64decode(part + '=' * (-len(part) % 4)))
    except Exception:
        return {}


# ---------------------------------------------------------------- browserul (fir dedicat)
class _Browser:
    """Playwright nu e thread-safe: toate operatiile cu browserul ruleaza intr-un singur fir, prin coada."""

    def __init__(self, cfg):
        self.cfg = cfg
        self.q = queue.Queue()
        self.thread = None
        self._start_lock = threading.Lock()   # rapoartele se cer in paralel: un singur fir "edge", nu cate unul pe cerere
        self.pw = self.ctx = None
        self.headless = bool(cfg.get('creditsafeWeb', 'headless', default=True))
        self.token = None
        self.token_exp = 0.0
        self.user_id = None

    def call(self, fn, *args, timeout=600):
        with self._start_lock:
            if self.thread is None or not self.thread.is_alive():
                self.thread = threading.Thread(target=self._loop, name='edge', daemon=True)
                self.thread.start()
        box = {}
        done = threading.Event()
        self.q.put((fn, args, box, done))
        if not done.wait(timeout):
            raise AppError('NETWORK', 'Creditsafe website did not respond in time.')
        if 'error' in box:
            raise box['error']
        return box.get('result')

    def _loop(self):
        while True:
            item = self.q.get()
            if item is None:
                break
            fn, args, box, done = item
            try:
                box['result'] = fn(*args)
            except Exception as e:
                box['error'] = e
            finally:
                done.set()
        self._close()

    def stop(self):
        if self.thread and self.thread.is_alive():
            self.q.put(None)
            self.thread.join(15)

    # --- in firul browserului
    def _ensure_ctx(self, headless=None):
        headless = self.headless if headless is None else headless
        if self.ctx is not None and getattr(self, '_ctx_headless', None) == headless:
            return self.ctx
        self._close()
        from playwright.sync_api import sync_playwright
        # sesiune Edge curata la fiecare pornire (login-ul Creditsafe oricum nu se pastreaza intre sesiuni);
        # un profil permanent se poate bloca daca un Edge ramas deschis il foloseste
        self.pw = sync_playwright().start()
        try:
            self.browser_obj = self.pw.chromium.launch(channel='msedge', headless=headless,
                                                       args=[] if headless else ['--start-maximized'])
            self.ctx = self.browser_obj.new_context(accept_downloads=True,
                                                    viewport=None if not headless else {'width': 1600, 'height': 1000},
                                                    no_viewport=not headless)
        except Exception as e:
            self._close()
            first = str(e).strip().splitlines()[0] if str(e).strip() else type(e).__name__
            raise AppError('NETWORK', f'Microsoft Edge could not be started for Creditsafe: {first[:200]}')
        self._ctx_headless = headless
        self.ctx.on('request', self._sniff)
        return self.ctx

    def _sniff(self, req):
        h = req.headers.get('authorization', '')
        if h.startswith('Bearer ') and re.search(r'(api\.app|upp-connect)\.creditsafe\.com', req.url):
            tok = h[7:]
            if tok != self.token:
                self.token = tok
                self.token_exp = float(_jwt_claims(tok).get('exp') or (time.time() + 1800))
        m = re.search(r'/users/(\d{5,})', req.url)
        if m:
            self.user_id = m.group(1)

    def _close(self):
        for obj, meth in ((self.ctx, 'close'), (getattr(self, 'browser_obj', None), 'close'), (self.pw, 'stop')):
            try:
                if obj is not None:
                    getattr(obj, meth)()
            except Exception:
                pass
        self.ctx = self.pw = self.browser_obj = None

    def _page(self):
        ctx = self._ensure_ctx()
        return ctx.pages[0] if ctx.pages else ctx.new_page()

    def _debug(self, page, tag):
        try:
            DEBUG_DIR.mkdir(parents=True, exist_ok=True)
            stamp = dt.datetime.now().strftime('%Y%m%d_%H%M%S')
            page.screenshot(path=str(DEBUG_DIR / f'{stamp}_{tag}.png'), full_page=False)
            html = page.content()
            html = re.sub(r'value="[^"]{20,}"', 'value="<x>"', html)
            (DEBUG_DIR / f'{stamp}_{tag}.html').write_text(html, encoding='utf-8')
        except Exception:
            pass

    def login(self, force=False):
        """Token valid (cel putin 5 minute ramase). Login automat; daca nu reuseste, Edge devine vizibil."""
        if not force and self.token and self.token_exp - time.time() > 300:
            return self.token
        self.token = None
        page = self._page()
        page.goto(APP + '/', timeout=90000)
        if self._wait_token(page, 15):           # sesiunea din profil e inca valida
            return self.token
        user, pwd = get_credentials(self.cfg)
        try:
            self._fill_login(page, user, pwd)
            if self._wait_token(page, 45):
                _log.info('Creditsafe website login OK (user id %s)', self.user_id)
                return self.token
        except AppError:
            raise
        except Exception as e:
            _log.warning('Automatic login did not finish: %s', e)
        self._debug(page, 'login')
        if self._ctx_headless:
            # pas neasteptat (2FA, termeni noi...): Edge vizibil, analistul termina login-ul
            self._ensure_ctx(headless=False)
            page = self._page()
            page.goto(APP + '/', timeout=90000)
            try:
                self._fill_login(page, user, pwd)
            except Exception:
                pass
            timeout = int(self.cfg.get('creditsafeWeb', 'loginTimeout', default=180))
            if self._wait_token(page, timeout):
                return self.token
        raise AppError('AUTH', 'Creditsafe website login did not complete.', f'Last page: {page.url[:100]}')

    def _fill_login(self, page, user, pwd):
        page.wait_for_load_state('domcontentloaded')
        for sel in ('#onetrust-reject-all-handler', '#onetrust-accept-btn-handler'):
            try:
                if page.locator(sel).is_visible(timeout=1500):
                    page.locator(sel).click()
                    break
            except Exception:
                pass
        if 'mylogin.creditsafe.com' not in page.url:
            return
        u = page.locator('#username')
        if u.count() and u.is_visible():
            u.fill(user)
            page.locator('#ContinueButton').click()
        pw = page.locator('input[type="password"]')
        pw.first.wait_for(state='visible', timeout=30000)
        pw.first.fill(pwd)
        submit = page.locator('button[type="submit"]:visible, input[type="submit"]:visible')
        if submit.count():
            submit.first.click()
        else:
            pw.first.press('Enter')
        page.wait_for_timeout(1500)
        err = page.locator('.validation-summary-errors, .field-validation-error, .alert-danger, .text-danger:visible')
        try:
            if 'mylogin' in page.url and err.count() and err.first.is_visible():
                txt = err.first.inner_text().strip()
                if txt:
                    raise AppError('AUTH', f'Creditsafe website rejected the login: {txt}')
        except AppError:
            raise
        except Exception:
            pass

    def _wait_token(self, page, seconds):
        t0 = time.time()
        while time.time() - t0 < seconds:
            if self.token and self.token_exp - time.time() > 60:
                return True
            try:
                page.wait_for_timeout(500)
            except Exception:
                return False
        return False

    def open_report(self, connect_id, json_path, pdf_path):
        """Deschide pagina firmei (ca manual), salveaza raportul JSON din raspunsul paginii si PDF-ul."""
        self.login()
        page = self._ensure_ctx().new_page()
        holder = {}

        def on_resp(r):
            if r.url.startswith(f'{UPP}/v1/companies/{connect_id}?') and 'template=' in r.url and r.request.method == 'GET':
                try:
                    holder['status'] = r.status
                    holder['body'] = r.text()
                except Exception as e:
                    holder['err'] = str(e)
        page.on('response', on_resp)
        try:
            page.goto(f'{APP}/companies/{connect_id}', timeout=90000)
            t0 = time.time()
            while 'body' not in holder and time.time() - t0 < 90:
                page.wait_for_timeout(300)
            if 'body' not in holder:
                self._debug(page, 'report')
                raise AppError('REPORT_UNAVAILABLE', f'The Creditsafe report page for {connect_id} did not load.')
            if holder['status'] >= 400:
                body = holder['body'][:400]
                code = 'CREDITS' if re.search(r'credit|exceed|insufficient', body, re.I) else ('FORBIDDEN' if holder['status'] == 403 else 'REPORT_UNAVAILABLE')
                raise AppError(code, f'Creditsafe report {connect_id}: HTTP {holder["status"]}', body)
            data = json.loads(holder['body'])
            if 'report' not in data:
                raise AppError('REPORT_UNAVAILABLE', f'No report in the Creditsafe answer for {connect_id}.')
            tmp = Path(json_path).with_suffix('.tmp')
            tmp.write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
            tmp.replace(json_path)
            if pdf_path:
                if self.cfg.get("creditsafeWeb", "pdfButtonSelector"):
                    self._download_pdf_custom(page, pdf_path)
                else:
                    self._download_pdf(page, pdf_path)
            return True
        finally:
            try:
                page.close()
            except Exception:
                pass

    def _download_pdf(self, page, pdf_path):
        """PDF ca din site, pas cu pas, doar pe elementele identificate in codul site-ului (data-testid):
        More Actions -> Generate PDF -> optiunea Download -> butonul Download PDF din formular.
        Orice element lipsa = stop (captura in data/logs/creditsafe_web), fara alte click-uri."""
        steps = [
            ('More Actions', '[data-testid="moreActionsButton"]', False),
            ('Generate PDF', '[data-testid="createPdfButton"]:not(form [data-testid="createPdfButton"])', False),
            ('optiunea Download', '[data-testid="download-pdf-button"]', True),
        ]
        submit = '[data-testid="printPdfPopup"] button[type="submit"][data-testid="createPdfButton"]'   # "Download PDF"
        page.wait_for_timeout(1500)
        try:
            header_btn = page.locator('[data-testid="createPdfButton"]').first
            if header_btn.is_visible():
                steps = steps[1:]          # in unele tari butonul e direct in antet
            for label, sel, optional in steps:
                loc = page.locator(sel).first
                try:
                    loc.wait_for(state='visible', timeout=15000)
                except Exception:
                    if optional:
                        continue
                    raise AppError('REPORT_UNAVAILABLE', f'Creditsafe page: "{label}" not found.')
                loc.click()
                page.wait_for_timeout(700)
            btn = page.locator(submit).first
            btn.wait_for(state='visible', timeout=20000)
            with page.expect_download(timeout=180000) as dl:     # PDF-ul se genereaza in browser
                btn.click()
            self._save_download(dl.value, pdf_path)
        except AppError:
            self._debug(page, 'pdf')
            raise
        except Exception as e:
            self._debug(page, 'pdf')
            raise AppError('REPORT_UNAVAILABLE', 'The Creditsafe PDF could not be generated.', f'{e} - see data\\logs\\creditsafe_web')

    def _download_pdf_custom(self, page, pdf_path):
        """Varianta configurabila (doar daca site-ul se schimba): creditsafeWeb.pdfButtonSelector / pdfMenuSelector."""
        cfgsel = self.cfg.get('creditsafeWeb', 'pdfButtonSelector') or ''
        page.wait_for_timeout(1500)
        # DOAR butoane identificate exact: pagina are si butoane care costa / creeaza ceva
        # (Visura, Export to KYC Protect, Additional Information) - nicio cautare generica.
        candidates = [page.locator(cfgsel)] if cfgsel else []
        if not candidates:
            raise AppError('REPORT_UNAVAILABLE', 'PDF button not configured (creditsafeWeb.pdfButtonSelector).')
        menu_sel = self.cfg.get('creditsafeWeb', 'pdfMenuSelector') or ''
        last = None
        for loc in candidates:
            try:
                if not loc.count():
                    continue
                btn = loc.first
                if not btn.is_visible():
                    continue
                try:
                    with page.expect_download(timeout=8000) as dl:
                        btn.click()
                    self._save_download(dl.value, pdf_path)
                    return
                except Exception as e:
                    last = e
                # meniu / dialog cu optiuni: alege PDF / Download
                opts = [page.locator(menu_sel)] if menu_sel else []
                opts += [page.get_by_role('menuitem', name=re.compile(r'pdf', re.I)),
                         page.get_by_role('option', name=re.compile(r'pdf', re.I)),
                         page.get_by_text(re.compile(r'^\s*(pdf|download pdf|full report)\s*$', re.I)),
                         page.get_by_role('button', name=re.compile(r'^\s*(download|confirm|ok)\s*$', re.I))]
                for o in opts:
                    if o.count() and o.first.is_visible():
                        with page.expect_download(timeout=60000) as dl:
                            o.first.click()
                        self._save_download(dl.value, pdf_path)
                        return
            except Exception as e:
                last = e
        self._debug(page, 'pdf')
        raise AppError('REPORT_UNAVAILABLE', 'The PDF download button was not found on the Creditsafe page.',
                       f'{last or ""} - see data\\logs\\creditsafe_web')

    @staticmethod
    def _save_download(download, pdf_path):
        tmp = Path(pdf_path).with_suffix('.pdftmp')
        download.save_as(str(tmp))
        if not tmp.read_bytes()[:4] == b'%PDF':
            tmp.unlink()
            raise AppError('REPORT_UNAVAILABLE', 'The downloaded file is not a PDF.')
        tmp.replace(pdf_path)


# ---------------------------------------------------------------- clientul (aceeasi interfata ca CreditsafeClient)
class CreditsafeWebClient(CreditsafeClient):
    mode = 'web'

    def __init__(self, cfg, http=None):
        super().__init__(cfg, http)
        self.browser = _Browser(cfg)

    def close(self):
        self.browser.stop()

    def token(self, force=False):
        return self.browser.call(self.browser.login, force, timeout=int(self.cfg.get('creditsafeWeb', 'loginTimeout', default=180)) + 120)

    def test_login(self):
        self.token(force=True)
        return True

    def _api(self, url, params=None, attempts=3):
        for attempt in range(1, attempts + 1):
            headers = {'Authorization': f'Bearer {self.token()}', 'Content-Type': 'application/json', 'Accept': 'application/json'}
            try:
                r = self.http.request('GET', url, params=params, headers=headers, timeout=60)
            except OSError as e:
                if attempt < attempts:
                    time.sleep(2 * attempt)
                    continue
                raise AppError('NETWORK', f'Creditsafe website could not be reached: {e}')
            if r.status == 401 and attempt < attempts:
                self.token(force=True)
                continue
            if r.status in (429,) or r.status >= 500:
                if attempt < attempts:
                    time.sleep(3 * attempt)
                    continue
            if not r.ok:
                raise self._http_error(r, url.split('.com', 1)[-1].split('?')[0])
            return r.json()
        raise AppError('UNKNOWN', f'Creditsafe website: no answer for {url}')

    def _user_id(self):
        self.token()
        if not self.browser.user_id:
            claims = _jwt_claims(self.browser.token)
            uid = claims.get('upp_user_id') or claims.get('userId') or claims.get('sub')
            if uid and str(uid).isdigit():
                self.browser.user_id = str(uid)
        if not self.browser.user_id:
            raise AppError('AUTH', 'Creditsafe user id unknown after login.')
        return self.browser.user_id

    # --- cautare (gratuita)
    def search(self, country, vat=None, reg_no=None, name=None, page_size=10):
        from .creditsafe import vat_without_prefix
        params = {'_limit': page_size, '_page': 1, 'country': country}
        if vat:
            params['vatNo'] = vat_without_prefix(vat, country)
        if reg_no:
            params['regNo'] = reg_no
        if name:
            params['name'] = name
        try:
            data = self._api(f'{API}/v1/search/companies', params)
        except AppError as e:
            if e.code == 'NOT_FOUND':
                return []
            raise
        out = []
        for c in data.get('content') or []:
            out.append({'id': c.get('id'), 'name': c.get('name'), 'regNo': c.get('regNumber'), 'safeNo': c.get('safeNumber'),
                        'vatNo': c.get('vatNos') or [], 'status': c.get('status'), 'address': c.get('address') or {},
                        'dateOfLatestAccounts': c.get('dateOfLatestAccounts'), 'country': c.get('country')})
        return out

    # --- contoare de rapoarte (din contractul vizibil pe site)
    def credits(self, country):
        uid = self._user_id()
        rows = self._api(f'{API}/v1/UserServices', {'userId': uid, 'country': 'US', 'locale': 'en', 'includeAutoCreate': 'true'})
        now = dt.datetime.now()
        paid = used = 0
        expire = None
        found = unlimited = False
        for r in rows or []:
            if r.get('serviceId') != REPORT_SERVICE or (r.get('country') or '').upper() != country.upper():
                continue
            try:
                exp = dt.datetime.fromisoformat(str(r.get('expireDate'))[:19])
            except ValueError:
                exp = None
            if exp and exp < now:
                continue
            found = True
            unlimited = unlimited or bool(r.get('isUnlimited'))
            paid += int(r.get('paid') or 0)
            used += int(r.get('used') or 0)
            expire = exp if expire is None or (exp and exp < expire) else expire
        if not found:
            return None
        return {'left': 999999 if unlimited else paid - used, 'paid': paid, 'used': used, 'expires': expire, 'unlimited': unlimited}

    def will_charge(self, connect_id):
        """True daca deschiderea raportului consuma un credit (verificarea facuta si de site). None = necunoscut."""
        try:
            uid = self._user_id()
            states = []
            for sid in CHECK_SERVICES:
                r = self._api(f'{API}/ubo/users/{uid}/services/{sid}/check', {'amount': 1, 'suppliedRef': connect_id})
                states.append(str(r.get('serviceState') or ''))
            # "ServiceValidAndRequireCharge" apare si pentru rapoarte deschise recent (verificat 16.10.2026),
            # deci nu dovedeste o taxare noua; doar un raspuns explicit fara taxare inseamna "gratuit".
            if states and all('NoCharge' in s or s == 'ServiceValid' for s in states):
                return False
            if any(s and not s.startswith('ServiceValid') for s in states):
                raise AppError('FORBIDDEN', f'Creditsafe service not available for {connect_id}: {", ".join(states)}')
            return None
        except Exception as e:
            _log.warning('Charge check failed for %s: %s', connect_id, e)
            return None

    # --- raport: pagina firmei in Edge (JSON + PDF)
    def fetch_report(self, connect_id, with_pdf=True, use_cache=True):
        c = self.cached(connect_id) if use_cache else None
        if c and (c['pdf_path'] or not with_pdf):
            return self._load(c, True)
        d = self.cache_dir(connect_id)
        d.mkdir(parents=True, exist_ok=True)
        stamp = dt.datetime.now().replace(microsecond=0)
        json_path = d / f'{stamp:%Y%m%d_%H%M%S}.json'
        pdf_path = json_path.with_suffix('.pdf') if with_pdf else None
        self.browser.call(self.browser.open_report, connect_id, json_path, pdf_path, timeout=400)
        _log.info('Report %s opened on the website', connect_id)
        return self._load({'json_path': json_path, 'pdf_path': pdf_path if pdf_path and pdf_path.exists() else None, 'fetched': stamp}, False)


def make_client(cfg):
    """Clientul Creditsafe ales in Setari: 'web' (user + parola de pe site) sau 'api' (cont Connect API)."""
    if (cfg.get('creditsafe', 'mode') or 'web') == 'api':
        return CreditsafeClient(cfg)
    return CreditsafeWebClient(cfg)


def has_credentials(cfg):
    try:
        if (cfg.get('creditsafe', 'mode') or 'web') == 'api':
            from .creditsafe import get_credentials as api_creds
            api_creds(cfg)
        else:
            get_credentials(cfg)
        return True
    except Exception:
        return False

