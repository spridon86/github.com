import datetime as dt

from creditapp import limits_book as lb


def snap():
    rows = [
        lb.NwceRow(10, {'company_code': '6675 - Italy', 'customer_code': 76021671.0, 'bp_code': 76014759.0, 'name': 'MIRA SUD S.R.L.', 'vat': 'IT01491571210', 'open_kloc': 800.0, 'valid_till': 46477.0}),
        lb.NwceRow(11, {'company_code': '6675 - CBT', 'customer_code': 76021671.0, 'name': 'MIRA SUD S.R.L.', 'vat': 'IT01491571210'}),
        lb.NwceRow(12, {'company_code': '6501 - Mannheim', 'customer_code': 76033479.0, 'name': 'MONDELEZ', 'vat': 'DE123'}),
        lb.NwceRow(13, {'company_code': '6675 - Italy', 'customer_code': 76055555.0, 'name': 'DUP', 'vat': ''}),
        lb.NwceRow(14, {'company_code': '6675 - Italy', 'customer_code': 76055555.0, 'name': 'DUP 2', 'vat': ''}),
        lb.NwceRow(15, {'company_code': '6675 - Italy', 'customer_code': 0, 'name': 'ONLY VAT', 'vat': 'IT09087170016'}),
    ]
    return lb.Snapshot(rows, {}, dt.datetime.now(), 'test').index('IT')


def test_pick_exact_company():
    r, why = snap().pick('76021671', '', '6675 - Italy')
    assert r.sheet_row == 10 and 'Customer Code' in why


def test_pick_other_company_only():
    r, why = snap().pick('76033479', '', '6675 - Italy')
    assert r is None and '6501' in why


def test_pick_ambiguous():
    r, why = snap().pick('76055555', '', '6675 - Italy')
    assert r is None and '2 randuri' in why


def test_pick_by_vat_fallback():
    r, why = snap().pick('76099091', '09087170016', '6675 - Italy')
    assert r.sheet_row == 15 and 'VAT' in why


def test_candidates_order():
    rows, _ = snap().candidates('76021671', '', '6675 - Italy')
    assert [r.sheet_row for r in rows] == [10, 11]


def test_serial_dates_and_display():
    d = dt.date(2027, 3, 31)
    assert lb.from_serial(lb.to_serial(d)) == d
    assert lb.to_serial(d) == 46477.0
    assert lb.display('valid_till', 46477.0) == '31.03.2027'
    assert lb.display('bp_code', 76014759.0) == '76014759'
    assert lb.display('open_kloc', 800.0) == '800'


def test_same_tolerant():
    assert lb.same('open_kloc', 800, 800.0)
    assert lb.same('comments', ' n/a ', 'n/a')
    assert lb.same('valid_till', 46477.0, 46477)
    assert not lb.same('open_kloc', 800, 850)
    assert lb.same('mtm_kusd', '-', None)          # "-" din formatul contabil = gol


def test_excel_value_dates():
    assert lb._excel_value('valid_till', dt.date(2027, 3, 31)) == 46477.0
    assert lb._excel_value('valid_till', dt.datetime(2027, 3, 31, 10)) == 46477.0
    assert lb._excel_value('open_kloc', 850) == 850


def test_cache_roundtrip(tmp_path, monkeypatch):
    monkeypatch.setattr(lb, '_CACHE', tmp_path / 'c.json')
    s = snap()
    s.dropdowns = {'grading': ['1', '2']}
    s.save_cache()
    s2 = lb.Snapshot.load_cache('IT')
    assert len(s2.rows) == len(s.rows) and s2.from_cache and s2.dropdowns == {'grading': ['1', '2']}
    assert s2.pick('76021671', '', '6675 - Italy')[0].sheet_row == 10
