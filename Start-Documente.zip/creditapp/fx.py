"""Cursuri de schimb BCE (ECB): USD per EUR. Cache local, fallback la valoarea din config."""
import datetime as dt
import json
import threading

from . import log, paths
from .http import default as default_http

_log = log.get('fx')
_lock = threading.Lock()
_URL = 'https://data-api.ecb.europa.eu/service/data/EXR/D.{ccy}.EUR.SP00.A'


def _cache_file(ccy):
    return paths.LOCAL_DIR / f'fx_ecb_{ccy.lower()}.json'


def _load_cache(ccy='USD'):
    try:
        return json.loads(_cache_file(ccy).read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return {}


def _save_cache(c, ccy='USD'):
    try:
        _cache_file(ccy).parent.mkdir(parents=True, exist_ok=True)
        _cache_file(ccy).write_text(json.dumps(c, indent=0, sort_keys=True), encoding='utf-8')
    except OSError:
        pass


def _fetch(start, end, http=None, ccy='USD'):
    """{ 'YYYY-MM-DD': unitati <ccy> per 1 EUR } intre start si end (zile lucratoare BCE)."""
    r = (http or default_http()).request('GET', _URL.format(ccy=ccy), params={'startPeriod': start.isoformat(), 'endPeriod': end.isoformat(), 'format': 'csvdata'}, timeout=30)
    if not r.ok:
        raise ConnectionError(f'ECB HTTP {r.status}')
    lines = r.text.splitlines()
    hdr = lines[0].split(',')
    i_d, i_v = hdr.index('TIME_PERIOD'), hdr.index('OBS_VALUE')
    out = {}
    for line in lines[1:]:
        p = line.split(',')
        if len(p) > max(i_d, i_v) and p[i_v]:
            out[p[i_d]] = float(p[i_v])
    return out


def usd_per_eur(on_date=None, http=None):
    return ecb_rate('USD', on_date, http)


def ecb_rate(ccy, on_date=None, http=None):
    """Unitati <ccy> per 1 EUR (BCE) in ziua data sau ultima zi lucratoare dinainte. None daca BCE nu raspunde."""
    on_date = on_date or dt.date.today()
    key = on_date.isoformat()
    with _lock:
        cache = _load_cache(ccy)
        if key in cache:    # cheia exista si pentru weekend / sarbatori (rezolvata la ultima zi lucratoare)
            return cache[key]
        try:
            obs = _fetch(on_date - dt.timedelta(days=10), on_date, http, ccy)
        except Exception as e:
            _log.warning('ECB rate for %s unavailable: %s', key, e)
            return None
        best = [d for d in obs if d <= key]
        if not best:
            return None
        cache.update(obs)
        if on_date < dt.date.today():   # azi cursul poate aparea mai tarziu (BCE publica ~16:00)
            cache[key] = obs[max(best)]
        _save_cache(cache, ccy)
        return obs[max(best)]


def usd_per_unit(ccy, http=None):
    """USD pentru 1 unitate din moneda locala (EUR, HUF, RON...) azi, din BCE. None daca BCE nu raspunde."""
    ccy = (ccy or 'EUR').upper()
    eur_usd = ecb_rate('USD', dt.date.today(), http)
    if ccy == 'USD':
        return 1.0
    if ccy == 'EUR' or not eur_usd:
        return eur_usd
    per_eur = ecb_rate(ccy, dt.date.today(), http)
    return eur_usd / per_eur if per_eur else None


def eur_usd_today(cfg, http=None):
    """(curs, sursa) pentru conversia limitelor EUR -> USD."""
    rate = usd_per_eur(dt.date.today(), http)
    if rate:
        return rate, 'ECB'
    return float(cfg.get('fx', 'eurUsdFallback')), 'config (ECB indisponibil)'
