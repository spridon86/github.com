"""Evaluarea unui grup de firme (sau a unei firme pe mai multe tari) intr-o singura decizie:
limitele tuturor membrilor se aduna (USD), un singur grade pe tot grupul, nivelul de aprobare din matricea
"Limits by grade" (grade vs limita totala necesara).

Trei aranjari ale aceleiasi ferestre (Setari -> General -> "Fereastra evaluare grup"):
  clasic - totul pe un ecran (grade, tabel complet, decizie, Annual Review);
  pasi   - pe pasi numerotati: 1 grade, 2 limite noi, 3 cine aproba, 4 decizie;
  simplu - o fraza-rezumat sus, tabel scurt, restul sub "Mai multe optiuni"."""
import datetime as dt

from PyQt5.QtCore import QDate, QLocale, Qt
from PyQt5.QtGui import QBrush, QColor
from PyQt5.QtWidgets import (QAbstractItemView, QCheckBox, QComboBox, QDateEdit, QDialog, QDialogButtonBox, QFormLayout,
                             QGroupBox, QHBoxLayout, QLabel, QLineEdit, QMessageBox, QPushButton, QSpinBox,
                             QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget)

from .. import groups, rules
from .models import fmt_money

COLS = ['', 'Client', 'Companie', 'Grade NWCE', 'Open USD', 'MTM USD', 'Total acum USD', 'Open NOU USD', 'MTM NOU USD',
        'Total NOU USD', 'Regiune', 'Comercial', 'Stare']
VARIANTS = {'clasic': 'Clasic - totul pe un ecran', 'pasi': 'Pe pasi (1 grade, 2 limite, 3 cine aproba, 4 decizie)',
            'simplu': 'Simplu - rezumat sus, restul la cerere'}
# coloanele ascunse in fiecare varianta (indexii din COLS)
HIDDEN = {'clasic': (), 'pasi': (3, 4, 5, 10, 11, 12), 'simplu': (3, 4, 5, 9, 10, 11, 12)}


def _qd(d):
    return QDate(d.year, d.month, d.day)


def _pd(q):
    return dt.date(q.year(), q.month(), q.day())


def _step(n, text):
    lbl = QLabel(f'<span style="font-size:12pt;color:#1F5C99"><b>{n}.</b> {text}</span>')
    lbl.setContentsMargins(0, 8, 0, 2)
    return lbl


class GroupDialog(QDialog):
    APPROVE = 1
    REVIEW = 3

    def __init__(self, parent, title, rows, cfg, variant=None):
        super().__init__(parent)
        self.cfg = cfg
        self.title = title
        self.variant = variant or cfg.get('ui', 'groupDialogVariant', default='clasic') or 'clasic'
        if self.variant not in VARIANTS:
            self.variant = 'clasic'
        self.lines = groups.member_lines(rows)
        self.setWindowTitle(f'Evaluare grup - {title}')
        self.resize(1300 if self.variant == 'clasic' else 1050, 860 if self.variant == 'clasic' else 780)
        self._build_widgets()
        getattr(self, f'_layout_{self.variant}')()
        self._recalc()

    # --- componentele (aceleasi in toate variantele)
    def _build_widgets(self):
        cfg, title = self.cfg, self.title
        self._source_lock = False
        self.grade = QSpinBox()
        self.grade.setRange(0, 11)
        self.grade.setSpecialValueText('— alege')          # fara grade in NWCE: nu se presupune unul
        nwce_grade = groups.default_group_grade(self.lines)
        self.grade.setValue(nwce_grade or 0)
        self.grade.valueChanged.connect(self._grade_edited)
        self.source = QLineEdit('grade-ul actual din NWCE' if nwce_grade else '')
        self.source.setPlaceholderText('de unde vine grade-ul (apare in decizie si in Annual Review)')
        self.sc_combo = QComboBox()
        self.sc_combo.addItem('Grade din scorecard...', None)
        for m in self.lines:
            sc = (m.row.ev.scorecard or {}) if m.row.ev else {}
            if sc.get('grade'):
                self.sc_combo.addItem(f'{m.name}: grade {sc.get("grade")}', m)
        self.sc_combo.currentIndexChanged.connect(self._apply_scorecard)

        self.t = QTableWidget(len(self.lines), len(COLS))
        self.t.setHorizontalHeaderLabels(COLS)
        self.t.verticalHeader().setVisible(False)
        self.t.setSelectionMode(QAbstractItemView.NoSelection)
        self.spins = []
        for i, m in enumerate(self.lines):
            chk = QCheckBox()
            chk.setChecked(m.row.nwce is not None)
            chk.setEnabled(m.row.nwce is not None)
            chk.stateChanged.connect(self._recalc)
            self.t.setCellWidget(i, 0, chk)
            vals = [m.name, m.company, str(rules.grade_number(m.grade) or (m.grade or '')), fmt_money(m.open_usd), fmt_money(m.mtm_usd),
                    fmt_money(m.total_usd)]
            for j, v in enumerate(vals, 1):
                it = QTableWidgetItem(v)
                it.setFlags(it.flags() & ~Qt.ItemIsEditable)
                if j >= 4:
                    it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                self.t.setItem(i, j, it)
            so, sm = QSpinBox(), QSpinBox()
            for sp, v in ((so, m.new_open_usd), (sm, m.new_mtm_usd)):
                sp.setLocale(QLocale(QLocale.German))       # 1.300.000 - ca restul tabelului (nu 1,300,000)
                sp.setRange(0, 2_000_000_000)
                sp.setSingleStep(100_000)
                sp.setGroupSeparatorShown(True)
                sp.setValue(int(round(v)))
                sp.valueChanged.connect(self._recalc)
            self.t.setCellWidget(i, 7, so)
            self.t.setCellWidget(i, 8, sm)
            self.spins.append((chk, so, sm))
            for j, v in ((9, ''), (10, m.region), (11, m.trader), (12, m.row.ev.display_state if m.row.ev else '')):
                it = QTableWidgetItem(v)
                it.setFlags(it.flags() & ~Qt.ItemIsEditable)
                if j == 9:
                    it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                self.t.setItem(i, j, it)
            if m.row.nwce is None:
                for j in range(1, len(COLS)):
                    if self.t.item(i, j):
                        self.t.item(i, j).setForeground(QBrush(QColor(150, 150, 150)))
        for c in HIDDEN[self.variant]:
            self.t.setColumnHidden(c, True)
        self.t.resizeColumnsToContents()
        self.t.setColumnWidth(1, 300)
        self.t.setColumnWidth(7, 130)
        self.t.setColumnWidth(8, 120)
        self.t.horizontalHeader().setStretchLastSection(True)
        self.reset_btn = QPushButton('Limite noi = actuale')
        self.reset_btn.clicked.connect(self._reset)
        self.totals = QLabel()
        self.totals.setStyleSheet('font-size:11pt')
        self.auth = QLabel()
        self.auth.setWordWrap(True)
        self.summary = QLabel()                           # varianta "simplu": fraza de sus
        self.summary.setWordWrap(True)
        self.summary.setStyleSheet('background:#EEF4FB;border:1px solid #C9DDF2;border-radius:6px;padding:12px;font-size:12pt')

        today = dt.date.today()
        months = int(cfg.get('limitsBook', 'validityMonths'))
        self.approved = QDateEdit(_qd(today))
        self.approved.setCalendarPopup(True)
        self.approved.setDisplayFormat('dd.MM.yyyy')
        self.valid = QDateEdit(_qd(rules.valid_till(today, months)))
        self.valid.setCalendarPopup(True)
        self.valid.setDisplayFormat('dd.MM.yyyy')
        self.approved.dateChanged.connect(lambda q: self.valid.setDate(_qd(rules.valid_till(_pd(q), months))))
        self.comments = QLineEdit(f'Annual review {title} {today.year}')
        self.write_comments = QCheckBox('scrie si comentariul in NWCE')
        self.parent_combo = QComboBox()
        self.parent_combo.addItem('-- fara financiare --', None)
        for m in self.lines:
            ev = m.row.ev
            if ev and ev.report_json and self.parent_combo.findText(ev.cs.get('name') or m.name) < 0:
                self.parent_combo.addItem(ev.cs.get('name') or m.name, ev)
        if self.parent_combo.count() > 1:
            self.parent_combo.setCurrentIndex(1)
        self.compliance = QLineEdit('OK')

        self.bb = QDialogButtonBox()
        bdoc = self.bb.addButton('Genereaza Annual Review (Word)', QDialogButtonBox.ActionRole)
        bdoc.clicked.connect(self._review)
        self.on_review = None
        self.bok = self.bb.addButton('Aproba decizia', QDialogButtonBox.AcceptRole)
        self.bok.setStyleSheet('background:#2E7D32;color:white;font-weight:bold;padding:8px 18px;')
        self.bb.addButton('Inchide', QDialogButtonBox.RejectRole)
        self.bb.accepted.connect(self._approve)
        self.bb.rejected.connect(self.reject)

    def _grade_row(self, with_label=True):
        h = QHBoxLayout()
        if with_label:
            h.addWidget(QLabel('Grade:'))
        h.addWidget(self.grade)
        h.addWidget(self.sc_combo)
        h.addWidget(QLabel('Sursa:'))
        h.addWidget(self.source, 1)
        return h

    def _decision_form(self):
        f = QFormLayout()
        f.addRow('Approved on:', self.approved)
        f.addRow('Valid till:', self.valid)
        f.addRow('Comentariu:', self.comments)
        f.addRow('', self.write_comments)
        return f

    def _review_form(self):
        f = QFormLayout()
        f.addRow('Financiare din (Creditsafe):', self.parent_combo)
        f.addRow('Compliance:', self.compliance)
        return f

    # --- variantele
    def _layout_clasic(self):
        lay = QVBoxLayout(self)
        head = QLabel(f'<h2 style="margin:0">{self.title}</h2>Toate firmele grupului, pe toate companiile Bunge. '
                      'Limitele se aduna; un singur grade pentru tot grupul.')
        head.setWordWrap(True)
        lay.addWidget(head)
        g = QGroupBox('Grade-ul grupului')
        g.setLayout(self._grade_row())
        lay.addWidget(g)
        lay.addWidget(self.t, 1)
        bl = QHBoxLayout()
        bl.addWidget(self.reset_btn)
        bl.addStretch(1)
        bl.addWidget(self.totals)
        lay.addLayout(bl)
        lay.addWidget(self.auth)
        low = QHBoxLayout()
        d = QGroupBox('Decizie (pentru toate randurile bifate)')
        d.setLayout(self._decision_form())
        low.addWidget(d, 1)
        r = QGroupBox('Annual Review')
        r.setLayout(self._review_form())
        low.addWidget(r, 1)
        lay.addLayout(low)
        lay.addWidget(self.bb)

    def _layout_pasi(self):
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel(f'<h2 style="margin:0">{self.title}</h2>'))
        lay.addWidget(_step(1, 'Alege grade-ul grupului'))
        lay.addLayout(self._grade_row(with_label=False))
        lay.addWidget(_step(2, 'Verifica limitele noi (USD)'))
        lay.addWidget(self.t, 1)
        bl = QHBoxLayout()
        bl.addWidget(self.reset_btn)
        bl.addStretch(1)
        bl.addWidget(self.totals)
        lay.addLayout(bl)
        lay.addWidget(_step(3, 'Cine aproba'))
        lay.addWidget(self.auth)
        lay.addWidget(_step(4, 'Decizie'))
        row = QHBoxLayout()
        row.addLayout(self._decision_form(), 1)
        row.addLayout(self._review_form(), 1)
        lay.addLayout(row)
        lay.addWidget(self.bb)

    def _layout_simplu(self):
        lay = QVBoxLayout(self)
        lay.addWidget(self.summary)
        lay.addLayout(self._grade_row())
        lay.addWidget(self.t, 1)
        bl = QHBoxLayout()
        bl.addWidget(self.reset_btn)
        bl.addStretch(1)
        more = QPushButton('Mai multe optiuni ▾')
        more.setCheckable(True)
        bl.addWidget(more)
        lay.addLayout(bl)
        extra = QWidget()
        el = QHBoxLayout(extra)
        el.setContentsMargins(0, 0, 0, 0)
        el.addLayout(self._decision_form(), 1)
        el.addLayout(self._review_form(), 1)
        extra.setVisible(False)
        more.toggled.connect(lambda on: (extra.setVisible(on), more.setText('Mai multe optiuni ▴' if on else 'Mai multe optiuni ▾')))
        lay.addWidget(extra)
        lay.addWidget(self.bb)

    # --- calcule
    def collect(self):
        for m, (chk, so, sm) in zip(self.lines, self.spins):
            m.include = chk.isChecked()
            m.new_open_usd = float(so.value())
            m.new_mtm_usd = float(sm.value())
        return self.lines

    def total_new(self):
        return sum(m.new_total_usd for m in self.collect() if m.include)

    def authority(self):
        return rules.approval_authority(self.grade.value(), self.total_new(), self.cfg)

    def _recalc(self, *_):
        lines = self.collect()
        for i, m in enumerate(lines):
            self.t.item(i, 9).setText(fmt_money(m.new_total_usd) if m.include else '')
        cur = sum(m.total_usd for m in lines if m.include)
        new = sum(m.new_total_usd for m in lines if m.include)
        diff = f'{"+" if new >= cur else ""}{fmt_money(new - cur)}'
        self.totals.setText(f'Total: <b>{fmt_money(cur)}</b> → <b>{fmt_money(new)}</b> USD ({diff})')
        a = self.authority()
        firms = len({getattr(m.row, 'client', '') or m.name for m in lines if m.include})
        if a is None:
            self.auth.setText('<span style="font-size:12pt;color:#9C5700"><b>Alege grade-ul</b> (din scorecard sau manual).</span>')
            self.summary.setText(f'<b>{self.title}</b> · {firms} firme · total nou <b>{fmt_money(new)}</b> USD<br>'
                                 '<span style="color:#9C5700">Alege grade-ul ca sa vezi cine aproba.</span>')
            return
        mine = a.name == self.cfg.get('approval', 'analystRow')
        color = '#C62828' if (a.no_trade or a.exceeds_all) else ('#2E7D32' if mine else '#9C5700')
        self.auth.setText(f'<span style="font-size:12pt;color:{color}"><b>{a.text()}</b></span>')
        who = 'tu' if mine else a.name
        verdict = (a.text() if (a.no_trade or a.exceeds_all) else f'Aproba: <b>{who}</b>')
        self.summary.setText(f'<b>{self.title}</b> · {firms} firme · grade <b>{a.grade}</b> · total nou <b>{fmt_money(new)}</b> USD '
                             f'({diff})<br><span style="color:{color}">{verdict}</span>')

    def _reset(self):
        for m, (chk, so, sm) in zip(self.lines, self.spins):
            so.setValue(int(round(m.open_usd)))
            sm.setValue(int(round(m.mtm_usd)))

    def _grade_edited(self, _v):
        if not self._source_lock:
            self.source.setText('stabilit manual' if self.grade.value() else '')
        self._recalc()

    def _apply_scorecard(self):
        m = self.sc_combo.currentData()
        if m is None:
            return
        g = rules.grade_number(m.row.ev.scorecard.get('grade'))
        if g:
            self._source_lock = True
            try:
                self.grade.setValue(g)
            finally:
                self._source_lock = False
            self.source.setText(f'scorecard {m.name}')
            self._recalc()

    def _review(self):
        if self.authority() is None:
            QMessageBox.information(self, 'Grup', 'Alege intai grade-ul.')
            return
        if self.on_review:
            self.on_review(self.decision_data())

    def _approve(self):
        a = self.authority()
        if a is None:
            QMessageBox.information(self, 'Grup', 'Alege intai grade-ul.')
            return
        if not self.source.text().strip():
            QMessageBox.information(self, 'Grup', 'Scrie de unde vine grade-ul.')
            return
        if not any(m.include for m in self.collect()):
            QMessageBox.information(self, 'Grup', 'Niciun rand bifat.')
            return
        if a.no_trade:
            QMessageBox.warning(self, 'Grup', a.text())
            return
        msg = a.text()
        zero = [m for m in self.collect() if m.include and m.new_open_usd == 0 and m.new_mtm_usd == 0 and m.other_usd == 0]
        if zero:
            msg += (f'\n\n{len(zero)} randuri cu limita noua 0 vor fi INACTIVATE: '
                    + ', '.join(f'{m.name} ({m.company})' for m in zero[:8]) + ('...' if len(zero) > 8 else ''))
        if a.exceeds_all:
            msg += '\n\nTotalul depaseste matricea. Aprobi totusi?'
        elif a.name != self.cfg.get('approval', 'analystRow'):
            msg += f'\n\nAi aprobarea de la {a.name}? Da = inregistrez decizia.'
        else:
            msg += '\n\nInregistrez decizia?'
        if QMessageBox.question(self, 'Decizie de grup', msg) != QMessageBox.Yes:
            return
        self.accept()

    def decision_data(self):
        a = self.authority()
        return {
            'title': self.title, 'grade': self.grade.value(), 'grade_source': self.source.text().strip(),
            'lines': [m for m in self.collect() if m.include], 'authority': a,
            'approved_on': _pd(self.approved.date()), 'valid_till': _pd(self.valid.date()),
            'comments': self.comments.text().strip(), 'write_comments': self.write_comments.isChecked(),
            'parent_ev': self.parent_combo.currentData(), 'compliance': self.compliance.text().strip(),
        }
