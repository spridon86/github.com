"""Credit Limits Tool - evaluare clienti: scorecard, raport Creditsafe, actualizare limite (NWCE + SAP)."""
__version__ = '2.0.0'
