"""Raport Creditsafe sintetic (structura Connect API, Global Financials GGS) pentru teste - fara credite consumate."""


def statement(year, scale=1.0):
    pl = {
        'revenue': 52_000_000 * scale, 'operatingCosts': 49_800_000 * scale, 'operatingProfit': 2_200_000 * scale,
        'wagesAndSalaries': 1_900_000 * scale, 'depreciation': 600_000 * scale, 'financialIncome': 20_000 * scale,
        'financialExpenses': 310_000 * scale, 'profitBeforeTax': 1_910_000 * scale, 'tax': 520_000 * scale,
        'profitAfterTax': 1_390_000 * scale, 'retainedProfit': 1_390_000 * scale,
    }
    bs = {
        'landAndBuildings': 4_100_000, 'plantAndMachinery': 2_300_000, 'otherTangibleAssets': 400_000,
        'totalTangibleAssets': 6_800_000, 'otherIntangibleAssets': 120_000, 'totalIntangibleAssets': 120_000,
        'investments': 50_000, 'totalOtherFixedAssets': 50_000, 'totalFixedAssets': 6_970_000,
        'rawMaterials': 3_200_000 * scale, 'finishedGoods': 2_100_000 * scale, 'totalInventories': 5_300_000 * scale,
        'tradeReceivables': 9_800_000 * scale, 'miscellaneousReceivables': 700_000, 'totalReceivables': 9_800_000 * scale + 700_000,
        'cash': 1_400_000, 'totalCurrentAssets': 17_900_000 * scale, 'totalAssets': 17_900_000 * scale + 6_970_000,
        'tradePayables': 7_100_000 * scale, 'bankLiabilities': 3_300_000 * scale, 'miscellaneousLiabilities': 900_000,
        'totalCurrentLiabilities': 11_300_000 * scale, 'bankLiabilitiesDueAfter1Year': 2_000_000,
        'totalLongTermLiabilities': 2_000_000, 'totalLiabilities': 13_300_000 * scale,
        'calledUpShareCapital': 1_000_000, 'revenueReserves': 9_000_000, 'otherReserves': 1_570_000,
        'totalShareholdersEquity': 17_900_000 * scale + 6_970_000 - 13_300_000 * scale,
    }
    end = f'{year}-12-31' if isinstance(year, int) else year     # an sau data exacta 'YYYY-MM-DD'
    return {'type': 'GlobalFinancialsGGS', 'yearEndDate': f'{end}T00:00:00Z', 'numberOfWeeks': 52,
            'currency': 'EUR', 'consolidatedAccounts': False, 'profitAndLoss': pl, 'balanceSheet': bs}


def report(company_id='IT-0-NA470398', name='MIRA SUD S.R.L.', years=(2025, 2024, 2023), common='B', score='62', status='Active'):
    return {
        'companyId': company_id,
        'language': 'en',
        'companySummary': {'businessName': name, 'country': 'IT', 'companyNumber': 'NA470398',
                           'companyStatus': {'status': status, 'description': status},
                           'creditRating': {'commonValue': common}},
        'companyIdentification': {'basicInformation': {'businessName': name, 'registeredCompanyName': name,
                                                        'companyRegistrationNumber': 'NA470398',
                                                        'vatRegistrationNumber': '01491571210',
                                                        'companyRegistrationDate': '1998-03-15T00:00:00Z', 'country': 'IT'}},
        'creditScore': {'currentCreditRating': {'commonValue': common, 'commonDescription': 'Low Risk',
                                                'creditLimit': {'currency': 'EUR', 'value': '650000'},
                                                'providerValue': {'maxValue': '100', 'minValue': '1', 'value': score}}},
        'financialStatements': [statement(y, 1.0 - 0.05 * i) for i, y in enumerate(years)],
    }
