"""Grupuri de firme, matricea de aprobare "Limits by grade" si Annual Review."""
import datetime as dt

import pytest

import make_report
from creditapp import groups, limits_book as lb, rules
from creditapp.portfolio import Portfolio


@pytest.mark.parametrize('raw,key', [
    ('ENI', 'ENI'), ('Nestle', 'NESTLE'), ('NESTLE', 'NESTLE'), ('(GROHAGE)', 'GROHAGE'), ('REWE - bill to', 'REWE'),
    ('Fenaco (BP group 89542)', 'FENACO'), ('Avril Group', 'AVRIL'), ('n/a', ''), ('0', ''), ('CBT', ''), ('Warehouse', ''), (None, ''),
    (0.0, ''), (0, ''), ('0.0', ''), ('  ', ''),
])
def test_norm_group(raw, key, cfg):
    assert groups.norm_group(raw, cfg) == key


@pytest.mark.parametrize('grade,total,who', [
    (5, 16_640_000, 'BEMEA - Aylin'),        # exemplul ENI: grade 5, 16.64M USD -> BEMEA
    (5, 5_500_000, 'Ionut Spridon'),
    (5, 5_500_001, 'Valentina / Bea'),
    (6, 4_600_000, 'Valentina / Bea'),
    (10, 1_000_000, 'Ionut Spridon'),
    ('Intuitive 9', 1_600_000, 'Valentina / Bea'),
    (3, 80_000_000, 'GLOBAL - Alex'),
])
def test_approval_authority(grade, total, who, cfg):
    a = rules.approval_authority(grade, total, cfg)
    assert a.name == who and not a.exceeds_all


def test_approval_limits_no_trade_and_exceed(cfg):
    assert rules.approval_authority(11, 1, cfg).no_trade
    a = rules.approval_authority(9, 25_000_000, cfg)
    assert a.exceeds_all and 'GLOBAL' in a.text()
    assert rules.approval_authority(None, 1, cfg) is None
    assert rules.approval_authority(5, 16_640_000, cfg).nwce_level == 'BEMEA'


def test_no_external_agency_ratings(cfg):
    """Ratingurile externe ale agentiilor nu se folosesc (cerinta analistului, 20.10.2026)."""
    assert not hasattr(rules, 'external_to_grade')
    assert cfg.get('approval', 'externalRatingToGrade') is None and cfg.get('approval', 'subsidiaryNotches') is None


def _eni_snapshot():
    def row(n, name, vat, opn, mtm, trader, comp='6675 - Italy', grp='ENI'):
        return lb.NwceRow(n, {'company_code': comp, 'customer_code': 76000000.0 + n, 'name': name, 'vat': vat, 'group': grp,
                              'grading': 5.0, 'open_kusd': opn, 'mtm_kusd': mtm, 'total_kusd': (opn or 0) + (mtm or 0),
                              'trader': trader, 'tbd_by': 'TBD by IS', 'approval_level': 'BEMEA'})
    rows = [row(1, 'ENI NATURAL ENERGIES S.P.A.', 'IT00000000001', 2400.0, 600.0, 'Tommaso Luppi'),
            row(2, 'ENI TRADE & BIOFUELS SPA', 'IT00000000002', 1700.0, 800.0, 'Edwin de Klerck', comp='7020 - Netherlands'),
            row(3, 'ENILIVE S.P.A.', 'IT00000000003', 8500.0, 2400.0, 'Tommaso Luppi'),
            row(4, 'NOVAMONT SPA', 'IT00000000004', 3200.0, 1400.0, 'Enzo Truppa', grp='Eni'),
            row(5, 'ALTRO SRL', 'IT00000000009', 100.0, 0.0, '', grp='n/a')]
    return lb.Snapshot(rows, {}, dt.datetime.now(), 't').index('IT')


@pytest.fixture
def eni(cfg):
    from creditapp.ui.models import ClientsModel
    m = ClientsModel()
    m.load(Portfolio('x', dt.datetime.now(), {}, [], [], [], []), {}, _eni_snapshot(), '6675 - Italy', 'IT', cfg)
    return m


def test_group_rows_together(eni):
    eni_rows = [r for r in eni.rows if r.group == 'GRP:ENI']
    assert len(eni_rows) == 4 and eni_rows[0].group_name == 'ENI'
    assert eni_rows[0].group_kusd == 21000.0                      # 15.8M open + 5.2M MTM = 21M USD (actual)
    assert all(r.group_rows is eni_rows[0].group_rows for r in eni_rows)


def test_member_lines_and_review_table(eni, cfg):
    rows = [r for r in eni.rows if r.group == 'GRP:ENI']
    lines = groups.member_lines(rows)
    assert sum(m.total_usd for m in lines) == 21_000_000
    assert groups.default_group_grade(lines) == 5
    new = {'ENI NATURAL ENERGIES S.P.A.': (1_600_000, 400_000), 'ENI TRADE & BIOFUELS SPA': (1_700_000, 2_800_000),
           'ENILIVE S.P.A.': (5_000_000, 1_800_000), 'NOVAMONT SPA': (2_000_000, 1_340_000)}
    for m in lines:
        m.new_open_usd, m.new_mtm_usd = new[m.name]
    total = sum(m.new_total_usd for m in lines)
    assert total == 16_640_000
    assert rules.approval_authority(5, total, cfg).name == 'BEMEA - Aylin'
    cps = groups.review_counterparties(lines, 5)
    assert len(cps) == 4 and {c.regions[0] for c in cps} == {'ITA', 'NL'}


def test_review_document(tmp_path, eni, cfg, monkeypatch):
    from creditapp import fx, review_doc
    monkeypatch.setattr(fx, 'ecb_rate', lambda ccy, d=None, http=None: 1.10)
    rows = [r for r in eni.rows if r.group == 'GRP:ENI']
    lines = groups.member_lines(rows)
    out = review_doc.build(tmp_path / 'Annual Review ENI.docx', {
        'group': 'ENI GROUP', 'total_new_usd': 16_640_000, 'grade': 5, 'grade_source': 'stabilit manual',
        'compliance': 'OK', 'fiscal_year': 'December 2025', 'counterparties': groups.review_counterparties(lines, 5),
        'authority': rules.approval_authority(5, 16_640_000, cfg).text_en(), 'relationship': ['Commercial relationship since 2015.'],
        'report': make_report.report(), 'analyst': 'Ionut Spridon', 'insurance_usd': 6_500_000, 'feedback': ['Grade 5;']})
    import docx
    d = docx.Document(str(out))
    text = '\n'.join(p.text for p in d.paragraphs)
    assert 'Annual Review – ENI GROUP' in text and 'USD 16.6 million' in text
    assert 'Approval required' not in text        # modelul aprobat (19.10.2026) nu are randul de aprobare
    assert 'External Credit Ratings' not in text  # fara ratinguri externe (Moody's / S&P scoase)
    assert len(d.tables) == 2                     # limite, financiare
    assert d.tables[0].rows[-1].cells[0].text == 'Grand Total'
